/*
 * @(#) Kwirk.java  @(#)
 * 
 * Main Kwirk Java file
 * 
 */
 
 	
import tiled.*;
import com.nttdocomo.ui.*;

public class Kwirk extends TiledApp 
{

	// Constructeurs interdits
	protected void initApp()
	{
		level = new KwirkLevel();
		canvas = new TiledCanvas(this);
	}
	
	protected void initVariables()
	{
		varAppPanel = "k_panel.gif";
        varAppBack = "k_tile.gif";
		varTiles[0]= "k_blanc.gif";
		varTiles[1]= "k_mur.gif";
		varTiles[2]= "k_sortie.gif";
		varTiles[3]= "k_trou.gif";
		varTiles[4]= "k_joueur1.gif";
		varTiles[5]= "k_joueur2.gif";
		varTiles[6]= "k_joueur3.gif";
		varTiles[7]= "k_joueur4.gif";
		varTiles[8]= "k_bloc_sol.gif";
		varTiles[9]= "k_bloc_trou.gif";
		varTiles[10]= "k_tourn_centre.gif";
		varTiles[11]= "k_tourn_ext_sol.gif";
		varTiles[12]= "k_tourn_ext_trou.gif";
	}
	
	public void keyPressed(int key)
	{
		int ret = 0;
		
		if (status != ST_PLAYING) { super.keyPressed(key); return; } 
		
		switch(key)
		{
			case Display.KEY_0:
			case Display.KEY_SOFT1:
				reloadLevel();
				canvas.repaint();
				ret = KwirkEngine.OK_NOTHING;
				break;
			case Display.KEY_4:
			case Display.KEY_LEFT: 
				ret = KwirkEngine.move((KwirkLevel)level, KwirkEngine.MOVE_LEFT);
				break;
			case Display.KEY_8:
			case Display.KEY_UP: 
				ret = KwirkEngine.move((KwirkLevel)level, KwirkEngine.MOVE_UP);
				break;
			case Display.KEY_6:
			case Display.KEY_RIGHT: 
				ret = KwirkEngine.move((KwirkLevel)level, KwirkEngine.MOVE_RIGHT);
				break;
			case Display.KEY_2:
			case Display.KEY_DOWN: 
				ret = KwirkEngine.move((KwirkLevel)level, KwirkEngine.MOVE_BOTTOM);
				break;
			case Display.KEY_3:
			case Display.KEY_POUND:
				goNextLevel();
				canvas.repaint();
				ret = KwirkEngine.OK_NOTHING;
				break;
			case Display.KEY_1:
			case Display.KEY_ASTERISK:
				goPrevLevel();
				canvas.repaint();
				ret = KwirkEngine.OK_NOTHING;
				break;
			case Display.KEY_5:
			case Display.KEY_SELECT:
				do {
					level.setCurPlayer(level.getCurPlayer() + 1);
					if (level.getCurPlayer() >= level.getNbPlayers()) level.setCurPlayer(0);
				} while (!((KwirkLevel)level).isPlayerOK(level.getCurPlayer()));
				ret = KwirkEngine.OK_NOTHING;
				break;
			default:
	 			super.keyPressed(key);
				ret = KwirkEngine.OK_NOTHING;
				break;
		}
		
        /*
		System.out.print("Position " + level.getCurPlayer() + " : " 
							+ level.getPosPlayerX(level.getCurPlayer()) + "x" +
							+ level.getPosPlayerY(level.getCurPlayer()) + "\n");
        */
		
		if (lastException != null)
		{
			status = ST_ERROR;
		}
		
		switch(ret)
		{
			case KwirkEngine.OK_NOTHING:
				break;
			case KwirkEngine.OK_NEED_REFRESH:
				canvas.update();
				break;
			case KwirkEngine.OK_WON_LEVEL:
				System.out.print("Won Level\n");
				goNextLevel();
				canvas.repaint();
				break;
			case KwirkEngine.KO_MOVE_IMPOSSIBLE:
				System.out.print("Move is impossible\n");
				break;
			default:
				System.out.print("Unexpected Problem\n");
				break;
		}
	}
}