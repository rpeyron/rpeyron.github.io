package tiled;

import java.io.*;
import java.util.*;
import com.nttdocomo.ui.*;
import com.nttdocomo.io.*;
import javax.microedition.io.*;

/**
* <p>The size limit of the scratchpad is larger than the limit of the JAR
* file in DoJa.  By utilizing this spec, application programmers can use
* resource files the total size of which is larger than the limit of the JAR
* file.  Specifically, resource files and application data can be stored in the
* scratchpad instead of the JAR file.</p>
*
* <p>Application can use resource files in the scratchpad by the following steps.
* <ol>
*   <li>Add "SPsize" attribute to the ADF file with a value calculated as below:<br>
*       <code><pre>
*       SPsize = value of FILE_TABLE_SIZE
*                + [total size of the resource files to be stored in the scratchpad]
*                + [maximum data size that application stores on runtime]
*       </pre></code>
*   <li>Add "UseNetwork" attribute to the ADF with the value "http".
*   <li>Upload the application(ADF and JAR files) to a HTTP server.
*   <li>Upload the resource files to be saved in the scratchpad to the same
*       http server.  The directory may be different from the one that holds
*       the application as long as the resource files are accessible from the
*       application.
*   <li>When launched for the first time, the application downloads the resource
*       files uploaded in the step 4 and stores them in the scratchpad.
*   <li>The application reads the resource files from the scratchpad instead of
*       the HTTP server when launched for the second time and thereafter.
* </ol>
*
* <p>This class eases application programmers to store and read resource files
* in the scratchpad.</p>
*
* <p>
* Code sample:
* <code><pre>
*   public class MyApplication extends IApplication {
*       Image image1, image2;
*       byte[] data1, data2;
*
*       public void start() {
*           try {
*               // initializes ScratchUtil object.
*               // must be called before any other methods of ScratchUtil.
*               ScratchUtil.getInstance().init();
*
*               // sets the base server url from which the resource files are
*               // to be downloaded.
*               ScratchUtil.getInstance().setServer(
*                   IApplication.getCurrentApp().getSourceURL());
*
*               // downloads and stores the resource files in the scratchpad.
*               // storeFromServer() can be called every time the application is
*               // launched because resources will not be downloaded again if
*               // the resources have been already downloaded in the scratchpad.
*               ScratchUtil.getInstance().storeFromServer("image_in_server.gif");
*               ScratchUtil.getInstance().storeFromServer("data_in_server.dat");
*           } catch (IOException e) {
*               System.out.println(e.getClass().getName() + " is thrown in start()");
*               System.out.println(e.getMessage());
*           }
*       }
*
*       private void setUpData() {
*           try {
*               // getImage(String), getData(String) method can be used for the
*               // resource files either in the JAR file, scratchpad, or server.
*               // The resource files will not be stored in the scratchpad in
*               // case they are only in the server.  Use storeFromServer(String)
*               // to permanently store in the scratchpad.
*               image1 = ScratchUtil.getInstance().getImage("image_in_server.gif");
*               image2 = ScratchUtil.getInstance().getImage("image_in_jar.gif");
*               data1 = ScratchUtil.getInstance().getData("data_in_server.dat");
*               data2 = ScratchUtil.getInstance().getData("data_in_jar.dat");
*           } catch (IOException e) {
*               System.out.println(e.getClass().getName() + " is thrown in setUpData()");
*               System.out.println(e.getMessage());
*           }
*       }
*
*       private void saveScore(int score) {
*           DataOutputStream out = null;
*           try {
*               // must finish calling storeFromServer(String) for all the
*               // resource files to be stored in the scratchpad before calling
*               // getFreeOffset(), otherwise the application data will be
*               // overwritten by the resource files.
*               out = Connector.openDataOutputStream(
*                     "scratchpad:///0;pos="
*                     + ScratchUtil.getInstance().getFreeOffset());
*
*               // saves the score
*               out.writeInt(score);
*           } catch (IOException e) {
*               System.out.println(e.getClass().getName() + " is thrown in saveScore()");
*               System.out.println(e.getMessage());
*           } finally {
*               if (out != null) {
*                   try {
*                       out.close();
*                   } catch (Exception e) {
*                   }
*               }
*           }
*       }
*
*       private int readScore() {
*           DataInputStream in = null;
*           int score = 0;
*           try {
*               in = Connector.openDataInputStream(
*                     "scratchpad:///0;pos="
*                    + ScratchUtil.getInstance().getFreeOffset());
*
*               // loads the score
*               score = in.readInt();
*           } catch (IOException e) {
*               System.out.println(e.getClass().getName() + " is thrown in readScore()");
*               System.out.println(e.getMessage());
*           } finally {
*               if (in != null) {
*                   try {
*                       in.close();
*                   } catch (Exception e) {
*                   }
*               }
*           }
*           return score;
*       }
*   }
* </pre></code>
* </p>
*
*<p>
* <h3>Limitations:</h3>
*<ol>
*  <li>The size of each file stored in the scratchpad is limited to the maximum
*      downloadable size defined in the DoJa specification.  For example, the
*      size is limited to 10Kbytes in DoJa1.5.
*  <li>The number of files is limited to the value of MAX_FILES.
*  <li>The length of the file name is limited to the value of MAX_FILENAME_LEN.
*  <li>File overwrite is not supported.
*  <li>If there are files with the same filename both in the JAR file and the
*      scratchpad, the file in the JAR file is always loaded.
*</ol>
*</p>
* <h2>Technical Information</h2>
* <p>ScratchUtil uses a file table to store file information in the scratchpad.
* The file table consists of a mark, number of entries, and the entries.
* <ul>
* <li>Mark - scratchUtil uses this value to see if the file table has been stored
*     in the scratchpad.
* <li>Entry - an entry consists of a file name, an offset value from the
*     beginning of the scratchpad of the file, and the byte length of the file.
* </ul></p>
* <p>The table is stored in the beginning of the scratchpad.  Each file is
* stored after the end of the file table at the offset of FILE_TABLE_SIZE.
* </p>
*/
public class ScratchUtil {
  // the only instance
  private static ScratchUtil scratchpadUtil = null;

  // Hashtable for storing offset values.
  // key: filename as String
  // value: offset value as Integer
  private Hashtable offsetTable;

  // Hashtable for storing length values.
  // key: filename as String
  // value: length value as Integer
  private Hashtable lenTable;

  // next free area in the scratchpad
  private int nextFreeOffset;

  // The URL, serverURL + filename, is used to download the data that is
  // not found locally.
  private String serverURL = "";

  // file table constants
  /**
   * A value saved in the beginning of the scratchpad.
   * ScratchUtil uses this value to see if the file table has been saved
   * in the scratchpad.
   */
  public final static int MARK = "MARK".hashCode();

  /**
   * The maximum length of the file name.
   */
  // modify this number to change the maximum
  public final static int MAX_FILENAME_LEN = 255;

  /**
   * The maximum number of files.
   */
  // modify this number to change the maximum
  public final static int MAX_FILES = 100;

  /**
   * The size of file table.
   *<code><pre>
   * file table size = byte length of MARK + byte length of the number of entries
   *                   + MAX_FILES * (MAX_FILENAME_LEN
   *                                   + byte length of the offset value
   *                                   + byte length of the file length value)
   *</pre></code>
   */
  public static int FILE_TABLE_SIZE = 4 + 4 +
                                        MAX_FILES * (MAX_FILENAME_LEN
                                                     + 4
                                                     + 4);

  /*
   * Exception definitions
   */
  // The file name is invalid because it is null, zero in length, or too long.
  private final static IOException INVALID_FILE_NAME_EXCEPTION
      = new IOException("File name is invalid.");

  // The data is not found either in the JAR file, scratchpad, or server.
  private final static IOException SAME_FILE_EXISTS_EXCEPTION
      = new IOException(
      "The same file already exists.");

  // The data is not found either in the JAR file, scratchpad, or server.
  private final static IOException FILE_NOT_FOUND_EXCEPTION
      = new IOException(
      "Could not find file either in jar, scratchpad, or server.");

  // The number of the files is over MAX_FILES.
  private final static IOException TOO_MANY_FILES_EXCEPTION
      = new IOException("Maximum file number reached in the file system.");

  /**
   * Only method to acquire the ScratchUtil instance.
   *
   * @return the only instance
   */
  public static final ScratchUtil getInstance() {
    if (scratchpadUtil == null) {
      scratchpadUtil = new ScratchUtil();
    }
    return scratchpadUtil;
  }

  /**
   * Initializes on-memory file table.
   * Needs to be called every time an application is launched
   * before ScratchUtil is used.
   *
   * @throws IOException thrown when there is an error accessing the scratchpad.
   */
  public void init() throws IOException {
    DataInputStream in = null;

    offsetTable = new Hashtable();
    lenTable = new Hashtable();
    nextFreeOffset = FILE_TABLE_SIZE;

    try {
      // reads marker from scratchpad
      in = Connector.openDataInputStream("scratchpad:///0;pos=0");
      int mark = in.readInt();

      if (mark != MARK) {
        // The file table has not been stored in the scratchpad.
        return;
      }

      // reads number of entries
      int nofEntries = in.readInt();

      // initializes on-memory file table
      for (int i = 0; i < nofEntries; i++) {
        String fileName = in.readUTF();
        int fileOffset = in.readInt();
        int fileLen = in.readInt();

        offsetTable.put(fileName, new Integer(fileOffset));
        lenTable.put(fileName, new Integer(fileLen));

        // Files are not sorted in the file table.
        if ( fileOffset + fileLen > nextFreeOffset ) {
          nextFreeOffset = fileOffset + fileLen;
        }
      }
    }
    finally {
      if (in != null) {
        in.close();
      }
    }
  }

  /**
   * Acquires the image specified by filename.
   * This method looks for the data in the following order.</br>
   * <ol>
   * <li>JAR file
   * <li>scratchpad
   * <li>HTTP server
   * </ol>
   * Note that if files with the same filename exist both in the JAR file and
   * the scratchpad, the file in the JAR file is always used.  Also note that
   * the data will not be written to the scratchpad in case the data
   * is acquired from the server.  Use storeFromServer(String) to store the
   * data to the scratchpad.
   *
   * @param filename file name of the image
   * @throws IOException thrown when the file cannot be found.
   * @return image acquired, always not null.
   * @see #setServer(String)
   * @see #storeFromServer(String)
   */
  public Image getImage(String filename) throws IOException {
    MediaImage mImg = null;

    System.out.println("reading image " + filename);
    try {
      mImg = MediaManager.getImage("resource:///" + filename);
      mImg.use();
      System.out.println("getImage(resource) success.");
    }
    catch (Exception e) {
      try {
        mImg = getImageFromScratchpad(filename);
        mImg.use();
        System.out.println("getImageFromScratchpad() success.");
      }
      catch (Exception ee) {
        try {
          mImg = MediaManager.getImage(serverURL + filename);
          mImg.use();
          System.out.println("getImage(http) success.");
        }
        catch (Exception eee) { System.out.println("getImage(" + serverURL + filename + ") failed."); }
      }
    }

    if (mImg == null) {
      throw FILE_NOT_FOUND_EXCEPTION;
    }
    System.out.println("ok");
    return mImg.getImage();
  }

  /**
   * Acquires byte array of the data specified by filename.
   * This method looks for the data in the following order.</br>
   * <ol>
   * <li>JAR file
   * <li>scratchpad
   * <li>HTTP server
   * </ol>
   * Note that if files with the same filename exist both in the JAR file and
   * the scratchpad, the file in the JAR file is always used.  Also note that
   * the data will not be written to the scratchpad in case the data
   * is acquired from the server.  Use storeFromServer(String) to store the
   * data to the scratchpad.
   *
   * @param filename file name of the data
   * @throws IOException thrown when the file cannot be found.
   * @return data acquired, always not null.
   * @see #setServer(String)
   * @see #storeFromServer(String)
   */
  public byte[] getData(String filename) throws IOException {
    byte[] data = null;

    System.out.println("reading data " + filename);
    try {
      data = getDataFromResource(filename);
      System.out.println("getDataFromResource() success.");
    }
    catch (Exception e) {
      try {
        data = getDataFromScratchpad(filename);
        System.out.println("getDataFromScratchpad() success.");
      }
      catch (Exception ee) {
        try {
          data = getDataFromHttpToMem(serverURL + filename);
          System.out.println("getDataFromHttpToMem() success.");
        }
        catch (Exception eee) {
        }
      }
    }

    if (data == null) {
      throw FILE_NOT_FOUND_EXCEPTION;
    }
    System.out.println("ok");
    return data;
  }

  /**
   * Sets the base URL.
   * ScratchUtil uses this base URL to download data in case the data specified
   * by filename is not found either in the JAR file or in the scratchpad.  Note
   * that the URL is made simply by adding this base URL to the filename.
   *
   * @param url base URL
   */
  public void setServer(String url) {
    System.out.println("Set base url: " + url);
    serverURL = url;
  }

  /**
   * Downloads the file from the server and stores it in the scratchpad.
   * This method downloads data from the URL specified by #setServer(String)
   * and filename, and saves it to the scratchpad.  In case the same file
   * already exists in the scratchpad, the existing file is kept.  If the same
   * file exists in the JAR file, the file will still be stored, but the file
   * will be inaccessible.  See the documentation for getImage(String) and
   * getData(String) for detail.
   *
   * @see #getImage(String)
   * @see #getData(String)
   * @param filename file name of the data
   * @throws IOException thrown when the file cannot be stored locally.
   */
  public void storeFromServer(String filename) throws IOException {
    // checks if the same file already exists in the scratchpad
    if (offsetTable.containsKey(filename)) {
      // does not do anything
      return;
    }

    byte[] data;
    System.out.println("storing " + filename);
    data = getDataFromHttpToMem(serverURL + filename);
    save(filename, data, 0, data.length);
    writeScratchpadTable();
  }

  /**
   * Gets the offset from the beginning of the scratchpad for application use.
   * The file table and all the resource files are stored in the beginning of the
   * scratchpad, and the data continues until the offset returned by this
   * method.  Application may use the scratchpad after it stores all the resource
   * files locally by calling storeFromServer(String) method.
   *
   * @return offset of the scratchpad for application use
   * @see #storeFromServer(String)
   */
  public int getFreeOffset() {
    return nextFreeOffset;
  }

  /**
   * Clears file table both on the memory and in the scratchpad.
   * Note that actual file data in the scratchpad will not be cleared.
   * The scratchpad needs to be overwritten explicitly by the application.
   *
   * @throws IOException thrown when the file table cannot be cleared.
   */
  public void clear() throws IOException {
    offsetTable.clear();
    lenTable.clear();
    nextFreeOffset = FILE_TABLE_SIZE;
    writeScratchpadTable();
  }

  /***********************************************************/
  // PRIVATE METHODS
  /***********************************************************/

  /**
   * Constructor
   */
  private ScratchUtil() {
  }

  /**
   * Downloads the data from the HTTP server specified by url.
   * This method does not store the data in the scratchpad.
   *
   * @param url URL of the data
   * @throws IOException thrown when there is an error in accessing the server.
   * @return data acquired, always not null.
   */
  private byte[] getDataFromHttpToMem(String url) throws IOException {
    HttpConnection conn = null;
    InputStream is = null;
    ByteArrayOutputStream bOut = null;
    int read;

    try {
      conn = (HttpConnection) Connector.open(url, Connector.READ);
      conn.setRequestMethod(HttpConnection.GET);
      conn.connect();
      is = conn.openInputStream();

      bOut = new ByteArrayOutputStream();
      byte[] buf = new byte[2048];

      while (true) {
        read = is.read(buf);
        if (read < 0) {
          break;
        }
        bOut.write(buf, 0, read);
      }
      bOut.flush();
      return bOut.toByteArray();
    }
    finally {
      if (is != null) {
        is.close();
      }
      if (conn != null) {
        conn.close();
      }
    }
  }

  /**
   * Gets the data from the JAR file.
   * @throws IOException thrown when there is an error in accessing the JAR file.
   * @param filename file name of the data
   * @return data acquired, always not null.
   */
  private byte[] getDataFromResource(String filename) throws IOException {
    InputStream is = null;
    ByteArrayOutputStream bOut = null;
    int read;

    try {
      is = Connector.openInputStream("resource:///" + filename);

      bOut = new ByteArrayOutputStream();
      byte[] buf = new byte[2048];

      while (true) {
        read = is.read(buf);
        if (read < 0) {
          break;
        }
        bOut.write(buf, 0, read);
      }
      bOut.flush();
      return bOut.toByteArray();
    }
    finally {
      if (is != null) {
        is.close();
      }
      if (bOut != null) {
        bOut.close();
      }
    }
  }

  /**
   * Gets the data from the scratchpad.
   * @throws IOException thrown when there is an error in accessing the scratchpad.
   * @param filename file name of the data
   * @return data acquired, always not null.
   */
  private byte[] getDataFromScratchpad(String filename) throws IOException {
    DataInputStream in = null;

    try {
      Integer offset = (Integer) offsetTable.get(filename);
      if (offset == null) {
        throw FILE_NOT_FOUND_EXCEPTION;
      }

      Integer len = (Integer) lenTable.get(filename);
      if (len == null) {
        throw FILE_NOT_FOUND_EXCEPTION;
      }

      in = Connector.openDataInputStream(
          "scratchpad:///0;pos=" + offset.intValue()
          + ",length=" + len.intValue());

      byte[] data = new byte[len.intValue()];
      int read = in.read(data);
      if (read == -1) {
        throw new ConnectionException(ConnectionException.SCRATCHPAD_OVERSIZE);
      }
      return data;
    }
    finally {
      if (in != null) {
        in.close();
      }
    }
  }

  /**
   * Gets the image from the scratchpad.
   * @throws IOException thrown when there is an error in accessing the scratchpad.
   * @param filename file name of the image
   * @return MediaImage instance acquired, always not null.
   */
  private MediaImage getImageFromScratchpad(String filename) throws IOException {
    Integer offset = (Integer) offsetTable.get(filename);
    if (offset == null) {
      throw FILE_NOT_FOUND_EXCEPTION;
    }

    Integer len = (Integer) lenTable.get(filename);
    if (len == null) {
      throw FILE_NOT_FOUND_EXCEPTION;
    }

    MediaImage mi = MediaManager.getImage(
        "scratchpad:///0;pos=" + offset.intValue()
        + ",length=" + len.intValue());

    return mi;
  }

  /**
   * Saves data to the scratchpad.
   * The data is stored as filename.
   * Note that this method does not update the file table in the scratchpad.
   * Use writeScratchpadTable() to save the file table.
   *
   * @param filename file name of the data
   * @param data data to be saved
   * @param offset offset in data
   * @param len length of the data from offset to be saved
   * @see #writeScratchpadTable()
   * @throws IOException thrown when there is an error in saving the file.
   */
  private void save(String filename, byte[] data, int offset, int len) throws
      IOException {
    DataOutputStream out = null;

    System.out.println("saving to scratchpad.");
    // checks file name
    if (filename == null ||
        filename.length() < 1 ||
        filename.length() > MAX_FILENAME_LEN) {
      throw INVALID_FILE_NAME_EXCEPTION;
    }

    // checks if the same file already exists
    if (offsetTable.containsKey(filename)) {
      throw SAME_FILE_EXISTS_EXCEPTION;
    }

    // checks file system size
    if (offsetTable.size() + 1 > MAX_FILES) {
      throw TOO_MANY_FILES_EXCEPTION;
    }

    try {
      out = Connector.openDataOutputStream("scratchpad:///0;pos=" +
                                           nextFreeOffset);

      // writes the marker
      out.write(data, offset, len);

      offsetTable.put(filename, new Integer(nextFreeOffset));
      lenTable.put(filename, new Integer(len));
      nextFreeOffset += len;
      System.out.println("done.");
    }
    finally {
      if (out != null) {
        out.close();
      }
    }
  }

  /**
   * Writes the file table to the scratchpad.
   *
   * @throws IOException thrown when there is an error in writing the file table.
   */
  private void writeScratchpadTable() throws IOException {
    DataOutputStream out = null;

    try {
      System.out.println("writing file table.");
      out = Connector.openDataOutputStream("scratchpad:///0;pos=0");

      // saves the marker
      out.writeInt(MARK);

      // saves the number of entries
      int nofEntries = offsetTable.size();
      out.writeInt(nofEntries);

      Enumeration en = offsetTable.keys();
      while (en.hasMoreElements()) {
        String fileName = (String) en.nextElement();
        Integer fileOffset = (Integer) offsetTable.get(fileName);
        Integer fileLen = (Integer) lenTable.get(fileName);
        out.writeUTF(fileName);
        out.writeInt(fileOffset.intValue());
        out.writeInt(fileLen.intValue());
      }
      System.out.println("done.");
    }
    finally {
      if (out != null) {
        out.close();
      }
    }
  }
}
