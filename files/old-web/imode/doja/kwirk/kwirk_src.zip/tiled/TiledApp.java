/*
 * @(#) TiledCanvas.java  @(#)
 * 
 * Tiled Canvas class
 * 
 */

package tiled;

import com.nttdocomo.ui.*;
import java.io.*;
import javax.microedition.io.*;

abstract public class TiledApp extends IApplication 
{
 	public String varAppPanel = "";
    public String varAppBack = "";
 	public String varTiles[] = {"","","","","","","","","","","","","","","",""};
 	public String varLevelsFile = "levels/levels.lst";
 	public String varSizesFile = "imgs/sizes.lst";
 	public String varSizeName = "";
 	
 	public int varPanelOffX = 0;
 	public int varPanelOffY = 0;
 	public int varPanelLevelX = 0;
 	public int varPanelLevelY = 0;
    public int varPanelBackX = 0;
    public int varPanelBackY = 0;
 	
	final static public int ST_ERROR_NETWORK    = -3;
	final static public int ST_ERROR_LEVELS		= -2;
	final static public int ST_ERROR 			= -1;
 	final static public int ST_LOADING 			= 10;
	final static public int ST_LOADING_IMAGES 	= 11;
	final static public int ST_LOADING_LEVELS 	= 12;
 	final static public int ST_MENU	 			= 30;
 	final static public int ST_PLAYING  		= 40;
 	final static public int ST_WON	 			= 50;

	public ScratchUtil sp;
	public TiledLevel level;
	public TiledCanvas canvas;
	
	public int status;
	public Exception lastException = null;
	
	protected String levelFileName = "";

 	public void start() 
 	{
 		// Initialising
		initApp();
 		initVariables();
 		sp = ScratchUtil.getInstance();
		try {
			sp.init();
			sp.setServer(getSourceURL());
		} 
		catch (IOException e ) { System.out.println("Error : Unable to create SP."); }

		status = ST_LOADING;	Display.setCurrent(canvas); 	canvas.update(); 
		// Loading Stuff
		try
		{
			// Getting the proper Size
			getSize();
			canvas.initCanvas();
			status = ST_LOADING_IMAGES;		canvas.update();		spStoreImages();
			status = ST_LOADING_LEVELS;		canvas.update();		spStoreLevels();
			canvas.initImagesBlocs();
		}
		catch (Exception e)
		{
			lastException = e;
			status = ST_ERROR_NETWORK;
			canvas.repaint();
			return;
		}
		// Initialize Level
		if (loadState() == 0)
		{
			status = ST_PLAYING;
			canvas.repaint();
		}
		else
		{
			if( goNextLevel() == 0 )
			{
				status = ST_PLAYING;
				canvas.repaint();
			}
			else
			{
				status = ST_ERROR_LEVELS;
				canvas.repaint();
			}
		}
 	}
 	
 	abstract protected void initVariables();
 	abstract protected void initApp();
	
	protected String readLine(Reader in)
	{
		String str = "";
		char c = 0;
		do {
			try {
				if (in.ready()) c = (char)in.read(); else c = '\n';
				if ((c != '\r') && (c != '\n')) str += c;
			} catch (IOException e) { c = '\n'; }
		} while (c != '\n') ;
		return str;
	}

	protected void spStoreImages()
	{
		try
		{
			for(int i=0; i < varTiles.length; i++)
			{
				if (varTiles[i] != "") sp.storeFromServer("imgs/" + varSizeName + "/" + varTiles[i]);
			}
			sp.storeFromServer("imgs/" + varSizeName + "/" + varAppPanel);
			sp.storeFromServer("imgs/" + varSizeName + "/" + varAppBack);
		}
		catch (IOException e) { lastException = e; }
	}

	protected void spStoreLevels()
	{
		String levelFile;
		try
		{
			Reader levelList;
			ScratchUtil.getInstance().storeFromServer(varLevelsFile);
			levelList = new InputStreamReader(
							new ByteArrayInputStream(
								ScratchUtil.getInstance().getData(varLevelsFile)));
			while( (levelFile = readLine(levelList)) != "" )
			{
				try
				{
					ScratchUtil.getInstance().storeFromServer("levels/" + levelFile);
				}
				catch (IOException e) 
				{ 
					lastException = e; 
					System.out.println("Error storing level " + levelFile);
				}
			}
		}
		catch (IOException e) { lastException = e; }
	}
 
 
	public int goLevel(String levelFileName)
	{
		int ret;
		InputStream in;
		try 
		{
			in = new ByteArrayInputStream(ScratchUtil.getInstance().getData("levels/" + levelFileName));
			ret = level.loadLevel(in);
			this.levelFileName = levelFileName;
			in.close();
		} 
		catch (IOException e) { lastException = e; return -4; }
		return ret;
	}
	
	public int goNextLevel()
	{
		int ret;
		String line = "";
		Reader lst;
		try {
			lst = new InputStreamReader(
						new ByteArrayInputStream(
							ScratchUtil.getInstance().getData(varLevelsFile)));
			do {
				line = readLine(lst);
			} while ( (levelFileName != "") && 
					  (line != "") && 
					  (line.compareTo(levelFileName) != 0) );
			if (line == "") return -1;
			if (levelFileName != "") line = readLine(lst);
			ret = goLevel(line);
		}  
		catch (IOException e) { lastException = e; return -2; }
		return ret;
	}
	
	public int goPrevLevel()
	{
		int ret;
		String prevLine="", line = "";
		Reader lst;
		try {
			lst = new InputStreamReader(
						new ByteArrayInputStream(
							ScratchUtil.getInstance().getData(varLevelsFile)));
			do {
				prevLine = line;
				line = readLine(lst);
			} while ( (levelFileName != "") && 
					  (line != "") && 
					  (line.compareTo(levelFileName) != 0) );
			if (prevLine == "") return -1;
			ret = goLevel(prevLine);
		}  
		catch (IOException e) { lastException = e; return -2; }
		return ret;
	}
	
	public void reloadLevel()
	{
		if (levelFileName != "") goLevel(levelFileName);
	}
	
	public void saveSate()
	{
		OutputStream os;
		try
		{
			os = Connector.openOutputStream("scratchpad:///0;pos=" + sp.getFreeOffset());
			// Save Magic
			os.write(242);
			// Save Level
			level.writeLevel(os);
			// Save Level Name
			for(int i = 0; i < levelFileName.length() ; i++) os.write(levelFileName.charAt(i));
			os.write(0);
			os.close();
		}
		catch (IOException e) 
		{
			lastException = e; 
			System.out.println("Unable to save data : " + e.getMessage()); 
		}
	}
	
	public int loadState()
	{
		InputStream is;
		int b;
		try
		{
			is = Connector.openInputStream("scratchpad:///0;pos=" + sp.getFreeOffset());
			if (is.available() == 0) { is.close(); return -1; }
			b = is.read();
			if (b != 242) { is.close(); return -2; }
			if (level.loadLevel(is) != 0) { is.close(); return -3; }
			levelFileName = "";
			while ((is.available() > 0) && ((b = is.read()) != 0)) levelFileName = levelFileName + (char)b;
			if (b != 0) { is.close(); return -4; }
			is.close();			
		}
		catch (IOException e) { lastException = e; }
		return 0;
	}

	public String getSize()
	{
		String line = "";
		int selWidth = 0;	int curWidth;
		int selHeight = 0;  int curHeight;
		int curIndex; int lastIndex;
		Reader lst;
		try {
			lst = new InputStreamReader(
						new ByteArrayInputStream(
							ScratchUtil.getInstance().getData(varSizesFile)));
			ScratchUtil.getInstance().storeFromServer(varSizesFile);
			do {
				line = readLine(lst);
				if (line == "") continue;
				System.out.println("Size : " + line);
				lastIndex = 0;			curIndex = line.indexOf(';');
				curWidth  = Integer.parseInt(line.substring(lastIndex, curIndex));
				lastIndex = curIndex+1;	curIndex = line.indexOf(';', lastIndex);
				curHeight = Integer.parseInt(line.substring(lastIndex, curIndex));
				if ( ((selWidth == 0) || (selHeight == 0)) ||
				     ( (selWidth <= curWidth) && (selHeight <= curHeight) &&
				       (curWidth <= canvas.getWidth()) && (curHeight <= canvas.getHeight()) ) )
		        {
		        	selWidth = curWidth;
		        	selHeight = curHeight;
					lastIndex = curIndex+1;	curIndex = line.indexOf(';', lastIndex);
		        	varSizeName = line.substring(lastIndex, curIndex);
		        	System.out.println("Selecting size : " + varSizeName);
    				lastIndex = curIndex+1;	curIndex = line.indexOf(';', lastIndex);
		        	varPanelOffX = Integer.parseInt(line.substring(lastIndex, curIndex));
					lastIndex = curIndex+1;	curIndex = line.indexOf(';', lastIndex);
		        	varPanelOffY = Integer.parseInt(line.substring(lastIndex, curIndex));
					lastIndex = curIndex+1;	curIndex = line.indexOf(';', lastIndex);
		        	varPanelLevelX = Integer.parseInt(line.substring(lastIndex, curIndex));
					lastIndex = curIndex+1;	curIndex = line.indexOf(';', lastIndex);
		        	varPanelLevelY = Integer.parseInt(line.substring(lastIndex, curIndex));
					lastIndex = curIndex+1;	curIndex = line.indexOf(';', lastIndex);
		        	varPanelBackX = Integer.parseInt(line.substring(lastIndex, curIndex));
					lastIndex = curIndex+1;	curIndex = line.indexOf(';', lastIndex);
		        	varPanelBackY = Integer.parseInt(line.substring(lastIndex, curIndex));
		        }
			} while ( line != "" );
		}  
		catch (IOException e) { lastException = e; return ""; }
		return varSizeName;
	}
	
	
 
	public void keyPressed(int key)
	{
		switch(key)
		{
			case Display.KEY_SOFT2:
				saveSate();
				terminate();
				break;
		}
	
	}
}