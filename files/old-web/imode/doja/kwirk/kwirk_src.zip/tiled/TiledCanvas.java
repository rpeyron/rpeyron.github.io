/*
 * @(#) TiledCanvas.java  @(#)
 * 
 * Tiled Canvas class
 * 
 */

package tiled;

import java.io.IOException;

import com.nttdocomo.ui.*;

public class TiledCanvas extends Canvas
{

	protected TiledApp app;
    /// Attributes
    protected int tileWidth;
	protected int tileHeight;
    
	protected int offsetX;
	protected int offsetY;
    
    protected Image imgBack;
    protected Image imgBackTile;
	protected Image imgBlocs[];
	
	protected boolean repaintAll = true;
    
    // Constants
	final static int BORDER_LEFT   = 0x80;
	final static int BORDER_TOP    = 0x40;
	final static int BORDER_RIGHT  = 0x20;
	final static int BORDER_BOTTOM = 0x10;

    public TiledCanvas(TiledApp app)
    {
    	this.app = app;
    }

    public void initCanvas()
    {
		// Soft Labels 
		setSoftLabel(Frame.SOFT_KEY_1, "New");
		setSoftLabel(Frame.SOFT_KEY_2, "Quit");
		// Image Back
		try {
			imgBack = app.sp.getImage("imgs/" + app.varSizeName + "/" + app.varAppPanel);    	
            imgBackTile = app.sp.getImage("imgs/" + app.varSizeName + "/" + app.varAppBack);     
		} 
		catch (IOException e) { app.lastException = e;}
    }
    
    public void initImagesBlocs()
    {
		imgBlocs = new Image [16];
		try 
		{
			for(int i = 0; i < 16 ; i++)
			{
				if ((app.varTiles.length > i) && (app.varTiles[i] != ""))
				{
					imgBlocs[i] = app.sp.getImage("imgs/" + app.varSizeName + "/" +  app.varTiles[i]);
				}
				else
				{
					imgBlocs[i] = imgBlocs[0];
				}
			}
			this.tileWidth = imgBlocs[0].getWidth();
			this.tileHeight = imgBlocs[0].getHeight();
		}
		catch (IOException e) { app.lastException = e; }
    }
    
	public void update()
	{
		super.repaint();
	}
	
	public void repaint()
	{
		repaintAll = true;
		super.repaint();
	}

	protected void paintTextLine(Graphics g, String text, int line)
	{
		if (text == null) return;
		g.drawString(text, offsetX + 10, offsetY + 20 + line * Font.getDefaultFont().getHeight());		
	}

    public void paint(Graphics g)
    {
        // System.out.print("Paint Statuts : "+app.status + "\n");
    	
		// Use Double Buffering
		g.lock();
		
		if ( (app.status != TiledApp.ST_LOADING) && (app.status != TiledApp.ST_ERROR_NETWORK))
		{
	    	// Offsets
	    	calcOffsets();
			if (repaintAll) 
			{ 
				paintBoard(g, offsetX, offsetY);
				if (app.level.name != null)
				{
					g.drawString(app.level.name, offsetX + app.varPanelLevelX, offsetY + app.varPanelLevelY);				
					app.level.cleanDirtyFlags(); // Force redraw
				}
 			 	repaintAll = false; 
			}
		}
		
		switch(app.status)
		{
		case TiledApp.ST_ERROR:
			paintTextLine(g, "FATAL ERROR", 0);
			paintTextLine(g, "An unexpected error occured.", 2);
			if (app.lastException != null)
			{
				paintTextLine(g, app.lastException.getClass().getName(), 4);
				paintTextLine(g, app.lastException.getMessage(), 5);
			}
			break;	
		case TiledApp.ST_ERROR_LEVELS:
			paintTextLine(g, "FATAL ERROR", 0);
			paintTextLine(g, "Could not load level.", 2);
			try { app.sp.clear(); } catch (Exception e) {}
			paintTextLine(g, "Try to restart the application ", 4);
			paintTextLine(g, " or delete and re-download ", 5);
			paintTextLine(g, " the application.", 6);
			break;	
		case TiledApp.ST_ERROR_NETWORK:
			paintTextLine(g, "FATAL ERROR", 0);
			paintTextLine(g, "Could not connect.", 2);
			paintTextLine(g, "Please allow the application ", 4);
			paintTextLine(g, " to use the network.", 5);
			paintTextLine(g, "This is only needed at first run", 7);
			paintTextLine(g, " to load images and levels.", 8);
			break;	
		case TiledApp.ST_LOADING_LEVELS:
			paintTextLine(g, "Loading Levels...", 2);
		case TiledApp.ST_LOADING_IMAGES:
			paintTextLine(g, "Loading Images...", 1);
		case TiledApp.ST_LOADING:
			paintTextLine(g, "Initializing...", 0);
			break;				
		case TiledApp.ST_WON:
			paintTextLine(g, "You Won !", 0);
			break;				
		case TiledApp.ST_PLAYING:
			if ( (!repaintAll) &&
					(app.level.getDirtyMinX() != -1) &&
					(app.level.getDirtyMaxX() != -1) &&
					(app.level.getDirtyMinY() != -1) &&
					(app.level.getDirtyMaxY() != -1) ) 
			{
				paintTiles(g, app.level.getDirtyMinX(), app.level.getDirtyMinY(), app.level.getDirtyMaxX(), app.level.getDirtyMaxY(), offsetX, offsetY);
			}
			else
			{
				paintTiles(g, 0, 0, app.level.getLevelWidth(), app.level.getLevelHeight(), offsetX, offsetY);
			}
			break;
		default:
		}
		
		g.unlock(true);
		
		app.level.cleanDirtyFlags();
    }
    
	protected void calcOffsets()
	{
		offsetX = ((getWidth() - imgBack.getWidth()) / 2) + app.varPanelOffX;
		offsetY = ((getHeight() - imgBack.getHeight()) / 2) + app.varPanelOffY;
	}

	protected void paintBoard(Graphics g, int ox, int oy)
	{
        int ofx, ofy;
        ofx = (getWidth() - imgBack.getWidth()) / 2;
        ofy = (getHeight() - imgBack.getHeight()) / 2;
        for(int iy = app.varPanelBackY - ofy - imgBackTile.getHeight(); 
        		iy < getHeight(); 
        		iy += imgBackTile.getHeight())
        {
            for(int ix = app.varPanelBackX - ofx - imgBackTile.getWidth(); 
            		ix < getWidth(); 
            		ix += imgBackTile.getWidth())
            {
                g.drawImage(imgBackTile, ix, iy);
            }
        }
		g.drawImage(imgBack, ofx, ofy); 
	}
    
    protected void paintTiles(Graphics g, int x1, int y1, int x2, int y2, int ox, int oy)
    {
		for (int iy = y1 ; iy < y2 ; iy++ )
		{
			for (int ix = x1 ; ix < x2 ; ix++)
			{
				paintTile(g, ix, iy, ox, oy, 
						imgBlocs[app.level.getBlocIndex(ix, iy)], 
						app.level.getBlocBorders(ix, iy));
			}
		}
    }
    
	protected void paintTile(Graphics g, int x, int y, int ox, int oy, Image img, int borders)
    {
    	int dx1, dx2, dy1, dy2;
    	dx1 = x * tileWidth + ox; dx2 = (x + 1) * tileWidth + ox - 1; 
    	dy1 = y * tileHeight + oy; dy2 = (y + 1) * tileHeight + oy - 1;
    	g.setColor(Graphics.BLACK); 
    	g.drawImage(img, dx1, dy1);
		if ((borders & BORDER_LEFT  ) != 0) g.drawLine(dx1, dy1, dx1, dy2);
		if ((borders & BORDER_TOP   ) != 0) g.drawLine(dx1, dy1, dx2, dy1);
		if ((borders & BORDER_RIGHT ) != 0) g.drawLine(dx2, dy1, dx2, dy2);
		if ((borders & BORDER_BOTTOM) != 0) g.drawLine(dx1, dy2, dx2, dy2);
    }

	// Process key events.
	public void processEvent(int type, int param)
	{
		if (type == Display.KEY_PRESSED_EVENT)
		{
			app.keyPressed(param);
		}
	}
}