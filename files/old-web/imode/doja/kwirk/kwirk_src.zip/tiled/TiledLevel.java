/*
 * @(#) TiledLevel.java  @(#)
 * 
 * Tiled Level class
 * 
 */

package tiled;

import java.io.*;

public class TiledLevel
{
	
	// Level Data	
	byte width;
	byte height;
	byte blocs[][];
	byte nbPlayers, curPlayer;
	short posPlayers[];
	String name;
	
	// Dirty
	int dirtyMinX;
	int dirtyMaxX;
	int dirtyMinY;
	int dirtyMaxY;
	
	// Constants
	final static int blocMask = 15;
	final static byte magicByte = 13;
	
	public TiledLevel()
	{
		cleanDirtyFlags();
	}
	
	// Dirtyness management
	public void dirty(int x, int y)
	{
		if ((dirtyMinX == -1) || (x < dirtyMinX)) { dirtyMinX = x; }	
		if ((dirtyMaxX == -1) || (x >= dirtyMaxX)) { dirtyMaxX = x + 1; }	
		if ((dirtyMinY == -1) || (y < dirtyMinY)) { dirtyMinY = y; }	
		if ((dirtyMaxY == -1) || (y >= dirtyMaxY)) { dirtyMaxY = y + 1; }	
	}
	
	public void cleanDirtyFlags()
	{
		dirtyMinX = -1;
		dirtyMaxX = -1;
		dirtyMinY = -1;
		dirtyMaxY = -1;
	}
	
	public int getDirtyMinX() { return dirtyMinX; }
	public int getDirtyMaxX() { return dirtyMaxX; }
	public int getDirtyMinY() { return dirtyMinY; }
	public int getDirtyMaxY() { return dirtyMaxY; }
	
	// Getter / Setters for blocs[][]
	public int getBloc(int x, int y)	{ return ub2i(blocs[y][x]);	}
	public void setBloc(int x, int y, int bloc)	{	blocs[y][x] = i2ub(bloc); dirty(x, y); }

	public int getBlocIndex(int x, int y) { return ( getBloc(x,y) & blocMask); }
	public void setBlocIndex(int x, int y, int index) { setBloc(x,y, ((blocs[y][x] & ~ blocMask) + (index & blocMask))); }

	public int getBlocBorders(int x, int y) { return (getBloc(x,y) & ~blocMask); }
	public void setBlocBorders(int x, int y, int borders)	{ setBloc(x,y,(ub2i(blocs[y][x]) & blocMask) | (borders & ~blocMask));	}

	// Getter 
	
	// Getter / Setter for other
	public int getLevelWidth() { return width; }
	public int getLevelHeight() { return height; }
	public int getPosPlayer(int nb) { return posPlayers[nb];	}
	public int getPosPlayerX(int nb) { return (getPosPlayer(nb) % width); }
	public int getPosPlayerY(int nb) { return (getPosPlayer(nb) / width); }
	public void setPosPlayer(int nb, int x, int y) { setPosPlayer(nb,(y * width + x)); } 
	public void setPosPlayer(int nb, int pos) { posPlayers[nb] = (short)(pos); }
	public String getLevelName() { return name; }
	public void setLevelName(String name) { this.name = name; }
	public int getNbPlayers() { return ub2i(nbPlayers); }
	public void setNbPlayers(int nbPlayers) { this.nbPlayers = i2ub(nbPlayers); }
	public int getCurPlayer() { return ub2i(curPlayer); }
	public void setCurPlayer(int curPlayer) { this.curPlayer = i2ub(curPlayer); }
				
	public int createEmptyLevel(int width, int height, int nbMaxPlayers)
	{
		this.width = i2ub(width);
		this.height = i2ub(height);
		blocs = new byte[height][width];
		posPlayers = new short[nbMaxPlayers];
		return 0;
	}
	
	public int loadLevel(InputStream in) throws IOException
	{
		byte r[]; r = new byte[2];
		if (in.read() != magicByte) return -1;
		width = i2ub(in.read());
		height = i2ub(in.read());
		blocs = new byte[height][width];
		for (int iy = 0 ; iy < height ; iy++)
			for (int ix = 0; ix < width ; ix++)
				setBloc(ix, iy, i2ub(in.read()));
		nbPlayers = i2ub(in.read());
		posPlayers = new short[nbPlayers];
		for (int i = 0 ; i < nbPlayers ; i++)
			posPlayers[i] = (short)(in.read() + in.read() * 0x100);
		curPlayer = i2ub(in.read());
		in.read(r);
		name = "" + ((char)r[0]) + ((char)r[1]);
		if (in.read() != magicByte) return -1;
		return 0;
	}
	
	public int writeLevel(OutputStream out) throws IOException
	{
		out.write(magicByte);
		// Write Level Blocs
		out.write(ub2i(width));
		out.write(ub2i(height));
		for (int iy = 0 ; iy < height ; iy++)
			for (int ix = 0; ix < width ; ix++)
				out.write(getBloc(ix,iy));
		// Write Player Infos
		out.write(ub2i(nbPlayers));
		for (int i = 0 ; i < nbPlayers ; i++)
		{
			out.write(posPlayers[i] & 0x00FF);
			out.write(posPlayers[i] & 0xFF00);
		}
		out.write(ub2i(curPlayer));
		// Write Level Info
		out.write(name.getBytes()[0]);
		out.write(name.getBytes()[1]);
		out.write(magicByte);
		out.flush();
		return 0;
	}
	
	// Int <-> Unsigned Byte
	protected byte i2ub(int value) { return (byte)(value & 0xFF); }
	protected int  ub2i(byte value) { return (((int) value) & 0xFF); }
}