/*
 * @(#) Kwirk.java  @(#)
 * 
 * Main Kwirk Java file
 * 
 */
 
 	

public class KwirkEngine 
{
	// Return codes
	final static int OK_NOTHING = 1;
	final static int OK_NEED_REFRESH = 2;
	final static int OK_WON_LEVEL = 3;
	final static int KO_MOVE_IMPOSSIBLE = -1;
	
	// Directions
	final static int MOVE_LEFT  = 0;
	final static int MOVE_UP     = 1;
	final static int MOVE_RIGHT  = 2;
	final static int MOVE_BOTTOM = 3;
	
	// This array gives the directions :
	// - [dir][0] : x increment
	// - [dir][1] : y increment
	// - [dir][2] : mask 0xF0 corresponding to the direction
	final static short dirs[][]={{-1,0,0x80},{0,-1,0x40},{1,0,0x20},{0,1,0x10}};

	public static int move(KwirkLevel level, int dir)
	{
	  // Setting up some useful variables
	  boolean can = true;
	  boolean disp = false;
	  int dirx = dirs[dir][0];
	  int diry = dirs[dir][1];
	  int dirm = dirs[dir][2];
	  int curPlayerX = level.getPosPlayerX(level.getCurPlayer());
	  int curPlayerY = level.getPosPlayerY(level.getCurPlayer());
	  
	  int bdest = level.getBloc(curPlayerX+dirx,curPlayerY+diry);
	  int curx=curPlayerX, cury=curPlayerY;
	  int cur2x=curPlayerX, cur2y=curPlayerY;
	  int cur3x = 0, cur3y = 0;
	  int dir2 = dir, dir3=dir, dird = -1;
	  int bcur,bcur2,bint;
	  // Si c'est autre chose que du vide, a priori on peut pas y aller
	  if ((bdest & 0x0F) != 0x00) { can = false; }
	  // Test des blocs -------------------------------------------------------
	  if ((bdest & 0x0F) == 0x08)
	  {
	   // System.out.print("Bloc\n");
	   // On va faire ce test uniquement pour des blocs rectangulaires
	   // De m�moire c'est toujours le cas.
	   curx += dirx; cury += diry;
	   // - on va jusqu'a l'extremite du bloc dans la direction
	   // System.out.print(" * 1/ x="+curx+", y="+cury+", bloc="+level.getBloc(curx,cury)+"\n");
	   cur2x = curx; cur2y = cury;
	   while ((level.getBloc(cur2x,cur2y) & dirm) == 0) 
	   { 
		cur2x+=dirx; cur2y+=diry; 
	   }
	   // - on part dans les directions ortho <- et -> dir+1 et dir-1
	   can = true;
	   // This code is fairly gruiiik, but it is to avoid duplicated code.
	   // - go to the extreme left, then go to the right
	   dir2 = getOrtho(dir,-1);
	   while ((level.getBloc(cur2x,cur2y) & dirs[dir2][2]) == 0) 
		 {  cur2x+=dirs[dir2][0]; cur2y+=dirs[dir2][1];  }
	   // System.out.print(" * 1-/ x="+cur2x+", y="+cur2y+", bloc="+level.getBloc(cur2x,cur2y)+"\n");
	   dir2 = getOrtho(dir,1);
	   cur2x-=dirs[dir2][0]; cur2y-=dirs[dir2][1];
	   do {
		cur2x+=dirs[dir2][0]; cur2y+=dirs[dir2][1];
		if ( ((level.getBlocIndex(cur2x+dirx,cur2y+diry)) != 0) &&
			 ((level.getBlocIndex(cur2x+dirx,cur2y+diry)) != 3) )
			 { can = false;  }
	   } while ( ((level.getBloc(cur2x,cur2y) & dirs[dir2][2]) == 0) );
	  }
	  // Test des tourniquets ------------------------------------------------
	  if ((bdest & 0x0F) == 0x0B)
	  {
	   // System.out.print("Tourniquet.\n");
	   // Detection du centre.
	   // Detection du centre.
	   for(dir2=0; (dir2<4)&&((bdest&dirs[dir2][2])!=0) ;dir2++);
	   curx=curPlayerX+dirx+dirs[dir2][0];
	   cury=curPlayerY+diry+dirs[dir2][1];
	   // On v�rifie qu'on est pas dans l'alignement
	   if (dir2!=dir)
	   {
		can = true;
		// Detection direct_indirect
		dird=(0-diry*(dirx+dirs[dir2][0])+dirx*(diry+dirs[dir2][1]));
		// System.out.print(" * Sens "+dird+"\n");
		for (dir3=0;dir3<4;dir3++)
		{
		 if ((level.getBloc(curx,cury) & dirs[dir3][2]) == 0)
		 { // il y a ici un bloc a pour lequel il faut checker le mouvement
		  cur2x = curx + dirs[dir3][0];
		  cur2y = cury + dirs[dir3][1];
		  cur3x = curx + dirs[getOrtho(dir3,dird)][0];
		  cur3y = cury + dirs[getOrtho(dir3,dird)][1];
		  bint = level.getBlocIndex(cur2x+cur3x-curx,cur2y+cur3y-cury);
		  if ( (bint != 0x03) && (bint != 0x00) && (bint != (0x04+level.getCurPlayer())) ) 
		  { 
		   can = false; 
		   System.out.print(" * "+(cur3x+cur2x-curx)+","+(cur2y+cur3y-cury)+":"+bint+" - Jet� par bloc interm�diaire pour ("+cur2x+","+cur2y+")\n");
		  }
		  bint = level.getBlocIndex(cur3x,cur3y);
		  if ( (bint != 0x00) && (bint != 0x03) )
		  {
		   if ( ((bint == 0x0B) || (bint == 0x0C)) && 
				((level.getBloc(curx,cury) & dirs[getOrtho(dir3,dird)][2]) == 0) )
		   {} else {
			can = false;
			System.out.print(" * "+cur3x+","+cur3y+":"+level.getBloc(cur3x,cur3y)+" - Jet� par bloc angle pour ("+cur2x+","+cur2y+"\n");
		   }
		  }
              

		 }
		}
	   }
	  }
      
	  // Test de la sortie ---------------------------------------------------
	  if ((bdest & 0x0F) == 0x02)
	  {
	   // System.out.print("Sortie !\n");
	   can = true;
	   disp = true;
	   //throw new WinKWException(); throws SUXX !! becauseof KeyListener
	   for (int i=0; i < level.getNbPlayers(); i++)
	   {
		if (i != level.getCurPlayer())
		{
		 if ( (level.getPosPlayerX(i) != (curPlayerX+dirx)) ||
			  (level.getPosPlayerY(i) != (curPlayerY+diry)) )
		   {
			level.setBlocIndex(curPlayerX,curPlayerY, 0x00);
			curPlayerX+=dirx;
			curPlayerY+=diry;
			level.setPosPlayer(level.getCurPlayer(), curPlayerX, curPlayerY);
			level.setCurPlayer(i);
			return OK_NEED_REFRESH;
		   }
		}
	   }
	   return OK_WON_LEVEL;
	  }

	  if (can)
	  {
	   // Deplacement des �l�ments
	   // Deplacement des blocs ---------------------------------------------
	   if ((bdest & 0x0F) == 0x08)
	   {
		// Test de la flotte ==========
		boolean flood = true;
		curx=curPlayerX+dirs[dir][0];
		cury=curPlayerY+dirs[dir][1];
		// Go to the extreme left
		dir2 = getOrtho(dir,-1);
		while ((level.getBloc(curx,cury) & dirs[dir2][2]) == 0) 
		  {  curx+=dirs[dir2][0]; cury+=dirs[dir2][1];  }
		// Go to the right and up  
		dir2=getOrtho(dir,1);
		curx-=dirs[dir][0]; cury-=dirs[dir][1];
		do { 
		 curx+=dirs[dir][0]; cury+=dirs[dir][1];
		 cur2x=curx; cur2y=cury;
		 cur2x-=dirs[dir2][0]; cur2y-=dirs[dir2][1];
		 do { 
		  cur2x+=dirs[dir2][0]; cur2y+=dirs[dir2][1];
		  if ( ((level.getBlocIndex(cur2x+dirx,cur2y+diry)) != 9) && 
			   ((level.getBlocIndex(cur2x+dirx,cur2y+diry)) != 3) )
			   { flood=false; }
		 } while ((level.getBloc(cur2x,cur2y) & dirs[dir2][2]) == 0);
		} while ((level.getBloc(curx,cury) & dirm) == 0);
		// Deplacement effectif
		// System.out.print(" * BlocFlood : "+flood+"\n");
		// go to the right and down
		dir3=getOpposite(dir);
		dir2=getOrtho(dir,1);
		curx-=dirs[dir3][0]; cury-=dirs[dir3][1];
		do { 
		 curx+=dirs[dir3][0]; cury+=dirs[dir3][1];
		 cur2x=curx; cur2y=cury;
		 cur2x-=dirs[dir2][0]; cur2y-=dirs[dir2][1];
		 bcur2=level.getBloc(curx,cury);
		 do { 
		  cur2x+=dirs[dir2][0]; cur2y+=dirs[dir2][1];
		  bcur=level.getBloc(cur2x,cur2y);
		  level.setBlocIndex(cur2x,cur2y, (((bcur & 0x0F)==9)?3:0));
		  level.setBlocBorders(cur2x,cur2y, 0);
		  level.setBlocIndex(cur2x+dirx,cur2y+diry,((flood)?0:(((level.getBlocIndex(cur2x+dirx,cur2y+diry))==3)?9:8)));
		  level.setBlocBorders(cur2x+dirx,cur2y+diry,(flood)?0:(bcur&0xF0));
		 } while ((bcur & dirs[dir2][2]) == 0);
		} while ((bcur2 & dirs[dir3][2]) == 0);
        
	   }
	   // Deplacement du tourniquet ---------------------------------------
	   if ((bdest & 0x0F) == 0x0B)
	   {
		//short dirs_tourn[][], dird=1;
		// Detection du centre.
		for(dir2=0; (dir2<4)&&((bdest&dirs[dir2][2])!=0) ;dir2++);
		curx=curPlayerX+dirx+dirs[dir2][0];
		cury=curPlayerY+diry+dirs[dir2][1];
		// Detection direct_indirect
		dird=-(0-diry*(dirx+dirs[dir2][0])+dirx*(diry+dirs[dir2][1]));
		// Rotation effective
		// - on commence par gicler tous les tourniquets exterieurs
		for (dir3=0;dir3<4;dir3++)
		{
		 if ((level.getBloc(curx,cury) & dirs[dir3][2]) == 0)
		 { // il y a ici un bloc a virer
		  cur2x = curx + dirs[dir3][0];
		  cur2y = cury + dirs[dir3][1];
		  level.setBlocIndex(cur2x,cur2y,(((level.getBlocIndex(cur2x,cur2y)) == 0x0C)?3:0));
		  level.setBlocBorders(cur2x,cur2y,0);
		 }
		}
		// On tourne les flags du centre*
		int temp = level.getBlocBorders(curx,cury);
		if (dird==1)
		{
		 temp <<= 1;
		 if ((temp & 0x100) != 0) { temp |= 0x10; }
		}
		else
		{
		 temp >>= 1;
		 if ((temp & 0x08) != 0) { temp |= 0x80; }
		}
		level.setBlocBorders(curx,cury,temp);
		// On remet les tourniquets exterieurs
		for (dir3=0;dir3<4;dir3++)
		{
		 if ((level.getBloc(curx,cury) & dirs[dir3][2]) == 0)
		 { // il y a ici un bloc a virer
		  cur2x = curx + dirs[dir3][0];
		  cur2y = cury + dirs[dir3][1];
		  level.setBlocIndex(cur2x,cur2y,(((level.getBlocIndex(cur2x,cur2y)) == 0x03)?0x0C:0x0B));
		  level.setBlocBorders(cur2x,cur2y,((~(dirs[getOpposite(dir3)][2]))&0xF0));
		 }
		}
	   }
	   // Deplacement du joueur -------------------------------------------
		level.setBlocIndex(curPlayerX,curPlayerY,0x00);
		curPlayerX+=dirx;
		curPlayerY+=diry;
		level.setPosPlayer(level.getCurPlayer(), curPlayerX, curPlayerY);
		if ((level.getBlocIndex(curPlayerX,curPlayerY)) == 0x0B)
		{ // S'il y a encore un tourniquet ca veut dire qu'il faut avancer encore
		 curPlayerX+=dirx;
		 curPlayerY+=diry;
		 level.setPosPlayer(level.getCurPlayer(), curPlayerX, curPlayerY);
		}
		level.setBlocIndex(curPlayerX,curPlayerY,(0x04+level.getCurPlayer()));
		return OK_NEED_REFRESH;
	  } 
	  else
	  {
	  	return KO_MOVE_IMPOSSIBLE;
	  }
	}
	
	// returns the orthogonal direction
	public static int getOrtho(int dir, int sens)
	{
	 if (sens > 0) { return ((dir < 3)?dir+1:0);} 
	 if (sens < 0) { return ((dir > 0)?dir-1:3);}
	 return dir;
	}

	// return the opposite direction
	public static int getOpposite(int dir)
	{
	 switch(dir)
	 {
	  case 0: return 2;
	  case 1: return 3;
	  case 2: return 0;
	  case 3: return 1;
	 }
	 return 0;
	}

}

