/*
 * @(#) TiledLevel.java  @(#)
 * 
 * Tiled Level class
 * 
 */

import tiled.*;
import java.io.*;

public class KwirkLevel extends TiledLevel
{
	// Constants
	final static byte blocMask = 15;
	
	public KwirkLevel()
	{
		super();
	}
	
	public boolean isPlayerOK(int player)
	{
		return (getBlocIndex(getPosPlayerX(player), getPosPlayerY(player)) == (player + 4));
	}
	
	public int readLevelFromAsm(InputStream reader)
	{
		try {
		super.createEmptyLevel(20, 18, 4);
		// Parse the level file
		// Note: this parsing stage is very "tricky". it relies on some triggers.
		//    the format of the file is because of compatibility with the same
		//    game in assembly on TI89/92
		int c;
		// Lecture du tableau bloc.
		for (int j=0 ; j < getLevelHeight() ; j++)
		 for (int i=0 ; i< getLevelWidth() ; i++)
		 {
		    // On se cale sur le prochain $
		    while ((c=reader.read())!='$');
			setBloc(i,j,(16*translateHex((char)reader.read())+translateHex((char)reader.read())));
		  }
		// Lecture des informations compl�mentaires 
		// Lecture de nombre de joueurs et du joueur courant
		while (reader.read()!='b');  // Calage sur b.
		while (!Character.isDigit((char)(c=reader.read())));
		setNbPlayers((byte)Integer.parseInt("0"+(char)c));
		while (!Character.isDigit((char)(c=reader.read())));
		setCurPlayer((byte)Integer.parseInt("0"+(char)c));
		// Lecture des positions des joueurs
		while (reader.read()!='w');  // Calage sur w.
		int pos = 0;
		for (int i=0;i<4;i++)
		{
		 while (!Character.isDigit((char)(c=reader.read()))); // Calage sur prochain chiffre.
		 pos = Integer.parseInt("0"+(char)c);
		 while (Character.isDigit((char)(c=reader.read())))
		 {  // Lecture chiffre
		  pos = pos * 10 + Integer.parseInt("0"+(char)c);
		 }
		 setPosPlayer(i, pos);
		}
		// Lecture du nom du niveau
		while (reader.read()!='"');  // Calage sur ".
		setLevelName("");
		while ((c=reader.read())!='"') { setLevelName(getLevelName() + (char)c); }
		}
		catch (IOException e) { return -1; }
		return 0;
	}
	
	// This very simple function is used to convert Hex values.
	static int translateHex(char hex) {
	  if (hex >= 'A')
		if (hex >= 'a')
		 {
		  return ((hex & 0xdf) - 'a' + 10);
		 } else {
		  return ((hex & 0xdf) - 'A' + 10);
		 } 
	  else
		return (hex - '0');
	 }
	
}