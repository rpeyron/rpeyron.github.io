#! /usr/bin/env python
""" Extact attached files.
"""

import sys,getopt,string,os,multifile, mailbox, mimetools, re

VERSION = '0.1'
USAGE = """Usage: extr-attach.py [ OPTION ] <mailbox-file> <directory>

   -h, --help
            Show this help text and exit
   -v, --version
            Show file version and exit

"""


def treat_file(mbox_fname,output_dir,new_dir):
  if output_dir[-1] != '/': output_dir = output_dir + '/'
      
  # Make the output directory, if required
  try:
      os.mkdir(output_dir)
  except os.error,ertxt:
      if string.find(str(ertxt),'File exists') == -1:
          print 'Failed to create or use directory',output_dir,'[',ertxt,']'
          sys.exit(1)

  try:
      mbox_file = open(mbox_fname)
  except:
      print "Failed to open file",mbox_fname
      sys.exit(1)

  print new_dir, mbox_fname

  mdest = open(os.path.join(new_dir,mbox_fname),"wb+")

  mbox = mailbox.UnixMailbox(mbox_file,mimetools.Message)

  count = 0
  # Parcours de la boite aux lettre
  while 1:
      msg = mbox.next()
      if not msg: break
      count = count + 1
      print count, msg.getheader("Subject"), "/" ,msg.getheader("From"), msg.getmaintype(), msg.getheader("Message-ID")
      mdest.write("From - Thu May  3 22:59:55 2001\n")
      mdest.writelines(msg.headers)
      mdest.write("\n")
      if (msg.getmaintype() == "multipart") and (msg.getparam("boundary") != "None"):
        mf=multifile.MultiFile(msg.fp,0)
        l = msg.fp.readline()
        count = len(l)
        while  (string.find(l,"--",0,3) < 0) and (string.find(l,"\n",0,2) < 0):
          mdest.write(l)
          l = msg.fp.readline()
          count = count + len (l)
        msg.fp.seek(-count,1)
        #if (msg.gettype() == "multipart/alternative"): mdest.write("\nThis is a multi-part message in MIME format.")
        #if (msg.gettype() == "multipart/mixed"): mdest.write("\nC'est un message de format MIME en plusieurs parties.")
        msg_mf =mimetools.Message(mf,mf.seekable)
        boundary = msg.getparam("boundary")
        mf.push(boundary)
        mf.read()
        #mdest.writelines(msg_mf.headers)
        #mdest.writelines(msg_mf.fp.readlines())
        partno = 0;
        # Parcours des attachements
        while not mf.last:
          msg_mf = mimetools.Message(mf, mf.seekable)
          if msg_mf.getmaintype == "multipart":
             print "got it !", msg_mf.getparam("boundary")
             
          partno = partno + 1
          ttype = msg_mf.gettype()
          name = msg_mf.getparam("name")
          if (partno != 1): mdest.write("\n")
          # Save / Skip
          if ((ttype != "text/plain") and \
              ((ttype != "text/html") or (name != None)) and \
              (ttype != "multipart/alternative") ):
            print "   save", partno, name, ttype
            # Warning : need to supply better names...
            dstdir = output_dir
            if not name: name = "part_%d" % (partno)
            pathname = os.path.join(dstdir,name)
            pathnametry = 1
            while os.path.exists(pathname):
              pathname = os.path.join(dstdir,name+"_"+str(pathnametry))
              pathnametry = pathnametry + 1
            dstfile = open (pathname,"wb+")
            encoding = msg_mf.getencoding()
            if not encoding: raise "Unknow encoding"
            if encoding == "7bit":
              mimetools.copyliteral(mf,dstfile)
            else:
              mimetools.decode(mf,dstfile,encoding)
            dstfile.close()  
            mdest.writelines(msg_mf.headers)
            mdest.write("\r\n")
            mdest.writelines(msg_mf.fp.readlines())
            mdest.write("Attachment removed\n")
          else:
            print "   skip", partno, name, ttype 
            mdest.writelines(msg_mf.headers)
            mdest.write("\n")
            mdest.writelines(msg_mf.fp.readlines())
          mdest.write("--"+boundary)
          mf.next()
        mdest.write("--\n");
        mf.pop()  
      else:
        print "Not multipart"
        mdest.writelines(msg.fp.readlines())
      mdest.write("\n\n")  
  mdest.close()      


def parcours(arg, dirname, names):
  output_dir, new_dir = arg
  try: 
    newdir = os.path.join(new_dir,dirname)
    print newdir
    os.makedirs(newdir)
  except:
    print "exists"
  for n in names:
    if (string.find(n,".snm") < 0) and (os.path.isfile(os.path.join(dirname,n))):
        print "Processing ",dirname,n
        attdir = os.path.join(os.path.join(output_dir,dirname),n)
        try: 
          os.makedirs(attdir);
          print attdir
        except:
          print "exists"
        treat_file (os.path.join(dirname,n),attdir,new_dir)


try:
    optlist, args = getopt.getopt(sys.argv[1:],'hv',['help','version'])
except getopt.error, error_text:
    print error_text,'\n'
    print USAGE
    sys.exit(1)

for tuple in optlist:
    if tuple[0] == '-h' or tuple[0] == '--help':
        print USAGE
        sys.exit(0)
    if tuple[0] == '-v' or tuple[0] == '--version':
        print VERSION
        sys.exit(0)

if len(args) != 3:
    print USAGE

mbox_fname, output_dir, new_dir = args

if os.path.isdir(mbox_fname):
   os.path.walk(mbox_fname,parcours,(output_dir,new_dir))
else:
   treat_file(mbox_fname, output_dir, new_dir)
