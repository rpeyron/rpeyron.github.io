/**
 * (C) 2002 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
 * 
 * Source code based on the brillant documentation of OSR about the RecognizerFsControl
 * 1997 OSR Open Systems Resources, Inc. 
 * 
 */

/// Include the Precompiled Header
#include "PCH.h"

/// Constants
#define FSD_SERVICE_PATH L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\DummyFS0"
#define FSD_DRIVER_NAME L"\\FileSystem\\DummyFS0"

/// Global static objects
static PDRIVER_OBJECT DummyDriverObject;
static PDEVICE_OBJECT DummyDeviceObject;

/// Forward reference
///  The names are prefixed with DFS (DummyFS)
static VOID DFSUnload(PDRIVER_OBJECT);
static NTSTATUS DFSControl(PDEVICE_OBJECT, PIRP);

/// Some usefull defines
#define TracePrint DbgPrint

/** DriverEntry
 * This is a trivial driver, with a trivial entry point.
 * @brief This is the entry point for the driver.
 * @param DriverObject [IN] the driver object for this driver.
 * @param RegistryPath [IN] the path to this driver's key.
 * @return Success
 */
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
	NTSTATUS code;
	UNICODE_STRING driverName;

	TracePrint("[DummyFS] Driver Entry (DummyFS - Step0)!\n");
	
	// Save driver object pointer
	DummyDriverObject = DriverObject;
	// Set up dispatch entry point.
	DriverObject->MajorFunction[IRP_MJ_FILE_SYSTEM_CONTROL] = DFSControl;

	// Other Entry Points - Testing

	DriverObject->MajorFunction[IRP_MJ_CREATE] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_PNP] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_POWER] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_READ] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_WRITE] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_FLUSH_BUFFERS] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_QUERY_INFORMATION] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_SET_INFORMATION] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_INTERNAL_DEVICE_CONTROL] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_SYSTEM_CONTROL] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_CLEANUP] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_CLOSE] = DFSControl;
	DriverObject->MajorFunction[IRP_MJ_SHUTDOWN] = DFSControl;

	// Set up unload entry point.
	DriverObject->DriverUnload = DFSUnload;
	// Initialize the name string for the file system Dummy device	object.
	RtlInitUnicodeString(&driverName, FSD_DRIVER_NAME);
	// Create the named device object.
	code = IoCreateDevice(	DummyDriverObject,
							0,
							&driverName,
							FILE_DEVICE_CD_ROM_FILE_SYSTEM, /*FILE_DEVICE_DISK_FILE_SYSTEM, /*FILE_DEVICE_NETWORK_FILE_SYSTEM, */
							0,
							FALSE,
							&DummyDeviceObject);
	if (!NT_SUCCESS(code)) 
	{
		DbgPrint("[DummyFS] Dummy failed to load, failure in IoCreateDevice call returned 0x%x\n", code);
		return (code);
	}
	// Register the device object as a file system.
	//IoRegisterFileSystem(DummyDeviceObject);
	// Done!
	TracePrint("[DummyFS] Dummy loaded !\n");
	return STATUS_SUCCESS;
}

/** DFSUnload
 *
 * This is the function is called when the OS has determined
 * that their are no more references to the device Object.
 * It is our job to unregister ourselves as a File System and
 * delete the Device Object we created. 
 *
 * @param DeviceObject [IN] presumably our device object
 *
 */
static VOID DFSUnload(PDRIVER_OBJECT DriverObject)
{
	// Delete our device object.
	TracePrint("[DummyFS] Ask for unload.\n");
	if (DummyDeviceObject) 
	{
		//IoUnregisterFileSystem(DummyDeviceObject);
		IoDeleteDevice(DummyDeviceObject);
		DummyDeviceObject = 0;
	}
	TracePrint("[DummyFS] Dummy unloaded.\n");
}

/** DFSControl
 *
 * This is the dispatch function. 
 * It handles all the requests to our driver, and dispatch them in 
 * the appropriates functions.
 *
 * @param DeviceObject [IN] presumably our device object
 * @param Irp [IN] the mount/load request
 * @return Status code :
 *   - STATUS_NOT_IMPLEMENTED - something other than we can do
 *   - SUCCESS - load was successfull
 */
static NTSTATUS DFSControl(PDEVICE_OBJECT DeviceObject, PIRP
									Irp)
{
	PIO_STACK_LOCATION irpSp = IoGetCurrentIrpStackLocation(Irp);
	UNICODE_STRING driverName;
	NTSTATUS code;

	TracePrint("[DummyFS] DummyFsControl - Maj = %x, Min = %x\n", irpSp->MajorFunction, irpSp->MinorFunction);

	/// Check for our DeviceObject
	if (DeviceObject != DummyDeviceObject) 
	{
		// Not ours.
		Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
		Irp->IoStatus.Information = 0;
		IoCompleteRequest(Irp, IO_NO_INCREMENT);
		return STATUS_NOT_IMPLEMENTED;
	}

	switch (irpSp->MinorFunction)
	{
		// Well, for now we don't do anything exciting :)
		default:
			// The function is not implemented
			TracePrint("[DummyFS] DummyFsControl - Not Implemented.\n");
			Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
			Irp->IoStatus.Information = 0;
			IoCompleteRequest(Irp, IO_NO_INCREMENT);
			return STATUS_NOT_IMPLEMENTED;
	}

	// Hum, we should never go there, but who knows...
	DbgPrint("[DummyFS] DummyFsControl end reached.");
	Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
	Irp->IoStatus.Information = 0;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return STATUS_NOT_IMPLEMENTED;
}

