/**
 * (C) 2002 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
 * 
 * Source code based on the brillant documentation of OSR about the RecognizerFsControl
 * 1997 OSR Open Systems Resources, Inc. 
 * 
 */

/// Includes
#include <stdio.h>
#include <assert.h>
#include <windows.h>
#include <winioctl.h>
//#include <ntifs.h>
//#include <ntddk.h>

//#include "dummyfs.h"

/// Constants 
#define FSD_SERVICE_PATH L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\DummyFS1"
#define FSD_DRIVER_NAME L"\\FileSystem\\DummyFS1"
// ROOT\LEGACY_DUMMYFS\0000


/// IOCTL codes
#define IOCTL_DUMMYFS_UNREGISTERFS \
			CTL_CODE( FILE_DEVICE_UNKNOWN, 0x4212, METHOD_NEITHER, FILE_ANY_ACCESS)


/// External, non-confidential but unpublished NT entry points
/*
NTSYSAPI NTSTATUS NTAPI ZwLoadDriver(IN PUNICODE_STRING DriverServiceName);
NTSYSAPI NTSTATUS NTAPI ZwUnloadDriver(IN PUNICODE_STRING DriverServiceName);
NTKERNELAPI VOID IoRegisterFileSystem(IN OUT PDEVICE_OBJECT DeviceObject);
NTKERNELAPI VOID IoUnregisterFileSystem(IN OUT PDEVICE_OBJECT DeviceObject);

/// Global static objects
static PDRIVER_OBJECT DummyDriverObject;
static PDEVICE_OBJECT DummyDeviceObject;
*/

/** Main
 */
void __cdecl main(int argc, char ** argv)
{
	int size;
	
	/*
	NTSTATUS code;
	UNICODE_STRING driverName;
	UNICODE_STRING driverServiceName;
	PFILE_OBJECT fileObject;
	PDEVICE_OBJECT deviceObject;
	*/

	// First Try : CreateFile
	HANDLE hDriver;
	char * driverFileName;

	if (argc != 1)
	{
		driverFileName = argv[1];
	}
	else
	{
		driverFileName = "\\\\.\\DummyFS1";
	
	}
	

	/// Send a sppecial IOCTL to the driver to unregister it.
	
	//  - Open the Driver
	printf("[Unloader] Opening %s.\n",driverFileName);
	hDriver = CreateFile(driverFileName, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hDriver == INVALID_HANDLE_VALUE)
	{
		printf("[Unloader] CreateFile failed.\n");
	}

	// - Send the IOCTL

	DeviceIoControl(hDriver, IOCTL_DUMMYFS_UNREGISTERFS, NULL, 0, NULL, 0, &size, NULL);

	CloseHandle(hDriver);

	

	/*

	DbgPrint("[Unloader] Starting...\n");

	// Initialize the name string for the file system Dummy device	object.
	RtlInitUnicodeString(&driverName, FSD_DRIVER_NAME);

	// Get the Device Pointer
	fileObject = NULL;
	deviceObject = NULL;
	
	code = IoGetDeviceObjectPointer(&driverName, FILE_READ_ATTRIBUTES, &fileObject, &deviceObject);
	if (!NT_SUCCESS(code)) {
		DbgPrint("[Unloader] IoGetDeviceObjectPointer Error 0x%x\n", code);
	}
	

	*/

	/*
	/// Unload the Driver 
	// Initialize the name string for the file system Dummy device	object.
	RtlInitUnicodeString(&driverServiceName, FSD_SERVICE_PATH);

	// Tenter : IoGetDeviceObjectPointer ....
	code = ZwUnloadDriver(&driverServiceName);
	if (!NT_SUCCESS(code)) {
		DbgPrint("[Unloader] Error 0x%x\n", code);
		return;
	}
	*/
	

	return;
}

