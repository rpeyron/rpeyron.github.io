#include <ntifs.h>
//#include <winioctl.h>
#include <ntdddisk.h>