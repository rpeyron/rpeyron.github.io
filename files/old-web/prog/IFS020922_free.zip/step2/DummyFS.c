/**
 * (C) 2002 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
 * 
 * Source code based on the brillant documentation of OSR about the RecognizerFsControl
 * 1997 OSR Open Systems Resources, Inc. 
 * 
 */

/// Include the Precompiled Header
#include "PCH.h"

/// Constants
#define FSD_SERVICE_PATH L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\DummyFS1"
#define FSD_DRIVER_NAME L"\\FileSystem\\DummyFS1Driver"
#define FSD_DRIVER_DOS_NAME L"\\DosDevices\\DummyFS1"

/// IOCTL codes

#define IOCTL_DUMMYFS_UNREGISTERFS \
			CTL_CODE( FILE_DEVICE_UNKNOWN, 0x4212, METHOD_NEITHER, FILE_ANY_ACCESS)

/// External, non-confidential but unpublished NT entry points
NTSYSAPI NTSTATUS NTAPI ZwLoadDriver(IN PUNICODE_STRING DriverServiceName);
NTKERNELAPI VOID IoRegisterFileSystem(IN OUT PDEVICE_OBJECT DeviceObject);
NTKERNELAPI VOID IoUnregisterFileSystem(IN OUT PDEVICE_OBJECT DeviceObject);

/// Global static objects
static PDRIVER_OBJECT DummyDriverObject;
static PDEVICE_OBJECT DummyDeviceObject;

/// Forward reference
///  The names are prefixed with DFS (DummyFS)
static VOID DFSUnload(PDRIVER_OBJECT);
static NTSTATUS DFSControl(PDEVICE_OBJECT, PIRP);
static NTSTATUS DFSCreate(PDEVICE_OBJECT, PIRP);
static NTSTATUS DFSClose(PDEVICE_OBJECT, PIRP);
static NTSTATUS DFSDispatch(PDEVICE_OBJECT, PIRP);

/// Some usefull defines
#define TracePrint DbgPrint

/** DriverEntry
 * This is a trivial driver, with a trivial entry point.
 * @brief This is the entry point for the driver.
 * @param DriverObject [IN] the driver object for this driver.
 * @param RegistryPath [IN] the path to this driver's key.
 * @return Success
 */
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
	NTSTATUS code;
	UNICODE_STRING driverName, driverDosName;

	TracePrint("[DummyFS] Driver Entry (DummyFS - Step1) !\n");
	
	// Save driver object pointer
	DummyDriverObject = DriverObject;
	// Set up dispatch entry point.
	DriverObject->MajorFunction[IRP_MJ_FILE_SYSTEM_CONTROL] = DFSDispatch;

	// Other Entry Points - Testing

	DriverObject->MajorFunction[IRP_MJ_CREATE] = DFSCreate;
	DriverObject->MajorFunction[IRP_MJ_CLOSE] = DFSClose;
	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DFSControl;
	
	DriverObject->MajorFunction[IRP_MJ_PNP] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_POWER] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_READ] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_WRITE] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_FLUSH_BUFFERS] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_QUERY_INFORMATION] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_SET_INFORMATION] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_INTERNAL_DEVICE_CONTROL] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_SYSTEM_CONTROL] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_CLEANUP] = DFSDispatch;
	DriverObject->MajorFunction[IRP_MJ_SHUTDOWN] = DFSDispatch;
	

	// Set up unload entry point.
	DriverObject->DriverUnload = DFSUnload;
	// Initialize the name string for the file system Dummy device	object.
	RtlInitUnicodeString(&driverName, FSD_DRIVER_NAME);
	// Create the named device object.
	code = IoCreateDevice(	DummyDriverObject,
							0,
							&driverName,
							FILE_DEVICE_CD_ROM_FILE_SYSTEM, /*FILE_DEVICE_DISK_FILE_SYSTEM, /*FILE_DEVICE_NETWORK_FILE_SYSTEM, */
							0,
							FALSE,
							&DummyDeviceObject);
	if (!NT_SUCCESS(code)) 
	{
		DbgPrint("[DummyFS] Dummy failed to load, failure in IoCreateDevice call returned 0x%x\n", code);
		return (code);
	}

	
	// Create a symbolic link to the DOS Name
	RtlInitUnicodeString(&driverDosName, FSD_DRIVER_DOS_NAME);
	code = IoCreateSymbolicLink(&driverDosName, &driverName);
	if (!NT_SUCCESS(code)) 
	{
		DbgPrint("[DummyFS] CreateSymbolicName failed, code = 0x%x\n", code);
		IoDeleteDevice(DummyDeviceObject);
		DummyDeviceObject = 0;
		return (code);
	}
	

	// Register the device object as a file system.
	
	IoRegisterFileSystem(DummyDeviceObject);
	//IoUnregisterFileSystem(DummyDeviceObject); 

	// Done!
	TracePrint("[DummyFS] Dummy loaded !\n");
	return STATUS_SUCCESS;
}

/** DFSUnload
 *
 * This is the function is called when the OS has determined
 * that their are no more references to the device Object.
 * It is our job to unregister ourselves as a File System and
 * delete the Device Object we created. 
 *
 * Some of the actions performed should already be done. In
 * fact, they must be done before, else the driver won't be
 * unloaded by the driver manager, and the driver will stay
 * in UNLOAD_PENDING mode.
 *
 * @param DeviceObject [IN] presumably our device object
 *
 */
static VOID DFSUnload(PDRIVER_OBJECT DriverObject)
{
	UNICODE_STRING driverDosName;

	// Delete our device object.
	TracePrint("[DummyFS] Ask for unload.\n");
	// Remove the symbolic link
	RtlInitUnicodeString(&driverDosName, FSD_DRIVER_DOS_NAME);
	IoDeleteSymbolicLink(&driverDosName);

	if (DummyDeviceObject) 
	{
		// Unregister the File System - Should be already done
		IoUnregisterFileSystem(DummyDeviceObject);

		// Delete the Device - Should be done too
		IoDeleteDevice(DummyDeviceObject);
		DummyDeviceObject = 0;
	}
	TracePrint("[DummyFS] Dummy unloaded.\n");
}

/** DFSCreate
 *
 * This is the create function. 
 * It handles all the create requests to our driver.
 *
 * Currently it does only return SUCCESS if the DeviceObject is 
 * ours, in order the CreateFile("\\\\.\\\OurDevice") to work.
 * 
 *
 * @param DeviceObject [IN] presumably our device object
 * @param Irp [IN] the mount/load request
 * @return Status code :
 *   - STATUS_NOT_IMPLEMENTED - something other than we can do
 *   - SUCCESS - create was successfull
 */
static NTSTATUS DFSCreate(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
	TracePrint("[DummyFS] DFSCreate\n");
	if (DeviceObject == DummyDeviceObject) 
	{
		// Our driver
		Irp->IoStatus.Status = STATUS_SUCCESS;
		Irp->IoStatus.Information = 0;
		IoCompleteRequest(Irp, IO_NO_INCREMENT);
		return STATUS_SUCCESS;
	}

	// Not ours, we don't do anything from now.
	Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
	Irp->IoStatus.Information = 0;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return STATUS_NOT_IMPLEMENTED;
}

/** DFSClose
 *
 * This is the close function. 
 * It handles all the close requests to our driver.
 *
 * Currently it does only return SUCCESS if the DeviceObject is 
 * ours, in order the CloseHandle to work.
 * 
 *
 * @param DeviceObject [IN] presumably our device object
 * @param Irp [IN] the mount/load request
 * @return Status code :
 *   - STATUS_NOT_IMPLEMENTED - something other than we can do
 *   - SUCCESS - close was successfull
 */
static NTSTATUS DFSClose(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
	TracePrint("[DummyFS] DFSClose\n");

	if (DeviceObject == DummyDeviceObject) 
	{
		// Our driver
		Irp->IoStatus.Status = STATUS_SUCCESS;
		Irp->IoStatus.Information = 0;
		IoCompleteRequest(Irp, IO_NO_INCREMENT);
		return STATUS_SUCCESS;
	}

	// Not ours, we don't do anything from now.
	Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
	Irp->IoStatus.Information = 0;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return STATUS_NOT_IMPLEMENTED;
}


/** DFSControl
 *
 * This is the dispatch function for IOCTL codes. 
 * It handles all the IOCTLS to our driver.
 *
 * @param DeviceObject [IN] presumably our device object
 * @param Irp [IN] the mount/load request
 * @return Status code :
 *   - STATUS_NOT_IMPLEMENTED - something other than we can do
 *   - SUCCESS - IOCTL was successfull
 */
static NTSTATUS DFSControl(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
	PIO_STACK_LOCATION irpSp = IoGetCurrentIrpStackLocation(Irp);
	UNICODE_STRING driverName;
	NTSTATUS code;

	//TracePrint("[DummyFS] DFSControl - IOCTL = 0x%x\n", irpSp->Parameters.DeviceIoControl.IoControlCode);

	/// Check for our DeviceObject
	if (DeviceObject != DummyDeviceObject) 
	{
		// Not ours.
		Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
		Irp->IoStatus.Information = 0;
		IoCompleteRequest(Irp, IO_NO_INCREMENT);
		return STATUS_NOT_IMPLEMENTED;
	}

	switch (irpSp->Parameters.DeviceIoControl.IoControlCode)
	{
		case IOCTL_DUMMYFS_UNREGISTERFS :
			// Unregister our FileSystem
			//  This is mandatory to remove the reference on our device object,
			//  else it won't be possible to unload our driver.
			TracePrint("[DummyFS] DFSControl - IOCTL DummyFS_UnregisterFS\n");

			Irp->IoStatus.Status = STATUS_SUCCESS;
			Irp->IoStatus.Information = 0;
			IoCompleteRequest(Irp, IO_NO_INCREMENT);

			// Prepare the driver to be unloaded : 
			//  - unregister the FS
			//  - for a FSD to be unloaded, all the device must be deleted, so delete it.
			// It may be an idea to call DFSUnload instead of duplicate the code.
			IoUnregisterFileSystem(DummyDeviceObject);
			IoDeleteDevice(DummyDeviceObject);
			DummyDeviceObject = 0;
			return STATUS_SUCCESS;
			
		// Well, for now we don't do anything exciting :)
		default:
			// The function is not implemented
			TracePrint("[DummyFS] DFSControl - Unknown IOCTL = 0x%x\n", irpSp->Parameters.DeviceIoControl.IoControlCode);
			Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
			Irp->IoStatus.Information = 0;
			IoCompleteRequest(Irp, IO_NO_INCREMENT);
			return STATUS_NOT_IMPLEMENTED;
	}

	// Hum, we should never go there, but who knows...
	DbgPrint("[DummyFS] DummyFsControl end reached.");
	Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
	Irp->IoStatus.Information = 0;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return STATUS_NOT_IMPLEMENTED;
}

/** DFSDispatch
 *
 * This is the dispatch function. 
 * It handles all the requests to our driver, and dispatch them in 
 * the appropriates functions.
 *
 * @param DeviceObject [IN] presumably our device object
 * @param Irp [IN] the mount/load request
 * @return Status code :
 *   - STATUS_NOT_IMPLEMENTED - something other than we can do
 *   - SUCCESS - load was successfull
 */
static NTSTATUS DFSDispatch(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
	PIO_STACK_LOCATION irpSp = IoGetCurrentIrpStackLocation(Irp);
	UNICODE_STRING driverName;
	NTSTATUS code;

	TracePrint("[DummyFS] DFsDispatch - Maj = %x, Min = %x\n", irpSp->MajorFunction, irpSp->MinorFunction);

	/// Check for our DeviceObject
	if (DeviceObject != DummyDeviceObject) 
	{
		// Not ours.
		Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
		Irp->IoStatus.Information = 0;
		IoCompleteRequest(Irp, IO_NO_INCREMENT);
		return STATUS_NOT_IMPLEMENTED;
	}

	switch (irpSp->MajorFunction)
	{
		// Well, for now we don't do anything exciting :)
		default:
			// The function is not implemented
			TracePrint("[DummyFS] DummyFsControl - Not Implemented.\n");
			Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
			Irp->IoStatus.Information = 0;
			IoCompleteRequest(Irp, IO_NO_INCREMENT);
			return STATUS_NOT_IMPLEMENTED;
	}

	// Hum, we should never go there, but who knows...
	DbgPrint("[DummyFS] DummyFsControl end reached.");
	Irp->IoStatus.Status = STATUS_NOT_IMPLEMENTED;
	Irp->IoStatus.Information = 0;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return STATUS_NOT_IMPLEMENTED;
}

