To build this documentation you must have :
 - a XSLT parser. I use the free xstlproc.
 - a GNU make (not Microfost's nmake),
 - gVim, also free, to generate the html output