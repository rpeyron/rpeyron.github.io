config_filename = "config.xml"

IN_FILE_HEADER = "jobs/VD_Jobs_Header.txt"
IN_FILE_FOOTER = "jobs/VD_Jobs_Footer.txt"

IN_FILE_MAIN   = "jobs/VD_Jobs_Main_DivX_250.job"
IN_DEST_PREFIX = "New - "
IN_TXT_NEWITEM = "New Item"
OUT_FILE       = "VD_Jobs.jobs"

IN_JOBLIST_REP = "jobs/"

import re;
import string;
import dircache;
import sys;
import os.path;
import shutil;
import xml.parsers.expat;
import xml.dom.minidom;


# #########################################################################
# Gestion des parametres : fichier config.xml
def getText(nodelist):
    rc = ""
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc = rc + node.data
    return rc

def config():
	global config_filename;
	
	# General Variable Parser :
	#  parse le fichier XML
	#  pour chaque element, modifie le param�tre global
	#  ATTENTION : COMPLETEMENT NON SECURE !
	#  si des elements fils de tageName "element" existes, alors => tableau
	try:
		dom = xml.dom.minidom.parse(config_filename);
		for element in dom.getElementsByTagName("config")[0].childNodes:
			if element.nodeType != element.ELEMENT_NODE: 
				continue;
			els = element.getElementsByTagName("element");
			val = ""
			if len(els) == 0:
				# Gestion d'un param�tre de type chaine
				val += getText(element.childNodes);
			else:
				# Gestion d'un param�tre de type tableau
				val = [];
				for el in els:
					val.append(getText(el.childNodes));
			globals()[element.tagName] = val;
		dom.unlink();
	except:
                print "[ERROR] While parsing the config file.";
                sys.__excepthook__(sys.exc_info()[0], sys.exc_info()[1], sys.exc_info()[2]);

