#! /usr/bin/env python

import os
import os.path
import string
import sys

# replaceTokens
#  - tokens : dictionnary of tokens {'%TOKEN%' : 'replace with'}
#  - inStr  : string to be processed
# Returns the resulting string
def replaceTokens(tokens, inStr):
    str = inStr
    for token, value in tokens.items():
        str = string.replace(str, token, value)
    return str

# Convert / to \, and escape \ to \\
def escapeSlashes(inStr):
    str = inStr
    str = string.replace(str, '/','\\')
    str = string.replace(str, '\\', '\\\\')
    return str

def readFile(file):
    fin = open(file,"r")
    str = fin.read()
    fin.close()
    return str

# createJobTokens : 
#  - job : this is the job definition (in, out, job)
# Returns a dictionnary of tokens
#  %JOBNAME%    Name of the Job
#  %INPUTFILE%  job['In']
#  %OUTPUTFILE% job['Out']
#  %INPUTFILE_SLASH% job['In'] with escaped slashes
#  %OUTPUTFILE_SLASH% job['Out'] with escaped slashes
def createJobTokens(job):
    tokens = {}
    tokens['%JOBNAME%'] = os.path.basename(job['In'])
    tokens['%INPUTFILE%'] = job['In']
    tokens['%OUTPUTFILE%'] = job['Out']
    tokens['%INPUTFILE_SLASH%'] = escapeSlashes(job['In'])
    tokens['%OUTPUTFILE_SLASH%'] = escapeSlashes(job['Out'])
    return tokens

# processJob : do all the stuff related to a job
#  - job : the job vector.
# Returns the resulting string
def processJob(job):
    tokens = createJobTokens(job)
    str = readFile(job['Job'])
    str = replaceTokens(tokens, str)
    return str

# processList : do all the stuff related to a joblist
#  * process each job
#  * add the header and the footer
#  * make the correct tokens replacements
# - jobList : array of dictionnaries 
#     jobList[n]['In']  : Input AVI File
#     jobList[n]['Out'] : Output AVI File
#     jobList[n]['Job'] : Job File 
# - headerFileName
# - footerFileName
# - outFileName
def processList(jobList, headerFileName, footerFileName, outFileName):
    str = ""
    for job in jobList:
        str += processJob(job)
    numJobs = string.count(str, "// $job ")
    header = readFile(headerFileName)
    footer = readFile(footerFileName)
    header = replaceTokens({'%NUMJOBS%' : `numJobs`},header)
    fout = open(outFileName, "w")
    fout.write(header)
    fout.write(str)
    fout.write(footer)
    fout.close()
    return
    
    
    
    
    
