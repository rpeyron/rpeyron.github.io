from wxPython.wx import *

import os
import os.path
import vdjobmake

import config

ID_EXIT     =   101;
ID_ABOUT    =   102;
ID_SAVE     =   103;

IC_LIST     =   201;
IC_SPLITTER =   202;
IC_PANEL    =   203;

ID_TXT_SRC = 210;
ID_TXT_DEST = 211;
ID_COMBO_JOB = 212;

ID_TOOL_EXIT=   301;
ID_TOOL_SAVE=   302;
ID_TOOL_ADD = 303;
ID_TOOL_DELETE= 304;

ID_BTN_ADD = 401;
ID_BTN_DEL = 402;
ID_BTN_APPLY = 403;
ID_BTN_BW_SRC = 404;
ID_BTN_BW_DEST = 405;
ID_BTN_BW_JOB = 406;

# This create Defaults Names
# --> unused, moved in the class MyFrame
# Input : base filename
# Return : 3-tuple (srcFile, destFile, jobFile)
def createDefaultNames(file):
    dir, filename = os.path.split(file);
    srcFile = file;
    destFile = os.path.join(dir,config.IN_DEST_PREFIX + filename);
    jobFile = config.IN_FILE_MAIN;
    if file == config.IN_TXT_NEWITEM:
        return (srcFile,"",jobFile)
    return (srcFile, destFile, jobFile);

# This class is used to be able to handle the Drag'n Drop on the grid
#  - self.list : the gridlist we use.
class MyDropTarget(wxFileDropTarget):
    def __init__(self, list, frame):
        wxFileDropTarget.__init__(self)
        self.list = list
        self.frame = frame

    def OnDropFiles(self, x, y, filenames):
        #self.window.SetInsertionPointEnd()
        #self.window.WriteText("\n%d file(s) dropped at %d,%d:\n" %
        #                      (len(filenames), x, y))
        for file in filenames:
            (srcFile, destFile, jobFile) = self.frame.createDefaultNames(file)
            self.list.InsertStringItem(self.list.GetItemCount(),srcFile)
            self.list.SetStringItem(self.list.GetItemCount()-1, 1, destFile);
            self.list.SetStringItem(self.list.GetItemCount()-1, 2, jobFile);
        
# This is our Frame.
#  Well, we will do almost everything in there, so it is a bit complicated
class MyFrame(wxFrame):

    # Initialisation ----------------------------------------------------

    def __init__(self, parent, ID, title):
        wxFrame.__init__(self, parent, ID, title, wxDefaultPosition, wxSize(500, 450));
        self.SetBackgroundColour(wxSystemSettings_GetColour(wxSYS_COLOUR_BTNFACE))
        self.initMenu(parent);
        self.initCtls(parent);

    # Configure the Grid List (Columns and Drop Target)
    def initList(self, parent):
        parent.InsertColumn(col=0, heading='Source', width=-1);
        parent.InsertColumn(col=1, heading='Destination', width=-1);
        parent.InsertColumn(col=2, heading='Job', width=-1);
        dropTarget = MyDropTarget(parent, self);
        parent.SetDropTarget(dropTarget);
        EVT_SIZE(self, self.OnResize)
        
    # Create the controls and register the corresponding events :
    #  self.sizer       : root sizer
    #  self.list         : List Control (see initList)
    #  gridjob          : Flew Grid Sizer containing the job pane
    
    def initCtls(self, parent):
        self.sizer = wxBoxSizer(wxVERTICAL);
        self.SetSizer(self.sizer);

        # List Control
        self.list = wxListCtrl(
                        id = IC_LIST,
                        name = 'listCtrl',
                        parent = self,
                        pos = wxPoint(0,0),
                        size = wxSize(-1,-1),
                        style = wxLC_REPORT | wxLC_SINGLE_SEL ,
                        validator = wxDefaultValidator);
        self.sizer.Add(self.list, 2, wxEXPAND);
        self.initList(self.list);
        #  handle Delete Key
        EVT_LIST_KEY_DOWN(self, IC_LIST, self.OnListKey)          
        #  handle Selection Change
        EVT_LIST_ITEM_SELECTED(self, IC_LIST, self.OnListItem)


        # Job Pane
        gridJob = wxFlexGridSizer(3, 3, 2, 5)

        self.label_1 = wxStaticText(self, -1, "Source")
        self.label_2 = wxStaticText(self, -1, "Target")
        self.label_3 = wxStaticText(self, -1, "Job")

        self.txtSource = wxTextCtrl(self, ID_TXT_SRC, "")
        self.txtTarget = wxTextCtrl(self, ID_TXT_DEST, "")
        self.comboJob = wxComboBox(self, ID_COMBO_JOB, choices=[], style=wxCB_DROPDOWN)
        self.populateDropDown()

        self.btnBrowseSource = wxBitmapButton(self, ID_BTN_BW_SRC, wxBitmap("img/open.xpm", wxBITMAP_TYPE_XPM))
        self.btnBrowseTarget = wxBitmapButton(self, ID_BTN_BW_DEST, wxBitmap("img/open.xpm", wxBITMAP_TYPE_XPM))
        self.btnBrowseJob = wxBitmapButton(self, ID_BTN_BW_JOB, wxBitmap("img/open.xpm", wxBITMAP_TYPE_XPM))

        gridJob.Add(self.label_1, 0, wxALIGN_CENTER_VERTICAL, 0)
        gridJob.Add(self.txtSource, 0, wxEXPAND, 0)
        gridJob.Add(self.btnBrowseSource, 0, 0, 0)
        gridJob.Add(self.label_2, 0, wxALIGN_CENTER_VERTICAL, 0)
        gridJob.Add(self.txtTarget, 0, wxEXPAND, 0)
        gridJob.Add(self.btnBrowseTarget, 0, 0, 0)
        gridJob.Add(self.label_3, 0, wxALIGN_CENTER_VERTICAL, 0)
        gridJob.Add(self.comboJob, 0, wxEXPAND, 0)
        gridJob.Add(self.btnBrowseJob, 0, 0, 0)

        gridJob.AddGrowableCol(1)
        
        self.sizer.Add(gridJob, 0, wxEXPAND | wxALL,5)
        
        EVT_BUTTON(self,ID_BTN_BW_SRC, self.OnBtnBwSrc)
        EVT_BUTTON(self,ID_BTN_BW_DEST, self.OnBtnBwDest)
        EVT_BUTTON(self,ID_BTN_BW_JOB, self.OnBtnBwJob)
        EVT_TEXT(self,ID_TXT_SRC, self.OnChangedSrc)
        EVT_TEXT(self,ID_TXT_DEST,self.OnChangedDest)
        EVT_TEXT(self,ID_COMBO_JOB,self.OnChangedJob)
        
        # Boutons pour g�rer
        btnSizer = wxBoxSizer(wxHORIZONTAL)
        self.btnAdd = wxButton(self, ID_BTN_ADD, "&Add", wxPoint(-1,-1))
        self.btnDel = wxButton(self, ID_BTN_DEL, "&Delete", wxPoint(-1,-1))
        btnSizer.Add(self.btnAdd, 0,0,0)
        btnSizer.Add(self.btnDel, 0,0,0)
        self.sizer.Add(btnSizer, 0, wxALIGN_CENTER  | wxBOTTOM, 5)
        
        EVT_BUTTON(self,ID_BTN_ADD, self.OnAdd)
        EVT_BUTTON(self,ID_BTN_DEL, self.OnDelete)
        
        self.Layout()
        
    # Build the menu and register the corresponding events.
    def initMenu(self, parent):
        self.CreateStatusBar();
        self.SetStatusText("Initialising...");

        menu = wxMenu();
        menu.Append(ID_SAVE, "&Save...", "Save the current job list.");
        menu.AppendSeparator();
        menu.Append(ID_ABOUT,"&About", "About this program");
        menu.Append(ID_EXIT, "&Exit", "Terminate the program");

        menuBar = wxMenuBar();
        menuBar.Append(menu, "&File");

        self.SetMenuBar(menuBar);

        tb = self.CreateToolBar(wxTB_FLAT,-1,"ToolBar");
        tb.AddSimpleTool(ID_TOOL_EXIT, wxBitmap("img/misc06.xpm",wxBITMAP_TYPE_XPM), "Quit", "Terminate the program")
        tb.AddSimpleTool(ID_TOOL_SAVE, wxBitmap("img/save.xpm",wxBITMAP_TYPE_XPM), "Save", "Save the job list.")
        tb.AddSeparator()
        tb.AddSimpleTool(ID_TOOL_ADD, wxBitmap("img/open.xpm",wxBITMAP_TYPE_XPM), "Delete", "Delete the selected jobs.")
        tb.AddSimpleTool(ID_TOOL_DELETE, wxBitmap("img/delete.xpm",wxBITMAP_TYPE_XPM), "Delete", "Delete the selected jobs.")
        tb.Realize()

        EVT_MENU(self,  ID_EXIT, self.OnQuit);
        EVT_MENU(self,  ID_ABOUT, self.OnAbout);
        EVT_MENU(self,  ID_SAVE, self.OnSave);
        EVT_TOOL(self,  ID_TOOL_EXIT, self.OnQuit);
        EVT_TOOL(self,  ID_TOOL_SAVE, self.OnSave);
        EVT_TOOL(self,  ID_TOOL_ADD, self.OnAdd);
        EVT_TOOL(self,  ID_TOOL_DELETE, self.OnDelete);
        EVT_IDLE(self, self.OnReady);

    def populateDropDown(self):
        for jobfile in os.listdir(config.IN_JOBLIST_REP):
            (root, ext) = os.path.splitext(jobfile)
            if ext == ".job":
                self.comboJob.Append(config.IN_JOBLIST_REP+jobfile)

        
    # Events ------------------------------------------------------------

    def OnQuit(self, event):
        self.Close(true);

    def OnReady(self, event):
        self.SetStatusText("Ready.");

    def OnAbout(self, event):
        dlg = wxMessageDialog(self, 
                    "This sample program shows off\n"
                        "frames, menus, statusbars, and this\n"
                        "message dialog.\n",
                    "About..." , wxOK | wxICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()

    # OnSave : Cr�ation de la JobList
    def OnSave(self, event):
        wildcard = "Job Lists (*.jobs)|*.jobs|Text Files (*.txt)|*.txt|All files (*.*)|*.*";
        dlg = wxFileDialog(self, "Save job list as...", "", config.OUT_FILE, wildcard, wxSAVE);
        if dlg.ShowModal() == wxID_OK:
            vdjobmake.processList(self.createList(), config.IN_FILE_HEADER, config.IN_FILE_FOOTER, dlg.GetPath());
        dlg.Destroy();

    def OnAdd(self, event):
        self.list.InsertStringItem(self.list.GetItemCount(),config.IN_TXT_NEWITEM)
        self.list.EnsureVisible(self.list.GetItemCount())
        self.currentItem = self.list.GetItemCount() - 1
        self.list.SetItemState(self.list.GetItemCount()-1,wxLIST_STATE_SELECTED, wxLIST_STATE_SELECTED)
        self.OnBtnBwSrc(None)

    def OnDelete(self, event):
        item = -1;
        while 1:
            item = self.list.GetNextItem(item, wxLIST_NEXT_ALL, wxLIST_STATE_SELECTED);
            if item == -1:
                 break;
            self.list.DeleteItem(item);
            item = item - 1;
        

    # OnListKey : Handler quand une touche est appuy�e sur la liste
    #  On souhaite pouvoir supprimer des entr�es de la liste.
    def OnListKey(self, event):
        if event.GetKeyCode() ==  WXK_DELETE :
            self.OnDelete(event)

    # OnListItem : modification d'un item
    def OnListItem(self, event):
        self.currentItem = event.GetIndex()
        self.txtSource.SetValue(self.list.GetItem(event.GetIndex(),0).GetText())
        self.txtTarget.SetValue(self.list.GetItem(event.GetIndex(),1).GetText())
        self.comboJob.SetValue(self.list.GetItem(event.GetIndex(),2).GetText())
          
    def OnResize(self, event):
        width = self.GetClientSize().GetWidth() / 3 - 2
        self.list.SetColumnWidth(0, width)
        self.list.SetColumnWidth(1, width)
        self.list.SetColumnWidth(2, width)
        self.Layout()
        
    def OnBtnBwSrc(self, event):
        wildcard = "AVI Files (*.avi)|*.avi|MPEG Files (*.mpeg)|*.mpeg|All files (*.*)|*.*";
        (dirname, filename) = os.path.split(self.txtSource.GetValue())
        dlg = wxFileDialog(self, "Choose a file", dirname, filename, wildcard, wxOPEN)
        if dlg.ShowModal() == wxID_OK:
            self.txtSource.SetValue(dlg.GetPath())
        dlg.Destroy()
        

    def OnBtnBwDest(self, event):
        wildcard = "AVI Files (*.avi)|*.avi|MPEG Files (*.mpeg)|*.mpeg|All files (*.*)|*.*";
        (dirname, filename) = os.path.split(self.txtTarget.GetValue())
        dlg = wxFileDialog(self, "Choose a file", dirname, filename, wildcard, wxOPEN)
        if dlg.ShowModal() == wxID_OK:
            self.txtTarget.SetValue(dlg.GetPath())
        dlg.Destroy()

    def OnBtnBwJob(self, event):
        global IN_JOBLIST_REP
        wildcard = "Job Files (*.job)|*.job|Text Files (*.txt)|*.txt|All files (*.*)|*.*";
        (dirname, filename) = os.path.split(self.comboJob.GetValue())
        if dirname == "" : dirname = IN_JOBLIST_REP
        dlg = wxFileDialog(self, "Choose a file", dirname, filename, wildcard, wxOPEN)
        if dlg.ShowModal() == wxID_OK:
            self.comboJob.SetValue(dlg.GetPath())
        dlg.Destroy()
        self.OnChangedJob(None)

    def OnChangedSrc(self, event):
        self.list.SetStringItem(self.currentItem, 0, self.txtSource.GetValue())
        if self.txtTarget.GetValue() == "":
             (srcFile, destFile, jobFile) = createDefaultNames(self.txtSource.GetValue())
             self.txtTarget.SetValue(destFile)
             self.comboJob.SetValue(jobFile)
             self.OnChangedJob(None)

    def OnChangedDest(self, event):
        self.list.SetStringItem(self.currentItem, 1, self.txtTarget.GetValue())

    def OnChangedJob(self, event):
        self.list.SetStringItem(self.currentItem, 2, self.comboJob.GetValue())

    # Process ----------------------------------------------------------

    # Fonction Interne qui va cr�er la liste de fichiers contenus dans 
    #   le controle liste � passer � processList.
    def createList(self):
        theList = [];
        for i in range(self.list.GetItemCount()):
                theList.append({
                    "In"    : self.list.GetItem(i,0).GetText(),
                    "Out"   : self.list.GetItem(i,1).GetText(),
                    "Job"   : self.list.GetItem(i,2).GetText()
                 });
        return theList;

    # This create Defaults Names
    # Input : base filename
    # Return : 3-tuple (srcFile, destFile, jobFile)
    def createDefaultNames(self, file):
        dir, filename = os.path.split(file);
        srcFile = file;
        destFile = os.path.join(dir,config.IN_DEST_PREFIX + filename);
        if self.comboJob.GetValue() == "":
            jobFile = config.IN_FILE_MAIN;
        else:
            jobFile = self.comboJob.GetValue();
        if file == config.IN_TXT_NEWITEM:
            return (srcFile,"",jobFile)
        return (srcFile, destFile, jobFile);


# Main Application GUI class
class MyApp(wxApp):
    def OnInit(self):
        frame = MyFrame(NULL, -1, "Virtual Dub Jobs Maker")
        frame.Show(true)
        self.SetTopWindow(frame)
        return true

# Launch the Application in GUI mode
def interfMain():
    app = MyApp(0)
    app.MainLoop()
    
# Auto Launch
if __name__ == "__main__":
    interfMain();