#! /usr/bin/env python

# Virtual Dub Jobs Maker  (c) 2003 - R�mi Peyronnet
"""
Virtual Dub Jobs Maker
"""

import string;
import sys;

import vdjobmake;
import vdgui;
import config;

# Main -----------------------------------------------------------------------

def main():
    # demo();
    vdgui.interfMain();


print "VirtualDubJobsMaker (c) 2003 - R�mi Peyronnet"

try:
    config.config();
    main();
except:
    print "[ERROR] \n"
    sys.__excepthook__(sys.exc_info()[0], sys.exc_info()[1], sys.exc_info()[2]);

# Wait 
#print "Done. Press enter to quit.";
#sys.stdin.read(1)
    

