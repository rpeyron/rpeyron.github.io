// QuickLaunch.cpp : Defines the entry point for the application.
//

#include <windows.h>
#include <direct.h>
#include <stdlib.h>
#include <stdio.h>

const char _section[]="Button3";
const char filename[]="quicklaunch.ini";

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	char inifile[1024],cmd[1024],param[1024], *section;
	char *cl, drive[_MAX_DRIVE], path[_MAX_DIR], fn[_MAX_FNAME], ext[_MAX_EXT] ;
	HWND myWnd;
	int show, wmcommand;
	// QuickStartButton works as follow :
	//  - Button1 : start Button1
	//  - Button2 (URL) : start Button1 Button2
	//  - Button3 (URL) : start Button1 Button3
	//  - Button4 : start Button4
	// So we see if there is any arg and if there is, we take it instead of the CL
	if (strlen(lpCmdLine) != 0) cl = lpCmdLine;
							else cl = GetCommandLine();
	if (cl[0] == '"') cl += 1;
	_splitpath(cl, drive, path, fn, ext);
	section = fn;
	// getcwd(inifile,1023);	strcat(inifile,"\\");
	strcpy(inifile, drive);
	strcat(inifile, path);
	strcat(inifile,filename);
	//MessageBox(NULL,cl,"inifile",MB_OK);
	//printf("%s\n",inifile);

	GetPrivateProfileString(section,"command","",cmd,1023,inifile);
	if (strlen(cmd)!=0)
	{
		GetPrivateProfileString(section,"params","",param,1023,inifile);
		show = GetPrivateProfileInt(section,"show",SW_SHOWNORMAL,inifile);
		ShellExecute(NULL,"open",cmd,param,"",show);
		return 0;
	}
	GetPrivateProfileString(section,"findWindow","",cmd,1023,inifile);
	if (strlen(cmd)!=0)
	{
		myWnd=FindWindow(cmd,NULL);
		wmcommand = GetPrivateProfileInt(section,"wmCommand",0,inifile);
		SendMessage(myWnd,WM_COMMAND, wmcommand,NULL); 
		return 0;
	}
	return -1;
}



