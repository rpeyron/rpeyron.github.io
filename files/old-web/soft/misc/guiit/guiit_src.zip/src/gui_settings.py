#! /usr/bin/python
# -*- coding: latin-1 -*-
#
# Versatile launcher
#
# (c) 2003 - R�mi Peyronnet
# Licence GPL


# Import librairies
import string
import xml.parsers.expat
import xml.dom.minidom
from gui_expr import *
from xml_utils import *
from wxPython.wx import *
# from wxPython.lib.ErrorDialogs import *

# Settings class 

class GuiSettings:
    def __init__(self, filename, encoding):
        self.encoding = encoding
        self.defaultValues()
        if filename != "": 
            self.parseFile(filename)
    
    # Instanciate items and Set Defaults Values
    def defaultValues(self):
        # Strings
        self.string = {}
        self.string["Process"] = "Process"
        self.string["Arguments"] = "Arguments"
        self.string["Outputs"] = "Outputs"
        self.string["mnu_File"] = "File"
        self.string["mnu_File_Quit"] = "Quit"
        self.string["des_File_Quit"] = "Terminate the program"
        self.string["st_Ready"] = "Ready."
        self.string["st_Done"] = "Done."
        self.string["st_Process"] = "Processing in progres..."
        self.string["fl_FileMask"] = "XML Files (*.xml)|*.xml|Text Files (*.txt)|*.txt"
        self.string["mask_AllFiles"] = "All files (*.*)|*.*"
        self.string["st_ChooseFile"] = "Choose the file"
        self.string["st_ChooseDir"] = "Choose the directory"
        self.string["Command"] = "Command"
        self.string["Input"] = "Input"
        self.string["Send"] = "Send"
        self.string["CloseStream"] = "Close the Stream"
        # Parameters
        self.parameter = {}
        self.parameter["display-output"] = "yes"
        self.parameter["display-input"] = "no"
        self.parameter["display-out"] = "no"
        self.parameter["width"] = "500"
        self.parameter["height"] = "450"
        self.parameter["buttons-align"] = "horizontal"
        self.parameter["open-with"] = "notepad.exe"
        self.parameter["update-on-over"] = "no"
        # Functions
        self.func = {}
        # Directory
        self.dir = ""
        
    def parseFile(self, filename):
        try:
            dom = xml.dom.minidom.parse(filename);
        except IOError:
            wxMessageBox("Configuration file not found : " +filename)
            raise
        except xml.sax._exceptions.SAXParseException, e:
            wxMessageBox("[PARSER ERROR]" + e.getMessage() + "[ li " + str(e.getLineNumber()) + " col " + str(e.getColumnNumber()) + " ]")
            raise
        else:
            dom = dom.getElementsByTagName("gui")[0]
            self.parseNode(dom)
            dom.unlink()

    def parseNode(self, node):
        for setting in xmlGetNodes(node, ["settings"]):
            for element in setting.getElementsByTagName("string"):
                self.string[xmlGetAttribute(element, "id", self.encoding)] = xmlGetText(element, self.encoding);
            for element in setting.getElementsByTagName("parameter"):
                self.parameter[xmlGetAttribute(element, "id", self.encoding)] = xmlGetText(element, self.encoding);
            for element in setting.getElementsByTagName("func"):
                lang  = xmlGetAttribute(element, "lang", self.encoding)
                id = xmlGetAttribute(element, "id", self.encoding)
                text = xmlGetText(element, self.encoding)
                if lang=="python":
                    self.func[id] = n_func_python(text)
                else:
                    self.func[id] = n_func_expr(text)
        
