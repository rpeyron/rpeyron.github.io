#! /usr/bin/python
# -*- coding: latin-1 -*-
#
# Versatile launcher
#
# (c) 2003 - R�mi Peyronnet
# Licence GPL

# Import librairies
from wxPython.wx import *
# from wxPython.lib.ErrorDialogs import *
from wxPython.html import *
import os
import string
import sys
import os.path
import xml.parsers.expat
import xml.dom.minidom
from xml_utils import *
from gui_settings import *
import gui_expr
import copy
import traceback
from gui_images import catalog

debugUpdateVar = 0;

# Parse Gui File
def parseGuiFile(filename, parent, panel, settings):
    # Process File
    dom = xml.dom.minidom.Document()
    try:
        dom = xml.dom.minidom.parse(filename);
        dom = dom.getElementsByTagName("gui")[0]
    except IOError:
        wxMessageBox("Configuration file not found : " + filename)
        raise
    except xml.sax._exceptions.SAXParseException, e:
        wxMessageBox("[PARSER ERROR] " + str(e.getMessage()) + "[" + "li" + str(e.getLineNumber()) + "col" + str(e.getColumnNumber()) + "]")
        raise
   
    oldpath = os.getcwd()
    oldsettingsdir = settings.dir
    settings.dir = os.path.dirname(filename)
    if settings.dir: os.chdir(settings.dir)
    settings.dir = os.getcwd()
    elem = parseGuiElement(dom, parent, panel, settings)
    elem.updateVar("","",elem.modeUpdateOnLoad);
    settings.dir = oldsettingsdir
    os.chdir(oldpath)
    return elem


# Create Gui Elements
def parseGuiElement(node, parent, panel, settings):
    tagname = node.nodeName
    # Main Tag Handling : if tab / program elements appears, the behavior should be "tab", otherwise it is "program"
    if tagname == "gui":
        if len(xmlGetNodes(node, ["tab","program","nested"])) > 0:
            tagname = "tab"
        else:
            tagname = "program"
    # Back to normal processing
    if tagname == "nested":
        return parseGuiFile(xmlGetAttribute(node, "href", settings.encoding), parent, panel, settings)
    elif tagname == "tab":
        return GuiPanelTab(parent, panel, node, settings)
    elif tagname == "program":
        return GuiPanelCommand(parent, panel,  node, settings)
    elif tagname == "command":
        return GuiCommand(parent, panel, node, settings)
    elif tagname == "help":
        return GuiHelp(parent, panel, node, settings)
    elif tagname == "arg":
        typename = xmlGetAttribute(node, "type",settings.encoding)
        if typename == "text":
            return GuiItemText(parent, panel,  node, settings)
        elif typename == "file":
            return GuiItemFile(parent, panel,  node, settings)
        elif typename == "dir":
            return GuiItemDir(parent, panel,  node, settings)
        elif typename == "check":
            return GuiItemCheck(parent, panel,  node, settings)
        elif typename == "combo":
            return GuiItemCombo(parent, panel,  node, settings)
        else :
            return GuiItemText(parent, panel,  node, settings)
    elif tagname == "out":
        return GuiItemOut(parent, panel,  node, settings)

class GuiElementNotFound: pass

# GuiElement 
class GuiElement:
    def __init__(self, parent, panel, node, settings):
        self.parent = parent
        self.panel = panel
        self.node = node
        self.settings = copy.deepcopy(settings)
        self.id = xmlGetAttribute(node, "id", settings.encoding)
        self.display = xmlGetAttribute(node, "display", settings.encoding)
        if self.id == "" and (node == None or node.nodeName == "arg" or node.nodeName == "out"): 
            self.id = self.display
        if self.id == "": self.id = "__" + repr(self.node)
        if self.display == "":   self.display = self.id
        self.inUpdate = 0
        self.parseParams()

    def parseParams(self):
        self.params = {}
        params = xmlGetAttribute(self.node, "params", self.settings.encoding)
        for param in params.split(","):
            items = param.split("=")
            if len(items) == 1:
                self.params[items[0]] = 1
            else:
                for item in items[0:len(items)-1]:
                    self.params[item] = items[-1]

    modeUpDown = 0
    modeDownOnly = 1
    modeUpdateOnLoad = 2

    def updateVar(self, var, value, mode = 0):
        if (mode == 0) and (self.parent != None):
            rc = self.parent.updateVar(var, value)
            return rc
        else:
            return 0
    
    def getVar(self, var, mode=0):
        if mode == self.modeDownOnly: raise GuiElementNotFound()
        if self.parent != None:
            return self.parent.getVar(var)
        else:
            return 0
        
# GuiPanel : Main GUI It ! Element.
class GuiPanel(GuiElement, wxScrolledWindow):
    def __init__(self, parent, panel, node, settings):
        GuiElement.__init__(self, parent, panel, node, settings)
        wxScrolledWindow.__init__(self, panel, -1)
        
        self.sizer = wxBoxSizer(wxVERTICAL)
        self.SetSizer(self.sizer)
        self.settings.parseNode(node)
        for introNode in xmlGetNodes(node, ["intro"]):
            panel = GuiIntro(self, self, introNode, self.settings)
            self.addToSizerWithHeight(panel, wxEXPAND, 0)
            
    def addToSizerWithHeight(self, item, flags, border):
        height = xmlGetAttribute(item.node, "height", self.settings.encoding)
        if height != "":
            if height[-1]=="%":
                self.sizer.Add(item, string.atoi(height[0:-1]), flags, border)
            else:
                item.SetSize(wxSize(-1, string.atoi(height)))
                self.sizer.Add(item, 0, flags, border)
        else:
            self.sizer.Add(item, 100, flags, border)
    
    def SetStatusText(self, text):
        self.parent.SetStatusText(text)
        
class GuiPanelTab(GuiPanel):
    def __init__(self, parent, panel, node, settings):
        GuiPanel.__init__(self, parent, panel, node, settings)
        self.tabs = []
        self.notebook = wxNotebook(self, -1)
        # self.notebookSizer = wxNotebookSizer(self.notebook)
        self.notebook.SetBackgroundColour(wxSystemSettings_GetColour(wxSYS_COLOUR_BTNFACE))
        for panelNode in xmlGetNodes(node, ["program","tab","nested"]):
            panel = parseGuiElement(panelNode, self, self.notebook, self.settings)
            self.tabs.append(panel)
            self.notebook.AddPage(panel, panel.display)
        # Add with proportion = 100 to deal with height %
        self.sizer.Add(self.notebook,100,wxEXPAND,0)
        self.FitInside()
        #self.Layout()
        # Small Hack to make scrollbars work
        s = self.GetMinSize()
        self.SetScrollbars(0,1,s.GetWidth(),s.GetHeight())

    def updateVar(self, var, value, mode=0):
        if debugUpdateVar == 1: print "UpdateVar [", self.id, "] ", var, " = ", value
        rc = 0
        for tab in self.tabs:
            if mode == self.modeUpDown:
                rc += tab.updateVar(var, value, self.modeDownOnly)
            else:
                rc += tab.updateVar(var, value, mode)
        rc += GuiPanel.updateVar(self, var, value, mode)
        return rc
    
    def getVar(self, var, mode = 0):
        for tab in self.tabs:
            try:
                result = tab.getVar(var, self.modeDownOnly)
            except GuiElementNotFound:
                pass
            else:
                return result
        return GuiPanel.getVar(self, var, mode)
        
class GuiPanelCommand(GuiPanel):
    def __init__(self, parent, panel, node, settings):
        GuiPanel.__init__(self, parent, panel, node, settings)
        self.items = {}
        
        # Arguments processing
        argNodes = xmlGetNodes(node, ["arg"])
        if len(argNodes) > 0:
            self.argSizer = wxStaticBoxSizer(wxStaticBox(self, -1, self.settings.string["Arguments"]), wxVERTICAL)
            for itemNode in argNodes:
                item = parseGuiElement(itemNode, self, self, self.settings)
                self.items[item.id] = item
                self.argSizer.Add(item, 0, wxEXPAND + wxALL, 2)
            self.sizer.Add(self.argSizer, 0, wxEXPAND + wxALL, 2)
        
        self.commands = {}
        if self.settings.parameter["buttons-align"] == "vertical":
            commandSizer = wxBoxSizer(wxVERTICAL)
        else:
            commandSizer = wxBoxSizer(wxHORIZONTAL)
        for commandNode in xmlGetNodes(self.node, ["command"]):
            button = parseGuiElement(commandNode, self, self, self.settings)
            self.items[button.id] = button
            self.commands[button.id] = button
            commandSizer.Add(button, 1, wxALIGN_CENTER  | wxALL | wxEXPAND, 2)
        self.sizer.Add(commandSizer, 0, wxALIGN_CENTER  | wxALL | wxEXPAND, 2)
            
        self.initCommandItems()
        
        # Output processing
        outNodes = xmlGetNodes(node, ["out"])
        if len(outNodes) > 0:
            self.outSizer = wxStaticBoxSizer(wxStaticBox(self, -1, self.settings.string["Outputs"]), wxVERTICAL)
            for itemNode in outNodes:
                item = parseGuiElement(itemNode, self, self, self.settings)
                self.items[item.id] = item
                self.outSizer.Add(item, 0,  wxEXPAND + wxALL, 2)
            self.sizer.Add(self.outSizer, 0, wxEXPAND + wxALL, 2)

        # Helps
        self.helps = {}
        if self.settings.parameter["buttons-align"] == "vertical":
            helpSizer = wxBoxSizer(wxVERTICAL)
        else:
            helpSizer = wxBoxSizer(wxHORIZONTAL)
        for helpNode in xmlGetNodes(self.node, ["help"]):
            button = parseGuiElement(helpNode, self, self, self.settings)
            self.items[button.id] = button
            self.helps[button.id] = button
            helpSizer.Add(button, 1, wxALIGN_CENTER  | wxALL | wxEXPAND, 2)
        self.sizer.Add(helpSizer, 0, wxALIGN_CENTER  | wxALL | wxEXPAND, 2)

        self.Layout()
        self.FitInside()
        
        # Small Hack to make scrollbars work
        w,h = self.GetSizeTuple()
        self.SetScrollbars(0,1,w,h)
        
    def initCommandItems(self):
        
        # Output
        self.out = wxTextCtrl(self, -1, '', style=wxTE_MULTILINE|wxTE_READONLY)
        #self.out.Enable(false)
        if self.settings.parameter["display-output"] != "yes":
            self.out.Hide()
        else:
            self.sizer.Add(self.out, 2, wxEXPAND | wxALL, 5)
            
        # Input
        sizer = wxBoxSizer(wxHORIZONTAL)
        label = wxStaticText(self, -1, self.settings.string["Input"])
        sizer.Add(label, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 10)
        self.inp = wxTextCtrl(self, -1, '', style=wxTE_PROCESS_ENTER)
        sizer.Add(self.inp, 1, wxEXPAND, 0)
        self.sndBtn = wxButton(self, -1, self.settings.string["Send"], style = wxBU_EXACTFIT)
        sizer.Add(self.sndBtn, 0, 0, 0)
        self.termBtn = wxButton(self, -1, self.settings.string["CloseStream"], style = wxBU_EXACTFIT)
        sizer.Add(self.termBtn, 0, 0, 0)
        self.inp.Enable(false)
        self.sndBtn.Enable(false)
        self.termBtn.Enable(false)
        EVT_BUTTON(self, self.sndBtn.GetId(), self.OnSendText)
        EVT_BUTTON(self, self.termBtn.GetId(), self.OnCloseStream)
        EVT_TEXT_ENTER(self, self.inp.GetId(), self.OnSendText)
        if self.settings.parameter["display-input"] != "yes":
            label.Hide()
            self.inp.Hide()
            self.sndBtn.Hide()
            self.termBtn.Hide()
        else:
            self.sizer.Add(sizer, 0, wxEXPAND | wxALL, 5)

        EVT_END_PROCESS(self, -1, self.OnProcessEnded)
        EVT_IDLE(self, self.OnIdle)

    def updateVar(self, var, value,mode=0):
        if debugUpdateVar == 1: print "UpdateVar / GuiPanelCommand [", self.id, "] ", var, " = ", value
        rc = 0
        for item in self.items:
            if mode == self.modeUpDown:
                rc += self.items[item].updateVar(var, value, self.modeDownOnly)
            else:
                rc += self.items[item].updateVar(var, value, mode)
        rc += GuiPanel.updateVar(self, var, value, mode)        
        return rc
    
    def getVar(self, var, mode = 0):
        for item in self.items:
            if self.items[item].id == var:
                return self.items[item].getValue()
        return GuiPanel.getVar(self, var, mode)
        
    def OnSendText(self, evt):
        text = self.inp.GetValue()
        for command in self.commands:
            self.commands[command].sendText(text)
        self.inp.SetValue('')
        self.inp.SetFocus()
    
    def OnCloseStream(self, evt):
        for command in self.commands:
            self.commands[command].closeStream()
    
    def OnProcessEnded(self, evt):
        for command in self.commands:
            self.commands[command].processEnded()
        
    def OnIdle(self, evt):
        for command in self.commands:
            self.commands[command].idle()
        
    def enableCommands(self, bool):
        for command in self.commands:
            self.commands[command].button.Enable(bool)
        self.inp.Enable(not bool)
        self.sndBtn.Enable(not bool)
        self.termBtn.Enable(not bool)

# GuiItem

class GuiItem(GuiElement, wxBoxSizer):
    def __init__(self, parent, panel, node, settings):
        wxBoxSizer.__init__(self, wxHORIZONTAL)
        GuiElement.__init__(self, parent, panel, node, settings)
        self.sizer = self 
        if self.params.has_key("notrim"):
            self.expr = xmlGetText(node, settings.encoding)
        else:
            self.expr = xmlGetText(node, settings.encoding, 1)
        self.compiled = gui_expr.exprEvaluate(self.expr)
        self.value = self.expr
        
    def getValue(self):
        if (self.expr == self.value): self.updateVar("", "", self.modeDownOnly)
        return self.value

    # TODO : Pose probl�me en cas de mise � jour d'un �l�ment sur une page distante d�pendant 
    # d'un �l�ment de m�me nom et syntaxiquement plus proche. 
    # Cependant ce n'est pas grave, cela provoque juste une exception...
    def updateVar(self, var, value, mode=0):
        if ((mode == self.modeUpdateOnLoad) and (not self.params.has_key('onload'))): return 0;
        before = self.value
        if (var == "") and (self.inUpdate == 0):
            self.inUpdate = 1
            for item in self.parent.items:
                if self.compiled.depends(item, self):
                    self.parent.items[item].updateVar(var, value, mode)
            self.inUpdate = 0
        if (var == self.id) and (self.inUpdate == 0):
            self.value = value
            return -1
        elif not(self.params.has_key("nointerpret")) and (((var == "") and (self.value == self.expr)) or self.compiled.depends(var, self)):
            try:
                self.value = self.compiled.get(self)
                if debugUpdateVar == 1:  print "updateVar / GuiItem", self.id, "] ", var, " = ", value, "->", self.value, " was ", before
            except:
                print "[ERROR] While updating ", self.id, "(for", var,"=",value, ") =", self.value
                traceback.print_exc()
                self.value = ""
                #raise
            if self.value != before:
                return 1
        return 0
        
class GuiItemText(GuiItem):
    def __init__(self, parent, panel, node, settings):
        GuiItem.__init__(self, parent, panel, node ,settings)
        # Label Creation
        self.label = wxStaticText(self.panel, -1, self.display, style = wxALIGN_CENTRE)
        self.sizer.Add(self.label, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 10)
        # Text Field Creation
        self.text = wxTextCtrl(self.panel, -1, self.value)
        if self.params.has_key("noedit"):
            self.text.SetEditable(false)
            self.text.SetBackgroundColour(wxSystemSettings_GetColour(wxSYS_COLOUR_BTNFACE))
        self.sizer.Add(self.text, 1, wxEXPAND, 0)
        EVT_TEXT(self.panel, self.text.GetId(), self.OnArgChange) 
        EVT_ENTER_WINDOW(self.text, self.onMouseEnter)
    
    def onMouseEnter(self, evt):
        if self.settings.parameter["update-on-over"] == "yes":
            self.value = self.getValue()
            #self.updateVar("","")
    
    def getValue(self):
        if self.text.GetValue() == self.expr: self.updateVar("","", self.modeDownOnly)
        return str(self.text.GetValue())
    
    def updateVar(self, var, value, mode=0):
        rc = GuiItem.updateVar(self, var, value, mode)
        if rc:
            if rc == -1:
                self.inUpdate = -1
            self.text.SetValue(self.value)
            self.inUpdate = 0
            return rc
        return 0
    
    def OnArgChange(self, evt):
        if self.inUpdate == 0:
            self.inUpdate = 1
            self.parent.updateVar(self.id, self.getValue())
            self.inUpdate = 0
        
class GuiItemOut(GuiItemText):
    def __init__(self, parent, panel, node, settings):
        GuiItemText.__init__(self, parent, panel, node, settings)
        # Button Creation
        # self.btn = wxButton(self.panel, -1, "...", style = wxBU_EXACTFIT)
        self.btn = wxBitmapButton(self.panel, -1, catalog["play"].getBitmap())
        self.sizer.Add(self.btn, 0, 0, 0)
        self.text.SetEditable(false)
        self.text.Enable(false)
        self.open_with = xmlGetAttribute(self.node, "open-with", self.settings.encoding)
        if self.open_with == "":
            self.open_with = self.settings.parameter["open-with"]
        EVT_BUTTON(self.panel, self.btn.GetId(), self.OnButton)
        
    def getValue(self):
        # self.updateVar("","")
        return GuiItemText.getValue(self)
    
    def OnButton(self, evt):
        # self.updateVar("","")
        self.value = self.getValue()
        if self.params.has_key("command"):
            command = self.value
        elif self.params.has_key("noquote"):
            command = self.open_with  + ' ' + self.value
        else:
            command = self.open_with  + ' "' + self.value + '"'
        oldpath = os.getcwd()
        if self.settings.dir != "": os.chdir(self.settings.dir)
        wxExecute(command)        
        os.chdir(oldpath)
        
class GuiItemFile(GuiItemText):
    def __init__(self, parent, panel, node, settings):
        GuiItemText.__init__(self, parent, panel, node, settings)
        # Button Creation
        #self.btn = wxButton(self.panel, -1, "...", style = wxBU_EXACTFIT)
        self.btn = wxBitmapButton(self.panel, -1, catalog["open"].getBitmap())
        self.sizer.Add(self.btn, 0, 0, 0)
        self.filemask = xmlGetAttribute(self.node, "mask", self.settings.encoding)
        # Filemask Handling.
        if self.filemask == "":
            self.filemask = self.settings.string["fl_FileMask"]
        if self.filemask != "":
            self.filemask += "|"
        self.filemask += self.settings.string["mask_AllFiles"]
        EVT_BUTTON(self.panel, self.btn.GetId(), self.OnButton)

    def OnButton(self, evt):
        (dirname, filename) = os.path.split(self.text.GetValue())
        dlg = wxFileDialog(self.panel, self.settings.string["st_ChooseFile"], dirname, filename, self.filemask, wxOPEN)
        if dlg.ShowModal() == wxID_OK:
            self.text.SetValue(dlg.GetPath())
        dlg.Destroy()        


class GuiItemDir(GuiItemText):
    def __init__(self, parent, panel, node, settings):
        GuiItemText.__init__(self, parent, panel, node, settings)
        # Button Creation
        #self.btn = wxButton(self.panel, -1, "...", style = wxBU_EXACTFIT)
        self.btn = wxBitmapButton(self.panel, -1, catalog["explorer"].getBitmap())
        self.sizer.Add(self.btn, 0, 0, 0)
        EVT_BUTTON(self.panel, self.btn.GetId(), self.OnButton)

    def OnButton(self, evt):
        (dirname, filename) = os.path.split(self.text.GetValue())
        dlg = wxDirDialog(self.panel, self.settings.string["st_ChooseFile"], dirname)
        if dlg.ShowModal() == wxID_OK:
            self.text.SetValue(dlg.GetPath())
        dlg.Destroy()        


class GuiItemCheck(GuiItem):
    def __init__(self, parent, panel, node, settings):
        GuiItem.__init__(self, parent, panel, node, settings)
        self.check = wxCheckBox(self.panel, -1, self.display)
        self.sizer.Add(self.check, 0, wxEXPAND, 0)
        self.compiledChecked = exprEvaluate(xmlGetNodesText(xmlGetNodes(self.node, ['checked']), self.settings.encoding))
        self.compiledUnchecked = exprEvaluate(xmlGetNodesText(xmlGetNodes(self.node, ['unchecked']), self.settings.encoding))
        if xmlGetNodesText(xmlGetNodes(self.node, ['checked']), self.settings.encoding) == "":
            self.compiledChecked = self.compiled
        if xmlGetAttribute(self.node, "default", self.settings.encoding) == "checked":
            self.check.SetValue(1)
            self.compiled = self.compiledChecked
        else:
            self.check.SetValue(0)
            self.compiled = self.compiledUnchecked
        EVT_CHECKBOX(self.panel, self.check.GetId(), self.OnCheck)
        
    def OnCheck(self, evt):
        if evt.IsChecked():
            self.compiled = self.compiledChecked
        else:
            self.compiled = self.compiledUnchecked
        self.value = self.compiled.get(self)
        if self.inUpdate == 0:
            self.inUpdate = 1
            self.parent.updateVar(self.id, self.getValue())
            self.inUpdate = 0

    def updateVar(self, var, value, mode=0):
        rc = GuiItem.updateVar(self, var, value, mode)
        if rc == -1:
            if self.value == self.compiledChecked.get(self):
                self.check.SetValue(1)
                self.compiled = self.compiledChecked
            else:
                self.check.SetValue(0)
                self.compiled = self.compiledUnchecked
        return rc

class GuiItemCombo(GuiItem):
    def __init__(self, parent, panel, node, settings):
        GuiItem.__init__(self, parent, panel, node ,settings)
        # Label Creation
        self.label = wxStaticText(self.panel, -1, self.display, style = wxALIGN_CENTRE)
        self.sizer.Add(self.label, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 10)
        # Text Field Creation
        self.combo = wxComboBox(self.panel, -1, self.value)
        if self.params.has_key("noedit"):
            self.combo.SetEditable(false)
        self.sizer.Add(self.combo, 1, wxEXPAND, 0)
        EVT_COMBOBOX(self.panel, self.combo.GetId(), self.OnArgChange) 
        self.compiledEntries = []
        for entryNode in xmlGetNodes(self.node, ['value']):
            entryContent = xmlGetText(entryNode, self.settings.encoding)
            entryDisplay = xmlGetAttribute(entryNode, "display", self.settings.encoding)
            if entryDisplay == "":
                entryDisplay = entryContent
            self.combo.Append(entryDisplay)
            self.compiledEntries.append(exprEvaluate(entryContent))
        if xmlGetAttribute(self.node, "default", self.settings.encoding) != "":
            num = int(xmlGetAttribute(self.node, "default", self.settings.encoding)) - 1
            if (num >= 0) and (num < len(self.compiledEntries)):
                self.combo.SetSelection(num)
                self.activateEntry(num)
            
    def activateEntry(self, num):
        self.compiled = self.compiledEntries[num]
        self.value = self.compiled.get(self)
    
    def OnArgChange(self, evt):
        self.activateEntry(evt.GetSelection())
        if self.inUpdate == 0:
            self.inUpdate = 1
            self.parent.updateVar(self.id, self.getValue())
            self.inUpdate = 0

    def updateVar(self, var, value, mode=0):
        rc = GuiItem.updateVar(self, var, value, mode)
        if rc == -1:
            for entry in range(len(self.compiledEntries)):
                if self.value == self.compiledEntries[entry].get(self):
                    self.activateEntry(entry)
                    self.combo.SetSelection(entry)
        return rc

class GuiIntro(GuiElement, wxHtmlWindow):
    def __init__(self, parent, panel, node, settings):
        GuiElement.__init__(self, parent, panel, node, settings)
        wxHtmlWindow.__init__(self, self.panel, -1)
        text = ""
        for subnode in node.childNodes:
            text += subnode.toxml()
        url = xmlGetAttribute(node, "href", settings.encoding)
        if url != "":
            self.LoadPage(url)
        else:
            self.SetPage(text)

class GuiButton(GuiItem):
    def __init__(self, parent, panel, node, settings, defaultsettingsname):
        GuiItem.__init__(self, parent, panel, node, settings)
        if (self.display == "") or (self.display[0:2] == "__"):
            self.display = self.settings.string[defaultsettingsname]
        self.button = wxButton(panel, -1, self.display)
        self.sizer.Add(self.button, 1, wxEXPAND, 0)
        self.button.SetToolTip(wxToolTip(self.value))
        EVT_BUTTON(self.panel, self.button.GetId(), self.OnButton)
        
    def OnButton(self, evt):
        print "OnButton ", self.id

class GuiHelp(GuiButton):
    def __init__(self, parent, panel, node, settings):
        GuiButton.__init__(self, parent, panel, node, settings, "Help")
        
    def OnButton(self, evt):
        text = ""
        for subnode in self.node.childNodes:
            text += subnode.toxml()
        self.helpwin = GuiHelpFrame(self.panel, self.display, text)
        url = xmlGetAttribute(self.node, "href", self.settings.encoding)
        if url != "":
            self.helpwin.html.LoadPage(url)
        self.helpwin.Show(true)

class GuiCommand(GuiButton):
    def __init__(self, parent, panel, node, settings):
        GuiButton.__init__(self, parent, panel, node, settings, "Process")
        self.expr += xmlGetNodesText(xmlGetNodes(self.node, ["commandline"]),self.settings.encoding)
        self.compiled = exprEvaluate(self.expr)
        self.value = self.expr
        self.button.GetToolTip().SetTip(self.value)
        
        self.workingpath = xmlGetNodesText(xmlGetNodes(self.node, ["workingpath"]), self.settings.encoding)
        self.commandpath = xmlGetNodesText(xmlGetNodes(self.node, ["commandpath"]), self.settings.encoding) 
        self.redirect = xmlGetAttribute(self.node, "redirect-to-id", self.settings.encoding)
        self.process = None
        self.redirectFile = None
        EVT_ENTER_WINDOW(self.button, self.onMouseEnter)
        
    def onMouseEnter(self, evt):
        if self.settings.parameter["update-on-over"] == "yes":
            self.value = self.getValue()
            # updateVar("","")

    def updateVar(self, var, value, mode=0):
        GuiButton.updateVar(self,var,value,mode)
        self.button.GetToolTip().SetTip(self.value)
        return 0
        
    def OnButton(self, evt):
        # self.updateVar("","")
        self.launch()

    def launch(self):
        
        if self.redirect != "":
            redirect_filename = self.getVar(self.redirect)
            self.redirectFile = open(redirect_filename,"wb")
   
        self.process = wxProcess(self.panel)
        self.process.Redirect();
        
        self.value = self.getValue()
        oldpath = os.getcwd()
        if self.settings.dir != "": os.chdir(self.settings.dir)
        if self.workingpath != "": os.chdir(self.workingpath)
        cmd = os.path.join(self.commandpath, self.value)
        self.parent.out.SetValue(self.settings.string["Command"] + "> " + cmd + "\n\n")
        pid = wxExecute(cmd, wxEXEC_ASYNC, self.process)        
        os.chdir(oldpath)

        if pid != 0:
            wxBeginBusyCursor()
            self.parent.SetStatusText(self.settings.string["st_Process"])
            self.parent.enableCommands(false)
            self.parent.inp.SetFocus()


    def sendText(self, text):
        if self.process != None:
            if self.process.GetOutputStream() != None:
                self.process.GetOutputStream().write(text + '\n')

    def closeStream(self):
        if self.process != None:
            self.process.CloseOutput()

    def idle(self):
        self.getOutput()
        
    def getOutput(self):
        if self.process != None:
            stream = self.process.GetInputStream()
            if (stream is not None) and (stream.CanRead()):
                text = stream.read()
                if self.redirectFile != None:
                    self.redirectFile.write(text)
                self.parent.out.AppendText(text)
            stream_err = self.process.GetErrorStream()
            if (stream_err is not None) and (stream_err.CanRead()):
                text = stream_err.read()
                self.parent.out.AppendText(text)
                if self.settings.parameter["popup-on-error"] == "yes":
                    wxMessageBox(text, "Sortie de stderr", wxICON_ERROR + wxOK)
                if self.redirectFile != None:
                    self.redirectFile.write(text)

    def processEnded(self):
        if self.process == None: return
        self.getOutput()
        wxEndBusyCursor()
        self.parent.SetStatusText(self.settings.string["st_Done"])
        if self.redirectFile != None:
            self.redirectFile.close()
            self.redirectFile = None
        self.process.Destroy()
        self.process = None
        self.parent.enableCommands(true)

class GuiHelpFrame(wxFrame):
    def __init__(self, parent, title, text):
           wxFrame.__init__(self, parent, -1, title)
           self.html = wxHtmlWindow(self, -1)
           self.html.SetPage(text)
           sizer = wxBoxSizer(wxVERTICAL)
           self.SetSizer(sizer)
           sizer.Add(self.html, 1, wxEXPAND, 0)