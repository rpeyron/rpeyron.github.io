#! /usr/bin/python
# -*- coding: latin-1 -*-
#
# (c) 2003 - R�mi Peyronnet
# Licence GPL


# Import librairies
import string
import re
import xml.dom.minidom

# Utility function to get the text of a node.
def xmlGetText(node, encoding, trim = 0):
    rc = ""
    for child in node.childNodes:
        if (child.nodeType == child.TEXT_NODE) or (child.nodeType == child.CDATA_SECTION_NODE):
            s = child.data.encode(encoding)
            if trim:
                s = re.sub(r'^['+string.whitespace+r']*',r'',s)
                s = re.sub(r'['+string.whitespace+r']*$',r'',s)
                rc += s
            else:
                rc += s
    return rc
    
# Get the text of a nodelist
def xmlGetNodesText(nodelist, encoding):
    str = ""
    for element in nodelist:
        str += xmlGetText(element,encoding);
    return str

# Get Attribute Value, or empty string if not found
def xmlGetAttribute(node, attribute, encoding):
    try:
        str = node.getAttribute(attribute).encode(encoding)
    except:
        str = ""
    return str
    
def xmlGetNodes(node, tagnames):
    nodelist = []
    for element in node.childNodes:
        for tagname in tagnames:
            if element.nodeName == tagname:
                nodelist.append(element)
    return nodelist

# Test Procedure
def test():
    try:
        dom = xml.dom.minidom.parse("settings.gui");
    except xml.sax._exceptions.SAXParseException, e:
        print "[PARSER ERROR] " + e.getMessage() + "[" + "li" + e.getLineNumber() + "col" + e.getColumnNumber() + "]"
    else:
        print xmlGetNodes(dom, ["gui"])


# Auto Launch    
if __name__ == "__main__":
    test();