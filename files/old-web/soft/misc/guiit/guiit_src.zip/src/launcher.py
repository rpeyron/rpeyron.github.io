#! /usr/bin/python
# -*- coding: latin-1 -*-
#
# Versatile launcher
#
# (c) 2003 - R�mi Peyronnet
# Licence GPL


# Import librairies
from wxPython.wx import *
# from wxPython.lib.ErrorDialogs import *
from wxPython.html import *
import os
import re
import string
import dircache
import sys
import os.path
import shutil
import xml.parsers.expat
import xml.dom.minidom

# Constants
CONFIG_FILENAME="launcher.xml"
ENCODING="ISO-8859-1"
VERSION=2.0

ID_BTN_PROCESS=101
ID_MNU_EXIT = 201
ID_ARG_TXT = 1000
ID_ARG_BTN = 2000

# Configuration class --------------------------------------

class XmlConfig:
    def __init__(self, filename):
        global ENCODING
        self.filename = filename
        self.args = []
        self.encoding = ENCODING
        
    # Utility function to get the text of a node.
    def xml_getText(self, nodelist):
        rc = ""
        for node in nodelist:
            if node.nodeType == node.TEXT_NODE:
                rc += node.data.encode(self.encoding)
            if node.nodeType == node.CDATA_SECTION_NODE:
                rc += node.data.encode(self.encoding)
        return rc
    # Utility function to get the text of a element tag name
    def xml_getTagText(self, dom, tagname):
        str = ""
        for element in dom.getElementsByTagName(tagname):
            str += self.xml_getText(element.childNodes);
        return str

    def parse(self):
        try:
            dom = xml.dom.minidom.parse(self.filename);
        except IOError:
            wxMessageBox("Configuration file not found : " + self.filename)
            
        # Arguments
        for element in dom.getElementsByTagName("arg"):
            #print "arg " + element.attributes["name"].nodeValue + " " + self.xml_getText(element.childNodes)
            arg = {}
            arg["value"] = self.xml_getText(element.childNodes);
            arg["name"] = ""
            arg["id"] = ""
            arg["file"] = "no"
            arg["type"] = ""
            arg["hidden"] = "no"
            arg["use"] = "yes"
            if element.hasAttributes():
                for i in range(element.attributes.length):
                    att = element.attributes.item(i)
                    arg[att.name] = att.nodeValue.encode(self.encoding);
            # Compatibility conversions.
            if arg["file"]=="yes":
                arg["type"]="file";
            if arg["hidden"]=="yes":
                arg["type"]="hidden";
            if arg["id"]=="":
                arg["id"]=arg["name"];
            self.args.append(arg)
        # Output files
        for element in dom.getElementsByTagName("out"):
            #print "arg " + element.attributes["name"].nodeValue + " " + self.xml_getText(element.childNodes)
            arg = {}
            arg["value"] = self.xml_getText(element.childNodes);
            arg["name"] = ""
            arg["id"] = ""
            arg["type"] = "out"
            arg["use"] = "no"
            arg["edit-with"] = "notepad.exe"
            if element.hasAttributes():
                for i in range(element.attributes.length):
                    att = element.attributes.item(i)
                    arg[att.name] = att.nodeValue.encode(self.encoding);
            self.args.append(arg)
       
        # Main values
        self.intro = self.xml_getTagText(dom, "intro")
        self.title = self.xml_getTagText(dom, "title")
        self.commandpath  = self.xml_getTagText(dom, "commandpath")
        self.workingpath  = self.xml_getTagText(dom, "workingpath")
        self.command  = self.xml_getTagText(dom, "command")
        self.redirect = ""
        for element in dom.getElementsByTagName("redirect-output"):
            for i in range(element.attributes.length):
                att = element.attributes.item(i)
                if att.name == "to-id":
                    self.redirect = att.nodeValue.encode(self.encoding);
        
        # Pseudo arguments
        arg={};  arg["name"] = "";   arg["type"] = "hidden";  arg["use"] = "no";   arg["id"] = "command";     arg["value"] = self.command;   self.args.append(arg)
        arg={};  arg["name"] = "";   arg["type"] = "hidden";  arg["use"] = "no";   arg["id"] = "workingpath";   arg["value"] = self.workingpath;    self.args.append(arg)
        arg={};  arg["name"] = "";  arg["type"] = "hidden";  arg["use"] = "no";    arg["id"] = "commandpath";   arg["value"] = self.commandpath;  self.args.append(arg)
        # Strings
        self.strings = {}
        self.strings["Process"] = "Process"
        self.strings["Arguments"] = "Arguments"
        self.strings["Outputs"] = "Outputs"
        self.strings["mnu_File"] = "File"
        self.strings["mnu_File_Quit"] = "Quit"
        self.strings["des_File_Quit"] = "Terminate the program"
        self.strings["st_Ready"] = "Ready."
        self.strings["st_Done"] = "Done."
        self.strings["st_Process"] = "Processing in progres..."
        self.strings["fl_FileMask"] = "XML Files (*.xml)|*.xml|Text Files (*.txt)|*.txt|All files (*.*)|*.*"
        self.strings["st_ChooseFile"] = "Choose the file"
        self.strings["st_ChooseDir"] = "Choose the directory"
        self.strings["Command"] = "Command"
        self.strings["Input"] = "Input"
        self.strings["Send"] = "Send"
        self.strings["CloseStream"] = "Close the Stream"
        for element in dom.getElementsByTagName("string"):
            self.strings[element.attributes["name"].value] = self.xml_getText(element.childNodes);
        # Parameters
        self.parameters = {}
        self.parameters["display-output"] = "yes"
        self.parameters["display-input"] = "no"
        self.parameters["display-out"] = "no"
        self.parameters["width"] = "500"
        self.parameters["height"] = "450"
        for element in dom.getElementsByTagName("parameter"):
            self.parameters[element.attributes["name"].value] = element.attributes["value"].value.encode(self.encoding);
       
        dom.unlink();
    
# Launcher Frame class -------------------------------------
class LauncherFrame(wxFrame):
    def __init__(self, parent, ID, title, config):
                
        # Trap Errors
        sys.stderr = wxPyNonFatalErrorDialogWithTraceback (
            None, -1,
            programname='Launcher',
            mailto='remi+launcher@via.ecp.fr')
            
        # Read config
        self.config = config
        self.config.parse()

        # Create the Frame
        wxFrame.__init__(self, parent, ID, title, wxDefaultPosition, 
            wxSize( string.atoi(str(self.config.parameters["width"])), 
                    string.atoi(str(self.config.parameters["height"]))), 
                    wxRESIZE_BORDER | wxMINIMIZE_BOX | wxSYSTEM_MENU | wxCAPTION )
        backColor = wxSystemSettings_GetColour(wxSYS_COLOUR_BTNFACE)
        self.SetBackgroundColour(backColor)

        # Set Title
        self.SetTitle(self.config.title)
            
#        # Menu
#        menuBar = wxMenuBar()
#        menu = wxMenu()
#        menu.Append(ID_MNU_EXIT, 
#            self.config.strings["mnu_File_Quit"], 
#            self.config.strings["des_File_Quit"])
#        
#        menuBar.Append(menu, self.config.strings["mnu_File"])
#        self.SetMenuBar(menuBar)
#        EVT_MENU(self, ID_MNU_EXIT, self.OnClose)
        
        # StatusBar
        self.CreateStatusBar()
        self.SetStatusText(self.config.strings["st_Ready"])

        self.process = None
        EVT_IDLE(self, self.OnIdle)
        EVT_END_PROCESS(self, -1, self.OnProcessEnded)

        # Layout
        horBox = wxBoxSizer(wxVERTICAL)
        self.SetSizer(horBox)
        
        # Introduction
        self.htmlIntro = wxHtmlWindow(self,-1)
        self.htmlIntro.SetPage(self.config.intro)
        self.htmlIntro.SetBackgroundColour(backColor)
        horBox.Add(self.htmlIntro, 2, wxEXPAND | wxALL, 5)
        
        # Arguments
        staticSizer = wxStaticBoxSizer(wxStaticBox(self, -1, self.config.strings["Arguments"]), wxVERTICAL)
        gridBox = wxFlexGridSizer(0, 3, 2, 5)
        gridBox.AddGrowableCol(1)
        
        if self.config.parameters["display-out"] != "no":
            staticSizerOut = wxStaticBoxSizer(wxStaticBox(self, -1, self.config.strings["Outputs"]), wxVERTICAL)
            gridBoxOut = wxFlexGridSizer(0, 3, 2, 5)
            gridBoxOut.AddGrowableCol(1)

        argCount = 0
        for arg in config.args:
            if (arg["type"] == "check"):
                check = wxCheckBox(self, ID_ARG_TXT + argCount, arg["name"])
                EVT_CHECKBOX(self, ID_ARG_TXT + argCount, self.OnArgChange) 
                arg["txt"] = check
            else:
                label = wxStaticText(self, -1, arg["name"], style = wxALIGN_CENTRE )
                txt = wxTextCtrl(self, ID_ARG_TXT + argCount, arg["value"])
                arg["txt"] = txt
                EVT_TEXT(self, ID_ARG_TXT + argCount, self.OnArgChange) 
                if (arg["type"] != ""):
                    btn = wxButton(self, ID_ARG_BTN + argCount, "...", style = wxBU_EXACTFIT )
                    EVT_BUTTON(self, ID_ARG_BTN + argCount, self.OnBrowse)
                else:
                    btn = wxStaticText(self, -1, "")
            if arg["type"] == "hidden" or (arg["type"] == "out" and self.config.parameters["display-out"] == "no"):
                label.Hide()
                txt.Hide()
                btn.Hide()
            elif arg["type"] == "out":
                txt.SetEditable(FALSE)
                txt.SetBackgroundColour(backColor)
                gridBoxOut.Add(label, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 10)
                gridBoxOut.Add(txt, 0, wxEXPAND, 0)
                gridBoxOut.Add(btn, 0, 0, 0)
            elif arg["type"] == "check":
                gridBox.Add(check, 0, wxALIGN_CENTER_VERTICAL | wxEXPAND)
                gridBox.Add(wxStaticText(self,-1,""), 0, 0, 0)
                gridBox.Add(wxStaticText(self,-1,""), 0, 0, 0)
            else:
                gridBox.Add(label, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 10)
                gridBox.Add(txt, 0, wxEXPAND, 0)
                gridBox.Add(btn, 0, 0, 0)
            argCount += 1
        staticSizer.Add(gridBox, 0, wxEXPAND | wxALL, 5)
        horBox.Add(staticSizer, 0, wxEXPAND | wxALL, 5)
        
        # Command Line
        sizer = wxBoxSizer(wxHORIZONTAL)
        label = wxStaticText(self, -1, self.config.strings["Command"])
        sizer.Add(label, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 10)
        self.command = wxTextCtrl(self, -1, "")
        sizer.Add(self.command, 1, wxEXPAND, 0)
        horBox.Add(sizer, 0, wxEXPAND | wxALL, 5)
        self.UpdateCommandLine()
        
        # Update Arguments Text
        argCount = 0;
        for arg in config.args:
            self.UpdateArgChange(argCount)
            argCount += 1

        # Process Button
        self.btnProcess = wxButton(self, ID_BTN_PROCESS, self.config.strings["Process"])
        horBox.Add(self.btnProcess, 0, wxALIGN_CENTER  | wxALL, 5)
        EVT_BUTTON(self, ID_BTN_PROCESS, self.OnProcess)
         
        # Output
        self.out = wxTextCtrl(self, -1, '', style=wxTE_MULTILINE|wxTE_READONLY)
        self.out.SetBackgroundColour(backColor)
        if self.config.parameters["display-output"] != "yes":
            self.out.Hide()
        else:
            horBox.Add(self.out, 2, wxEXPAND | wxALL, 5)
            
        # Input
        sizer = wxBoxSizer(wxHORIZONTAL)
        label = wxStaticText(self, -1, self.config.strings["Input"])
        sizer.Add(label, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 10)
        self.inp = wxTextCtrl(self, -1, '', style=wxTE_PROCESS_ENTER)
        sizer.Add(self.inp, 1, wxEXPAND, 0)
        self.sndBtn = wxButton(self, -1, self.config.strings["Send"], style = wxBU_EXACTFIT)
        sizer.Add(self.sndBtn, 0, 0, 0)
        self.termBtn = wxButton(self, -1, self.config.strings["CloseStream"], style = wxBU_EXACTFIT)
        sizer.Add(self.termBtn, 0, 0, 0)
        self.inp.Enable(false)
        self.sndBtn.Enable(false)
        self.termBtn.Enable(false)
        EVT_BUTTON(self, self.sndBtn.GetId(), self.OnSendText)
        EVT_BUTTON(self, self.termBtn.GetId(), self.OnCloseStream)
        EVT_TEXT_ENTER(self, self.inp.GetId(), self.OnSendText)
        if self.config.parameters["display-input"] != "yes":
            label.Hide()
            self.inp.Hide()
            self.sndBtn.Hide()
            self.termBtn.Hide()
        else:
            horBox.Add(sizer, 0, wxEXPAND | wxALL, 5)


        # Display Out
        if self.config.parameters["display-out"] != "no":
            staticSizerOut.Add(gridBoxOut, 0, wxEXPAND | wxALL, 5)
            horBox.Add(staticSizerOut, 0, wxEXPAND | wxALL, 5)
        
        self.Layout()
        
        # Events Handlers
        EVT_CLOSE(self, self.OnClose) 
        
        # Misc
        self.workingpathok = 0;
    
    def OnClose(self, evt):
        sys.stderr.Destroy()
        self.Destroy();

    def UpdateCommandLine(self):
        cmd = ""
        cmd += self.config.command + " "
        for arg in self.config.args:
            if arg["use"]!="no" and arg["type"] != "out":
                if arg["use"]=="quoted":
                    cmd += '"' + arg["txt"].GetValue() + '" '
                else:
                    if arg["type"] == "check":
                        if arg["txt"].IsChecked():
                            cmd += arg["value"] + " "
                    else:
                        cmd += arg["txt"].GetValue() + " "
        self.command.SetValue(cmd)
        
    def OnArgChange(self, evt):
        self.UpdateArgChange(evt.GetId()-ID_ARG_TXT)
        self.UpdateCommandLine()
    
    def UpdateArgChange(self, num):
        global ENCODING;
        curarg = self.config.args[num]
        if curarg["type"] == "check":
            return
        for arg in self.config.args:
            if arg == curarg:
                continue
            st = str(arg["value"])
            ch = "{" + str(curarg["id"]) + "}"
            rep = str(curarg["txt"].GetValue().encode(ENCODING))
            #print str, rep
            strep = st.replace(ch, rep)
            strep = str(strep)
            if strep != st:
                if strep.find("`") != -1:
                    tab = strep.split("`")
                    cur = 1
                    while cur < len(tab):
                        tab[cur] = eval(tab[cur].replace("\\","\\\\"))
                        cur = cur + 2
                    strep = string.join(tab,"")
                arg["txt"].SetValue(strep)
        
    def OnBrowse(self, evt):
        arg = self.config.args[evt.GetId()-ID_ARG_BTN]
        if arg["type"] == "out":
            if arg["use"] == "quoted":
                wxExecute(arg["edit-with"] + ' "' + arg["txt"].GetValue() + '"')
            else:
                wxExecute(arg["edit-with"] + " " + arg["txt"].GetValue())
        else:
            wildcard = self.config.strings["fl_FileMask"];
            (dirname, filename) = os.path.split(arg["txt"].GetValue())
            if arg["type"]=="dir":
                dlg = wxDirDialog(self, self.config.strings["st_ChooseDir"], dirname)
            else:
                dlg = wxFileDialog(self, self.config.strings["st_ChooseFile"], dirname, filename, wildcard, wxOPEN)
            if dlg.ShowModal() == wxID_OK:
                arg["txt"].SetValue(dlg.GetPath())
            dlg.Destroy()        
    
    def OnProcess(self, evt):
        if self.config.redirect != "":
            redirect_filename = self.config.redirect
            for arg in self.config.args:
                if arg["id"] == self.config.redirect:
                    redirect_filename = arg["txt"].GetValue()
            self.redirect = open(redirect_filename,"wb")
   
        self.process = wxProcess(self)
        self.process.Redirect();
        if ((self.config.workingpath != "") and (self.workingpathok == 0)):
            os.chdir(self.config.workingpath)
            self.workingpathok = 1
        cmd = os.path.join(self.config.commandpath, self.command.GetValue())
        self.out.SetValue(self.config.strings["Command"] + "> " + cmd + "\n\n")
        pid = wxExecute(cmd, wxEXEC_ASYNC, self.process)        
        if pid != 0:
            wxBeginBusyCursor()
            self.SetStatusText(self.config.strings["st_Process"])
            self.inp.Enable(true)
            self.sndBtn.Enable(true)
            self.termBtn.Enable(true)
            self.command.Enable(false)
            self.btnProcess.Enable(false)
            self.inp.SetFocus()
        
    def OnSendText(self, evt):
        text = self.inp.GetValue()
        self.inp.SetValue('')
        self.process.GetOutputStream().write(text + '\n')
        self.inp.SetFocus()

    def OnCloseStream(self, evt):
        self.process.CloseOutput()

    def OnIdle(self, evt):
        if self.process is not None:
            stream = self.process.GetInputStream()
            if (stream is not None) and (stream.CanRead()):
                text = stream.read()
                if self.config.redirect != "":
                    self.redirect.write(text)
                self.out.AppendText(text)

    def OnProcessEnded(self, evt):
        wxEndBusyCursor()
        self.SetStatusText(self.config.strings["st_Done"])
        stream = self.process.GetInputStream()
        if stream.CanRead():
            text = stream.read()
            self.out.AppendText(text)
            if self.config.redirect != "":
                self.redirect.write(text)
        if self.config.redirect != "":
            self.redirect.close()
        self.process.Destroy()
        self.process = None
        self.inp.Enable(false)
        self.sndBtn.Enable(false)
        self.termBtn.Enable(false)
        self.command.Enable(true)
        self.btnProcess.Enable(true)
        
# Launcher Application class -------------------------------
class LauncherApp(wxApp):
    def OnInit(self):
        global CONFIG_FILENAME
        try:
            configfilename = sys.argv[1]
        except:
            configfilename = CONFIG_FILENAME
        if os.path.dirname(configfilename): os.chdir(os.path.dirname(configfilename))
        config = XmlConfig(configfilename)
        frame = LauncherFrame(NULL, -1, "Title",config)
        frame.Show(true)
        self.SetTopWindow(frame)
        return true;
    
# GUI Main Proc
def GUImain():
    app = LauncherApp(0)
    app.MainLoop()

"""
def compile2exe():
    from distutils.core import setup
    import py2exe
    setup(name="Launcher",
          scripts=[
                        "launcher.py",
                  ],
         )
"""

# Auto Launch    
if __name__ == "__main__":
    GUImain();