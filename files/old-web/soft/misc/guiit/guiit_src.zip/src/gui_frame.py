#! /usr/bin/python
# -*- coding: latin-1 -*-
#
# Versatile launcher
#
# (c) 2003 - R�mi Peyronnet
# Licence GPL


# Import librairies
from wxPython.wx import *
# from wxPython.lib.ErrorDialogs import *
from wxPython.html import *
import xml.dom.minidom
import string
from gui_items import *

class GuiFrame(wxFrame, GuiElement):
    def __init__(self, parent, ID, title, settings, filename):
        # Trap Errors
        #sys.stderr = wxPyNonFatalErrorDialogWithTraceback (
        #    None, -1,
        #    programname='Gui It !',
        #    mailto='remi+guiit@via.ecp.fr')
            
        self.settings = settings
        
        # Create the Frame
        wxFrame.__init__(self, parent, ID, title, wxDefaultPosition, wxSize( 300, 400), 
                    wxRESIZE_BORDER | wxMINIMIZE_BOX | wxCLOSE_BOX |  wxSYSTEM_MENU | wxCAPTION )
#        backColor = wxSystemSettings_GetColour(wxSYS_COLOUR_BTNFACE)
#        self.SetBackgroundColour(backColor)

        wxInitAllImageHandlers()


        # StatusBar
        self.CreateStatusBar()
        self.SetStatusText(self.settings.string["st_Ready"])
        
        GuiElement.__init__(self, None, None, None, settings)

        self.panel = parseGuiFile(filename, self, self, settings)
        
        self.sizer = wxBoxSizer(wxHORIZONTAL)
        self.SetSizer(self.sizer)
        self.sizer.Add(self.panel, 1, wxEXPAND, 0)
        
        # Set Title
        self.SetTitle(self.panel.display)

        self.Layout()
        
        # Resize there to have correct scrollbars
        self.SetSize(wxSize(string.atoi(self.panel.settings.parameter["width"]), string.atoi(self.panel.settings.parameter["height"])))
