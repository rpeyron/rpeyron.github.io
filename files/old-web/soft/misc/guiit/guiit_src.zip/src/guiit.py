#! /usr/bin/python
# -*- coding: latin-1 -*-
#
# Versatile launcher
#
# (c) 2003-2004 - R�mi Peyronnet
# Licence GPL


# Import librairies
from wxPython.wx import *
# from wxPython.lib.ErrorDialogs import * # Deprecated
import os
import os.path

from gui_items import *
from gui_frame import *
import gui_expr
from gui_settings import *

# Constants
SETTINGS_FILENAME="settings.gui"
#DEFAULT_FILENAME="xmldiff.gui"
DEFAULT_FILENAME="settings.gui"
ENCODING="ISO-8859-1"
VERSION=2.1
COPYRIGHT="Gui It ! v2.1 (c) 2004-2006 - R�mi Peyronnet - http://www.via.ecp.fr/~remi/soft/misc/guiit/guiit_en.php3"

# GUI Application class -------------------------------
class GuiApp(wxApp):
    def OnInit(self):
        global SETTINGS_FILENAME
        global DEFAULT_FILENAME
        global ENCODING
        global COPYRIGHT
        
        # Parse Settings File
        oldpath = os.getcwd()
        print sys.argv[0]
        if os.path.dirname(sys.argv[0]): os.chdir(os.path.dirname(sys.argv[0]))
        settings = GuiSettings(SETTINGS_FILENAME, ENCODING)
        os.chdir(oldpath)
        
        # Get Gui Description File Name
        try:
            configfilename = sys.argv[1]
        except:
            configfilename = DEFAULT_FILENAME
            
        frame = GuiFrame(NULL, -1, "Title", settings, configfilename)
        frame.Show(true)
        self.SetTopWindow(frame)
        frame.SetStatusText(COPYRIGHT)
        return true;
    
# GUI Main Proc
def GuiMain():
    app = GuiApp(0)
    app.MainLoop()

# Auto Launch    
if __name__ == "__main__":
    GuiMain();