#! /usr/bin/python -c
# -*- coding: iso-8859-1 -*-
#
# Versatile launcher
#
# (c) 2003 - R�mi Peyronnet
# Licence GPL


# Import librairies
import re
import string
import xml.dom.minidom
from gui_items import *
from xml_utils import *
import lex
import yacc

# Import what should be present in python expression
import time
import os
import os.path
import re
import urllib

# Classes

class n_expr:
    def __init__(self, str):
        self.str = str
        
    def get(self, item):
        yacc.parse(self.str)
        result.get(item)
        
    def depends(self, var, item):
        return 0

class n_text(n_expr):
    def __init__(self, str):
        self.text = str
    
    def get(self, item):
        return self.text
    
class n_var(n_expr):
    def __init__(self, var):
        self.var = var
        
    def get(self, item):
        s = item.getVar(self.var.get(item))
        return s
    
    def depends(self, var, item):
        if var == self.var.get(item):
            return 1
        else:
            return 0
        
class n_func(n_expr):
    def __init__(self, func, arglist):
        self.func = func
        self.arglist = arglist
    
    def get(self, item):
        s = ""
        func = self.func.get(item)
        if (func != "") and (item.settings.func.has_key(func)):
            s = item.settings.func[func].get(item, self.arglist)
            result = exprEvaluate(s)
            s = result.get(item)
        else:
            for arg in self.arglist:
                s += str(arg.get(item))
        return s
    
    def depends(self, var, item):
        rc = 0
        for arg in self.arglist:
            rc += arg.depends(var, item)
        rc += self.func.depends(var, item)
        return rc

class n_func_item:
    def __init__(self, arglist, item):
        self.item = item
        self.settings = item.settings
        self.vars = {}
        for i in range(len(arglist)):
            self.vars[repr(i+1)] = arglist[i]
    
    def getVar(self, var):
        if self.vars.has_key(var):
            return self.vars[var].get(self.item)
        else:
            return self.item.getVar(var)

class n_func_expr(n_expr):
    def __init__(self, code):
        self.code = exprEvaluate(code)
        
    def get(self, item, arglist):
        s = self.code.get(n_func_item(arglist, item))
        return s
        
    def depends(self, var, item):
        return self.code.depends(var, item)

class n_func_python(n_expr):
    def __init__(self, code):
        self.code = code.replace("\r\n","\n")
        
    def get(self, item, arglist):
        s = self.code
        for i in range(len(arglist)):
            s = s.replace('{' + repr(i+1) + '}', str(arglist[i].get(item)).replace("\\","\\\\"))
        s = str(eval(s))
        return s
    
    def depends(self, var, item):
        if self.code.find('{'+var+'}') != -1:
            return 1
        else:
            return 0

class n_concat(n_expr):
    def __init__(self, left, right):
        self.left = left
        self.right = right
        
    def get(self, item):
        left = self.left.get(item)
        right = self.right.get(item)
        return  left + right
    
    def depends(self, var, item):
        return self.left.depends(var, item) + self.right.depends(var, item)


# Lexer

tokens = ('LBRACKET', 'RBRACKET', 'DDOTS', 'COMMA', 'TEXT','QUOTE','DQUOTE')
t_LBRACKET = r'{'
t_RBRACKET = r'}'
t_DDOTS = r':'
t_COMMA = r','
t_QUOTE = r'\''
t_DQUOTE = r'"'
t_TEXT = r'[^{}:,\'"]+'
t_ignore = ""

def t_newline(t):
    r'\n+'
    t.lineno += t.value.count("\n")
    
def t_error(t):
    print "Illegal character '%s'" % t.value[0]
    t.skip(1)

lex.lex()

# Yacc 

class YaccParseError: pass

precedence = ()

def p_statement(t):
    'statement : expression'
    global result
    result = t[1]

def p_text(t):
    'text : TEXT'
    t[0] = n_text(t[1])
    
def p_quote(t):
    'quote : QUOTE'
    t[0] = n_text(t[1])
    
def p_dquote(t):
    'dquote : DQUOTE'
    t[0] = n_text(t[1])
    
def p_ftext_null(t):
    'ftext : null'
    t[0] = t[1]

def p_ftext(t):
    '''ftext : ftext TEXT
            | ftext DDOTS
            | ftext COMMA
            | ftext DQUOTE
            | ftext QUOTE'''
    t[0] = t[1] + t[2]

def p_qelm_ini(t):
    'qelm : null'
    t[0] = n_text(t[1])

def p_qelm_next(t):
    '''qelm : qelm text
            | qelm dquote
            | qelm func'''
    t[0] = n_concat(t[1],t[2])

def p_qtext(t):
    'qtext : QUOTE qelm QUOTE'
    t[0] = t[2]

def p_dqelm_ini(t):
    'dqelm : null'
    t[0] = n_text(t[1])

def p_dqelm_next(t):
    '''dqelm : dqelm text
              | dqelm quote
              | dqelm func'''
    t[0] = t[1] + t[2]

def p_dqtext(t):
    'dqtext : DQUOTE dqelm DQUOTE'
    t[0] = t[2]

def p_arg_var(t):
    'arg : text'
    t[0] = n_var(t[1])

def p_arg_text(t):
    '''arg : qtext
           | dqtext'''
    t[0] = t[1]

def p_arg_func(t):
    'arg : func'
    t[0] = n_var(t[1])

def p_arglist_ini(t):
    'arglist : arg'
    t[0] = [t[1]]
    
def p_arglist_next(t):    
    'arglist : arglist COMMA arg'
    t[0] = t[1]
    t[0].append(t[3])

def p_expr_text(t):
    'expr : ftext'
    t[0] = n_text(t[1])

def p_expr_func(t):
    'expr : func'
    t[0] = t[1]

def p_func_simple(t):
    'func : LBRACKET arglist RBRACKET'
    t[0] = n_func(n_text(""),t[2])

def p_func_full(t):
    '''func : LBRACKET arglist DDOTS text RBRACKET
            | LBRACKET arglist DDOTS func RBRACKET'''
    t[0] = n_func(t[4], t[2])

def p_func_single(t):
    '''func : LBRACKET DDOTS text RBRACKET'''
    t[0] = n_func(t[3], [])


def p_expression_expr(t):
    'expression : expr'
    t[0] = t[1]

def p_expression_all(t):
    'expression : expression expr'
    t[0] = n_concat(t[1], t[2])

def p_null(t):
    'null :'
    t[0] = ""

def p_error(t):
    raise YaccParseError()

#yacc.yacc(debug=1)
yacc.yacc(debug=0, write_tables=0)

def exprEvaluate(text):
    global result
    try:
        yacc.parse(text, debug=1)
    except:
        print "[ERROR] While parsing : ", text
        return n_text("")
    else:
        return result
    
class testItem:
    def __init__(self, vars, settings):
        self.vars = vars
        self.settings = settings
    
    def  getVar(self, var):
        print var
        return self.vars[var]

# Test Procedure
class testSettings:
    def __init__(self):
        self.func={}
        self.func["add"] = n_func_python("{1}+{2}")
        self.func["concat"] = n_func_expr("{1}-{2}")
        self.func["dir"] = n_func_python("os.path.dirname('{1}')")
        self.func["file"] = n_func_python("os.path.splitext(os.path.basename('{1}'))[0]")
        self.func["ext"] = n_func_python("os.path.splitext('{1}')[1]")
        self.func["join"] = n_func_python("os.path.join('{1}','{2}')")
        self.func["append"] = n_func_expr("{'{'{1}':dir}','{'{'{1}':file}','{2}','{'{1}':ext}'}':join}")
        
def test():
    vars = {}
    vars["test"] = "toto"
    vars["toto"] = "c:\\file\\tata.xml"
    item = testItem(vars, testSettings())
    str = "L'artiste, se {test,{test}} {'1','2':add} {test,{test}:concat}"
    print "[TEST] ", str
    exp = exprEvaluate(str)
    print exp.get(item)
    print exp.depends("tettst", item)
    print exprEvaluate("{toto,'add':append}").get(item)

# Auto Launch    
if __name__ == "__main__":
    test();    