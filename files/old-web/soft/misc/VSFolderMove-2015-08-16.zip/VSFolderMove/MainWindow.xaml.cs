﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Windows.Forms;
using System.IO;

namespace VSFolderMove
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        String rn_vs = "SOFTWARE\\Microsoft\\VisualStudio";
        String rn_vsl = "VisualStudioLocation";
        String vs_name = "Visual Studio ";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Initialized(object sender, EventArgs e)
        {
            cbVersion.Items.Clear();
            RegistryKey rk = Registry.CurrentUser;
            RegistryKey sk;

            RegistryKey rk_vs = rk.OpenSubKey(rn_vs);
            if (rk_vs != null)
            {
                try
                {
                    foreach (string subKeyName in rk_vs.GetSubKeyNames())
                    {
                        sk = rk_vs.OpenSubKey(subKeyName);
                        if ((sk != null) && (sk.GetValue(rn_vsl) != null))
                        {
                            cbVersion.Items.Add(vs_name + subKeyName);
                        }
                    }

                }
                catch (Exception)
                {
                    System.Windows.Forms.MessageBox.Show("Error while reading the registry !", "VSFolderMove", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            if (cbVersion.Items.IsEmpty)
            {
                System.Windows.Forms.MessageBox.Show("No Visual Studio instances found in the registry !", "VSFolderMove", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                cbVersion.SelectedIndex = 0;
            }
        }

        private void cbVersion_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            String sel_key = (String)cbVersion.SelectedValue;
            sel_key = sel_key.Substring(vs_name.Length);
            RegistryKey rk = Registry.CurrentUser;
            RegistryKey sk;
            RegistryKey rk_vs = rk.OpenSubKey(rn_vs);
            if (rk_vs == null) return;    // Have worked once
            sk = rk_vs.OpenSubKey(sel_key);
            if (sk == null) return;      // Have worked once
            tbCurLocation.Text = (String)sk.GetValue(rn_vsl);
        }

        private void btBrowseNewLocation_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog fb = new FolderBrowserDialog();
            fb.SelectedPath = (tbNewLocation.Text.Length != 0) ? tbNewLocation.Text : tbCurLocation.Text;
            if (fb.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                tbNewLocation.Text = fb.SelectedPath;
            }
        }

        private void btOk_Click(object sender, RoutedEventArgs e)
        {
            String result = "";
            tbNewLocation.Text = tbNewLocation.Text.TrimEnd(System.IO.Path.DirectorySeparatorChar, System.IO.Path.AltDirectorySeparatorChar);
            tbCurLocation.Text = tbCurLocation.Text.TrimEnd(System.IO.Path.DirectorySeparatorChar, System.IO.Path.AltDirectorySeparatorChar);
            if (System.Windows.Forms.MessageBox.Show("Are you sure to move VS folder to " + tbNewLocation.Text + " ?",
                                                    "VSFolderMove", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                                                    == System.Windows.Forms.DialogResult.Yes)
            {
                String sel_key = (String)cbVersion.SelectedValue;
                sel_key = sel_key.Substring(vs_name.Length);
                RegistryKey rk = Registry.CurrentUser;
                try
                {
                    RegistryKey sk;

                    // Move main settings location
                    RegistryKey rk_vs = rk.OpenSubKey(rn_vs);
                    if (rk_vs == null) return;    // Have worked once
                    sk = rk_vs.OpenSubKey(sel_key, true);
                    if (sk == null) return;      // Have worked once

                    foreach (String valueName in sk.GetValueNames())
                    {
                        if (sk.GetValue(valueName).ToString().ToLower().StartsWith(tbCurLocation.Text.ToLower()))
                        {
                            result += valueName + " : " + sk.GetValue(valueName) + " --> ";
                            sk.SetValue(valueName, tbNewLocation.Text + sk.GetValue(valueName).ToString().Substring(tbCurLocation.Text.Length));
                            result += sk.GetValue(valueName) + "\n";
                        }
                    }

                    // Additional places ...
                    RegistryKey rk_vsc = rk.OpenSubKey(rn_vs + "\\" + sel_key + "_Config\\Initialization", true);
                    if (rk_vsc != null)
                    {
                        String valueName = "UserFilesFolder";
                        result += valueName + " : " + sk.GetValue(valueName) + " --> ";
                        rk_vsc.SetValue(valueName, tbNewLocation.Text);
                        result += sk.GetValue(valueName) + "\n";
                    }

                    // End
                    result = "Successfully moved VS user folder to " + tbNewLocation.Text + ".\n\n" +
                             "List of changes made to HKCU\\" + rn_vs + "\\" + sel_key + " :\n" +
                             result +
                             "\nDo not forget to move your files before starting Visual Studio !";
                    System.Windows.Forms.MessageBox.Show(result,
                                                    "VSFolderMove", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch(Exception)
                {
                    result = "Error while moving VS user folder. This may be an access right issue.\n\n" +
                             "List of changes made to + HKCU\\" + rn_vs + "\\" + sel_key + " :\n" +
                             result +
                             "\nYou may try again, or manually reset changed made to previous values.";
                    System.Windows.Forms.MessageBox.Show(result,
                                                    "VSFolderMove", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}

/*
 *  Source URLs :
 *  - http://stackoverflow.com/questions/6395057/change-visual-studio-2010-folder-location
 *  - https://social.msdn.microsoft.com/Forums/vstudio/en-US/f2925f02-6523-4b02-849d-eab0871228da/is-there-a-way-to-specify-paths-for-saving-the-autorecovery-information-and-the-start-page-contents?forum=vseditor
 *  - http://stackoverflow.com/questions/3697381/where-is-the-vssettings-for-visual-studio-express
 *
 *  And maybe simpler : https://technet.microsoft.com/en-us/sysinternals/bb896768?f=255&MSPPError=-2147217396
 *  
 *  Vote for : https://visualstudio.uservoice.com/forums/121579-visual-studio/suggestions/2312281-stop-polluting-my-documents-with-visual-studio-fol
*/
