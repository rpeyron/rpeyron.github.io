/////////////////////////////////////////////////////////////////////////////
// Name:        chronometer.cpp
// Purpose:     chronometer wxWidgets sample
// Author:      Julian Smart
// Modified by:
// Created:     04/01/98
// RCS-ID:      $Id: chronometer.cpp,v 1.67 2005/02/20 16:14:03 JS Exp $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"
#include <wx/datetime.h>
#include <wx/timer.h>

#include <sys/timeb.h>
#include <sys/types.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWidgets headers)
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

// ----------------------------------------------------------------------------
// resources
// ----------------------------------------------------------------------------

// the application icon (under Windows and OS/2 it is in resources and even
// though we could still include the XPM here it would be unused)
#if !defined(__WXMSW__) && !defined(__WXPM__)
    #include "../sample.xpm"
#endif

// ----------------------------------------------------------------------------
// private classes
// ----------------------------------------------------------------------------

// Define a new application type, each program should derive a class from wxApp
class MyApp : public wxApp
{
public:
    // override base class virtuals
    // ----------------------------

    // this one is called on application startup and is a good place for the app
    // initialization (doing it here and not in the ctor allows to have an error
    // return: if OnInit() returns false, the application terminates)
    virtual bool OnInit();
};

// Define a new frame type: this is going to be our main frame
class MyFrame : public wxFrame
{
	long lastTime;
	int ticks;
	int resolution;
	wxTimer timer;
public:
    // ctor(s)
    MyFrame(const wxString& title);

    // event handlers (these functions should _not_ be virtual)
    void OnQuit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);
    void OnQuickHelp(wxCommandEvent& event);
    void OnChangeTicks(wxCommandEvent& event);
    void OnChangeTime(wxCommandEvent& event);

	void OnPaint(wxPaintEvent & event);
	void OnSize(wxSizeEvent & event);
	void OnIdle(wxIdleEvent & event);
	void OnTimer(wxTimerEvent & event);
	void OnChar(wxKeyEvent & event);

	void DrawTime(wxDC & dc, long time);

private:
    // any class wishing to process wxWidgets events must use this macro
    DECLARE_EVENT_TABLE()
};

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------

// IDs for the controls and the menu commands
enum
{
    // menu items
    chronometer_Quit = wxID_EXIT,

    // it is important for the id corresponding to the "About" command to have
    // this standard value as otherwise it won't be handled properly under Mac
    // (where it is special and put into the "Apple" menu)
    chronometer_About = wxID_ABOUT,
	MenuQuickHelp,
	MenuChangeTicks,
	MenuChangeTime
};

// ----------------------------------------------------------------------------
// event tables and other macros for wxWidgets
// ----------------------------------------------------------------------------

// the event tables connect the wxWidgets events with the functions (event
// handlers) which process them. It can be also done at run-time, but for the
// simple menu events like this the static method is much simpler.
BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(chronometer_Quit,  MyFrame::OnQuit)
    EVT_MENU(chronometer_About, MyFrame::OnAbout)
	EVT_MENU(MenuQuickHelp, MyFrame::OnQuickHelp)
	EVT_MENU(MenuChangeTicks, MyFrame::OnChangeTicks)
	EVT_MENU(MenuChangeTime, MyFrame::OnChangeTime)
    EVT_PAINT( MyFrame::OnPaint)
    EVT_SIZE( MyFrame::OnSize)
	EVT_IDLE(MyFrame::OnIdle)
	EVT_TIMER(-1, MyFrame::OnTimer)
	EVT_CHAR(MyFrame::OnChar)
END_EVENT_TABLE()

// Create a new application object: this macro will allow wxWidgets to create
// the application object during program execution (it's better than using a
// static object for many reasons) and also implements the accessor function
// wxGetApp() which will return the reference of the right type (i.e. MyApp and
// not wxApp)
IMPLEMENT_APP(MyApp)

// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// the application class
// ----------------------------------------------------------------------------

// 'Main program' equivalent: the program execution "starts" here
bool MyApp::OnInit()
{
    // create the main application window
    MyFrame *frame = new MyFrame(_T("Chronometer"));

    // and show it (the frames, unlike simple controls, are not shown when
    // created initially)
    frame->Show(true);

    // success: wxApp::OnRun() will be called which will enter the main message
    // loop and the application will run. If we returned false here, the
    // application would exit immediately.
    return true;
}

long getCurTime()
{
	wxDateTime t;
    struct _timeb timebuffer;
    _ftime( &timebuffer );
	t.SetToCurrent();
	t.SetMillisecond(timebuffer.millitm);
	return (((t.GetHour() * 60 + t.GetMinute()) * 60 + t.GetSecond()) * 1000) + t.GetMillisecond();
}

// ----------------------------------------------------------------------------
// main frame
// ----------------------------------------------------------------------------

// frame constructor
MyFrame::MyFrame(const wxString& title)
       : wxFrame(NULL, wxID_ANY, title)
{
    // set the frame icon
    SetIcon(wxICON(sample));
	SetBackgroundColour(*wxWHITE);
	lastTime = getCurTime();
	ticks = 200;
	resolution = 2 * 1000; // 2 secondes --> 1 tick = 20 ms
	timer.SetOwner(this);
	timer.Start(resolution / ticks / 10);

#if wxUSE_MENUS
    // create a menu bar
    wxMenu *fileMenu = new wxMenu;
    wxMenu *changeMenu = new wxMenu;
	changeMenu->Append(MenuChangeTicks, _T("Change Tic&ks number\tCtrl-K"), _T("Change Ticks Number"));
	changeMenu->Append(MenuChangeTime, _T("Change Total &Time\tCtrl-T"), _T("Change Total Time displayed in the clock"));

    // the "About" item should be in the help menu
    wxMenu *helpMenu = new wxMenu;
    helpMenu->Append(MenuQuickHelp, _T("&Quick Help...\tF1"), _T("Very short help"));
    helpMenu->Append(chronometer_About, _T("&About...\tCtrl-A"), _T("Show about dialog"));

    fileMenu->Append(chronometer_Quit, _T("E&xit\tAlt-X"), _T("Quit this program"));

    // now append the freshly created menu to the menu bar...
    wxMenuBar *menuBar = new wxMenuBar();
    menuBar->Append(fileMenu, _T("&File"));
    menuBar->Append(changeMenu, _T("&Change"));
    menuBar->Append(helpMenu, _T("&Help"));

    // ... and attach this menu bar to the frame
    SetMenuBar(menuBar);
#endif // wxUSE_MENUS

#if wxUSE_STATUSBAR
    // create a status bar just for fun (by default with 1 pane only)
    CreateStatusBar(2);
    SetStatusText(_T("Welcome to wxWidgets!"));
#endif // wxUSE_STATUSBAR
}



// event handlers

void MyFrame::OnPaint(wxPaintEvent & WXUNUSED(event))
{
	wxSize size;

	int radius;
	int i;
	wxPaintDC dc(this);

	size = GetClientSize();
	radius = ((size.GetWidth() > size.GetHeight())? size.GetHeight():size.GetWidth()) / 2 - 10;

	dc.DrawText(wxString::Format("1 tick = %d ms", resolution / ticks),5,5);

	dc.DrawCircle(size.GetWidth()/2, size.GetHeight()/2, radius);

	for(i=0;i<ticks;i++)
	{
		dc.DrawLine(
				size.GetWidth()/2 + cos(2 * 3.14159 / ticks * i) * (radius - 5),
				size.GetHeight()/2 + sin(2 * 3.14159 / ticks * i) * (radius - 5),
				size.GetWidth()/2 + cos(2 * 3.14159 / ticks * i) * (radius + 5),
				size.GetHeight()/2 + sin(2 * 3.14159 / ticks * i) * (radius + 5)
			);
	}

	DrawTime(dc,lastTime);

}

void MyFrame::DrawTime(wxDC & dc, long time)
{
	wxSize size;
	int radius;
	double pos;

	size = GetClientSize();
	radius = ((size.GetWidth() > size.GetHeight())? size.GetHeight():size.GetWidth()) / 2 - 10;

	pos = (double)(time % resolution) / (resolution / ticks);

	dc.DrawLine(
			size.GetWidth()/2,
			size.GetHeight()/2,
			size.GetWidth()/2 + cos(2 * 3.14159 / ticks * pos) * (radius + 5),
			size.GetHeight()/2 + sin(2 * 3.14159 / ticks * pos) * (radius + 5)
		);

}

void MyFrame::OnIdle(wxIdleEvent & WXUNUSED(event))
{
	wxClientDC dc(this);
	dc.SetLogicalFunction(wxINVERT);
	DrawTime(dc,lastTime);
	lastTime = getCurTime();
	DrawTime(dc,lastTime);
}

void MyFrame::OnTimer(wxTimerEvent & WXUNUSED(event))
{
	wxClientDC dc(this);
	dc.SetLogicalFunction(wxINVERT);
	DrawTime(dc,lastTime);
	lastTime = getCurTime();
	DrawTime(dc,lastTime);
}

void MyFrame::OnChar(wxKeyEvent & event)
{
	wxClientDC dc(this);
	dc.SetLogicalFunction(wxINVERT);
	DrawTime(dc,lastTime);
	if (event.GetKeyCode() == WXK_SPACE)
	{
		dc.SetLogicalFunction(wxCOPY);
		dc.SetPen(wxPen(*wxRED, 3));
		DrawTime(dc, getCurTime());
	}
	if (event.GetKeyCode() == WXK_RETURN)
	{
		Refresh();
	}
	dc.SetLogicalFunction(wxINVERT);
	dc.SetPen(*wxBLACK_PEN);
	lastTime = getCurTime();
	DrawTime(dc,lastTime);
}

void MyFrame::OnSize(wxSizeEvent & WXUNUSED(event))
{
	Refresh();
}

void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
    // true is to force the frame to close
    Close(true);
}

void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
    wxString msg;
    msg.Printf( _T("Chronometer (c) 2006 R�mi Peyronnet.\n\n"));

    wxMessageBox(msg, _T("About"), wxOK | wxICON_INFORMATION, this);
}

void MyFrame::OnQuickHelp(wxCommandEvent& WXUNUSED(event))
{
    wxString msg;
    msg.Printf( _T("Keys :\n\n")
                _T("[space] Mark time.\n")
				_T("[enter] Reset clock.\n")
				);

    wxMessageBox(msg, _T("QuickHelp"), wxOK | wxICON_INFORMATION, this);
}

void MyFrame::OnChangeTicks(wxCommandEvent& WXUNUSED(event))
{
	long ret;
	ret = ::wxGetNumberFromUser(_T(""), _T("Number of ticks ?"), _T("Ticks number"), ticks,0,2000);
	if (ret != 1) { ticks = ret; Refresh(); }
}

void MyFrame::OnChangeTime(wxCommandEvent& WXUNUSED(event))
{
	long ret;
	ret = ::wxGetNumberFromUser(_T(""), _T("Total time displayed (in milliseconds)"), _T("Total Time"), resolution,0,10000000);
	if (ret != 1) { resolution = ret; Refresh(); }
}
