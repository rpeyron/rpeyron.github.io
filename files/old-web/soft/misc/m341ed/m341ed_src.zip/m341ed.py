#! /usr/bin/env python

# (c) 2004 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>

import os
import os.path
import string
import time

# Processing Part ========================================================

# pidReader : read a list of item from a file
# Format : 
#       BEGIN:TYPE
#       FIELDNAME:FIELDVALUE
#       END:TYPE
#       ...
# Result : items[n][FIELDNAME] = FIELDVALUE
class pidReader:
    def __init__(self):
        self.state = 0
        self.items = []
    
    def loadFile(self, file):
        self.items = []
        item = {}
        fin = open(file, "r")
        line = fin.readline()
        while not(line == ''):
            line = line.strip('\n\r')
            if (line != '') and (line[0] != ' '):
                (key, value) = line.split(':', 1)
                item[key] = value
                if key == 'BEGIN':
                    item = {'BEGIN' : value}
                elif key == 'END':
                    self.items.append(item)
            else:
                if item.has_key(key):
                    item[key] += line[1:]
            line = fin.readline()
        fin.close()
            
    def saveFile(self, file):
        fout = open(file, "w")
        for item in self.items:
            fout.write("BEGIN:" + item["BEGIN"] + "\n")
            for key in item.keys():
                if key == "BEGIN" or key == "END": continue
                if len(item[key]) > 76:
                    tmp = item[key]
                    fout.write(key + ":")
                    while len(tmp) > 76:
                        fout.write(tmp[0:76] + "\n ")
                        tmp = tmp[76:]
                    fout.write(tmp + "\n\n")
                else:
                    fout.write(key + ":" + item[key] + "\n")
            fout.write("END:" + item["END"] + "\n")
        fout.close()

# PID Entry
class pidEntry:
    def __init__(self, item):
        self.setItem(item)
        
    def setItem(self, item):
        self.item = item
        self.parseItem()
        
    def getItem(self):
        self.generateItem(self)
        return self.item
    
    def parseItem(self):  print "[ERROR] Should be overloaded"
    def generateItem(self):  print "[ERROR] Should be overloaded"
    
    def getEntry(self, entry, pos = -1):
        if self.item.has_key(entry):
            value = self.item[entry]
            if pos == -1:
                return value
            else:
                values = value.split(";")
                if len(values) > pos:
                    return values[pos]
                else:
                    return ""
        else:
            return ""
    
    def setEntry(self, entry, value, pos = -1):
        if not self.item.has_key(entry) and value == "": return
        if (pos != -1):
            if not self.item.has_key(entry) : self.item[entry] = ""
            values = self.item[entry].split(";")
            if len(values) > pos:
                values[pos] = value
            else:
                if value != "":
                    while len(values) <= pos:
                        values.append("")
                    values[pos] = value
            self.item[entry] = string.join(values, ";")
        else:
            self.item[entry] = value
        
# Contact List Entry
class m341edRepEntry(pidEntry):
    def __init__(self, item):
        pidEntry.__init__(self,item)
    
    def parseItem(self):
        self.surname = self.getEntry("N",0)
        self.forename = self.getEntry("N",1)
        self.title = self.getEntry("TITLE")
        self.company = self.getEntry("ORG")
        self.adr_st = self.getEntry("ADR",2)
        self.adr_bp = self.getEntry("ADR",0)
        self.adr_cp = self.getEntry("ADR",5)
        self.adr_loc = self.getEntry("ADR",3)
        self.adr_state = self.getEntry("ADR",4)
        self.adr_country = self.getEntry("ADR",6)
        self.tel_home = self.getEntry("TEL;HOME")
        self.tel_work = self.getEntry("TEL;WORK")
        self.tel_cell = self.getEntry("TEL;CELL")
        self.tel_fax = self.getEntry("TEL;FAX")
        self.email_def = self.getEntry("EMAIL;PREF")
        self.email = self.getEntry("EMAIL")
        #print self.__dict__
   
    def generateItem(self):
        self.setEntry("N",self.surname,0)
        self.setEntry("N",self.forename,1)
        self.setEntry("TITLE", self.title)
        self.setEntry("ORG", self.company)
        self.setEntry("ADR",self.adr_st, 2)
        self.setEntry("ADR",self.adr_bp, 0)
        self.setEntry("ADR",self.adr_cp, 5)
        self.setEntry("ADR",self.adr_loc, 3)
        self.setEntry("ADR",self.adr_state, 4)
        self.setEntry("ADR",self.adr_country, 6)
        self.setEntry("TEL;HOME", self.tel_home)
        self.setEntry("TEL;WORK", self.tel_work)
        self.setEntry("TEL;CELL", self.tel_cell)
        self.setEntry("TEL;FAX", self.tel_fax)
        self.setEntry("EMAIL;PREF", self.email_def)
        self.setEntry("EMAIL", self.email)
        
    def getDisplayName(self):
        displayname = self.surname
        if self.forename != "": 
            if displayname != "":
                displayname += " "+self.forename
            else:
                displayname = self.forename
        return displayname

class m341edRep(pidReader):
    def __init__(self):
        pidReader.__init__(self)
    

# GUI Part ==============================================================

from wxPython.wx import *

class m341edFrame(wxFrame):

    # Initialisation -----------------------------------------------------------------

    def __init__(self, parent, ID, title):
        wxFrame.__init__(self, parent, ID, title, wxDefaultPosition, wxSize(420, 600));
        #self.SetBackgroundColour(wxSystemSettings_GetColour(wxSYS_COLOUR_BTNFACE))
        self.initMenu(parent);
        self.initToolbar(parent);
        self.initStatusbar(parent);
        self.initCtls(parent);
        
        self.rep = m341edRep()
        self.repEntry = m341edRepEntry({})
        self.repFilename = "contacts.vcf"

    # initMenu : Build the menu and register the corresponding events.
    def initMenu(self, parent):
        
        ID_EXIT     =   101;
        ID_ABOUT    =   102;
        ID_SAVE     =   103;
        ID_OPEN     =   104;
        ID_SAVEAS     =   105;

        menuBar = wxMenuBar();

        menu = wxMenu();
        menu.Append(ID_OPEN, "&Open...", "Open a file.");
        menu.Append(ID_SAVE, "&Save", "Save the current file.");
        menu.Append(ID_SAVEAS, "&Save as...", "Save the current file.");
        menu.AppendSeparator();
        menu.Append(ID_EXIT, "&Exit", "Terminate the program");
        menuBar.Append(menu, "&File");
        
        menu = wxMenu()
        menu.Append(ID_ABOUT,"&About", "About this program");

        menuBar.Append(menu, "&Help");

        self.SetMenuBar(menuBar);
        EVT_MENU(self,  ID_EXIT, self.OnQuit);
        EVT_MENU(self,  ID_ABOUT, self.OnAbout);
        EVT_MENU(self,  ID_OPEN, self.OnOpen);
        EVT_MENU(self,  ID_SAVE, self.OnSave);
        EVT_MENU(self,  ID_SAVEAS, self.OnSaveAs);
        
    # initToolbar : initialize the toolbar
    def initToolbar(self, parent):
        
        ID_TOOL_EXIT=   301;
        ID_TOOL_SAVE=   302;
        ID_TOOL_OPEN = 303;
        ID_TOOL_ADD = 306;
        ID_TOOL_DEL = 307;
        
        tb = self.CreateToolBar(wxTB_FLAT,-1,"ToolBar");
        tb.AddSimpleTool(ID_TOOL_OPEN, getOpenBitmap(), "Open", "Open a file.")
        tb.AddSimpleTool(ID_TOOL_SAVE, getSaveBitmap(), "Save", "Save the current file.")
        tb.AddSimpleTool(ID_TOOL_EXIT, getStopBitmap(), "Quit", "Terminate the program")
        tb.AddSeparator()
        tb.AddSimpleTool(ID_TOOL_ADD, getAddBitmap(), "Add", "Add an item")
        tb.AddSimpleTool(ID_TOOL_DEL, getDelBitmap(), "Remove", "Remove this item")

        tb.Realize()

        EVT_TOOL(self,  ID_TOOL_EXIT, self.OnQuit);
        EVT_TOOL(self,  ID_TOOL_SAVE, self.OnSave);
        EVT_TOOL(self,  ID_TOOL_OPEN, self.OnOpen);    
        EVT_TOOL(self,  ID_TOOL_ADD, self.OnAddItem);    
        EVT_TOOL(self,  ID_TOOL_DEL, self.OnDelItem);    

    # initStatusbar : initalize the status bar
    def initStatusbar(self, parent):
        self.CreateStatusBar();
        self.SetStatusText("Ready.");
        
    # initCtls : Create the controls and register the corresponding events :
    #  self.sizer       : root sizer
    def initCtls(self, parent):
        
        ID_REPLIST = 1000
        
        self.sizer = wxBoxSizer(wxVERTICAL)
        self.SetSizer(self.sizer)
        
        self.repSplit = wxSplitterWindow(self, -1)
        self.repList = wxListBox(self.repSplit, ID_REPLIST)
        self.repDetails = wxPanel(self.repSplit, -1)
        self.repSplit.SplitVertically(self.repList, self.repDetails, 130)
        self.curRepSelection = -1
        
        self.repControls = {}
        self.repSizer = wxBoxSizer(wxVERTICAL)
        #self.repSizer = wxFlexGridSizer(2, 2, 5)
        self.repDetails.SetSizer(self.repSizer)
        self.initRepControl(self.repSizer, "surname", "Surname", "", 20);
        self.initRepControl(self.repSizer, "forename", "Forename", "", 20);
        curSizer = wxStaticBoxSizer(wxStaticBox(self.repDetails, -1, "Phone Numbers"), wxVERTICAL)
        self.initRepControl(curSizer, "tel_home", "Home Phone", "", 46);
        self.initRepControl(curSizer, "tel_cell", "Cell Phone    ", "", 46);
        self.initRepControl(curSizer, "tel_work", "Work Phone ", "", 46);
        self.initRepControl(curSizer, "tel_fax", "Fax               ", "", 46);
        self.repSizer.Add(curSizer, 0, wxALL + wxEXPAND, 2)
        curSizer = wxStaticBoxSizer(wxStaticBox(self.repDetails, -1, "e-mails"), wxVERTICAL)
        self.initRepControl(curSizer, "email_def", "e-mail 1", "", 50);
        self.initRepControl(curSizer, "email", "e-mail 2", "", 50);
        self.repSizer.Add(curSizer, 0, wxALL + wxEXPAND, 2)
        curSizer = wxStaticBoxSizer(wxStaticBox(self.repDetails, -1, "Address"), wxVERTICAL)
        self.initRepControl(curSizer, "adr_st", "Street", "", 30);
        self.initRepControl(curSizer, "adr_loc", "Location", "", 30);
        self.initRepControl(curSizer, "adr_bp", "Postal Box", "", 10);
        self.initRepControl(curSizer, "adr_cp", "Postal Code", "", 10);
        self.initRepControl(curSizer, "adr_country", "Country", "", 20);
        self.initRepControl(curSizer, "adr_state", "State", "", 20);
        self.repSizer.Add(curSizer, 0, wxALL + wxEXPAND, 2)
        curSizer = wxStaticBoxSizer(wxStaticBox(self.repDetails, -1, "Company infos"), wxVERTICAL)
        self.initRepControl(curSizer, "title", "Job Title", "", 30);
        self.initRepControl(curSizer, "company", "Company", "", 30);
        self.repSizer.Add(curSizer, 0, wxALL + wxEXPAND, 2)
        self.repDetails.Layout()
        
        self.sizer.Add(self.repSplit, 1, wxEXPAND)
#        self.sizer.Fit(self)
        
        self.Layout()
        
        EVT_LISTBOX(self, ID_REPLIST, self.OnRepSelect)
    
    def initRepControl(self, curSizer, entry, text, value, max):
        sizer = wxBoxSizer(wxHORIZONTAL)
        sizer.Add(wxStaticText(self.repDetails, -1, text), 0, wxALIGN_CENTER_VERTICAL + wxRIGHT, 8)
        self.repControls[entry] = wxTextCtrl(self.repDetails, -1, value)
        self.repControls[entry].SetMaxLength(max)
        sizer.Add(self.repControls[entry], 1, wxEXPAND + wxALIGN_CENTER_VERTICAL)
        curSizer.Add(sizer, 0, wxALL + wxEXPAND, 2)

    # Events ------------------------------------------------------------

    # OnQuit : Quit the program
    def OnQuit(self, event):
        self.Close(true);

    def OnAbout(self, event):
        dlg = wxMessageDialog(self, 
                    "m341ed - Mitshubishi 341i Personal Information Editor\n\n"
                        "This program allows you to easily modify contacts, calendar and tasks.\n"
                        "(c) 2004 - R�mi Peyronnet - http://www.via.ecp.fr/~remi\n",
                    "About..." , wxOK | wxICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()
        
    def OnOpen(self, event):
        wildcard = "vCard Files (*.vcf)|*.vcf|Text Files (*.txt)|*.txt|All files (*.*)|*.*";
        dlg = wxFileDialog(self, "Open contact list as...", "", self.repFilename, wildcard, wxOPEN);
        if dlg.ShowModal() == wxID_OK:
            self.repFilename = dlg.GetPath()
            self.rep.loadFile(self.repFilename)
            self.repUpdateList()
            self.curRepSelection = -1
            self.repList.SetSelection(0);
        dlg.Destroy()

    def OnSave(self, event):
        self.repFromControls()
        self.rep.saveFile(self.repFilename)
        
    def OnSaveAs(self, event):
        wildcard = "vCard Files (*.vcf)|*.vcf|Text Files (*.txt)|*.txt|All files (*.*)|*.*";
        dlg = wxFileDialog(self, "Save contact list as...", "", self.repFilename, wildcard, wxSAVE);
        if dlg.ShowModal() == wxID_OK:
            self.repFilename = dlg.GetPath()
            self.repFromControls()
            self.rep.saveFile(self.repFilename)
        dlg.Destroy()
        
    def OnRepSelect(self, event):
        self.repFromControls()
        self.repEntry = m341edRepEntry(self.rep.items[event.GetSelection()])
        self.repToControls()
        self.curRepSelection = event.GetSelection()

    def OnAddItem(self, event):
        self.repFromControls()
        self.rep.items.append({"BEGIN":"VCARD","N":"New","END":"VCARD"})
        self.repEntry = m341edRepEntry(self.rep.items[len(self.rep.items)-1])
        self.repToControls()
        self.repList.Append(self.repEntry.getDisplayName())
        self.repList.SetSelection(self.repList.GetCount()-1)
        self.curRepSelection = self.repList.GetSelection()
        
    def OnDelItem(self, event):
        del self.rep.items[self.curRepSelection]
        self.repList.Delete(self.curRepSelection)
        if self.curRepSelection >= len(self.rep.items): self.curRepSelection -= 1
        self.repList.SetSelection(self.curRepSelection)
        self.repEntry = m341edRepEntry(self.rep.items[self.curRepSelection])
        self.repToControls()
        
    # UI - Component links ------------------------------------------------------------
    
    def repUpdateList(self):
        self.repList.Clear()
        for item in self.rep.items:
            entry = m341edRepEntry(item)
            self.repList.Append(entry.getDisplayName())
            
    def repFromControls(self):
        self.repEntry.surname = self.repControls["surname"].GetValue();
        self.repEntry.forename = self.repControls["forename"].GetValue();
        self.repEntry.title = self.repControls["title"].GetValue();
        self.repEntry.company = self.repControls["company"].GetValue();
        self.repEntry.adr_st = self.repControls["adr_st"].GetValue();
        self.repEntry.adr_bp = self.repControls["adr_bp"].GetValue();
        self.repEntry.adr_cp = self.repControls["adr_cp"].GetValue();
        self.repEntry.adr_loc = self.repControls["adr_loc"].GetValue();
        self.repEntry.adr_state = self.repControls["adr_state"].GetValue();
        self.repEntry.adr_country = self.repControls["adr_country"].GetValue();
        self.repEntry.tel_home = self.repControls["tel_home"].GetValue();
        self.repEntry.tel_work = self.repControls["tel_work"].GetValue();
        self.repEntry.tel_cell = self.repControls["tel_cell"].GetValue();
        self.repEntry.tel_fax = self.repControls["tel_fax"].GetValue();
        self.repEntry.email_def = self.repControls["email_def"].GetValue();
        self.repEntry.email = self.repControls["email"].GetValue();
        self.repEntry.generateItem();
        if self.curRepSelection != -1: self.repList.SetString(self.curRepSelection, self.repEntry.getDisplayName())
        
    def repToControls(self):
        self.repControls["surname"].SetValue(self.repEntry.surname);
        self.repControls["forename"].SetValue(self.repEntry.forename);
        self.repControls["title"].SetValue(self.repEntry.title);
        self.repControls["company"].SetValue(self.repEntry.company);
        self.repControls["adr_st"].SetValue(self.repEntry.adr_st);
        self.repControls["adr_bp"].SetValue(self.repEntry.adr_bp);
        self.repControls["adr_cp"].SetValue(self.repEntry.adr_cp);
        self.repControls["adr_loc"].SetValue(self.repEntry.adr_loc);
        self.repControls["adr_state"].SetValue(self.repEntry.adr_state);
        self.repControls["adr_country"].SetValue(self.repEntry.adr_country);
        self.repControls["tel_home"].SetValue(self.repEntry.tel_home);
        self.repControls["tel_work"].SetValue(self.repEntry.tel_work);
        self.repControls["tel_cell"].SetValue(self.repEntry.tel_cell);
        self.repControls["tel_fax"].SetValue(self.repEntry.tel_fax);
        self.repControls["email_def"].SetValue(self.repEntry.email_def);
        self.repControls["email"].SetValue(self.repEntry.email);

# Main Application GUI class
class m341edApp(wxApp):
    def OnInit(self):
        wxInitAllImageHandlers()
        frame = m341edFrame(NULL, -1, "m341ed - m341i Personal Information Editor")
        frame.Show(true)
        self.SetTopWindow(frame)
        return true


#----------------------------------------------------------------------
# This file was generated by C:\Python22\python C:\Python22\Lib\site-packages\wxPython\tools\img2py.py
#
from wxPython.wx import wxImageFromStream, wxBitmapFromImage, wxBitmapFromXPMData
import cStringIO, zlib


def getOpenData():
    return \
'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x10\x00\x00\x00\x0f\x08\x06\
\x00\x00\x00\xedsO/\x00\x00\x00\x04sBIT\x08\x08\x08\x08|\x08d\x88\x00\x00\
\x00\x8eIDATx\x9c\xa5\x92\xd1\r\xc4 \x0cC\x9dS\x07\xf0\xc8\x8c\xec\r\xd2\x0f\
\x14\x91p\xa8W8\xff@\x10\xcf8(F\x12\xff\xe8z{Q\x92\xc7\x9e\xa4m\x19H\xf2\x0c\
E-\xc9\xed\xb4\x85Ht\xcd\x07s\xc4\'\x18\x00\x8c$$\xb9;\x008\x00\x83=\xe0\xb3\
y\xfa\x83\x0e\x03\x0ew+u\xac\xb6p\xfe\x8c\xed\x1a\xaa\xeb\xb7\x96\tF\x1b\x01\
\r8\xf7?\x19T\xb8\xb5\xe5\x83E\xad\x95\x16\xba\xf1\x0eL\xd2J\x82]\x18H\tN` \
\xcd\xc1o\xb4k\x9e\x83\xe3Q\x0e\xdd\x02GB\xf5\xdfU\xf9\x02\x00\x00\x00\x00IE\
ND\xaeB`\x82' 

def getOpenBitmap():
    return wxBitmapFromImage(getOpenImage())

def getOpenImage():
    stream = cStringIO.StringIO(getOpenData())
    return wxImageFromStream(stream)

def getSaveData():
    return zlib.decompress(
'x\xda\xeb\x0c\xf0s\xe7\xe5\x92\xe2b``\xe0\xf5\xf4p\t\x02\xd2\x02 \xcc\xc1\
\x06$\xe5?\xffO\x04R,\xc5N\x9e!\x1c@P\xc3\x91\xd2\x01\xe4\xa7y\xba8\x86T\xcc\
9\x1a\xec\xc8u@\x81\xc7\xfb(\xfb\x93\x93\xb5\x9b\xeco\xf8\xa56\xf2\x16~LX\
\xd0\xee%\xad\x94\xd9\xa4Rv\x811\xa1\xa7\xd0\xf2\xb4\xca\xe2\xd0\xc9?m\xce\
\xadJ\xcbZ\x7f\xb0Ak\x1b\x87\xd7Z\xdf\x05\x16\xfe\x17\xb6\x9ed1z>\xed\xd5\
\xffx\x96x\xe6\xfd"k\x84"\xf4^(j\x9e\xdb-0\xd5M=@E\xb9\xecq\r\xf3\xa2=\x12\
\xfd\x17\xdf\xff\xef\x02\xda\xc8\xe0\xe9\xea\xe7\xb2\xce)\xa1\t\x00\xe8D=r' )

def getSaveBitmap():
    return wxBitmapFromImage(getSaveImage())

def getSaveImage():
    stream = cStringIO.StringIO(getSaveData())
    return wxImageFromStream(stream)

def getDeleteData():
    return zlib.decompress(
'x\xda\xeb\x0c\xf0s\xe7\xe5\x92\xe2b``\xe0\xf5\xf4p\t\x02\xd2\x02 \xcc\xc1\
\x06$\xe5?\xffO\x04R,\xc5N\x9e!\x1c@P\xc3\x91\xd2\x01\xe4\xd7y\xba8\x86T\xcc\
Y:)\x90\xeb\x80\x01\x87\xf3s\xbf\t\xbf\xe7o2\xbf\xb1\x8f)k\xb1\x98\x16O\x9bw\
\\\xee2\xc6\x8a\xbcW{\x8b\xaa\x0fD\xbd~\\\x9c\xb4\xc4\xcf\xef\x82c\x05\x07\
\x037\x83\x99\x15Gu\\\xb6\x96K\xfe\xb2\x88\x99\xde\x0e\xa6\x8ef\xed\xda>I\
\xa9y\x8c\x95MZ7>\xea3l\x98\xe3\xcc\x1d\xc0\xf8\xeb;\x0fg\xc3\xa9;_\x0f\xa9\
\xadz\xad\xd1q\xfd\x14\xcf\xaa#W\xbf\xe7\n\xab\x1bw\x07O\xe9.\x89\xb2OX\x19\
\xe1%\xe4\xd4\xfc\x0f\xe8\x12\x06OW?\x97uN\tM\x00\x9c\xb1E\xa2' )

def getDeleteBitmap():
    return wxBitmapFromImage(getDeleteImage())

def getDeleteImage():
    stream = cStringIO.StringIO(getDeleteData())
    return wxImageFromStream(stream)

def getStopData():
    return zlib.decompress(
"x\xda\xeb\x0c\xf0s\xe7\xe5\x92\xe2b``\xe0\xf5\xf4p\t\x02\xd2\x02 \xcc\xc1\
\x06$\xe5?\xffO\x04R,\xc5N\x9e!\x1c@P\xc3\x91\xd2\x01\xe4g{\xba8\x86T\xcc\
\xd9\x1a\xe4\xc8w@\x81c\xf1i\xb9\x03\xff\xfe\x9f\xf8\xc9l{Vc\xda\x8b\x94\xd7\
\xbd7\x94\xb68\x84\xaa6)/\x11\x9bx\xb9zG\xf0\xa9\xdc\xda\x95M\x1f\x13\xc278q\
\xdf^\x11\x9d\xa8\x966g\x03\xfb\xd6\x83\xa7\xde\xf7X\xcf\x9a\xa1^{\xa1\xfa\
\xa7s\xcf\x82\xcc\x9d+\x84+,\x8d\xb7\xdcy\x1f\x141\xf7PQ\x9bw\xcd\x86\xdaS\
\xf9\x82\xdf\x160\xa8\x89\xc9=\xad\xbb1\xe9'\xd0Z\x06OW?\x97uN\tM\x00\xe9\tE\
\xd5" )

def getStopBitmap():
    return wxBitmapFromImage(getStopImage())

def getStopImage():
    stream = cStringIO.StringIO(getStopData())
    return wxImageFromStream(stream)

def getAddData():
    return zlib.decompress(
'x\xda\xeb\x0c\xf0s\xe7\xe5\x92\xe2b``\xe0\xf5\xf4p\t\x02\xd2\x02 \xcc\xc1\
\x06$\xe5?\xffO\x04R,\xc5N\x9e!\x1c@P\xc3\x91\xd2\x01\xe4\xe7y\xba8\x86T\xcc\
9:\xd9\x90\xef\x80\x02\x87\xeb\xfe\xde\xe6\xe3\x8f2dz\x93-\x05\xde^\x08\xb9}\
\xc5-\x8a\xed\x7f\xca\x85\xef\x8eS\x16\xb8j\xcb\xdc\xb21`pa\xf00\xfc\xdb\xb4\
\xf9\xd9a\x06\x06\x97\'\xc2>.{\x9b\xc4D\x8c\x0e:\xd9\xce\xdc\xcd^\xcc\xfcM\
\xcaG$\xbe\xbcb\xc3\xb3\xe3\x9a\xcd\x8c\xfd\x07\x83_\xcf\xae\xd8}\xe8k\xedZ\
\xae\xa8-U\xfb\x8a"\xecz\xad\x99\x97\xc8\x9e\xacR_y\x00h3\x83\xa7\xab\x9f\
\xcb:\xa7\x84&\x00\xec;@\x95' )

def getAddBitmap():
    return wxBitmapFromImage(getAddImage())

def getAddImage():
    stream = cStringIO.StringIO(getAddData())
    return wxImageFromStream(stream)


def getAddBitmap():
    return wxBitmapFromImage(getAddImage())

def getAddImage():
    stream = cStringIO.StringIO(getAddData())
    return wxImageFromStream(stream)


def getDelData():
    return zlib.decompress(
"x\xda\xeb\x0c\xf0s\xe7\xe5\x92\xe2b``\xe0\xf5\xf4p\t\x02\xd2\x02 \xcc\xc1\
\x06$\xe5?\xffO\x04R,\xc5N\x9e!\x1c@P\xc3\x91\xd2\x01\xe4\xe7y\xba8\x86T\xcc\
9:\xd9\x90\xab\xc1\x80\xc75~\xa9s\xff\x93\x1b\xc9\x95,\xfdW7\xba\xbf\x12\x88\
b\x17}\xbd\xc4\xd0\xc3>\x85\xf3\xcft\x81\xba9!\x99\x12&\x91g\x18\xe4\x14~|8\
\x19\xb3\xe4\rC\xc3\x94I\xa7d\x92\xf7\x98Y\x98\xca\x9fU\x7f\x9a7\xe3'\xdb\
\x7f\xc60\x85\x92\xa5l:\x0e/\xbdx+V\x7fl\x88\xe6\xdbd\xe4\xc3\xe0\xb7\xca\
\xc4{\xca\xdd\x0f\xf9w\x18\x94t\xe5|\xb7\xd4_|\x00\xb4\x99\xc1\xd3\xd5\xcfe\
\x9dSB\x13\x00j1>\xc0" )

def getDelBitmap():
    return wxBitmapFromImage(getDelImage())

def getDelImage():
    stream = cStringIO.StringIO(getDelData())
    return wxImageFromStream(stream)


# Main Part ----------------------------------------------

# Launch the Application in GUI mode
def interfMain():
    app = m341edApp(0)
    app.MainLoop()

# Auto Launch
if __name__ == "__main__":
    interfMain();
    
