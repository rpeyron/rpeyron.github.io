// intellimenuDlg.cpp : implementation file
//

#include "stdafx.h"
#include "intellimenu.h"
#include "intellimenuDlg.h"
#include "../hookdll/hook.h"

#include "xmlmenu.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAX_TXT 36


/////////////////////////////////////////////////////////////////////////////
// CIntelliMenuDlg dialog

CIntelliMenuDlg::CIntelliMenuDlg(CWnd* pParent /*=NULL*/) : CTrayDialog(CIntelliMenuDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIntelliMenuDlg)
	m_DialogText = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	mMagicKey = false;
}

void CIntelliMenuDlg::DoDataExchange(CDataExchange* pDX)
{
	CTrayDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIntelliMenuDlg)
	DDX_Text(pDX, IDC_TEXT, m_DialogText);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIntelliMenuDlg, CTrayDialog)
//{{AFX_MSG_MAP(CIntelliMenuDlg)
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_SET, OnSet)
ON_BN_CLICKED(IDC_REMOVE, OnRemove)
ON_WM_COPYDATA()
ON_WM_DESTROY()
ON_BN_CLICKED(IDC_SET, OnSet)
ON_BN_CLICKED(IDC_REMOVE, OnRemove)
ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()




/////////////////////////////////////////////////////////////////////////////
// CIntelliMenuDlg message handlers




BOOL CIntelliMenuDlg::OnInitDialog()
{
	CTrayDialog::OnInitDialog();
	
	TraySetIcon(IDR_MAINFRAME);
	TraySetToolTip(_T("InsertMenuHook"));
	TraySetMenu(IDR_POPUP);
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// initialize member variables
	m_bTransition = false;
	m_bPrevious   = false;
	m_bAlt        = false;
	m_bExtended   = false;
	
	char str[1024];
	sprintf(str,"Insertion de texte rapide [%s]\r\n\r\nActivation par la Touche Windows + Espace\r\nR�glages par menu.xml.\r\n\r\n2003 - R�mi Peyronnet", VERSION);
	m_DialogText = CString(str);
	
	UpdateData(false);
	
	
	OnRefresh();
	
	OnSet();
	
	PostMessage(WM_SYSCOMMAND,SC_MINIMIZE,0);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}




// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CIntelliMenuDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CTrayDialog::OnPaint();
	}
}



// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CIntelliMenuDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}



//
// set hook when the "set"-button is pressed
//
void CIntelliMenuDlg::OnSet() 
{
	mMagicKey = false;
	SetHook(this->m_hWnd);
}




//
// remove hook when the "remove"-button is pressed
//
void CIntelliMenuDlg::OnRemove() 
{
	mMagicKey = false;
	RemoveHook();
}



//
// the copydata-message-handler is triggered by the WM_COPYDATA message
// the struct COPYDATASTRUCT contains a pointer to HEVENT which stores
// information on the hooked keycodes
//
BOOL CIntelliMenuDlg::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct) 
{
	if( pCopyDataStruct->cbData!=sizeof(HEVENT) || ((HEVENT*)pCopyDataStruct->lpData)->dwHookType != WH_KEYBOARD)
		return CTrayDialog::OnCopyData(pWnd, pCopyDataStruct);
	
	HEVENT Event;
	memcpy(&Event, (HEVENT*)pCopyDataStruct->lpData, sizeof(HEVENT));             // transfer data to internal variable
	
	// compute the additional keycode info in lParam
	m_bTransition = (((DWORD)KF_UP<<16)&Event.lParam)!=0;
	m_bPrevious   = (0x40000000&Event.lParam)!=0;
	m_bAlt        = (((DWORD)KF_ALTDOWN<<16)&Event.lParam)!=0;
	m_bExtended   = (((DWORD)KF_EXTENDED<<16)&Event.lParam)!=0;
	

	if ((!m_bTransition) && (Event.wParam == K_MAGIC_KEY)) mMagicKey = true;
	if ((m_bTransition) && (Event.wParam == K_MAGIC_KEY)) mMagicKey = false;
	
	if ((!m_bTransition) && (Event.wParam == K_KEY) && (mMagicKey) )
	{
		PostMessage(WM_COMMAND, NT_HOOKACTION, 0);
		return(TRUE);
	}
	
	return(FALSE);
}


//
// overrride standard destroy handler to safely unhook when we quit
//
void CIntelliMenuDlg::OnDestroy() 
{
	RemoveHook();
	CTrayDialog::OnDestroy();
}

void sendStringKeyEvents(CString str)
{
	for(int i = 0; i < str.GetLength(); i++)
	{
		keybd_event(VkKeyScan(str[i]), 1, 0, 0);
	}
}

void sendPasteEvent()
{
	keybd_event(VK_CONTROL, 1, 0, 0); 
	keybd_event(VkKeyScan('v'), 1, 0, 0); 
	keybd_event(VK_CONTROL, 1, KEYEVENTF_KEYUP, 0); 
}

BOOL CIntelliMenuDlg::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	if (wParam == NT_HOOKACTION)
	{
		
		POINT p;
		HMENU trackMenu;
		
		// BUGFIX for NT4 : invalidate the Magic Key
		mMagicKey = false;

		// keybd_event(VK_BACK, 1, 0, 0);
		
		GetCursorPos(&p);
		
		CWnd * curWnd = GetForegroundWindow();
		
		uni_string title = _T("");
		if (curWnd != NULL)
		{
			CString ctitle;
			curWnd->GetWindowText(ctitle);
			title = ctitle;
		}
		trackMenu = xmlMenu.GetMenu(title);
		
		if (!TrackPopupMenuEx(trackMenu, TPM_LEFTALIGN, p.x, p.y, this->m_hWnd, NULL))
		{
			LPVOID lpMsgBuf;
			FormatMessage( 
				FORMAT_MESSAGE_ALLOCATE_BUFFER | 
				FORMAT_MESSAGE_FROM_SYSTEM | 
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				GetLastError(),
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
				(LPTSTR) &lpMsgBuf,
				0,
				NULL 
				);
			// Process any inserts in lpMsgBuf.
			// ...
			// Display the string.
			::MessageBox( NULL, (LPCTSTR)lpMsgBuf, _T("Error"), MB_OK | MB_ICONINFORMATION );
			// Free the buffer.
			LocalFree( lpMsgBuf );
		}
		
		curWnd->SetForegroundWindow();
		
		return 0;
	}
	
	if ((wParam >= MN_START) && (wParam <= xmlMenu.curId + MN_START))
	{
		
		xmlMenu.CopyContentsToClipBoard(this->m_hWnd, wParam);
		// Paste
		sendPasteEvent();
		return 0;
	}
	if ((wParam >= MN_FILE_START) && (wParam < xmlMenu.fileMenuId + MN_FILE_START))
	{
		TCHAR file[10240], command[10240];
		GetMenuString(xmlMenu.fileMenu, wParam, file, 10240, MF_BYCOMMAND);
		if (xmlMenu.parameters.find(PA_EDIT_WITH) != xmlMenu.parameters.end())
		{
			_tcscpy(command, xmlMenu.parameters[PA_EDIT_WITH].c_str());
		}
		else
		{
			_tcscpy(command,_T("notepad"));
		}
		_tcscat(command,_T(" "));
		_tcscat(command, file);
		STARTUPINFO si;
		PROCESS_INFORMATION pi;
		GetStartupInfo(&si);	// Initialize the startup info struct
		CreateProcess(NULL, command, NULL, NULL, FALSE, NULL,  NULL, NULL, &si, &pi);
		CloseHandle(pi.hThread);	// Close our reference to the initial thread
		CloseHandle(pi.hProcess);	// And close our reference to the process.
		return 0;
	}
	return CTrayDialog::OnCommand(wParam, lParam);
}


void CIntelliMenuDlg::OnRefresh() 
{
	mMagicKey = false;
	if (!xmlMenu.ParseFile(XML_CONFIG_FILE))
	{
		TCHAR str[1024];
		_stprintf(str, _T("[Parsing Error] %s (%d : %d)"), xmlMenu.subMenu.GetErrorString(),xmlMenu.subMenu.GetCurrentLineNumber(), xmlMenu.subMenu.GetCurrentColumnNumber());
		MessageBox(str);
	}
	this->m_mnuTrayMenu.GetSubMenu(0)->SetDefaultItem(0, TRUE);
	this->m_mnuTrayMenu.GetSubMenu(0)->DeleteMenu(2, MF_BYPOSITION);
	this->m_mnuTrayMenu.GetSubMenu(0)->InsertMenu(2, MF_BYPOSITION | MF_POPUP, (UINT)xmlMenu.GetMenu(uni_string(_T(""))), _T("Menu XML"));
	this->m_mnuTrayMenu.GetSubMenu(0)->DeleteMenu(3, MF_BYPOSITION);
	this->m_mnuTrayMenu.GetSubMenu(0)->InsertMenu(3, MF_BYPOSITION | MF_POPUP, (UINT)xmlMenu.fileMenu, _T("Fichiers"));
}
