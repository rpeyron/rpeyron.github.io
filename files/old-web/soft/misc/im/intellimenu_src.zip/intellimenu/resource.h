//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by intellimenu.rc
//
#define IDD_INTELLIMENU_DIALOG          102
#define IDR_INTELLIMENU                 103
#define IDR_MAINFRAME                   128
#define IDR_POPUP                       129
#define IDC_LPARAM                      1000
#define IDC_WPARAM                      1001
#define IDC_SET                         1002
#define IDC_REMOVE                      1003
#define IDC_TESTBOX                     1004
#define IDC_REFRESH                     1004
#define IDC_SCANCODE                    1005
#define IDC_LOGBOX                      1006
#define IDC_TRANSITION                  1007
#define IDC_PREVIOUS                    1008
#define IDC_ALT                         1009
#define IDC_EXTENDED                    1010
#define IDC_REPEATCOUNT                 1011
#define IDC_TEXT                        1012
#define ID_POPUP_ITEM1                  32771
#define ID_POPUP_ITEM2                  32772
#define ID_POPUP_FERMER                 10000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
