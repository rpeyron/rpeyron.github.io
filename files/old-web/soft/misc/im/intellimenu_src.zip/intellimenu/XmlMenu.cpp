// (c) 2003 - R�mi Peyronnet - Licence GPL

// XmlMenu.cpp: implementation of the CXmlMenu class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "intellimenu.h"
#include "XmlMenu.h"
#include <assert.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4355)
CXmlMenu::CXmlMenu() : subMenu(CXmlSubMenu(*this))
{
	curId = -1;
	fileMenu = CreatePopupMenu();
}


CXmlMenu::~CXmlMenu()
{
	DestroyMenu(fileMenu);
}


bool CXmlMenu::CopyContentsToClipBoard(HWND wnd, int id)
{
	uni_string strData;
	assert(id >= MN_START );
	assert((id - MN_START) < ids.size());
	strData = contents[ids[id - MN_START]];
	// Correct the new line stuff
	for(int i=0; i < strData.size(); i++)
	{
		if (strData[i]=='\n')
		{
			if ( (i > 1) && (strData[i-1]=='\r') )
			{
			}
			else
			{
				strData.insert(i, _T("\r"));
			}
		}
	}
	// Copy To Clip Board
	OpenClipboard(wnd);
	EmptyClipboard();
	HGLOBAL hClipboardData = GlobalAlloc(GMEM_DDESHARE, (strData.size()+1)*sizeof(TCHAR));
	TCHAR * pchData;
	pchData = (TCHAR *)GlobalLock(hClipboardData);
	_tcscpy(pchData, strData.c_str());
	GlobalUnlock(hClipboardData);
#ifdef _UNICODE
	SetClipboardData(CF_UNICODETEXT,hClipboardData);
#else
	SetClipboardData(CF_TEXT,hClipboardData);
#endif
	CloseClipboard();
	return true;
}

HMENU CXmlMenu::GetMenu(uni_string &appTitle)
{
	HMENU retMenu;
	int curDepth = 0;
	retMenu = subMenu.hMenu;
	uni_string item;
	
	if (appTitle == _T("")) return retMenu;
	for(map<uni_string, struct appMenuEntry>::iterator ami = appMenus.begin(); ami != appMenus.end(); ami++)
	{
		item = ami->first;
		if ((appTitle.find(item) != uni_string::npos) && (ami->second.depth >= curDepth))
		{
			retMenu = ami->second.hMenu;
			curDepth = ami->second.depth;
		}
	}
	return retMenu;
}

bool CXmlMenu::ParseFile(const TCHAR * file)
{
	DestroyMenu(fileMenu);
	fileMenu = CreatePopupMenu();
	contents.clear();
	appMenus.clear();
	ids.clear();
	curId = -1;
	curDepth = 0;
	fileMenuId = 0;
	subMenu.Create();
	return subMenu.ParseFile(file);
	// subMenu.Destroy(); 
}