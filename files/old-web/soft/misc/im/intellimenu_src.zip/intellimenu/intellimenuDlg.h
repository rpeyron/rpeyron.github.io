// intellimenuDlg.h : header file
//

#if !defined(AFX_INTELLIMENUDLG_H__8A35218C_4AAC_11D5_AE1D_0050DA2A55E0__INCLUDED_)
#define AFX_INTELLIMENUDLG_H__8A35218C_4AAC_11D5_AE1D_0050DA2A55E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define NT_HOOKACTION		4212

#include "xmlmenu.h"
#include "traydialog.h"

//
// hook DLL functions
//
extern BOOL SetHook(HWND hWnd);
BOOL RemoveHook();

/////////////////////////////////////////////////////////////////////////////
// CIntelliMenuDlg dialog

class CIntelliMenuDlg : public CTrayDialog
{
// Construction
public:
	CXmlMenu xmlMenu;
	CIntelliMenuDlg(CWnd* pParent = NULL);	// standard constructor


	//{{AFX_DATA(CIntelliMenuDlg)
	enum { IDD = IDD_INTELLIMENU_DIALOG };
	BOOL	m_bTransition;
	BOOL	m_bPrevious;
	BOOL	m_bAlt;
	BOOL	m_bExtended;
	CString	m_DialogText;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntelliMenuDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL loadXML();
	HICON m_hIcon;
	bool mMagicKey;

	// Generated message map functions
	//{{AFX_MSG(CIntelliMenuDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSet();
	afx_msg void OnRemove();
	afx_msg BOOL OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct);
	afx_msg void OnDestroy();
	afx_msg void OnRefresh();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTELLIMENUDLG_H__8A35218C_4AAC_11D5_AE1D_0050DA2A55E0__INCLUDED_)
