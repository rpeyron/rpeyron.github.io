// (c) 2003 - R�mi Peyronnet - License GPL.

// XmlSubMenu.cpp: implementation of the CXmlSubMenu class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "intellimenu.h"
#include "XmlSubMenu.h"
#include "xmlmenu.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////


// These are helper functions to convert back to UTF-8 -----------------------------

#ifndef _UNICODE

int convert_back(string & str)
{
	WCHAR * wstr;
	char * cstr;
	int ws = 2*str.size()+2;
	wstr = (WCHAR *) malloc(ws);
	cstr = (char *) malloc(str.size()+1);
	if ((wstr == NULL) || (cstr == NULL)) return -1;
	MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, wstr, ws);
	WideCharToMultiByte(CP_ACP, 0, wstr, -1, cstr, str.size() + 1, NULL, NULL);
	free(wstr);
	str = cstr;
	free(cstr);
	return 0;
}

char * convert_back(const char * str)
{
	WCHAR * wstr;
	char * cstr;
	int ws = 2*strlen(str)+2;
	wstr = (WCHAR *) malloc(ws);
	cstr = (char *) malloc(strlen(str)+1);
	if ((wstr == NULL) || (cstr == NULL)) return NULL;
	MultiByteToWideChar(CP_UTF8, 0, str, -1, wstr, ws);
	WideCharToMultiByte(CP_ACP, 0, wstr, -1, cstr, strlen(str) + 1, NULL, NULL);
	free(wstr);
	return cstr;
}

#else 

#define convert_back

#endif // _UNICODE

inline bool
sp_UTF8_UCS(const char *& utf8, int& c)
{
	int b = (unsigned char)*utf8++;
	if (b <= 0x7F)
	{
		c = b;
	}
	else if ((b & 0xE0) == 0xC0)
	{       /* 110xxxxx 10xxxxxx */
		c = (b & 0x1F) << 6;
		b = *utf8++;
		c |= b & 0x3F;
	}
	else if ((b & 0xF0) == 0xE0)
	{       /* 1110xxxx + 2 */
		c = (b & 0x0F) << 12;
		b = *utf8++;
		c |= (b & 0x3F) << 6;
		b = *utf8++;
		c |= b & 0x3F;
	}
	else if ((b & 0xF1) == 0xF0)
	{       /* 11110xxx + 3 */
		c = (b & 0x0F) << 18;
		b = *utf8++;
		c |= (b & 0x3F) << 12;
		b = *utf8++;
		c |= (b & 0x3F) << 6;
		b = *utf8++;
		c |= b & 0x3F;
	}
	else if ((b & 0xFD) == 0xF8)
	{
		/* 111110xx + 4 */
		c = (b & 0x0F) << 24;
		b = *utf8++;
		c |= (b & 0x0F) << 18;
		b = *utf8++;
		c |= (b & 0x3F) << 12;
		b = *utf8++;
		c |= (b & 0x3F) << 6;
		b = *utf8++;
		c |= b & 0x3F;
	}
	else if ((b & 0xFE) == 0xFC)
	{
		/* 1111110x + 5 */
		c = (b & 0x0F) << 30;
		b = *utf8++;
		c |= (b & 0x0F) << 24;
		b = *utf8++;
		c |= (b & 0x0F) << 18;
		b = *utf8++;
		c |= (b & 0x3F) << 12;
		b = *utf8++;
		c |= (b & 0x3F) << 6;
		b = *utf8++;
		c |= b & 0x3F;
	}
	else
	{
		/* Error */
		return false;
	}
	return true;
}

int
ishUtilUTF8toANSI(char *pchString, int iStringLen)
{
	const size_t cszStringLen = iStringLen >= 0
		? (size_t)iStringLen
		: (pchString
		? strlen(pchString)
		: (size_t)0U);
	int bConverted = 1;
	size_t szInputIdx, szOutputIdx = (size_t)0U;
	
	for(szInputIdx = (size_t)0U;
	bConverted
		&& szInputIdx < cszStringLen;
	++szInputIdx)
    {
	/* If input_bin(0xxxxxxx) ~ ASCII_bin(0xxxxxxx)
	If input_bin(110000yy 10xxxxxx) ~ ANSI_bin(yyxxxxxx)
	All other UTF-8 encodings don't map to ANSI so we don't
	convert them and fail if we encounter them.
	See: http://www.unicode.org for more information about
	UTF-8 encoding.
		*/
		if(0x00 == (pchString[szInputIdx] & 0x80)) /* Plain ascii char */
			pchString[szOutputIdx++] = pchString[szInputIdx];
		else if(szInputIdx + (size_t)1U < cszStringLen
			&& 0xC0 == (pchString[szInputIdx] & 0xFC)
			&& 0x80 == (pchString[szInputIdx + (size_t)1U] & 0xC0))
		{
			/* UTF-8 encoded char that maps to ANSI. */
			pchString[szOutputIdx++] = ((pchString[szInputIdx] & 0x03) << 6)
				+ (pchString[szInputIdx + (size_t)1U] & 0x3F);
			++szInputIdx; /* We must skip the second input char. */
		}
		else /* UTF-8 encoding that doesn't map to ANSI or illegal input. */
			bConverted = 0;
    }
	return bConverted ? (int)szOutputIdx : -1;
}




// ---------------------------------------------------------------------------------



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXmlSubMenu::CXmlSubMenu(CXmlMenu & mainMenu) : mainMenu(mainMenu)
{
	hMenu = CreatePopupMenu();
	curMenu.push(hMenu);
	doNotDetach = false;
	noMenuName = false;
}

CXmlSubMenu::~CXmlSubMenu()
{
	if (!doNotDetach)
	{
		DestroyMenu(hMenu);
	}
}

void CXmlSubMenu::OnPostCreate ()
{
	// Enable all the event routines we want
	EnableStartElementHandler ();
	EnableEndElementHandler ();
	// Note: EnableElementHandler will do both start and end
	EnableCharacterDataHandler ();
}

void CXmlSubMenu::OnStartElement (const XML_Char *pszName, const XML_Char **papszAttrs)
{
	const XML_Char * name_attr = NULL;
	XML_Char * name = NULL;
	const XML_Char * id = NULL;
	uni_string & Id = uni_string(_T(""));
	
	HMENU mMenu = curMenu.top();
	
	name_attr = GetAttribute(papszAttrs, AT_NAME);
	curCharacterData = _T("");
#ifndef _UNICODE
	if (name_attr != NULL)
	{
		name = convert_back(name_attr);
	}
#else
	name = const_cast<XML_Char *>(name_attr);
#endif
	
	if (_tcscmp(pszName, EL_ROOT) == 0)
	{
		if ((!noMenuName) && (name != NULL))
		{
			AppendMenu(mMenu, 0, 0, name);
			AppendMenu(mMenu, MF_SEPARATOR, 0, NULL);
		}
		InsertAppMenuEntry(GetAttribute(papszAttrs, AT_APP), mMenu);
	}
	if (_tcscmp(pszName, EL_MENU) == 0)
	{
		mainMenu.curDepth++;
		HMENU nextMenu = CreatePopupMenu();
		AppendMenu(mMenu, MF_POPUP, (UINT)nextMenu,  name);
		curMenu.push(nextMenu);
		InsertAppMenuEntry(GetAttribute(papszAttrs, AT_APP), nextMenu);
	}
	if (_tcscmp(pszName, EL_ITEM_SEPARATOR) == 0)
	{
		AppendMenu(mMenu, MF_SEPARATOR, 0,  NULL);
	}
	else if ( (_tcscmp(pszName, EL_ITEM) == 0) || (_tcscmp(pszName, EL_CONTENT) == 0) )
	{
		mainMenu.curId++;
		id = GetAttribute(papszAttrs, AT_ID);
		if (id == NULL)
		{
			id = GetAttribute(papszAttrs, AT_REF_ID);
		}
		if (id != NULL)
		{
			Id = id;
			mainMenu.ids.push_back(Id);
		}
		else
		{
			TCHAR temp[1024];
			_stprintf(temp, _T("%d"), mainMenu.curId + MN_START);
			Id = temp;
			mainMenu.ids.push_back(Id);
		}
		if (_tcscmp(pszName, EL_ITEM) == 0) AppendMenu(mMenu, 0, mainMenu.curId + MN_START, name);
		appendText = true;
	}
	else if (_tcscmp(pszName, EL_MENU_INCLUDE) == 0)
	{
		mainMenu.curDepth++;
		CXmlSubMenu mySubMenu(mainMenu);
		mySubMenu.doNotDetach = true;
		mySubMenu.Create(); 
		mySubMenu.ParseFile(GetAttribute(papszAttrs, AT_HREF));
		AppendMenu(mMenu, MF_POPUP, (UINT)mySubMenu.hMenu, name);
		InsertAppMenuEntry(GetAttribute(papszAttrs, AT_APP), mySubMenu.hMenu);
		mainMenu.curDepth--;
	}
	else if (_tcscmp(pszName, EL_PARAMETER) == 0)
	{
		curItem = GetAttribute(papszAttrs, AT_NAME);
		appendText = true;
	}
	
#ifndef _UNICODE	
	if (name != NULL) free(name);
#endif
	return;
}

// @cmember End element handler

void CXmlSubMenu::OnEndElement (const XML_Char *pszName)
{
	if (_tcscmp(pszName, EL_MENU) == 0)
	{
		curMenu.pop();
		mainMenu.curDepth--;
	}
	if ( (_tcscmp(pszName, EL_ITEM) == 0) || (_tcscmp(pszName, EL_CONTENT) == 0) )
	{
		if ((mainMenu.curId >= 0) && (mainMenu.curId < mainMenu.ids.size()))
		{
			mainMenu.contents[mainMenu.ids[mainMenu.curId]] += curCharacterData;
		}
	}
	if (_tcscmp(pszName, EL_PARAMETER) == 0)
	{
		if (curItem.size() > 0) mainMenu.parameters[curItem] = curCharacterData;
	}
	curCharacterData = _T("");
	appendText = false;
	return;
}

// @cmember Character data handler

void CXmlSubMenu::OnCharacterData (const XML_Char *pszData, int nLength)
{
	if (!appendText) return;
	uni_string temp;
	if (nLength < 0)
	{
		temp = uni_string(pszData);
	}
	else
	{
		temp.append(pszData, nLength);
	}
#ifndef _UNICODE
	convert_back(temp);
#endif
	curCharacterData += temp;
	
	/*
	// Retire les chaines vides
	int i = temp.size() - 1;
	while (
	(temp[i] == '\n') ||
	(temp[i] == '\r') ||
	(temp[i] == '\t') ||
	(temp[i] == ' ')
	) i--;
	// if (i != (temp.size() - 1)) temp.substr(0, i);
	if (i == -1) temp = "";
	*/
	// Enregistre
	/*
	if ((mainMenu.curId >= 0) && (mainMenu.curId < mainMenu.ids.size()))
	{
	mainMenu.contents[mainMenu.ids[mainMenu.curId]] += temp;
	}
	*/
	return;
}

// @cmember Comment handler

void CXmlSubMenu::OnComment (const XML_Char *pszData)
{
	return;
}

// @cmember Start CDATA section handler

void CXmlSubMenu::OnStartCdataSection ()
{
	return;
}

// @cmember End CDATA section handler

void CXmlSubMenu::OnEndCdataSection ()
{
	return;
}

// @cmember Default handler

void CXmlSubMenu::OnDefault (const XML_Char *pszData, int nLength)
{
	return;
}


bool CXmlSubMenu::ParseFile(const TCHAR *file)
{
	// Reset the menu
	curMenu.empty();
	DestroyMenu(hMenu);
	hMenu = CreatePopupMenu();
	curMenu.push(hMenu);
	
	// Insert the file
	AppendMenu(mainMenu.fileMenu, 0, MN_FILE_START + mainMenu.fileMenuId++, file);
	
	// Treat the file
	FILE * fp = _tfopen (file, _T("r"));
	if (fp == NULL)		return false;
	
	// Loop while there is data
	
	bool fSuccess = true;
	while (!feof (fp) && fSuccess)
	{
		LPSTR pszBuffer = (LPSTR) GetBuffer (256); // REQUEST
		if (pszBuffer == NULL)	fSuccess = false;
		else
		{
			int nLength = fread (pszBuffer, 1, 256, fp); // READ
			fSuccess = ParseBuffer (nLength, nLength == 0); // PARSE
		}	
	}
	
	// Close the file
	
	fclose (fp);
	return fSuccess;
}

const XML_Char * CXmlSubMenu::GetAttribute(const XML_Char **papszAttrs, const XML_Char *name)
{
	while ( (*papszAttrs != NULL) && (_tcscmp(*papszAttrs, name) != 0) ) papszAttrs++;
	if (*papszAttrs != NULL) return *(++papszAttrs); else return NULL;
}

int CXmlSubMenu::InsertAppMenuEntry(const TCHAR *strApp, HMENU hMenu)
{
	struct CXmlMenu::appMenuEntry aME;
	TCHAR * sApp, * token;
	if (strApp == NULL) return -1;
	
	sApp = (TCHAR *) malloc(_tcslen(strApp)*sizeof(TCHAR)+2);
	if (sApp == NULL) { MessageBox(NULL, _T("Out of memory"), _T("Error"), MB_OK); return -2; }
	_tcscpy(sApp, strApp);
	
	aME.hMenu = hMenu;
	aME.depth = mainMenu.curDepth;
	
	token = _tcstok(sApp, AT_APP_DELIM);
	//while((token = strrchr(sApp,AT_APP_DELIM)) != NULL)
	while(token != NULL)
	{
		if (_tcslen(token) > 1)
		{
			mainMenu.appMenus[token + 1] = aME;
		}
		//*token = '\0';
		token = _tcstok(NULL, AT_APP_DELIM);
	}
	free(sApp);
	return 0;
}
