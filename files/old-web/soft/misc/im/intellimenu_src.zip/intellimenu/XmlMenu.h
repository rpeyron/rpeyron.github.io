// (c) 2003 - R�mi Peyronnet - License GPL.

/* CXmlMenu : Construct a menu from a xml file.

   (c) 2003 - R�mi Peyronnet

    This is GPL software.

  */
#if !defined(AFX_XMLMENU_H__0F06E05B_8EBC_4681_934F_4AF8B42A469A__INCLUDED_)
#define AFX_XMLMENU_H__0F06E05B_8EBC_4681_934F_4AF8B42A469A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "config.h"

class CXmlMenu;

#include "ExpatImpl.h"
#include "xmlsubmenu.h"
#include <string>
#include <xstring>
#include <stack>
#include <map>
#include <vector>


using namespace std;

class CXmlMenu   
{
public:
	struct appMenuEntry {HMENU hMenu; int depth; };
	map<uni_string, uni_string>  parameters;
	map<uni_string, uni_string>  contents;
	vector<uni_string> ids;
	map<uni_string, appMenuEntry> appMenus;
	CXmlSubMenu subMenu;
	int curId;
	int curDepth;
	HMENU fileMenu;
	int fileMenuId;
public:
	CXmlMenu();
	virtual ~CXmlMenu();

	HMENU GetMenu(uni_string & appTitle);
	bool CopyContentsToClipBoard(HWND wnd, int id);
	bool ParseFile(const TCHAR * file);
};

#endif // !defined(AFX_XMLMENU_H__0F06E05B_8EBC_4681_934F_4AF8B42A469A__INCLUDED_)
