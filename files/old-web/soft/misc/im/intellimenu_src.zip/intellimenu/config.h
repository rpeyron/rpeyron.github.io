#ifndef __CONFIG_H__
#define __CONFIG_H__

#pragma  warning (disable:4786)

#define VERSION "v0.2.0"

#define PA_EDIT_WITH _T("edit-with")

#define EL_ROOT _T("root")
#define EL_MENU _T("menu")
#define EL_MENU_INCLUDE _T("menu-include")
#define EL_ITEM _T("item")
#define EL_ITEM_SEPARATOR _T("item-separator")
#define EL_NAME _T("name")
#define EL_CONTENT _T("content")
#define EL_PARAMETER _T("parameter")

#define AT_APP _T("app")
#define AT_APP_DELIM _T(",")
#define AT_NAME _T("name")
#define AT_HREF _T("href")
#define AT_ID _T("id")
#define AT_REF_ID _T("ref_id")

#define XML_CONFIG_FILE _T("menu.xml")

#define MN_START		30000
#define MN_END			64000
#define MN_ALL_START	64001
#define MN_ALL_END		65000
#define MN_FILE_START	65001
#define MN_FILE_END		65300

#define K_KEY ' '
#define K_MAGIC_KEY VK_LWIN

#ifdef _UNICODE
#define uni_string wstring
#else
#define uni_string string
#endif

/*

History :
* 0.2.0 :
  - Major Enhancement of UNICODE string support : Unicode is handled internally.
* 0.1.6 :
  - BugFix : app string won't work
  - Support several strings in app=",,"
  - Parametre Edit Application
* 0.1.5 :
  - Depth App string support
  - BugFix for NT4 : the magic key is invalidated after a magic command
  - Easy File edition support
  - Close TrayMenu
  - Fixed root-strings
* 0.1.4 :
  - Fixed UTF-8 strings [WorkAround] : Expat convert everything in UTF-8...
* 0.1.3 : First public release

*/


#endif