// (c) 2003 - R�mi Peyronnet - License GPL.

// XmlSubMenu.h: interface for the CXmlSubMenu class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XMLSUBMENU_H__8E701DA1_D3BD_4B6B_B761_7B7650BD13DA__INCLUDED_)
#define AFX_XMLSUBMENU_H__8E701DA1_D3BD_4B6B_B761_7B7650BD13DA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "config.h"

class CXmlSubMenu;
class CXmlMenu;

#include "ExpatImpl.h"
#include <string>
#include <xstring>
#include <stack>
#include <map>
#include <vector>

using namespace std;

class CXmlSubMenu : public CExpatImpl<CXmlSubMenu>
{
protected:
	uni_string curItem;
	uni_string curCharacterData;
	int InsertAppMenuEntry(const TCHAR * strApp, HMENU hMenu);
	uni_string buffer;
	bool appendText;
	CXmlMenu & mainMenu;
	stack<HMENU> curMenu;
public:
	HMENU hMenu;
	bool noMenuName;
	bool doNotDetach;
public:
	CXmlSubMenu(CXmlMenu & mainMenu);
	virtual ~CXmlSubMenu();

	const XML_Char * GetAttribute(const XML_Char ** papszAttrs, const XML_Char * name);
	virtual void OnPostCreate ();
	virtual void OnStartElement (const XML_Char *pszName, const XML_Char **papszAttrs);
	virtual void OnEndElement (const XML_Char *pszName);
	virtual void OnCharacterData (const XML_Char *pszData, int nLength);
	virtual void OnComment (const XML_Char *pszData);
	virtual void OnStartCdataSection ();
	virtual void OnEndCdataSection ();
	virtual void OnDefault (const XML_Char *pszData, int nLength);
	bool ParseFile(const TCHAR * file);
};

#endif // !defined(AFX_XMLSUBMENU_H__8E701DA1_D3BD_4B6B_B761_7B7650BD13DA__INCLUDED_)
