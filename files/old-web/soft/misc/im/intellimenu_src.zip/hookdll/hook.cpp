// hook.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
//#include <psapi.h>
#include "hook.h"

//#pragma message("library is linking with \"Psapi.lib\"")
//#pragma comment(lib, "Psapi.lib")



//
// struct for global data
//
typedef struct
  {
  HHOOK     g_hHook;
  HWND      g_hWnd;
  HINSTANCE g_hInstance;
  } SCGLOBALDATA;


HANDLE hMappedFile;                                                             // handle for the memory mapped file
SCGLOBALDATA* pData;                                                            // pointer to a global data struct
bool bStartingProcess = false;                                                  // indicator if the process has started the dll for the first time


//
// DLL main function
//
BOOL WINAPI DllMain(HINSTANCE hInst, ULONG uReason, LPVOID lpReserved)
  {
  switch(uReason)
    {
    case DLL_PROCESS_ATTACH:                                                    // the DLL is attached to a process. we have to set the MMF
      {
      char  szBaseName[_MAX_FNAME]="\0",
            szTmp[_MAX_FNAME];
/*
      if (GetModuleBaseName(GetCurrentProcess(), hInst, szTmp, sizeof(szTmp)))  // compute MMF-filename from current module base name
        _splitpath(szTmp, NULL, NULL, szBaseName, NULL);
*/
      strcat(szBaseName, "RCMSharedMemMMF");                                    // add specifier string

      hMappedFile = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, sizeof(SCGLOBALDATA), szBaseName);
      pData = (SCGLOBALDATA*)MapViewOfFile(hMappedFile, FILE_MAP_WRITE, 0, 0, 0);
      bStartingProcess = (hMappedFile != NULL) && (GetLastError() != ERROR_ALREADY_EXISTS);

      if(bStartingProcess)                                                      // if the MMF doesn't exist, we have the first instance
        {
        pData->g_hInstance  = hInst;                                            // so set the instance handle
        pData->g_hWnd       = NULL;                                             // and initialize the other handles
        pData->g_hHook      = NULL;
        }

      DisableThreadLibraryCalls(hInst);
      }
      break;

    case DLL_PROCESS_DETACH:
      CloseHandle(hMappedFile);                                                 // on detaching the DLL, close the MMF
      break;
    }    
   
    return TRUE;
  }


//
// callback function for hooks
//
LRESULT CALLBACK HookProc(int nCode, WPARAM wParam, LPARAM lParam)
  {   
	COPYDATASTRUCT  CDS;
	HEVENT          Event;

	CDS.dwData = 0;
	CDS.cbData = sizeof(Event);
	CDS.lpData = &Event;

  Event.lParam      = lParam;
  Event.wParam      = wParam;
  Event.nCode       = nCode;
  Event.dwHookType  = WH_KEYBOARD;
	
	BOOL bRes = SendMessage(pData->g_hWnd, WM_COPYDATA, 0, (LPARAM)(VOID*)&CDS);  // ask the controlling program if the hook should be passed

  if(!bRes) return CallNextHookEx(pData->g_hHook, nCode, wParam, lParam);       // pass hook to next handler
  else return(bRes);                                                            // just returm
  }


//
// hook setup function
//
BOOL SetHook(HWND hWnd)
  {
  if(bStartingProcess)                                                          // if we're just starting the DLL for the first time,
    {
    pData->g_hWnd   = hWnd;                                                     // remember the windows and hook handle for further instances
    pData->g_hHook  = SetWindowsHookEx(WH_KEYBOARD, (HOOKPROC)HookProc, pData->g_hInstance, 0);   
    return(pData->g_hHook != NULL);
    }
  else return(false);
  }


//
// hook remove function
//
BOOL RemoveHook()
  {
  if(pData->g_hHook)                                                            // if the hook is defined
    {
    pData->g_hWnd       = NULL;                                                 // reset data
    pData->g_hHook      = NULL;
    return UnhookWindowsHookEx(pData->g_hHook);
    }
  return(true);
  }
