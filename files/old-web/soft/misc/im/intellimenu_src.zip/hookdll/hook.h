//
// struct for hook events
//
typedef struct
  {
  int     nCode;
  DWORD   dwHookType;
  WPARAM  wParam;
  LPARAM  lParam;
  } HEVENT;
