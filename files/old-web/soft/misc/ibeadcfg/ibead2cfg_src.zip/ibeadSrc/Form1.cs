using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using SHDocVw; // Contains IE ref

namespace iBead2Cfg
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem miOpen;
		private System.Windows.Forms.MenuItem miSave;
		private System.Windows.Forms.MenuItem miSaveAs;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem miQuit;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox textBox8;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox textBox9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox textBox10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox textBox11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox textBox12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox textBox13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox textBox14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox textBox15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox textBox16;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.TextBox textBox17;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.TextBox textBox18;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.TextBox textBox19;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.TextBox textBox20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.LinkLabel linkLabel1;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.LinkLabel linkLabel2;
		private System.Windows.Forms.Label label5;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.linkLabel2 = new System.Windows.Forms.LinkLabel();
			this.label27 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.label25 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.label11 = new System.Windows.Forms.Label();
			this.textBox11 = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.textBox12 = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.textBox13 = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.textBox14 = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.textBox15 = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.textBox16 = new System.Windows.Forms.TextBox();
			this.label17 = new System.Windows.Forms.Label();
			this.textBox17 = new System.Windows.Forms.TextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.textBox18 = new System.Windows.Forms.TextBox();
			this.label19 = new System.Windows.Forms.Label();
			this.textBox19 = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.textBox20 = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.textBox10 = new System.Windows.Forms.TextBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label8 = new System.Windows.Forms.Label();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.miOpen = new System.Windows.Forms.MenuItem();
			this.miSave = new System.Windows.Forms.MenuItem();
			this.miSaveAs = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.miQuit = new System.Windows.Forms.MenuItem();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.tabControl1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Location = new System.Drawing.Point(0, 0);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(328, 288);
			this.tabControl1.TabIndex = 0;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.linkLabel2);
			this.tabPage2.Controls.Add(this.label27);
			this.tabPage2.Controls.Add(this.label21);
			this.tabPage2.Controls.Add(this.label22);
			this.tabPage2.Controls.Add(this.label23);
			this.tabPage2.Controls.Add(this.label24);
			this.tabPage2.Controls.Add(this.label25);
			this.tabPage2.Controls.Add(this.label26);
			this.tabPage2.Controls.Add(this.linkLabel1);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(320, 262);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "About";
			// 
			// linkLabel2
			// 
			this.linkLabel2.Location = new System.Drawing.Point(8, 168);
			this.linkLabel2.Name = "linkLabel2";
			this.linkLabel2.Size = new System.Drawing.Size(256, 23);
			this.linkLabel2.TabIndex = 22;
			this.linkLabel2.TabStop = true;
			this.linkLabel2.Text = "http://membres.lycos.fr/tmp2074/iBead2/Start.html";
			this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
			// 
			// label27
			// 
			this.label27.Location = new System.Drawing.Point(8, 144);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(160, 24);
			this.label27.TabIndex = 21;
			this.label27.Text = "(c) 2003 - Nicolas Faivret  ";
			// 
			// label21
			// 
			this.label21.Location = new System.Drawing.Point(24, 120);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(264, 23);
			this.label21.TabIndex = 20;
			this.label21.Text = "3/ Save the file and copy it back on your iBead. ";
			// 
			// label22
			// 
			this.label22.Location = new System.Drawing.Point(24, 96);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(264, 23);
			this.label22.TabIndex = 19;
			this.label22.Text = "2/ Go To the Radios tab, and change your stations.";
			// 
			// label23
			// 
			this.label23.Location = new System.Drawing.Point(24, 72);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(264, 23);
			this.label23.TabIndex = 18;
			this.label23.Text = "1/ Open your Settings.dat file.";
			// 
			// label24
			// 
			this.label24.Location = new System.Drawing.Point(8, 32);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(240, 32);
			this.label24.TabIndex = 17;
			this.label24.Text = "It has been successfully tested on iBead2 256Mo with firmware 3.4.16.";
			// 
			// label25
			// 
			this.label25.Location = new System.Drawing.Point(8, 8);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(232, 24);
			this.label25.TabIndex = 16;
			this.label25.Text = "Be carefull : This is very alpha software ! ";
			// 
			// label26
			// 
			this.label26.Location = new System.Drawing.Point(48, 192);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(224, 40);
			this.label26.TabIndex = 15;
			this.label26.Text = "Many thanks to R�mi Peyronnet, author of the first version of this software for i" +
				"Bead100 and who let me use his sources.";
			this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// linkLabel1
			// 
			this.linkLabel1.Location = new System.Drawing.Point(80, 240);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(168, 23);
			this.linkLabel1.TabIndex = 14;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "http://people.via.ecp.fr/~remi";
			this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.label11);
			this.tabPage1.Controls.Add(this.textBox11);
			this.tabPage1.Controls.Add(this.label12);
			this.tabPage1.Controls.Add(this.textBox12);
			this.tabPage1.Controls.Add(this.label13);
			this.tabPage1.Controls.Add(this.textBox13);
			this.tabPage1.Controls.Add(this.label14);
			this.tabPage1.Controls.Add(this.textBox14);
			this.tabPage1.Controls.Add(this.label15);
			this.tabPage1.Controls.Add(this.textBox15);
			this.tabPage1.Controls.Add(this.label16);
			this.tabPage1.Controls.Add(this.textBox16);
			this.tabPage1.Controls.Add(this.label17);
			this.tabPage1.Controls.Add(this.textBox17);
			this.tabPage1.Controls.Add(this.label18);
			this.tabPage1.Controls.Add(this.textBox18);
			this.tabPage1.Controls.Add(this.label19);
			this.tabPage1.Controls.Add(this.textBox19);
			this.tabPage1.Controls.Add(this.label20);
			this.tabPage1.Controls.Add(this.textBox20);
			this.tabPage1.Controls.Add(this.label9);
			this.tabPage1.Controls.Add(this.textBox9);
			this.tabPage1.Controls.Add(this.label10);
			this.tabPage1.Controls.Add(this.textBox10);
			this.tabPage1.Controls.Add(this.panel1);
			this.tabPage1.Controls.Add(this.label8);
			this.tabPage1.Controls.Add(this.textBox8);
			this.tabPage1.Controls.Add(this.label7);
			this.tabPage1.Controls.Add(this.textBox7);
			this.tabPage1.Controls.Add(this.label6);
			this.tabPage1.Controls.Add(this.textBox6);
			this.tabPage1.Controls.Add(this.label5);
			this.tabPage1.Controls.Add(this.textBox5);
			this.tabPage1.Controls.Add(this.label4);
			this.tabPage1.Controls.Add(this.textBox4);
			this.tabPage1.Controls.Add(this.label3);
			this.tabPage1.Controls.Add(this.textBox3);
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.textBox2);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Controls.Add(this.textBox1);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(320, 262);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Radios";
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(168, 16);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(56, 20);
			this.label11.TabIndex = 21;
			this.label11.Text = "Radio 11";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox11
			// 
			this.textBox11.Location = new System.Drawing.Point(232, 16);
			this.textBox11.Name = "textBox11";
			this.textBox11.Size = new System.Drawing.Size(64, 20);
			this.textBox11.TabIndex = 20;
			this.textBox11.Text = "FM 11";
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(168, 40);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(56, 20);
			this.label12.TabIndex = 23;
			this.label12.Text = "Radio 12";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox12
			// 
			this.textBox12.Location = new System.Drawing.Point(232, 40);
			this.textBox12.Name = "textBox12";
			this.textBox12.Size = new System.Drawing.Size(64, 20);
			this.textBox12.TabIndex = 22;
			this.textBox12.Text = "FM 12";
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(168, 64);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(56, 20);
			this.label13.TabIndex = 25;
			this.label13.Text = "Radio 13";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox13
			// 
			this.textBox13.Location = new System.Drawing.Point(232, 64);
			this.textBox13.Name = "textBox13";
			this.textBox13.Size = new System.Drawing.Size(64, 20);
			this.textBox13.TabIndex = 24;
			this.textBox13.Text = "FM 13";
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(168, 88);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(56, 20);
			this.label14.TabIndex = 27;
			this.label14.Text = "Radio 14";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox14
			// 
			this.textBox14.Location = new System.Drawing.Point(232, 88);
			this.textBox14.Name = "textBox14";
			this.textBox14.Size = new System.Drawing.Size(64, 20);
			this.textBox14.TabIndex = 26;
			this.textBox14.Text = "FM 14";
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(168, 112);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(56, 20);
			this.label15.TabIndex = 29;
			this.label15.Text = "Radio 15";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox15
			// 
			this.textBox15.Location = new System.Drawing.Point(232, 112);
			this.textBox15.Name = "textBox15";
			this.textBox15.Size = new System.Drawing.Size(64, 20);
			this.textBox15.TabIndex = 28;
			this.textBox15.Text = "FM 15";
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(168, 136);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(56, 20);
			this.label16.TabIndex = 31;
			this.label16.Text = "Radio 16";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox16
			// 
			this.textBox16.Location = new System.Drawing.Point(232, 136);
			this.textBox16.Name = "textBox16";
			this.textBox16.Size = new System.Drawing.Size(64, 20);
			this.textBox16.TabIndex = 30;
			this.textBox16.Text = "FM 16";
			// 
			// label17
			// 
			this.label17.Location = new System.Drawing.Point(168, 160);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(56, 20);
			this.label17.TabIndex = 33;
			this.label17.Text = "Radio 17";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox17
			// 
			this.textBox17.Location = new System.Drawing.Point(232, 160);
			this.textBox17.Name = "textBox17";
			this.textBox17.Size = new System.Drawing.Size(64, 20);
			this.textBox17.TabIndex = 32;
			this.textBox17.Text = "FM 17";
			// 
			// label18
			// 
			this.label18.Location = new System.Drawing.Point(168, 184);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(56, 20);
			this.label18.TabIndex = 35;
			this.label18.Text = "Radio 18";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox18
			// 
			this.textBox18.Location = new System.Drawing.Point(232, 184);
			this.textBox18.Name = "textBox18";
			this.textBox18.Size = new System.Drawing.Size(64, 20);
			this.textBox18.TabIndex = 34;
			this.textBox18.Text = "FM 18";
			// 
			// label19
			// 
			this.label19.Location = new System.Drawing.Point(168, 208);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(56, 20);
			this.label19.TabIndex = 37;
			this.label19.Text = "Radio 19";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox19
			// 
			this.textBox19.Location = new System.Drawing.Point(232, 208);
			this.textBox19.Name = "textBox19";
			this.textBox19.Size = new System.Drawing.Size(64, 20);
			this.textBox19.TabIndex = 36;
			this.textBox19.Text = "FM 19";
			// 
			// label20
			// 
			this.label20.Location = new System.Drawing.Point(168, 232);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(56, 20);
			this.label20.TabIndex = 39;
			this.label20.Text = "Radio 20";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox20
			// 
			this.textBox20.Location = new System.Drawing.Point(232, 232);
			this.textBox20.Name = "textBox20";
			this.textBox20.Size = new System.Drawing.Size(64, 20);
			this.textBox20.TabIndex = 38;
			this.textBox20.Text = "FM 20";
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(8, 208);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(56, 20);
			this.label9.TabIndex = 17;
			this.label9.Text = "Radio 9";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox9
			// 
			this.textBox9.Location = new System.Drawing.Point(72, 208);
			this.textBox9.Name = "textBox9";
			this.textBox9.Size = new System.Drawing.Size(64, 20);
			this.textBox9.TabIndex = 16;
			this.textBox9.Text = "FM 9";
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(8, 232);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(56, 20);
			this.label10.TabIndex = 19;
			this.label10.Text = "Radio 10";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox10
			// 
			this.textBox10.Location = new System.Drawing.Point(72, 232);
			this.textBox10.Name = "textBox10";
			this.textBox10.Size = new System.Drawing.Size(64, 20);
			this.textBox10.TabIndex = 18;
			this.textBox10.Text = "FM 10";
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Location = new System.Drawing.Point(152, 8);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1, 248);
			this.panel1.TabIndex = 16;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(8, 184);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(56, 20);
			this.label8.TabIndex = 15;
			this.label8.Text = "Radio 8";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox8
			// 
			this.textBox8.Location = new System.Drawing.Point(72, 184);
			this.textBox8.Name = "textBox8";
			this.textBox8.Size = new System.Drawing.Size(64, 20);
			this.textBox8.TabIndex = 14;
			this.textBox8.Text = "FM 8";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(8, 160);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(56, 20);
			this.label7.TabIndex = 13;
			this.label7.Text = "Radio 7";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox7
			// 
			this.textBox7.Location = new System.Drawing.Point(72, 160);
			this.textBox7.Name = "textBox7";
			this.textBox7.Size = new System.Drawing.Size(64, 20);
			this.textBox7.TabIndex = 12;
			this.textBox7.Text = "FM 7";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 136);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(56, 20);
			this.label6.TabIndex = 11;
			this.label6.Text = "Radio 6";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox6
			// 
			this.textBox6.Location = new System.Drawing.Point(72, 136);
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(64, 20);
			this.textBox6.TabIndex = 10;
			this.textBox6.Text = "FM 6";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 112);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(56, 20);
			this.label5.TabIndex = 9;
			this.label5.Text = "Radio 5";
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(72, 112);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(64, 20);
			this.textBox5.TabIndex = 8;
			this.textBox5.Text = "FM 5";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 88);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(56, 20);
			this.label4.TabIndex = 7;
			this.label4.Text = "Radio 4";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(72, 88);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(64, 20);
			this.textBox4.TabIndex = 6;
			this.textBox4.Text = "FM 4";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 64);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 20);
			this.label3.TabIndex = 5;
			this.label3.Text = "Radio 3";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(72, 64);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(64, 20);
			this.textBox3.TabIndex = 4;
			this.textBox3.Text = "FM 3";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 40);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 20);
			this.label2.TabIndex = 3;
			this.label2.Text = "Radio 2";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(72, 40);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(64, 20);
			this.textBox2.TabIndex = 2;
			this.textBox2.Text = "FM 2";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 20);
			this.label1.TabIndex = 1;
			this.label1.Text = "Radio 1";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(72, 16);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(64, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "FM 1";
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.miOpen,
																					  this.miSave,
																					  this.miSaveAs,
																					  this.menuItem5,
																					  this.miQuit});
			this.menuItem1.Text = "File";
			// 
			// miOpen
			// 
			this.miOpen.Index = 0;
			this.miOpen.Text = "&Open...";
			this.miOpen.Click += new System.EventHandler(this.miOpen_Click);
			// 
			// miSave
			// 
			this.miSave.Index = 1;
			this.miSave.Text = "&Save";
			this.miSave.Click += new System.EventHandler(this.miSave_Click);
			// 
			// miSaveAs
			// 
			this.miSaveAs.Index = 2;
			this.miSaveAs.Text = "Save &as...";
			this.miSaveAs.Click += new System.EventHandler(this.miSaveAs_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 3;
			this.menuItem5.Text = "-";
			// 
			// miQuit
			// 
			this.miQuit.Index = 4;
			this.miQuit.Text = "&Quit";
			this.miQuit.Click += new System.EventHandler(this.miQuit_Click);
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 289);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(328, 24);
			this.statusBar1.TabIndex = 1;
			this.statusBar1.Text = "Ready";
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.Filter = "Settings File|*.dat|All Files|*.*";
			this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.FileName = "doc1";
			this.saveFileDialog1.Filter = "Settings File|*.dat|All Files|*.*";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(328, 313);
			this.Controls.Add(this.statusBar1);
			this.Controls.Add(this.tabControl1);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "iBead2 Configurator";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.tabControl1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void miQuit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void toolBar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
		
		}

		private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
		{
		
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void loadRadio(System.Windows.Forms.TextBox textBox, System.IO.Stream stream, int index)
		{
			int f1, f2, freq;
			stream.Seek(120+(3*2)*(index-1), System.IO.SeekOrigin.Begin);
			f1 = stream.ReadByte();
			f2 = stream.ReadByte();
			freq = f2*256+f1;
            textBox.Text = Convert.ToString(((decimal)(freq + 65536) / 1000), NumberFormatInfo.InvariantInfo);
		}

		private void saveRadio(System.Windows.Forms.TextBox textBox, System.IO.Stream stream, int index)
		{
			int f1, f2, freq;
			freq = (int)(Decimal.Parse(textBox.Text, NumberFormatInfo.InvariantInfo) * 1000 - 65536);
			f2 = (freq / 256) % 256;
			f1 = freq % 256;
			stream.Seek(120+(3*2)*(index-1), System.IO.SeekOrigin.Begin);
			stream.WriteByte((byte)f1);
			stream.WriteByte((byte)f2);
		}
		

		private void miOpen_Click(object sender, System.EventArgs e)
		{
			if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
			{
				System.IO.Stream file;
				file = openFileDialog1.OpenFile();
				loadRadio(textBox1, file, 1);
				loadRadio(textBox2, file, 2);
				loadRadio(textBox3, file, 3);
				loadRadio(textBox4, file, 4);
				loadRadio(textBox5, file, 5);
				loadRadio(textBox6, file, 6);
				loadRadio(textBox7, file, 7);
				loadRadio(textBox8, file, 8);
				loadRadio(textBox9, file, 9);
				loadRadio(textBox10, file, 10);
				loadRadio(textBox11, file, 11);
				loadRadio(textBox12, file, 12);
				loadRadio(textBox13, file, 13);
				loadRadio(textBox14, file, 14);
				loadRadio(textBox15, file, 15);
				loadRadio(textBox16, file, 16);
				loadRadio(textBox17, file, 17);
				loadRadio(textBox18, file, 18);
				loadRadio(textBox19, file, 19);
				loadRadio(textBox20, file, 20);
				file.Close();
				saveFileDialog1.FileName = openFileDialog1.FileName;
				file = null;
			}
		}

		private void miSave_Click(object sender, System.EventArgs e)
		{
			System.IO.FileAttributes att;
			att = System.IO.File.GetAttributes(saveFileDialog1.FileName);
			att &= System.IO.FileAttributes.Normal;
			System.IO.File.SetAttributes(saveFileDialog1.FileName, att);

			System.IO.Stream file;
			file = new System.IO.FileStream(saveFileDialog1.FileName, System.IO.FileMode.Open);
			// file = saveFileDialog1.OpenFile();
			saveRadio(textBox1, file, 1);
			saveRadio(textBox2, file, 2);
			saveRadio(textBox3, file, 3);
			saveRadio(textBox4, file, 4);
			saveRadio(textBox5, file, 5);
			saveRadio(textBox6, file, 6);
			saveRadio(textBox7, file, 7);
			saveRadio(textBox8, file, 8);
			saveRadio(textBox9, file, 9);
			saveRadio(textBox10, file, 10);
			saveRadio(textBox11, file, 11);
			saveRadio(textBox12, file, 12);
			saveRadio(textBox13, file, 13);
			saveRadio(textBox14, file, 14);
			saveRadio(textBox15, file, 15);
			saveRadio(textBox16, file, 16);
			saveRadio(textBox17, file, 17);
			saveRadio(textBox18, file, 18);
			saveRadio(textBox19, file, 19);
			saveRadio(textBox20, file, 20);
			file.Close();
		}

		private void miSaveAs_Click(object sender, System.EventArgs e)
		{
			if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
			{
				System.IO.File.Copy(openFileDialog1.FileName, saveFileDialog1.FileName, true);
				miSave_Click(sender, e);
			}
		}

		private void linkLabel2_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			/*
			SHDocVw.InternetExplorer oIE = new SHDocVw.InternetExplorerClass();
			object oEmpty = String.Empty;
			IWebBrowserApp wb = (IWebBrowserApp) oIE;
			wb.Visible = true;
			wb.Navigate(linkLabel2.Text, ref oEmpty, ref oEmpty, ref oEmpty, ref oEmpty);
			*/
		}

		private void linkLabel1_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			/*
			SHDocVw.InternetExplorer oIE = new SHDocVw.InternetExplorerClass();
			object oEmpty = String.Empty;
			IWebBrowserApp wb = (IWebBrowserApp) oIE;
			wb.Visible = true;
			wb.Navigate(linkLabel1.Text, ref oEmpty, ref oEmpty, ref oEmpty, ref oEmpty);
			*/
		}

	}
}
