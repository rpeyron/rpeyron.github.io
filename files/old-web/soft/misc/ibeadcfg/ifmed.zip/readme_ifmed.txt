iFMED - iBead FM Preset Editor (win32) - 30XX / 31XX v1.105 Experimental

-=[Purpose]=-
Allows PC based manipulation of the iBead presets, editing, reordering.

Currently developed with iBead Korean firmware revision 3140 but being tested against English 3061 also, and "iBead 100 - 256Mb" Model connected to Windows XP. Note it is highly unlikely that this would function correctly on any other firmware revision; if iBead.co wants better support then I need a bit more info.

Note this is not official iBead program or supported by them, don't go to them if you have any problems with it.

-=[Usage]=-
Run iFMED.exe, select the location of iBead.
Update Presets, by editing (Double click / Enter / F2 on a preset), or rearranging order (UP / DOWN).
Save to write back to the iBead.
Note, until the Save button all access to the iBead is read only.

-=[Notes]=-
Take a copy of Settings.dat from the top level of the iBead (make sure explore is set to view hidden / system files), before using this program.

-=[Contact]=-
Written by JB get in contact with me at jpbingham@hotmail, make sure you use "iBead" in the subject to make sure it doesn't get spam filtered. Gladly welcoming bug reports / suggestions for future versions, but remember this is a hobby not a job and include as much details as possible...

Brought to you with the tunes of Ladytron and there album "Light & Magic"... the best solid state MP3 player out there (well my opinion anyway)

-=[License Agreement and Copyright]=-
Copyright (c) Jason Bingham 2003. All rights reserved.

-=[License & Redistribution]=-
This software is free for personal use, it may not be posted to other sites, distrubuted via CD or any other mechanism without written permission.

-=[Conditions]=-
This software is provided "as is" and without any warranties expressed or implied, including, but not limited to, implied warranties of fitness for a particular purpose.

In no event shall the author be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use this software or documentation, even if the author has been advised of the possibility of such damages.