/////////////////////////////////////////////////////////////////////////////
// Name:        iBeadConfig2App.h
// Purpose:     
// Author:      R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Modified by: 
// Created:     
// RCS-ID:      
// Copyright:   (C) 2004 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Licence:     GPL
/////////////////////////////////////////////////////////////////////////////

#ifndef iBeadConfig2App_H
#define iBeadConfig2App_H

#define IBC_DEFAULTLOCATION _("France - Paris")
#define IBC_DEFAULTFIRMWARE _("iBead 100 - 3.061")

// Define a new application type, each program should derive a class from wxApp
class iBeadConfig2App : public wxApp
{
public:
    iBeadConfig2App();
    virtual ~iBeadConfig2App();

    // override base class virtuals
    // ----------------------------

    // this one is called on application startup and is a good place for the app
    // initialization (doing it here and not in the ctor allows to have an error
    // return: if OnInit() returns false, the application terminates)
    virtual bool OnInit();
    wxLocale locale;
    wxLocale std;
};

DECLARE_APP(iBeadConfig2App)

#endif // iBeadConfig2App_H


