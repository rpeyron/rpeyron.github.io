/////////////////////////////////////////////////////////////////////////////
// Name:        radioitem.cpp
// Purpose:     RadioItem implementation
// Author:      R�mi Peyronnet
// Modified by: 
// Created:     
// RCS-ID:      
// Copyright:   (C) 2004 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Licence:     GPL
/////////////////////////////////////////////////////////////////////////////

#include "radioitem.h"

#define ID_TEXT     12001
#define ID_COMBO    12002

RadioItem::RadioItem(wxString radioName,
                     wxFileConfig & radios,
                     wxWindow* parent, 
                     wxWindowID id, 
                     const wxPoint& pos,
                     const wxSize& size,
                     long style, 
                     const wxString& name)
     : wxPanel(parent, id, pos, size, style, name),
       radios(radios),
       radioName(radioName)
{
    m_pComboBox = NULL;
    m_pTextEdit = NULL;
    SetSizer(new wxBoxSizer(wxHORIZONTAL));
    GetSizer()->Add(new wxStaticText(this, -1, radioName,wxDefaultPosition,wxSize(50,-1)/*,wxST_NO_AUTORESIZE*/ ),0, wxALIGN_CENTER_VERTICAL |wxRIGHT, 10);

    m_pTextEdit = new wxTextCtrl(this, ID_TEXT, "", wxDefaultPosition, wxSize(50,-1));
    GetSizer()->Add(m_pTextEdit, 1, wxEXPAND);

    // Combo Box
    m_pComboBox = new wxComboBox(this, ID_COMBO);
    m_pComboBox->SetWindowStyle(wxCB_SORT);
    GetSizer()->Add(m_pComboBox, 3, wxEXPAND);
    PopulateRadios();

    Layout();
    GetSizer()->SetSizeHints(this);
}

RadioItem::~RadioItem()
{
}


// Event Map Table
BEGIN_EVENT_TABLE(RadioItem, wxPanel)
    EVT_TEXT(ID_TEXT, RadioItem::OnRadioEdit)
    EVT_COMBOBOX(ID_COMBO, RadioItem::OnComboSelect)
END_EVENT_TABLE()


void RadioItem::OnRadioEdit(wxCommandEvent & event)
{
    if (m_pComboBox == NULL) return;
    if (m_pTextEdit == NULL) return;
    wxString str;
    str = m_pTextEdit->GetValue();
    if ((m_pComboBox->GetString(0).Left(1) == "0") && (m_pComboBox->GetString(m_pComboBox->GetCount()-1).Left(1) == "1") )
    {
        if ((str.Len() > 0) && (str.Left(1) != "1")) str = "0" + str;
    }
    //m_pComboBox->SetValue(str);
    SyncCombo();
}

void RadioItem::OnComboSelect(wxCommandEvent & event)
{
    if (m_pComboBox == NULL) return;
    if (m_pTextEdit == NULL) return;
    wxString str;
    double d;
    str = m_pComboBox->GetStringSelection();
    str.ToDouble(&d);
    str = wxString::Format("%g",d);
    m_pTextEdit->SetValue(str);
}

void RadioItem::PopulateRadios()
{
    wxString entry;
    wxString value;
    long dummy;
    bool bCont;
    
    wxASSERT(m_pComboBox != NULL);

    // Purge combo
    m_pComboBox->Clear();

    // Enumerate radios
    bCont = radios.GetFirstEntry(entry, dummy);
    while (bCont)
    {
        radios.Read(entry, &value);
        m_pComboBox->Append(entry + " - " + value);
        bCont = radios.GetNextEntry(entry, dummy);
    }
    SyncCombo();
}

void RadioItem::SetFrequency(double freq)
{
    m_pTextEdit->SetValue(wxString::Format("%g", freq));
    SyncCombo();
}

double RadioItem::GetFrequency()
{
    double d;
    m_pTextEdit->GetValue().ToDouble(&d);
    return d;
}

void RadioItem::SyncCombo()
{
    int i;
    double cible, cur;
    cible = GetFrequency();
    m_pComboBox->SetSelection(-1);
    for (i = 0; i < m_pComboBox->GetCount(); i++)
    {
        m_pComboBox->GetString(i).ToDouble(&cur);
        if (cur == cible) { m_pComboBox->SetSelection(i); m_pComboBox->SetSelection(0,0); }
    }
}