/////////////////////////////////////////////////////////////////////////////
// Name:        iBeadConfig2Frm.h
// Purpose:     
// Author:      R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Modified by: 
// Created:     
// RCS-ID:      
// Copyright:   (C) 2004 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Licence:     GPL
/////////////////////////////////////////////////////////////////////////////

#ifndef iBeadConfig2Frame_H
#define iBeadConfig2Frame_H

#include "radioitem.h"
#include "wx/config.h"
#include "wx/fileconf.h"
#include <wx/wfstream.h>
#include <wx/scrolwin.h>

#define MAXRADIOS 32

// Define a new frame type: this is going to be our main frame
class iBeadConfig2Frame : public wxFrame
{
public:
    // ctor(s)
    iBeadConfig2Frame(const wxString& title, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = wxDEFAULT_FRAME_STYLE);
	virtual ~iBeadConfig2Frame();

    // event handlers (these functions should _not_ be virtual)
    void OnQuit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);
    void OnFileOpen(wxCommandEvent& event);
    void OnFileSave(wxCommandEvent& event);
    void OnFileSaveAs(wxCommandEvent& event);
    void OnPrefsLoadRadios(wxCommandEvent& event);
    void OnPrefsSaveRadios(wxCommandEvent& event);
    void OnRefresh(wxCommandEvent& event);
    void OnLocationChange(wxCommandEvent& event);
    void OnFirmwareChange(wxCommandEvent& event);

public:
    void ShowRadios(int n);
    void PopulateFirmwares();
    void PopulateLocations();
    void SetLocation(wxString location);
    void SetFirmware(wxString firmware);
    void LoadRadiosFromSettings(const wxString & filename);
    void SaveRadiosToSettings(const wxString & filename);
protected:
    wxConfig * config;
    wxFileConfig * radios;
    wxFileConfig * firmwares;
    wxFileInputStream * fisRadios;
    wxFileInputStream * fisFirmwares;

    struct firm_data_struct {
        int num;
        int position;
        int increment;
        int numbytes;
        wxString order;
        double offset;
        double multiply;
    } firm_data;

    wxString filename;

protected:
    wxComboBox * m_pComboFirmwares;
    wxComboBox * m_pComboRadios;
    wxScrolledWindow * m_pScrolledRadios;
    RadioItem * m_pRadioItem[MAXRADIOS];

private:
    DECLARE_CLASS(iBeadConfig2Frame)
    // any class wishing to process wxWindows events must use this macro
    DECLARE_EVENT_TABLE()
};

#endif // iBeadConfig2Frame_H
