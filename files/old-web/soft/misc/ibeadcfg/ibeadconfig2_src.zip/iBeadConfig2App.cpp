/////////////////////////////////////////////////////////////////////////////
// Name:        iBeadConfig2App.cpp
// Purpose:     
// Author:      R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Modified by: 
// Created:     
// RCS-ID:      
// Copyright:   (C) 2004 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Licence:     GPL
/////////////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------
#include "wx/wxprec.h"

#include <locale.h>

#ifndef WX_PRECOMP
	#include "wx/wx.h"
#endif

#include "iBeadConfig2App.h"
#include "iBeadConfig2Frm.h"
#include "resource.h"



// Create a new application object: this macro will allow wxWindows to create
// the application object during program execution (it's better than using a
// static object for many reasons) and also declares the accessor function
// wxGetApp() which will return the reference of the right type (i.e. iBeadConfig2App and
// not wxApp)
IMPLEMENT_APP(iBeadConfig2App)

// ============================================================================
// implementation
// ============================================================================

// ----------------------------------------------------------------------------
// the application class
// ----------------------------------------------------------------------------

iBeadConfig2App::iBeadConfig2App()
{
    locale.Init();
    locale.AddCatalog("iBeadConfig2");
    // Back to standart behaviour
    setlocale( LC_ALL, "English" );
}

iBeadConfig2App::~iBeadConfig2App()
{
}

// 'Main program' equivalent: the program execution "starts" here
bool iBeadConfig2App::OnInit()
{

    // create the main application window
    iBeadConfig2Frame *pFrame = new iBeadConfig2Frame(_("iBeadConfig2"));

    // and show it (the frames, unlike simple controls, are not shown when
    // created initially)
    // pFrame->Maximize(true) ;
    pFrame->Show(TRUE);
	SetTopWindow(pFrame);

    // success: wxApp::OnRun() will be called which will enter the main message
    // loop and the application will run. If we returned FALSE here, the
    // application would exit immediately.
    return TRUE;
}

