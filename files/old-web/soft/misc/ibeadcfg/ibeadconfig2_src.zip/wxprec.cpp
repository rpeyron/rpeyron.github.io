/////////////////////////////////////////////////////////////////////////////
// Name:        wxprec.cpp
// Purpose:		neede to generate Precompiled Header (.PCH) 
// Author:      
// Modified by: 
// Created:     
// RCS-ID:      
// Copyright:   (C)2003 
// Licence:     wxWindows
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h> 
