/////////////////////////////////////////////////////////////////////////////
// Name:        iBeadConfig2Frm.cpp
// Purpose:     
// Author:      R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Modified by: 
// Created:     
// RCS-ID:      
// Copyright:   (C) 2004 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Licence:     GPL
/////////////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------
#include "wx/wxprec.h"

#ifndef WX_PRECOMP
	#include "wx/wx.h"
#endif

#include <wx/image.h>
#include <wx/wfstream.h>
#include <wx/filename.h>

#include "res/resources.inc"

#include "iBeadConfig2App.h"
#include "iBeadConfig2Frm.h"

// ----------------------------------------------------------------------------
// resources
// ----------------------------------------------------------------------------
// the application icon
#if defined(__WXGTK__) || defined(__WXMOTIF__)
    #include "res/iBeadConfig2.xpm"
#endif

// ----------------------------------------------------------------------------
// constants
// ----------------------------------------------------------------------------

// IDs for the controls and the menu commands
enum
{
    // menu items
    Minimal_Quit = 1,
    Minimal_About,
    File_Save,
    File_SaveAs,
    File_Open,
    Combo_Radios,
    Combo_Firmwares,
    Param_Refresh,
    PrefsLoadRadios,
    PrefsSaveRadios
};

// ----------------------------------------------------------------------------
// event tables and other macros for wxWindows
// ----------------------------------------------------------------------------

// the event tables connect the wxWindows events with the functions (event
// handlers) which process them. It can be also done at run-time, but for the
// simple menu events like this the static method is much simpler.
IMPLEMENT_CLASS(iBeadConfig2Frame, wxFrame)
BEGIN_EVENT_TABLE(iBeadConfig2Frame, wxFrame)
    EVT_MENU(Minimal_Quit,  iBeadConfig2Frame::OnQuit)
    EVT_MENU(Minimal_About, iBeadConfig2Frame::OnAbout)
    EVT_MENU(File_Save, iBeadConfig2Frame::OnFileSave)
    EVT_MENU(File_SaveAs, iBeadConfig2Frame::OnFileSaveAs)
    EVT_MENU(File_Open, iBeadConfig2Frame::OnFileOpen)
    EVT_MENU(PrefsLoadRadios, iBeadConfig2Frame::OnPrefsLoadRadios)
    EVT_MENU(PrefsSaveRadios, iBeadConfig2Frame::OnPrefsSaveRadios)
    EVT_TOOL(File_Save, iBeadConfig2Frame::OnFileSave)
    EVT_TOOL(File_Open, iBeadConfig2Frame::OnFileOpen)
    EVT_TOOL(Param_Refresh, iBeadConfig2Frame::OnRefresh)
    EVT_COMBOBOX(Combo_Radios, iBeadConfig2Frame::OnLocationChange)
    EVT_COMBOBOX(Combo_Firmwares, iBeadConfig2Frame::OnFirmwareChange)
END_EVENT_TABLE()

// ----------------------------------------------------------------------------
// main frame
// ----------------------------------------------------------------------------

// frame constructor
iBeadConfig2Frame::iBeadConfig2Frame(const wxString& title, const wxPoint& pos, const wxSize& size, long style)
       : wxFrame((wxFrame *)NULL, -1, title, pos, size, style)
{
    // set the frame icon
    SetIcon(wxIcon(xpm_ibeadconfig));
    SetBackgroundColour(wxSystemSettings::GetColour(wxSYS_COLOUR_BTNFACE));

    // create menu bars
    wxMenu *fileMenu = new wxMenu("", wxMENU_TEAROFF);
    wxMenu *prefMenu = new wxMenu("", wxMENU_TEAROFF);
    wxMenu *helpMenu = new wxMenu("", wxMENU_TEAROFF);

    fileMenu->Append(File_Open, _("&Open...")+wxString("\tCtrl-O"), _("Open the file"));
    fileMenu->Append(File_Save, _("&Save")+wxString("\tCtrl-S"), _("Save the file"));
    fileMenu->Append(File_SaveAs, _("Save &as...")+wxString("\tCtrl-F"), _("Save the file under another file name"));
    fileMenu->AppendSeparator();
    fileMenu->Append(Param_Refresh, _("Refresh")+wxString("\tCtrl-R"), _("Refresh settings"));
    fileMenu->AppendSeparator();
    fileMenu->Append(Minimal_Quit, _("E&xit")+wxString("\tAlt-X"), _("Quit this program"));
    prefMenu->Append(PrefsLoadRadios, _("Load Radios From Preferences"), _("Load Radios From Preferences"));
    prefMenu->Append(PrefsSaveRadios, _("Save Radios To Preferences"), _("Save Radios To Preferences"));
    helpMenu->Append(Minimal_About, _("&About...")+wxString("\tCtrl-A"), _("Show about dialog"));

    // now append the freshly created menu to the menu bar...
    wxMenuBar *menuBar = new wxMenuBar();
    menuBar->Append(fileMenu, _("&File"));
    menuBar->Append(prefMenu, _("&Preferences"));
    menuBar->Append(helpMenu, _("&Help"));

    // ... and attach this menu bar to the frame
    SetMenuBar(menuBar);

    // create the toolbar and add our 1 tool to it
    wxToolBar* toolbar = CreateToolBar();
    toolbar->AddTool(File_Open, _("Open"), wxBitmap(xpm_open), _("Open a file"));
    toolbar->AddTool(File_Save, _("Save"), wxBitmap(xpm_save), _("Save the file"));
    toolbar->AddTool(Param_Refresh, _("Refresh"), wxBitmap(xpm_undo), _("Refresh"));
    toolbar->AddTool(Minimal_About, _("About"), wxBitmap(xpm_help), _("About this program"));
    toolbar->Realize();

    // create a status bar just for fun (by default with 1 pane only)
    CreateStatusBar(1);
    SetStatusText(_("Ready"));

    // Configuration
    config = new wxConfig("iBeadConfig","RPSoft");
    filename = "";
    config->Read("Defaults/Filename", &filename);

    fisRadios = new wxFileInputStream("radios.ini");
    radios = new wxFileConfig(*fisRadios);
    fisFirmwares = new wxFileInputStream("firmwares.ini");
    firmwares = new wxFileConfig(*fisFirmwares);

    // Sizer
    SetSizer(new wxBoxSizer(wxVERTICAL));

    GetSizer()->Add(0, 10);
    wxSizer * sizer;
    sizer = new wxBoxSizer(wxHORIZONTAL);
    sizer->Add(new wxStaticText(this, -1, _("Firmware")), 0, wxALIGN_CENTER_VERTICAL);
    sizer->Add(10,0);
    m_pComboFirmwares = new wxComboBox(this, Combo_Firmwares);
    sizer->Add(m_pComboFirmwares, 1, wxEXPAND);
    GetSizer()->Add(sizer, 0, wxEXPAND);

    sizer = new wxBoxSizer(wxHORIZONTAL);
    sizer->Add(new wxStaticText(this, -1, _("Location")), 0, wxALIGN_CENTER_VERTICAL);
    sizer->Add(10,0);
    m_pComboRadios = new wxComboBox(this, Combo_Radios);
    sizer->Add(m_pComboRadios, 1, wxEXPAND);
    GetSizer()->Add(sizer, 0, wxEXPAND);

    // Create Elements
    GetSizer()->Add(0, 10);
    m_pScrolledRadios = new wxScrolledWindow(this, -1);
    m_pScrolledRadios->SetSizer(new wxBoxSizer(wxVERTICAL));
    RadioItem * radio = NULL;
    int i;
    for (i=1; i<=MAXRADIOS; i++)
    {
       radio = new RadioItem(wxString::Format("Radio %2d",i), *radios, m_pScrolledRadios, -1);
       m_pScrolledRadios->GetSizer()->Add(radio, 0, wxEXPAND);
       m_pScrolledRadios->GetSizer()->Show(radio,FALSE);
       m_pRadioItem[i-1] = radio;
    }
    GetSizer()->Add(m_pScrolledRadios, 1, wxEXPAND);
    ShowRadios(16);
    if (radio != NULL) m_pScrolledRadios->SetScrollRate(0,radio->GetBestSize().GetHeight());

    PopulateFirmwares();
    PopulateLocations();
    if (filename != "") LoadRadiosFromSettings(filename);
}

// frame destructor
iBeadConfig2Frame::~iBeadConfig2Frame()
{
    if (config) delete config;
    if (radios) delete radios;
    if (firmwares) delete firmwares;
    if (fisFirmwares) delete fisFirmwares;
    if (fisRadios) delete fisRadios;
}

// event handlers
void iBeadConfig2Frame::OnQuit(wxCommandEvent& event)
{
    // TRUE is to force the frame to close
    Close(TRUE);
}

void iBeadConfig2Frame::OnAbout(wxCommandEvent& event)
{
    // called when help - about is picked from the menu or toolbar
    wxString msg;
    msg << _("iBeadConfig2 is a small tool to manipulate");
    msg << _("settings.dat files of iBead.\n");
    msg << _("It does not intend to be as extensive as iBead Ultime\n\n");
    msg << _("Use :\n");
    msg << _(" - Open your settings.dat file on the iBead\n");
    msg << _(" - Select the correct firmware version\n");
    msg << _(" - Select your location\n");
    msg << _(" - Choose or type your radios\n");
    msg << _(" - Save\n");
    msg << _("\n");
    msg << _("More information on : http://www.via.ecp.fr/~remi/soft/misc/ibeadcfg/\n");
    msg << _("(c) 2004 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>\n");
    wxMessageBox(msg, _("About iBeadConfig2"), wxOK | wxICON_INFORMATION, this);
}

void iBeadConfig2Frame::OnFileOpen(wxCommandEvent& event)
{
    wxFileDialog dialog(this, _("Load settings.dat"), "", (filename!="")?filename:_("settings.dat"), _("Settings files (*.dat)|*.dat|All Files (*.*)|*.*"),wxOPEN);
    if (dialog.ShowModal() == wxID_OK)
    {
        filename = dialog.GetPath();
        LoadRadiosFromSettings(filename);
        config->Write("Defaults/Filename", filename);
    }
}

void iBeadConfig2Frame::OnFileSave(wxCommandEvent& event)
{
    if (filename != "") SaveRadiosToSettings(filename);
}

void iBeadConfig2Frame::OnFileSaveAs(wxCommandEvent& event)
{
    wxFileDialog dialog(this, _("Save settings.dat"), "", (filename!="")?filename:_("settings.dat"), _("Settings files (*.dat)|*.dat|All Files (*.*)|*.*"),wxSAVE);
    if (dialog.ShowModal() == wxID_OK)
    {
        filename = dialog.GetPath();
        SaveRadiosToSettings(filename);
        config->Write("Defaults/Filename", filename);
    }
}

void iBeadConfig2Frame::OnRefresh(wxCommandEvent& event)
{
    if (firmwares) delete firmwares;
    if (fisFirmwares) delete fisFirmwares;
    fisFirmwares = new wxFileInputStream("firmwares.ini");
    firmwares = new wxFileConfig(*fisFirmwares);
    PopulateFirmwares();
    PopulateLocations();
    if (filename != "") LoadRadiosFromSettings(filename);
}

void iBeadConfig2Frame::OnPrefsLoadRadios(wxCommandEvent& event)
{
    int i;
    double freq;
    for (i=0; i<MAXRADIOS; i++)
    {
        freq = 0;
        config->Read(wxString::Format("Prefs/Radio%02d", i), &freq);
        if (freq != 0) m_pRadioItem[i]->SetFrequency(freq);
    }
}

void iBeadConfig2Frame::OnPrefsSaveRadios(wxCommandEvent& event)
{
    int i;
    double freq;
    for (i=0; i<MAXRADIOS; i++)
    {
        freq = m_pRadioItem[i]->GetFrequency();
        config->Write(wxString::Format("Prefs/Radio%02d", i), freq);
    }
    config->Flush();
}


void iBeadConfig2Frame::OnLocationChange(wxCommandEvent& event)
{
    SetLocation(m_pComboRadios->GetStringSelection());
}

void iBeadConfig2Frame::OnFirmwareChange(wxCommandEvent& event)
{
    SetFirmware(m_pComboFirmwares->GetStringSelection());
    if (filename != "") LoadRadiosFromSettings(filename);
}

void iBeadConfig2Frame::ShowRadios(int n)
{
    int i;
    GetSizer()->Remove(m_pScrolledRadios);
    for (i=0;i<MAXRADIOS;i++)
    {
        m_pScrolledRadios->GetSizer()->Show(m_pRadioItem[i], (i<n)?TRUE:FALSE);
    }
    m_pScrolledRadios->GetSizer()->Layout();
    m_pScrolledRadios->SetSize(m_pScrolledRadios->GetSizer()->GetMinSize().GetWidth()+20,150);
    GetSizer()->Add(m_pScrolledRadios, 1, wxEXPAND);
    GetSizer()->Layout();
    m_pScrolledRadios->GetSizer()->SetSizeHints(m_pScrolledRadios);
    GetSizer()->SetSizeHints(this);
    SetSize(GetSize().GetWidth(), GetSize().GetHeight()-150+m_pScrolledRadios->GetSizer()->GetMinSize().GetHeight());
}

void iBeadConfig2Frame::PopulateFirmwares()
{
    wxString str, value;
    long dummy;
    bool bCont;

    wxASSERT(m_pComboFirmwares != NULL);
    m_pComboFirmwares->Clear();
    firmwares->SetPath("/");
    bCont = firmwares->GetFirstGroup(str, dummy);
    while (bCont)
    {
        m_pComboFirmwares->Append(str);
        bCont = firmwares->GetNextGroup(str, dummy);
    }
    str = IBC_DEFAULTFIRMWARE;
    config->Read("Defaults/Firmware", &str);
    SetFirmware(str);
}

void iBeadConfig2Frame::PopulateLocations()
{
    wxString str, value;
    long dummy;
    bool bCont;

    wxASSERT(m_pComboRadios != NULL);
    m_pComboRadios->Clear();
    radios->SetPath("/");
    bCont = radios->GetFirstGroup(str, dummy);
    while (bCont)
    {
        m_pComboRadios->Append(str);
        bCont = radios->GetNextGroup(str, dummy);
    }
    str = IBC_DEFAULTLOCATION;
    config->Read("Defaults/Location", &str);
    SetLocation(str);
}

void iBeadConfig2Frame::SetFirmware(wxString firmware)
{
    m_pComboFirmwares->SetSelection(m_pComboFirmwares->FindString(firmware));
    m_pComboFirmwares->SetSelection(0,0);
    firmwares->SetPath(wxString("/")+firmware);
    config->Write("Defaults/Firmware", firmware);
    // Update firm_data
    firm_data.num = 16;           firmwares->Read("num", &firm_data.num);
    firm_data.position = 120;     firmwares->Read("position", &firm_data.position);
    firm_data.increment = 6;      firmwares->Read("increment", &firm_data.increment);
    firm_data.numbytes = 3;       firmwares->Read("numbytes", &firm_data.numbytes);
    firm_data.order = "little";   firmwares->Read("order", &firm_data.order);
    firm_data.offset = 0;         firmwares->Read("offset", &firm_data.offset);
    firm_data.multiply = 1000;    firmwares->Read("multiply", &firm_data.multiply);
    ShowRadios(firm_data.num);
}

void iBeadConfig2Frame::SetLocation(wxString location)
{
    int i;
    m_pComboRadios->SetSelection(m_pComboRadios->FindString(location));
    m_pComboRadios->SetSelection(0,0);
    radios->SetPath(wxString("/")+location);
    config->Write("Defaults/Location", location);
    m_pComboRadios->SetSelection(0,0);
    for(i=0;i<MAXRADIOS;i++)
    {
        m_pRadioItem[i]->PopulateRadios();
    }
    config->Write("Defaults/Location", m_pComboRadios->GetStringSelection());
    config->Flush();
}

void iBeadConfig2Frame::LoadRadiosFromSettings(const wxString & filename)
{
    int i;
    wxInt32 lfreq;
    double freq;
    wxFile file;

    file.Open(filename);
    if (!file.IsOpened())
    {
        wxMessageBox(wxString::Format(_("Unable to open file : %s."), filename));
        return;
    }
    if (firm_data.num > MAXRADIOS) firm_data.num = MAXRADIOS;
    for(i=0; i<firm_data.num; i++)
    {
        file.Seek(firm_data.position + i*firm_data.increment);
        lfreq = 0;
        file.Read(&lfreq, firm_data.numbytes);
        if (firm_data.order == "little") wxUINT32_SWAP_ALWAYS(lfreq);
        freq = lfreq / firm_data.multiply + firm_data.offset;
        m_pRadioItem[i]->SetFrequency(freq);
    }
    file.Close();
}

void iBeadConfig2Frame::SaveRadiosToSettings(const wxString & filename)
{
    int i;
    wxInt32 lfreq;
    double freq;
    wxFile file;

    // Huge block only because there is no attibute manipulation on wxWindows !!
    if (!file.Access(filename, wxFile::write) && file.Exists(filename))
    {
        if (file.Access(filename, wxFile::read))
        {
            bool success = TRUE;
            int j = 0;
            wxFileName backup(filename);
            backup.SetExt("BAK");
            wxRemoveFile(backup.GetFullPath());
            while ((file.Exists(backup.GetFullPath()) && (!file.Access(backup.GetFullPath(), wxFile::write))) && (j < 100))
            {
                backup.SetExt(wxString::Format("B%02d", j++));
            }
            success = file.Access(backup.GetFullPath(), wxFile::write) || !file.Exists(backup.GetFullPath());
            if (success) success = wxRenameFile(filename, backup.GetFullPath());
            if (success)
            {
                char buffer[1024];
                int size;
                wxFile fin(backup.GetFullPath());
                wxFile fout(filename, wxFile::write);
                while ((!fin.Eof()) && (fout.IsOpened()))
                {
                    size = fin.Read(&buffer, 1024);
                    fout.Write(buffer, size);
                }
            }
        }
        if (!file.Access(filename, wxFile::write) && file.Exists(filename))
        {
            wxMessageBox(_("Unable to open the file for writing. Please check the file or device is not read only."));
            return;
        }
    }
    // Check we can open the file
    file.Open(filename, wxFile::read_write);
    if (!file.IsOpened())
    {
        wxMessageBox(wxString::Format(_("Unable to open file : %s."), filename));
        return;
    }
    // Go Go Go !!
    if (firm_data.num > MAXRADIOS) firm_data.num = MAXRADIOS;
    for(i=0; i<firm_data.num; i++)
    {
        file.Seek(firm_data.position + i*firm_data.increment);
        lfreq = 0;
        freq = m_pRadioItem[i]->GetFrequency();
        lfreq = freq * firm_data.multiply - firm_data.offset;
        if (firm_data.order == "little") wxUINT32_SWAP_ALWAYS(lfreq);
        file.Write(&lfreq, firm_data.numbytes);
    }
    file.Close();
}


