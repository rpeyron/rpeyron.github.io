/////////////////////////////////////////////////////////////////////////////
// Name:        radioitem.h
// Purpose:     RadioItem declaration
// Author:      R�mi Peyronnet
// Modified by: 
// Created:     
// RCS-ID:      
// Copyright:   (C) 2004 - R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
// Licence:     GPL
/////////////////////////////////////////////////////////////////////////////

#ifndef __RADIOITEM_H__
#define __RADIOITEM_H__

#include "wx/wxprec.h"
#include "wx/config.h"
#include "wx/fileconf.h"

class RadioItem : public wxPanel
{
public:
    RadioItem(wxString radioName, wxFileConfig & radios, wxWindow* parent, wxWindowID id, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = 0, const wxString& name = wxPanelNameStr);
    virtual ~RadioItem();
public:
    void PopulateRadios();
    double GetFrequency();
    void SetFrequency(double freq);
protected:
    void OnRadioEdit(wxCommandEvent & event);
    void OnComboSelect(wxCommandEvent & event);
    void SyncCombo();
protected:
    wxString radioName;
    wxFileConfig & radios;
    wxComboBox * m_pComboBox;
    wxTextCtrl * m_pTextEdit;

    DECLARE_EVENT_TABLE()
};

#endif // __RADIOITEM_H__
