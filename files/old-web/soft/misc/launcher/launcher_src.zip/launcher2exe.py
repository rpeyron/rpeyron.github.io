# To Run py2exe, uncomment that and run python xxx2exe.py py2exe --windows --package encodings

# Do Not forget --package encodings, else you will get "LookupError: no codec search functions registered: can't find encoding"

from distutils.core import setup
import py2exe

setup(name="Launcher",
      scripts=[
                    "launcher.py",
              ],
     )