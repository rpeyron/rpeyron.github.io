# plugin-button
Dokuwiki Plugin

Button Plugin for dokuwiki 
https://www.dokuwiki.org/plugin:button
http://www.lprp.fr/wiki/doku.php/dokuwikibutton


@license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
@author     Rémi Peyronnet  <remi+button@via.ecp.fr>