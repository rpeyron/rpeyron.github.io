// RenDate.cpp (c) 2002 R�mi Peyronnet
//

#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <windows.h>  // For MoveFile and CopyFile. Use rename and fopen to pass through

#define DEBUG

const char format_default[] = "_%Y%m%d";

void usage()
{
	printf("RenDate 1.0 - (c) 2002 Remi Peyronnet <remi.peyronnet@via.ecp.fr>\n");
	printf("This utility allows you to copy or rename a file and add the \n current date/time to its filename.\n\n");
	printf("Usage : RenDate [/m] [/n] [/v] [/f <format>] <filename>\n\n");
	printf("    filename  : the name of the file to be copied/moved.\n");
	printf("    /m        : move the file instead of creating a copy.\n");
	printf("    /n        : do not use the filename provided as base filename.\n");
   	printf("    /v        : verbose mode.\n");
	printf("    /f format : User Defined Format\n");
	printf("                 the most common flags are : (see strftime for the full list)\n");
	printf("                    %%c Date and time representation appropriate for locale\n");
	printf("                    %%d Day of month as decimal number (01 - 31)\n");
	printf("                    %%H Hour in 24-hour format (00 - 23)\n");
	printf("                    %%j Day of year as decimal number (001 - 366)\n");
	printf("                    %%m Month as decimal number (01- 12)\n");
	printf("                    %%M Minute as decimal number (00 - 59)\n");
	printf("                    %%S Second as decimal number (00 - 59)\n");
	printf("                    %%y Year without century, as decimal number (00 - 99)\n");
	printf("                    %%Y Year with century, as decimal number\n");
	printf("                    %%%% Percent sign \n");
	printf("                 the default is : _%%Y%%m%%d (appends _YYYYMMDD)\n");
	exit(1);
}

int main(int argc, char* argv[])
{
	char fsource[_MAX_PATH], fcible[_MAX_PATH], strTime[256], format[256];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	int copie, verbose, nobasename, i, iRet;
    time_t ltime;

    // Check for args
	copie = true;
    nobasename = false;
    verbose = false;
	strcpy(fsource, "nofsourceprovided");
	strcpy(format,format_default);
	if (argc < 1) usage();
	for (i=1; i<argc; i++)
	{
		if ( (strcmp(argv[i],"/?") == 0) ||
			 (strcmp(argv[i],"/h") == 0) ||
			 (strcmp(argv[i],"/help") == 0) ||
			 (strcmp(argv[i],"-h") == 0) ) usage();
		if ( (strcmp(argv[i],"/m") == 0) ||
			 (strcmp(argv[i],"/M") == 0))  
		{
			copie = false;
			continue;
		}
        if ( (strcmp(argv[i],"/n") == 0) ||
			 (strcmp(argv[i],"/N") == 0))  
		{
			nobasename = true;
			continue;
		}
        if ( (strcmp(argv[i],"/v") == 0) ||
			 (strcmp(argv[i],"/V") == 0))  
		{
			verbose = true;
			continue;
		}
		if ( (strcmp(argv[i],"/f") == 0) ||
			 (strcmp(argv[i],"/F") == 0)) 
		{
			// User Defined Format
			if (i<argc)
			{
				i++;
				strcpy(format,argv[i]);
			}
			continue;
		}
		// Else it is the filename 
		strcpy(fsource, argv[i]);
	}
	// Performs some check
	if (strcmp(fsource,"nofsourceprovided") == 0) usage();

   // File name manipulation

   _splitpath( fsource, drive, dir, fname, ext );
   time(&ltime);
   strftime(strTime,256,format,localtime(&ltime)); 
   if (nobasename) strcpy(fname, strTime);
       else strcat(fname, strTime);
   _makepath( fcible, drive, dir, fname, ext );

   // Verbose mode 

   if (verbose)
   {
       printf( "File source : %s \n", fsource);
       printf( " copie : %i \n",copie);
       printf( " nobasename : %i \n",nobasename);
       printf( " format : %s \n",format);
       printf( "Path extracted with _splitpath:\n" );
       printf( "  Drive: %s\n", drive );
       printf( "  Dir: %s\n", dir );
       printf( "  Filename: %s\n", fname );
       printf( "  Ext: %s\n", ext );
       printf( "Date created : %s \n", strTime);
       printf( "File cible : %s \n", fcible);
   }


   // Performs the copy (or the move)
   if (copie)
   {
	iRet = CopyFile(fsource, fcible, false);
    if (iRet)
    {
        if (verbose) printf("Copy successful !\n");
        return 0;
    }
    else
    {
        if (verbose) printf("ERROR : Copy failed ! Check filenames\n");
        return 1;
    }
   }
   else
   {
	iRet = MoveFile(fsource, fcible);  
    if (iRet)
    {
        if (verbose) printf("File successfully renamed !\n");
        return 0;
    }
    else
    {
        if (verbose) printf("ERROR : Rename failed ! Check filenames, and that the target file does not exists.\n");
        return 1;
    }
   }
}

