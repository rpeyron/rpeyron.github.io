


EXPLORE_PATH = "client"
XML_MAKEFILE_FILENAME = "Makefile.xml"
XML_OUTPUT_FILENAME = "tree.xml"
XSL_FILENAME = "dsp.xsl"
OUTPUT_FILENAME = "VSProject.dsp"
VERSION="1.0"

import sys
import string
import os
import os.path
import re

# Filters
#  - if the name is found in INCLUDE, the file is processed
#  - otherwise, if it is found in EXCLUDE, the file is skipped
#  - otherwise, the file is processed.
# Note : the var is a regular re.
# Ext are only for files

# Example (used to build C'Nedra 's tree.xml)
INCLUDE = None
INCLUDE_EXT = re.compile("(.h|.cpp)")
EXCLUDE = re.compile("CVS|/solver")
EXCLUDE_EXT = re.compile(".*")
EXT_MATCH = \
    { \
        '.h'   : 'header',  \
        '.cpp' : 'source', \
        '.c'   : 'source' \
    }

# Another example (used to build OpenOffice.org's tree.xml)
#INCLUDE = None
#INCLUDE_EXT = None
#EXCLUDE = re.compile("CVS")
#EXCLUDE_EXT = re.compile(".html|.bmp|.gif|.ico|.map|.ptr|.stw")
#EXT_MATCH = { }


def writeFile(file, str):
    fout = open(file, "w")
    fout.write(str)
    fout.close()

def readFile(file):
    fin = open(file, "r")
    str = fin.read()
    fin.close()
    return str

def isToBeSkipped(root,path,file,ext):
    global EXCLUDE
    global INCLUDE
    global EXCLUDE_EXT
    global INCLUDE_EXT

    fullname = os.path.join(os.path.join(root,path),file+ext)
    if (INCLUDE != None):
        if (INCLUDE.match(file)): 
            return 0
    if ((INCLUDE_EXT != None) & (os.path.isfile(fullname))):
        if (INCLUDE_EXT.match(ext)): 
            return 0
    if (EXCLUDE != None):
        if (EXCLUDE.match(file)): 
            return 1
    if ((EXCLUDE_EXT != None) & (os.path.isfile(fullname))):
        if (EXCLUDE_EXT.match(ext)): 
            return 1

    return 0

def xmlProcessDir(root,path, level):
    global EXT_MATCH
    str = ""
    rootpath = os.path.join(root,path)
    files = os.listdir(rootpath)
    files.sort()
    for file in files:
        (base, ext) = os.path.splitext(file)
        if (isToBeSkipped(root,path,base,ext)): continue
        pathfile = os.path.join(path,file);
        rootpathfile = os.path.join(root,pathfile);
        if (os.path.isdir(rootpathfile)):
            str += level + "<dir name=\"" + file + "\">\n"
            str += xmlProcessDir(root, pathfile, level + " ")
            str += level + "</dir>\n"
        elif (os.path.isfile(rootpathfile)):
            #   "fullname=\"" + pathfile + "\" " + \
            if (ext in EXT_MATCH.keys()):
                type = EXT_MATCH[ext]
            else:
                type = 'file'
            str += level + "<" + type + " " + \
                "name=\"" + base + "\" " + \
                "ext=\"" + ext + "\" " + \
                " />\n"
    
    return str
    
def xmlExplorePath():
    global EXPLORE_PATH
    global VERSION
    pathfile = EXPLORE_PATH
    str = ""
    str += "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"yes\" ?>\n"
    str += "<tree path=\"" + pathfile + "\" ver=\"" + VERSION + "\" Makefile=\"Makefile.xml\" >\n"
    str += xmlProcessDir(pathfile, ""," ")
    str += "</tree>\n"
    return str


def xmlApplyXSL(str):
    global XSL_FILENAME
    global OUTPUT_FILENAME
    global XML_OUTPUT_FILENAME
    
    import libxml2
    import libxslt

    styledoc = libxml2.parseFile(XSL_FILENAME)
    style = libxslt.parseStylesheetDoc(styledoc)
    #doc = libxml2.parseFile(XML_OUTPUT_FILENAME)
    doc = libxml2.parseDoc(str)
    
    result = style.applyStylesheet(doc, None)

    style.saveResultToFilename(OUTPUT_FILENAME, result, 0)
    style.freeStylesheet()
    doc.freeDoc()
    result.freeDoc()

str = xmlExplorePath()
if (XML_OUTPUT_FILENAME != None): 
    writeFile(XML_OUTPUT_FILENAME, str)
    xmlApplyXSL(readFile(XML_MAKEFILE_FILENAME))