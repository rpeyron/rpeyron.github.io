You must have at least the following packages installed :
 - libxml2-dev
 - libxslt-dev
 
For DevPacks updates or more information : 
http://people.via.ecp.fr/~remi/dist/devpacks/

For libxmldiff information and utilities :
http://people.via.ecp.fr/~remi/soft/xml/xmldiff/xmldiff_en.php3

-- 
R�mi Peyronnet <http://www.via.ecp.fr/~remi>