#ifndef __XMLUTILS_H__
#define __XMLUTILS_H__

// Remove STL warnings
#ifdef _MSC_VER
#pragma warning(disable: 4786)
#endif


#include <string>

// StrX 

// ---------------------------------------------------------------------------
//  This is a simple class that lets us do easy (though not terribly efficient)
//  trancoding of XMLCh data to local code page for display.
// ---------------------------------------------------------------------------
class StrX
{
public :
    // -----------------------------------------------------------------------
    //  Constructors and Destructor
    // -----------------------------------------------------------------------
    StrX(const XMLCh* const toTranscode)
    {
        // Call the private transcoding method
        fLocalForm = XMLString::transcode(toTranscode);
    }

    ~StrX()
    {
        XMLString::release(&fLocalForm);
    }


    // -----------------------------------------------------------------------
    //  Getter methods
    // -----------------------------------------------------------------------
    const char* localForm() const
    {
        return fLocalForm;
    }

    operator char * ()
    {
        return (fLocalForm);
    }


private :
    // -----------------------------------------------------------------------
    //  Private data members
    //
    //  fLocalForm
    //      This is the local code page form of the string.
    // -----------------------------------------------------------------------
    char*   fLocalForm;
};

// ---------------------------------------------------------------------------
//  This is a simple class that lets us do easy (though not terribly efficient)
//  trancoding of XMLCh data to local code page for display.
// ---------------------------------------------------------------------------
class XStr
{
public :
    // -----------------------------------------------------------------------
    //  Constructors and Destructor
    // -----------------------------------------------------------------------
    XStr(const char * const toTranscode)
    {
        // Call the private transcoding method
        fLocalForm = XMLString::transcode(toTranscode);
    }

    ~XStr()
    {
        XMLString::release(&fLocalForm);
    }


    // -----------------------------------------------------------------------
    //  Getter methods
    // -----------------------------------------------------------------------
    const XMLCh * localForm() const
    {
        return fLocalForm;
    }

    operator XMLCh * ()
    {
        return (fLocalForm);
    }

private :
    // -----------------------------------------------------------------------
    //  Private data members
    //
    //  fLocalForm
    //      This is the local code page form of the string.
    // -----------------------------------------------------------------------
    XMLCh *   fLocalForm;
};

// ***************************************************************
// Provide XMLCh basic_string
// ***************************************************************

typedef std::basic_string<XMLCh> xmlstring;
	
#define DECLARE_XMLSTRING(x, y) string x ## _ascii = y; xmlstring x;

#define INITIALIZE_XMLSTRING(x)  x = xmlstring(XStr(x ## _ascii.c_str()));
#define INITIALIZE_XMLSTRING_ARRAY(x,y)  x[y] = xmlstring(XStr(x ## _ascii[y].c_str()));

#ifndef _MSC_VER

// Provide std::char_traits specialization.
namespace std
{
    struct char_traits<XMLCh>
    {
      typedef XMLCh             char_type;
      // NB: this type should be bigger than XMLCh, so as to
      // properly hold EOF values in addition to the full range of
      // XMLCh values.
      typedef int  		int_type;

      typedef streampos 	pos_type;
      typedef streamoff 	off_type;
      typedef mbstate_t 	state_type;
      
      static void 
      assign(XMLCh& __c1, const XMLCh& __c2)
      { __c1 = __c2; }

      static bool 
      eq(const XMLCh& __c1, const XMLCh& __c2)
      { return __c1 == __c2; }

      static bool 
      lt(const XMLCh& __c1, const XMLCh& __c2)
      { return __c1 < __c2; }

      static int 
      compare(const XMLCh* __s1, const XMLCh* __s2, size_t __n)
      { 
	for (size_t __i = 0; __i < __n; ++__i)
	  if (!eq(__s1[__i], __s2[__i]))
	    return lt(__s1[__i], __s2[__i]) ? -1 : 1;
	return 0; 
      }

      static size_t
      length(const XMLCh* __s)
      { 
	const XMLCh* __p = __s; 
	while (*__p) ++__p; 
	return (__p - __s); 
      }

      static const XMLCh* 
      find(const XMLCh* __s, size_t __n, const XMLCh& __a)
      { 
	for (const XMLCh* __p = __s; size_t(__p - __s) < __n; ++__p)
	  if (*__p == __a) return __p;
	return 0;
      }

      static XMLCh* 
      move(XMLCh* __s1, const XMLCh* __s2, size_t __n)
      { return (XMLCh*) memmove(__s1, __s2, __n * sizeof(XMLCh)); }

      static XMLCh* 
      copy(XMLCh* __s1, const XMLCh* __s2, size_t __n)
      { return (XMLCh*) memcpy(__s1, __s2, __n * sizeof(XMLCh)); }

      static XMLCh* 
      assign(XMLCh* __s, size_t __n, XMLCh __a)
      { 
	for (XMLCh* __p = __s; __p < __s + __n; ++__p) 
	  assign(*__p, __a);
        return __s; 
      }

      static XMLCh 
      to_XMLCh(const int_type& __c)
      {
	XMLCh __r = { __c };
	return __r;
      }

      static int_type 
      to_int_type(const XMLCh& __c) 
      { return int_type(__c); }

      static bool 
      eq_int_type(const int_type& __c1, const int_type& __c2)
      { return __c1 == __c2; }

      static int_type 
      eof() { return static_cast<int_type>(-1); }

      static int_type 
      not_eof(const int_type& __c)
      { return eq_int_type(__c, eof()) ? int_type(0) : __c; }
    };
};

#endif 

#endif // __XMLUTILS_H__
