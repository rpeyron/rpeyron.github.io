/* ****************************************************************************
 * xmldiff.cpp : a diff tool for XML files                                    *
 * -------------------------------------------------------------------------- *
 *                                                                            *
 * XMLDiff : a diff tool for XML files                                        *
 * Copyright (C) 2004 - R�mi Peyronnet <remi+rphoto@via.ecp.fr>               *
 *                                                                            *
 * This program is free software; you can redistribute it and/or              *
 * modify it under the terms of the GNU General Public License                *
 * as published by the Free Software Foundation; either version 2             *
 * of the License, or (at your option) any later version.                     *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program; if not, write to the Free Software                *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.*
 * http://www.gnu.org/copyleft/gpl.html                                       *
 * ************************************************************************** */


// Warning : may not compile everywhere, because of wchar_t and XMLCh * conflicts...


// Remove STL warnings
#ifdef _MSC_VER
#pragma warning(disable: 4786)
#endif

// Include precompiled headers (mostly Xerces)
#include "precomp.h"

#define _RWSTD_COMPILE_INSTANTIATE

#include "xmlutils.h"
#include <string>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

/// Options -----------------------------------------------------------

DECLARE_XMLSTRING(separator, "|")

DECLARE_XMLSTRING(diff_attr, "diff:status")
DECLARE_XMLSTRING(diff_ns, "http://www.via.ecp.fr/~remi/soft/xml/xmldiff")
DECLARE_XMLSTRING(diff_xmlns, "xmlns:diff")


string fileBefore = "before.xml";
string fileAfter = "after.xml";
string fileDiff = "output.xml";
string idsList = "@id,@value";

// options for DOMWriter's features
bool  gDiscardDefaultContent            = true;
bool  gFormatPrettyPrint                = true;
bool  gDOMWRTWhitespaceInElementContent = false;

bool  gTagChildsAddedRemoved            = true;
bool  gCleanText                        = true;
bool  gBeforeValue                      = true;


/// Internal Declarations -------------------------------------------

DECLARE_XMLSTRING(strSpace, " ")
DECLARE_XMLSTRING(strEqual, "=")
DECLARE_XMLSTRING(strQuote, "\"")

/// Name of User Data used
DECLARE_XMLSTRING(strUserDataNode, "node")

class DiffException
{
public:
    int code;
    DiffException(int code) : code(code) {};
};

/// Status List
enum DN_STATUS {
    DN_UNKNOWN = 0,
    DN_ADDED,
    DN_REMOVED,
    DN_MODIFIED,
    DN_BELOW,
    DN_NONE
};
vector<xmlstring> diff_attr_list;
const string diff_attr_list_ascii[] = {"unknown", "added", "removed", "modified", "below", "none"};

/// This struct contains the id string to be sorted, and a reference to the node
struct idNode {
    xmlstring id;
    DOMNode * node;
};

/// idNode comparaison function (compares the id strings)
struct IdNodeCompare {  
  bool operator()(const idNode& a, const idNode& b) {
      return a.id < b.id;  // based on last names only
  }
} idNodeCompare;

/// Lists of items to be taken as id (populated from idList)
vector<xmlstring> ids;


/// Get only text nodes of node, and not all text nodes of this node and subnodes
xmlstring getNodeTextOnly(DOMNode * node)
{
    xmlstring ret;
    DOMNode * curNode;
    if (node == NULL) return XMLUni::fgEmptyString;
    if (node->getNodeValue() != NULL) ret = node->getNodeValue();
    curNode = node->getFirstChild();
    while (curNode != NULL)
    {
        if (curNode->getNodeValue() != NULL) ret += curNode->getNodeValue();
        curNode = curNode->getNextSibling();
    }
    return ret;
}

/// Get the first child with this tagname : used for id elements.
DOMNode * getFirstChildByTagName(DOMNode * node, const XMLCh * name)
{
    DOMNode * curNode;
    if (node == NULL) return NULL;
    curNode = node->getFirstChild();
    while (curNode != NULL)
    {
        if (curNode->getNodeType() == DOMNode::ELEMENT_NODE)
        {
            if (XMLString::compareString(curNode->getNodeName(), name) == 0) return curNode;
        }
        curNode = curNode->getNextSibling();
    }

    return NULL;
}

/// Set diff;status attribute
void setAttributeToAllChilds(DOMNode * node, int status)
{
    DOMNode * curNode;
    if (node == NULL) return;
    if ((status != DN_NONE) && (node->getNodeType() == DOMNode::ELEMENT_NODE)) ((DOMElement *)node)->setAttribute(diff_attr.c_str(), diff_attr_list[status].c_str());
    if (!gTagChildsAddedRemoved) return;
    curNode = node->getFirstChild();
    while (curNode != NULL)
    {
        if (curNode->getNodeType() == DOMNode::ELEMENT_NODE)
        {
            setAttributeToAllChilds(curNode, status);
        }
        curNode = curNode->getNextSibling();
    }
    return;
}

/** Populate item list with id strings of child nodes.
 *
 * This list will be populated with the name of the node and 
 * attributes/elements contained in the ids list, and then sorted.
 *
 * @param node : the node to inspect
 * @param itemlist : the list to populate
 */
void populate_itemlist(DOMNode * node, vector<idNode> & itemlist)
{
    DOMNode * curNode, * tmpNode;
    DOMElement * element;
    idNode curNodeIdent;
    vector<xmlstring>::iterator id;

    curNode = node->getFirstChild();
    while (curNode != NULL)
    {
        if (curNode->getNodeType() == DOMNode::ELEMENT_NODE)
        {
            element = (DOMElement *) curNode;
            curNodeIdent.id = element->getNodeName();
            for (id = ids.begin(); id != ids.end(); id++)
            {
                if (id->at(0) == '@')
                {
                    if (element->hasAttribute(id->c_str()+1))
                    {
                        curNodeIdent.id += strSpace + *id + strEqual + strQuote + element->getAttribute(id->c_str()+1) + strQuote;
                    }
                }
                else
                {
                    tmpNode = getFirstChildByTagName(element, id->c_str());
                    if (tmpNode != NULL)
                    {
                        curNodeIdent.id += strSpace + *id + strEqual + getNodeTextOnly(tmpNode);
                    }
                }
            }
            curNodeIdent.node = curNode;
            itemlist.push_back(curNodeIdent);
        }
        curNode = curNode->getNextSibling();
    }
    stable_sort(itemlist.begin(), itemlist.end(), idNodeCompare);
}

/** Main diff function.
 * 
 * This function performs the diff between two nodes, and modify 
 * the nodeAfter to reflect the changes (diff:status, add elements,...)
 * It also free nodeBefore as much as possible, to save memory.
 * The algorithm is described in the function.
 *
 * @param nodeBefore : the node of the first file
 * @param nodeAfter  : the node of the second file
 * @return the status of the diff (@see DN_STATUS)
 *
 * @warning nodeBefore and nodeAfter are affected by this function.
 */
int diffNode(DOMNode * nodeBefore, DOMNode * nodeAfter)
{
    int i;
    int cmp;
    int status;
    DOMNode * curNode, *tmpNode;
    DOMNode * insertPoint;
    vector<idNode> * listBefore;
    vector<idNode> * listAfter;
    vector<idNode>::iterator iterBefore;
    vector<idNode>::iterator iterAfter;
    vector<DOMNode *> removed_nodes;
    vector<DOMNode *> subnodes_to_diff;
    vector<DOMNode *>::iterator iter;

    xmlstring s;

    status = DN_NONE;
    // Compare elements
    // * Create lists
    listBefore = new vector<idNode>;
    listAfter = new vector<idNode>;
    if ((listBefore == NULL) || (listAfter == NULL)) throw new DiffException(-1);
    // * Populate lists
    populate_itemlist(nodeBefore, *listBefore);
    populate_itemlist(nodeAfter, *listAfter);
    // * Iterate lists
    iterBefore = listBefore->begin();
    iterAfter = listAfter->begin();
    while ((iterBefore != listBefore->end()) || (iterAfter != listAfter->end()))
    {
        // Compare the two current id strings.
        if (iterBefore == listBefore->end()) cmp = -1;
        else if (iterAfter == listAfter->end()) cmp = 1;
        else cmp = iterAfter->id.compare(iterBefore->id);
        switch(cmp)
        {
        case -1:
            // If the id string after < before, the element has been added
            setAttributeToAllChilds(iterAfter->node, DN_ADDED);
            iterAfter++;
            status = DN_BELOW;
            break;
        case 1:
            // If the id string after > before, the element has been removed
            setAttributeToAllChilds(iterBefore->node, DN_REMOVED);
            // As we cannot insert it now, we add it in the removed_nodes list
            // which will be processed later.
            removed_nodes.push_back(iterBefore->node);
            iterBefore++;
            status = DN_BELOW;
            break;
        default:
            // If the two id are equal, these nodes are comparables
            // Due to memory reason (should free the id lists before recursing...)
            // these items will be placed in a list to be processed later.
            // Also the correspondance between these nodes is stored as UserData
            iterAfter->node->setUserData(strUserDataNode.c_str(), iterBefore->node, NULL);
            iterBefore->node->setUserData(strUserDataNode.c_str(), iterAfter->node, NULL);
            subnodes_to_diff.push_back(iterBefore->node);
            iterAfter++;
            iterBefore++;
            break;
        }
    }
    // * Free lists
    if (listBefore) delete listBefore;
    if (listAfter) delete listAfter;
    // * Add Removed nodes to current tree
    for (iter = removed_nodes.begin(); 
         iter != removed_nodes.end();)
    {
        insertPoint = NULL;
        curNode = *iter;
        iter++;
        tmpNode = curNode;
        while (tmpNode != NULL)
        {
            insertPoint = (DOMNode *) tmpNode->getUserData(strUserDataNode.c_str());
            if (insertPoint != NULL) tmpNode = NULL;
                else tmpNode = tmpNode->getNextSibling();
        }
        if (nodeAfter->getOwnerDocument() != NULL)
        {
            tmpNode = nodeAfter->getOwnerDocument()->importNode(curNode, true);
            nodeAfter->insertBefore(tmpNode, insertPoint);
            nodeBefore->removeChild(curNode);
            curNode->release();
        }
        else
        {
            printf("[WARNING] A problem has occured that is often due to different root elements ! \nBe sure there is no identification attributes that could affect the diff.\n");
        }
    }
    removed_nodes.clear();
    // * Diff Sub-Nodes
    for (iter = subnodes_to_diff.begin(); 
         iter != subnodes_to_diff.end();
         iter++)
    {
        DOMNode * iA, * iB;
        iB = *iter;
        iA = (DOMNode *) iB->getUserData(strUserDataNode.c_str());
        if (diffNode(iB, iA) != DN_NONE) status = DN_BELOW;
        nodeBefore->removeChild(iB);
        iB->release();
    }
    subnodes_to_diff.clear();
    // Compare attributes
    if (nodeAfter->getNodeType() == DOMNode::ELEMENT_NODE)
    {
        DOMElement * elementAfter = (DOMElement *) nodeAfter;
        DOMElement * elementBefore = (DOMElement *) nodeBefore;
        DOMNamedNodeMap * attrsAfter = nodeAfter->getAttributes();
        DOMNamedNodeMap * attrsBefore = nodeBefore->getAttributes();
        // Look for modified/added attributes
        for (i = 0; i < attrsAfter->getLength(); i++)
        {
            if (XMLString::compareString(attrsAfter->item(i)->getNodeValue(),elementBefore->getAttribute(attrsAfter->item(i)->getNodeName())))
            {
                if (gBeforeValue)
                {
                    s = attrsAfter->item(i)->getNodeValue();
                    s += separator;
                    s += elementBefore->getAttribute(attrsAfter->item(i)->getNodeName());
                    attrsAfter->item(i)->setNodeValue(s.c_str());
                    s = XMLUni::fgEmptyString;
                }
                status = DN_MODIFIED;
            }
        }
        // Removed attributes ?
        for (i = 0; i < attrsBefore->getLength(); i++)
        {
            if (!(elementAfter->hasAttribute(attrsBefore->item(i)->getNodeName())))
            {
                if (gBeforeValue)
                {
                    s = separator;
                    s += attrsBefore->item(i)->getNodeValue();
                    elementAfter->setAttribute(attrsBefore->item(i)->getNodeName(), s.c_str());
                    s = XMLUni::fgEmptyString;
                }
                status = DN_MODIFIED;
            }
        }
    }
    // Compare values
    if (getNodeTextOnly(nodeBefore) != getNodeTextOnly(nodeAfter))
    {
        if (gBeforeValue)
        {
            s = getNodeTextOnly(nodeBefore);
            s += separator;
            tmpNode = nodeAfter->getOwnerDocument()->createTextNode(s.c_str());
            nodeAfter->insertBefore(tmpNode, nodeAfter->getFirstChild());
            s = XMLUni::fgEmptyString;
        }
        status = DN_MODIFIED;
    }
    // Update Status if Element
    if ((status != DN_NONE) && (nodeAfter->getNodeType() == DOMNode::ELEMENT_NODE)) ((DOMElement *)nodeAfter)->setAttribute(diff_attr.c_str(), diff_attr_list[status].c_str());
    return status;
}

/// Print a node (with subnodes). Unused (replaced by a writer)
void printNode(DOMNode * node)
{
    DOMNode * curNode;
    unsigned int i;

    printf("<%s", (char *)StrX(node->getNodeName()));

    if (node->hasAttributes())
    {
        for(i=0; i < node->getAttributes()->getLength(); i++)
        {
            printf(" %s=\"%s\"", 
                (char *)StrX(node->getAttributes()->item(i)->getNodeName()),
                (char *)StrX(node->getAttributes()->item(i)->getNodeValue()) );
        }
    }
    

    printf("> %s", (char *)StrX(node->getNodeValue()));

    curNode = node->getFirstChild();
    while (curNode != NULL)
    {
        printNode(curNode);
        curNode = curNode->getNextSibling();
    }
    printf("</%s>", (char *)StrX(node->getNodeName()));
}

/// Clean the tree of blank text nodes.
void cleanTree(DOMNode * node)
{
    DOMNode * curNode, * nextNode;
    XMLCh * str;
    curNode = node->getFirstChild();
    while (curNode != NULL)
    {
        nextNode = curNode->getNextSibling();
        switch(curNode->getNodeType())
        {
        case  DOMNode::ELEMENT_NODE:
            cleanTree(curNode);
            break;
        case  DOMNode::TEXT_NODE:
            if (XMLString::isAllWhiteSpace(curNode->getNodeValue()))
            {
                node->removeChild(curNode);
                curNode->release();
            }
            else
            {
                str = XMLString::replicate(curNode->getNodeValue());
                XMLString::trim(str);
                curNode->setNodeValue(str);
                XMLString::release(&str);
            }
            break;
        default:
            break;
        }
        curNode = nextNode;
    }
}

/// Print usage
void usage()
{
    cout << "xmldiff - diff two XML files. (c) 2004 - R�mi Peyronnet" << endl
         << "Syntax : xmldiff [options] [file before.xml] [file after.xml]" << endl
         << "Options : " << endl
         << "  --output output.xml  : Output to the provided file name" << endl
         << "  --sep |              : Use this as the separator" << endl
         << "  --before-values yes  : Add before values in attributes or text nodes" << endl
         << "  --pretty-print yes   : Output using pretty print writer" << endl
         << "  --ids '@id,@value'   : Use these item to identify a node" << endl
         << "  --clean-text yes     : Remove all blank spaces" << endl
         << "  --tag-childs yes     : Tag Added or Removed childs" << endl;
}

/// Dump current configuration
void printConfiguration()
{
    vector<xmlstring>::iterator id;
    cout << "Before         : " << fileBefore << endl
         << "After          : " << fileAfter << endl
         << "Output to      : " << fileDiff << endl
         << "Use separator  : " << separator_ascii.c_str() << endl
         << "Before values  : " << ((gBeforeValue)?"Yes":"No") << endl
         << "Pretty Print   : " << ((gFormatPrettyPrint)?"Yes":"No") << endl
         << "Clean Text     : " << ((gCleanText)?"Yes":"No") << endl
         << "Tag Childs     : " << ((gTagChildsAddedRemoved)?"Yes":"No") << endl
         << "Ids            : ";
    for(id = ids.begin(); id != ids.end(); id++)
    {
        cout << StrX(id->c_str()).localForm() << " ";
    }
    cout << endl << endl;
}

/** Main function :
 * The main function :
 * - parse the command line
 * - adjust some parameters
 * - load / clean XML files
 * - call the diff function
 * - write the result
 */
int main(int argc, char* argv[])
{
    int rc, status;
    int curarg;
    int nArgOther;
    bool argBool;

    XercesDOMParser * parser;
    DOMNode * docBefore, * docAfter; //, * docOutput;

    status = 0;

    // Initialize strings
    XMLPlatformUtils::Initialize();

    INITIALIZE_XMLSTRING(separator)
    INITIALIZE_XMLSTRING(diff_attr)
    INITIALIZE_XMLSTRING(diff_ns)
    INITIALIZE_XMLSTRING(diff_xmlns)
    INITIALIZE_XMLSTRING(strSpace)
    INITIALIZE_XMLSTRING(strEqual)
    INITIALIZE_XMLSTRING(strQuote)
    INITIALIZE_XMLSTRING(strUserDataNode)
    diff_attr_list.resize(DN_NONE+1);
    INITIALIZE_XMLSTRING_ARRAY(diff_attr_list, DN_UNKNOWN)
    INITIALIZE_XMLSTRING_ARRAY(diff_attr_list, DN_ADDED)
    INITIALIZE_XMLSTRING_ARRAY(diff_attr_list, DN_REMOVED)
    INITIALIZE_XMLSTRING_ARRAY(diff_attr_list, DN_MODIFIED)
    INITIALIZE_XMLSTRING_ARRAY(diff_attr_list, DN_BELOW)
    INITIALIZE_XMLSTRING_ARRAY(diff_attr_list, DN_NONE)

    nArgOther = 0;
    // Parse command line
    for (curarg = 1; curarg < argc; curarg++)
    {
        if (argv[curarg][0] == '-')
        {
            if (strncmp(argv[curarg], "--", 2) == 0)
            {
                if (curarg + 1 >= argc)
                {
                    printf("Error : %s argument need a value.\n", argv[curarg]);
                    usage();
                    return(-1);
                }
                argBool = false;
                if ((stricmp(argv[curarg+1], "yes") == 0) ||
                    (stricmp(argv[curarg+1], "1") == 0) ||
                    (stricmp(argv[curarg+1], "oui") == 0) )
                        argBool = true;
                if (strcmp(argv[curarg], "--output") == 0) { fileDiff = argv[++curarg]; }
                else if (strcmp(argv[curarg], "--ids") == 0) { idsList = argv[++curarg]; }
                else if (strcmp(argv[curarg], "--sep") == 0) { separator_ascii = argv[++curarg]; }
                else if (strcmp(argv[curarg], "--before-values") == 0) { gBeforeValue = argBool; curarg++; }
                else if (strcmp(argv[curarg], "--pretty-print") == 0) { gFormatPrettyPrint = argBool; curarg++; }
                else if (strcmp(argv[curarg], "--clean-text") == 0) { gCleanText = argBool; curarg++; }
                else if (strcmp(argv[curarg], "--tag-childs") == 0) { gTagChildsAddedRemoved = argBool; curarg++; }
            }
            else
            {
                // No single => error
                printf("Error : unrecognized argument %s \n", argv[curarg]);
                usage();
                return(-1);
            }
        }
        else
        {
            switch(nArgOther)
            {
            case 0:
                fileBefore = argv[curarg];
                break;
            case 1:
                fileAfter = argv[curarg];
                break;
            default:
                printf("Error : extra argument %s ", argv[curarg]);
                usage();
                return -1;
            }
            nArgOther++;
        }
    }

    // Ids Splitting
    int pos, oldpos;
    oldpos = pos = 0;
    while((pos = idsList.find(',', pos+1)) > 0)
    {
        ids.push_back(xmlstring(XStr(idsList.substr(oldpos, pos-oldpos).c_str())));
        oldpos = pos + 1;
    }
    if (oldpos < idsList.size()) ids.push_back(xmlstring(XStr(idsList.substr(oldpos, oldpos-idsList.size()).c_str())));

    separator = xmlstring(XStr(separator_ascii.c_str()));

    printConfiguration();

    // Perform the diff

    parser = new XercesDOMParser;

    try
    {
        // IncludeIgnorableWhitespace inutile pour les documents non valid�s
        // parser->setIncludeIgnorableWhitespace(false);
        printf("\nParsing %s ... ", fileBefore.c_str());
        parser->parse(fileBefore.c_str());
        docBefore = parser->getDocument();
        if (gCleanText)
        {
            printf("cleaning...");
            cleanTree(docBefore);
        }
        printf("\nParsing %s ... ", fileAfter.c_str());
        parser->parse(fileAfter.c_str());
        docAfter = parser->getDocument();
        if (gCleanText)
        {
            printf("cleaning...");
            cleanTree(docAfter);
        }

        printf("\nDiffing ...");
        rc = diffNode(docBefore, docAfter);

        ((DOMDocument *)docAfter)->getDocumentElement()->setAttribute(diff_xmlns.c_str(), diff_ns.c_str());

        // Write
        printf("\nOutputing to %s ...", fileDiff.c_str());
        XMLCh tempStr[100];
        XMLString::transcode("LS", tempStr, 99);
        DOMImplementation *impl          = DOMImplementationRegistry::getDOMImplementation(tempStr);
        DOMWriter         *theSerializer = ((DOMImplementationLS*)impl)->createDOMWriter();

        if (theSerializer->canSetFeature(XMLUni::fgDOMWRTDiscardDefaultContent, gDiscardDefaultContent))
            theSerializer->setFeature(XMLUni::fgDOMWRTDiscardDefaultContent, gDiscardDefaultContent);

        if (theSerializer->canSetFeature(XMLUni::fgDOMWRTFormatPrettyPrint, gFormatPrettyPrint))
            theSerializer->setFeature(XMLUni::fgDOMWRTFormatPrettyPrint, gFormatPrettyPrint);

        if (theSerializer->canSetFeature(XMLUni::fgDOMWRTWhitespaceInElementContent, gDOMWRTWhitespaceInElementContent))
            theSerializer->setFeature(XMLUni::fgDOMWRTWhitespaceInElementContent, gDOMWRTWhitespaceInElementContent);


        XMLFormatTarget *myFormTarget;
        myFormTarget = new LocalFileFormatTarget(fileDiff.c_str());
        theSerializer->writeNode(myFormTarget, *docAfter);
    #ifdef _DEBUG
        myFormTarget = new StdOutFormatTarget();
        theSerializer->writeNode(myFormTarget, *docAfter);
    #endif

    }
    catch (DOMException e)
    {
        printf("\n[DOM ERROR] %d = %s\n", e.code, (char *)StrX(e.msg));
        status = e.code;
    }
    catch (DiffException e)
    {
        printf("\n[DIFF ERROR] %d\n", e.code);
        status = e.code;
    }

    delete parser;

    XMLPlatformUtils::Terminate();
    printf("\nDone.\n");

	return status;
}

