// linkupdt.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "linkupdt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif






#include <stdio.h>
#include <iostream.h>
//#include <windows.h>
#include <string.h>
#include <shlobj.h>
#include <objidl.h>

/*PARAMETERS
fname_to_create_link  = (e.g.) "c:\\mytextfile.txt"
lnk_fname = (e.g.) "yourname.lnk"
*/ 

void linkresolve(char * srcName, bool search)
{
	HRESULT hres;
	IShellLinkA *pSL = NULL;
	IPersistFile *pPF = NULL;
    WORD wsz1[256];
    WORD wsz2[256];
	CHAR buf[256];
	CString repl;

	// Initialize
	CoInitialize(NULL);
	// IShellLink Instance
	hres = CoCreateInstance(
			CLSID_ShellLink,
			NULL,
			CLSCTX_INPROC_SERVER,
			IID_IShellLink,
			(LPVOID*)&pSL
		 );
    if (FAILED(hres)) goto cleanup;
	
	// IPersistFile Instance
	hres = pSL->QueryInterface(IID_IPersistFile, (LPVOID*)&pPF);
	if(FAILED(hres)) goto cleanup;

	// Load the link file
	MultiByteToWideChar(CP_ACP, 0, srcName, -1, wsz1, MAX_PATH);
	hres = pPF->Load(wsz1, TRUE);
	if(FAILED(hres)) goto cleanup;

	// Resolve
	if (search)
	{
		 hres = pSL->Resolve(NULL, SLR_NO_UI || SLR_NOUPDATE);
	}
	else
	{
		 hres = pSL->Resolve(NULL, 0);
	}
	if (hres != 0) {cout << srcName << " : resolve error." << endl;}

cleanup:
	if(pPF) pPF->Release();
	if(pSL) pSL->Release();
	
} 

void main( int argc, char *argv[ ], char *envp[ ] )
{
  if ((argc != 2 ) || (argc != 3))
  {
	  printf ("linkresolve.exe <source lnk> [/nosearch]");
  }
  else if (argc == 2)
  {
	  linkresolve(argv[1],false);
  }
  else if (argc == 3)
  {
	  linkresolve(argv[1],true);
  }
}

/*



/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		CString strHello;
		strHello.LoadString(IDS_HELLO);
		cout << (LPCTSTR)strHello << endl;
	}

	return nRetCode;
}


*/