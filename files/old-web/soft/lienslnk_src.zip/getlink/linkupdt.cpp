// linkupdt.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "linkupdt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif






#include <stdio.h>
#include <iostream.h>
//#include <windows.h>
#include <string.h>
#include <shlobj.h>
#include <objidl.h>

/*PARAMETERS
fname_to_create_link  = (e.g.) "c:\\mytextfile.txt"
lnk_fname = (e.g.) "yourname.lnk"
*/ 

void getlink(char * srcName, bool all)
{
	HRESULT hres;
	IShellLinkA *pSL = NULL;
	IPersistFile *pPF = NULL;
    WORD wsz1[256];
    WORD wsz2[256];
	CHAR buf[256];
	CString repl;
	WORD hk;
	int i;

	// Initialize
	CoInitialize(NULL);
	// IShellLink Instance
	hres = CoCreateInstance(
			CLSID_ShellLink,
			NULL,
			CLSCTX_INPROC_SERVER,
			IID_IShellLink,
			(LPVOID*)&pSL
		 );
    if (FAILED(hres)) goto cleanup;
	
	// IPersistFile Instance
	hres = pSL->QueryInterface(IID_IPersistFile, (LPVOID*)&pPF);
	if(FAILED(hres)) goto cleanup;

	// Load the link file
	MultiByteToWideChar(CP_ACP, 0, srcName, -1, wsz1, MAX_PATH);
	hres = pPF->Load(wsz1, TRUE);
	if(FAILED(hres)) goto cleanup;

    // Print the path
	pSL->GetPath(buf, 255, NULL, 0); 
	if (all)
	{
		cout << "Path: " << buf << endl;
		pSL->GetWorkingDirectory(buf, 255); cout << "WorkingDirectory: " << buf << endl;
		pSL->GetArguments(buf, 255); cout << "Arguments: " << buf << endl;
		pSL->GetDescription(buf, 255); cout << "Description: " << buf << endl;
		pSL->GetHotkey(&hk); cout << "HotKey: " << hk << endl;
		pSL->GetIconLocation(buf, 255, &i); cout << "IconLocation: " << buf << "," << i << endl;
		pSL->GetShowCmd(&i); cout << "ShowCommand: " << i << endl;
	}
	else
	{ 
		cout << buf << endl;
	}



cleanup:
	if(pPF) pPF->Release();
	if(pSL) pSL->Release();
	
} 

void main( int argc, char *argv[ ], char *envp[ ] )
{
  if ((argc != 3) && (argc != 2))
  {
	  printf ("getlink.exe <source lnk> [/all]\n");
	  printf ("Displays the target file of the link.\n");
  }
  else if (argc == 2)
  {
	  getlink(argv[1],false);
  }
  else if (argc == 3)
  {
	  getlink(argv[1],true);
  }
}

/*



/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		CString strHello;
		strHello.LoadString(IDS_HELLO);
		cout << (LPCTSTR)strHello << endl;
	}

	return nRetCode;
}


*/