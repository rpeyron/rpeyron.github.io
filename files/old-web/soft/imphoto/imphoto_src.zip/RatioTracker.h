// RatioTracker.h: interface for the CRatioTracker class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RATIOTRACKER_H__51994107_6519_4B9B_B009_5A7C8175DEC8__INCLUDED_)
#define AFX_RATIOTRACKER_H__51994107_6519_4B9B_B009_5A7C8175DEC8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxext.h>

class CRatioTracker : public CRectTracker  
{
	CRect old_rect;
public:
	double ratio;
	CRect imgRect;
public:
	int maintainRatio;
	int allowFlip;
	int curHandle;
	void SaveRect();
	CRatioTracker();
	virtual void AdjustRect(int nHandle, LPRECT lpRect );
	virtual void OnChangedRect( const CRect& rectOld );
	virtual ~CRatioTracker();

};

#endif // !defined(AFX_RATIOTRACKER_H__51994107_6519_4B9B_B009_5A7C8175DEC8__INCLUDED_)
