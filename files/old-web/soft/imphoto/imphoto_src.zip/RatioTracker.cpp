// RatioTracker.cpp: implementation of the CRatioTracker class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "imdisplay.h"
#include "RatioTracker.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRatioTracker::CRatioTracker() : CRectTracker()
{
	// ratio = (double)4/3;
	// allowFlip = 1;
	imgRect.left  = imgRect.top    =	   0;
	imgRect.right = imgRect.bottom =  100000;
	old_rect.top = -1;
}

long rectDist(const CRect &rectA, const CRect &rectB)
{
	return (
			(rectA.top - rectB.top)*(rectA.top - rectB.top) +
			(rectA.bottom - rectB.bottom)*(rectA.bottom - rectB.bottom) +
			(rectA.left - rectB.left)*(rectA.left - rectB.left) +
			(rectA.right - rectB.right)*(rectA.right - rectB.right)
		);
}

void CRatioTracker::AdjustRect(int nHandle, LPRECT lpRect )
{
	long width, height, temp;
	const long INF = 10000000;


	// If no old_rect available, get this one.
	if (old_rect.top == -1) old_rect = *lpRect;
	
	// Adjust the current Rect to the image size.
	if (lpRect->left < imgRect.left) lpRect->left = imgRect.left;
	if (lpRect->top < imgRect.top) lpRect->top = imgRect.top;
	if (lpRect->right > imgRect.right) lpRect->right = imgRect.right;
	if (lpRect->bottom > imgRect.bottom) lpRect->bottom = imgRect.bottom;

	if (!maintainRatio) return;


	// Calculate the width (NB: This is a relative with : ie is it not always > 0)
	width = (lpRect->right - lpRect->left);
	height = (lpRect->bottom - lpRect->top);

	// Calculate the adjusted Rects (force expand in the direction mentionned)
	// - if allowFlip is set, the closest format is selected, between landscape and portrait
	CRect rectLeft = *lpRect;	rectLeft.left     = - (height * ratio) + rectLeft.right;
	CRect rectILeft = *lpRect;	rectILeft.left     = - (height / ratio) + rectILeft.right;
	if ((allowFlip) && (rectDist(*lpRect, rectILeft) < rectDist(*lpRect, rectLeft))) rectLeft = rectILeft;

	CRect rectRight = *lpRect;	rectRight.right   =   (height * ratio) + rectRight.left;
	CRect rectIRight = *lpRect;	rectIRight.right   =   (height / ratio) + rectIRight.left;
	if ((allowFlip) && (rectDist(*lpRect, rectIRight) < rectDist(*lpRect, rectRight))) rectRight = rectIRight;

	CRect rectTop = *lpRect;	rectTop.top       = - (width  / ratio) + rectTop.bottom;
	CRect rectITop = *lpRect;	rectITop.top       = - (width  * ratio) + rectITop.bottom;
	if ((allowFlip) && (rectDist(*lpRect, rectITop) < rectDist(*lpRect, rectTop))) rectTop = rectITop;

	CRect rectBottom = *lpRect; rectBottom.bottom =   (width  / ratio) + rectBottom.top;
	CRect rectIBottom = *lpRect; rectIBottom.bottom =   (width  * ratio) + rectIBottom.top;
	if ((allowFlip) && (rectDist(*lpRect, rectIBottom) < rectDist(*lpRect, rectBottom))) rectBottom = rectIBottom;

	// Calculate how distant from the original Rect the aboves ones are
	long dLeft = rectDist(*lpRect, rectLeft);
	long dRight = rectDist(*lpRect, rectRight);
	long dTop = rectDist(*lpRect, rectTop);
	long dBottom = rectDist(*lpRect, rectBottom);

	// Invalidate some Rect if it is out of bounds
	if (rectLeft.left < imgRect.left)		dLeft   = INF;
	if (rectTop.top < imgRect.top)			dTop    = INF;
	if (rectBottom.bottom > imgRect.bottom)	dBottom = INF;
	if (rectRight.right > imgRect.right)	dRight  = INF;

	// Do the whole test :
	// - test with the selected handle, and select the appropriate expand direction
	// - if this is a new rect (ie handle = -1), assume it is the BottomRight
	// - if the tracker is moved (ie middle), get the best Rect
	if (curHandle == hitRight)	*lpRect = rectBottom;
	else if (curHandle == hitLeft)	*lpRect = rectBottom;
	else if (curHandle == hitTop)	*lpRect = rectRight;
	else if (curHandle == hitBottom)	*lpRect = rectRight;
	else if ( (curHandle == hitBottomRight) || (curHandle == hitNothing) )
		if (dRight < dBottom) *lpRect = rectRight;
						 else *lpRect = rectBottom;
	else if (curHandle == hitBottomLeft) 
		if (dLeft < dBottom) *lpRect = rectLeft;
						 else *lpRect = rectBottom;
	else if (curHandle == hitTopRight) 
		if (dRight < dTop) *lpRect = rectRight;
				      else *lpRect = rectTop;
	else if (curHandle == hitTopLeft) 
		if (dLeft < dTop) *lpRect = rectLeft;
					 else *lpRect = rectTop;
	else if (curHandle == hitMiddle)
	{
		if ( (dLeft == 0) || ( (dLeft < dRight) && (dLeft < dTop) && (dLeft < dBottom) ) ) 		*lpRect = rectLeft;
		else if ( (dRight == 0) || ( (dRight < dLeft) && (dRight < dTop) && (dRight < dBottom) ) )	*lpRect = rectRight;
		else if ( (dTop == 0) || ( (dTop < dLeft) && (dTop < dRight) && (dTop < dBottom) ) )		*lpRect = rectTop;
		else if ( (dBottom == 0) || ( (dBottom < dLeft) && (dBottom < dRight) && (dBottom < dTop) ) )	*lpRect = rectBottom;
		else *lpRect = rectBottom;
	}

}

void CRatioTracker::OnChangedRect( const CRect& rectOld )
{

	// this->old_rect = rectOld;
}

CRatioTracker::~CRatioTracker()
{
	CRectTracker::~CRectTracker();
}


void CRatioTracker::SaveRect()
{
	this->old_rect = m_rect;
}
