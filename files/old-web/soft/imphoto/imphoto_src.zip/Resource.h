//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IMDisplay.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_IMDISPTYPE                  129
#define IDR_IMJPEGTYPE                  129
#define IDD_DIALOG_RESIZE               130
#define IDR_IMPNGTYPE                   131
#define IDD_DIALOG_ROTATE               131
#define IDR_IMTIFFTYPE                  132
#define IDD_DIALOG_SHEAR                132
#define IDR_IMBMPTYPE                   133
#define IDD_DIALOG_ROLL                 133
#define IDR_IMWMFTYPE                   134
#define IDR_IMMIFFTYPE                  135
#define IDR_IMSVGTYPE                   136
#define IDR_IMEPSTYPE                   137
#define IDD_DIALOG_INPUT                137
#define IDR_IMGIFTYPE                   138
#define IDC_WIDTH                       1001
#define IDC_HEIGHT                      1002
#define IDC_PERCENT                     1003
#define IDC_ROTATEANGLE                 1004
#define IDC_XSHEAR                      1005
#define IDC_YSHEAR                      1006
#define IDC_HPIXELS                     1007
#define IDC_VPIXELS                     1008
#define IDC_EDIT1                       1009
#define IDC_EDIT2                       1010
#define IDM_HALFSIZE                    32771
#define IDM_ORIGINALSIZE                32772
#define IDM_DOUBLESIZE                  32773
#define IDM_RESIZE                      32774
#define IDM_REVERT                      32775
#define ID_TRANSFORM_CROP               32776
#define ID_TRANSFORM_CHOP               32777
#define ID_TRANSFORM_FLIP               32778
#define ID_TRANSFORM_FLOP               32779
#define ID_TRANSFORM_ROTATERIGHT        32780
#define ID_TRANSFORM_ROTATELEFT         32781
#define ID_TRANSFORM_ROTATE             32782
#define ID_TRANSFORM_SHEAR              32783
#define ID_TRANSFORM_ROLL               32784
#define ID_TRANSFORM_TRIMEDGES          32785
#define ID_FLIP                         32786
#define ID_FIT_WINDOW                   32787
#define ID_RATIO_43                     32788
#define ID_LANDSCAPE                    32789
#define ID_PORTRAIT                     32790
#define ID_RATIO_23                     32791
#define ID_RATIO_CUSTOM                 32792
#define ID_RATIO_11                     32793
#define ID_RATIO_MAINTAIN               32794
#define ID_HELP_QUICK                   32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32797
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
