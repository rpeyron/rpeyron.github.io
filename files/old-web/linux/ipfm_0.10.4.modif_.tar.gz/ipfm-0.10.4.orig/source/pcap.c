/*
 *  pcap.c - interface to libpcap
 *
 *  Copyright (C) 1999 Robert Cheramy <tibob@via.ecp.fr>
 *  Copyright (C) 1999 Andres Krapf <dae@via.ecp.fr>
 *
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <pcap.h>

#ifdef __OS_LINUX__
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/if_ether.h>
#endif /* __OS_LINUX__ */

#include "pcap.h"
#include "init.h"
#include "utils.h"
#include "filter.h"
#include "data.h"

#define SNAPLEN 200

/* Global variable. This forbids to open 2 pcap descriptors. 
   Mettre un test de la valeur de offset. */
int     offset;
pcap_t  *pcap_global_descriptor = NULL;
int SigHup = 0;
extern struct AllLogsType * pAllLogs;

int iphdr_chksum(u_char *iphead, int size)
{
  unsigned long int sum = 0;
  int i;

  for (i = (size * 4) - 2; i > -1; i-=2) {
    sum += iphead[i] + 256 * iphead[i+1];
  }
  sum = (sum & 0xffff) + (sum >> 16);
  /* mmm I'm not sure the "(sum >> 16)" is usfull, but better be sure */
  sum += (sum >> 16) + 1;
  return (sum & 0xffff);
}


/*
 * Find a defaultpcap device
 */
char *pcap_default_device() {
  char errbuf[PCAP_ERRBUF_SIZE];
  char *tdev;

  tdev = pcap_lookupdev(errbuf);
  if (!tdev) { 
    fprintf(stderr, "[pcap] pcap_lookupdev error: %s\n", errbuf);
    exit(1);
  }
  return (tdev);
}


/*
** Ouvre un descripteur Pcap
** promisc = 0 pour pas de mode promisc, 1 pour ce mode.

*/
int openpcap(char *device, int promisc)
{
  char               errbuf[PCAP_ERRBUF_SIZE];
  int                datalink;
  
  if (pcap_global_descriptor != NULL) {
    printf("[pcap] I can't open two pcap descriptors\n");
    return 0 ;
  }

/* Under Linux, libpcap calls atexit to restore promisc mode after execution.
 * But it sets nopromisc mode after a child dies, ie at the first log output
 * This is why we set promisc mode ourselves under linux.
 */
#ifdef __OS_LINUX__
  if (promisc) {
    pcap_set_promisc(device);
  }
  pcap_global_descriptor = pcap_open_live(device, SNAPLEN, 0, 1000, errbuf);
#else
  pcap_global_descriptor = pcap_open_live(device, SNAPLEN, promisc, 1000, errbuf);
#endif /* __OS_LINUX__ */
  if (pcap_global_descriptor == NULL) {
    printf("[pcap] error opening pcap: %s\n", errbuf);
    return 0;
  }


  /* set the offset to the beginning of the iphdr */
  if ((datalink = pcap_datalink(pcap_global_descriptor)) <0) {
    printf("[pcap] error getting datalink info : %s\n",pcap_geterr(pcap_global_descriptor));
    return 0;
  }
  /*
    these offsets were taken from queso, written by 
    Jordi Murgo <savage@apostols.org>
    see http://apostols.org/projectz/queso/
  */
  switch(datalink) {
  case DLT_EN10MB:
    offset = 14; break;
  case DLT_NULL:
  case DLT_PPP:
    offset =  4; break;
  case DLT_SLIP:
    offset = 16; break;
#ifndef __OS_OPENBSD__
  case DLT_RAW:
    offset =  0; break;
  case DLT_SLIP_BSDOS:
  case DLT_PPP_BSDOS:
    offset = 24; break;
#endif /* __OS_OPENBSD__ */
  case DLT_ATM_RFC1483:
    offset =  8; break;
  case DLT_IEEE802:
    offset = 22; break;
  default:
    printf("[pcap] Unknown datalink type (%d)", datalink);
    return 0;
  }
  return 1;
}

void closepcap()
{
  if (pcap_global_descriptor == NULL ) {
	  fprintf(stderr, "[pcap] Can't close non-opened pcap descriptor\n");
  } else {
    pcap_close(pcap_global_descriptor);
#ifdef __OS_LINUX__
    pcap_restore_promisc();
#endif /* __OS_LINUX__ */
    pcap_global_descriptor = NULL;
  }
}

u_char *getnextippkt()
{
  struct pcap_pkthdr useless;
  u_char *           packet;

  if (pcap_global_descriptor == NULL ) {
	  fprintf(stderr, "[pcap] Can't read non-opened pcap descriptor");
  }

  for (;;) {
    packet = (u_char *) pcap_next(pcap_global_descriptor, &useless);
    if (NULL == packet) 
      continue;
    packet = packet + offset;

    if ( ((struct ip *) packet)->ip_hl < 5 || ((struct ip *) packet)->ip_v != 4 || iphdr_chksum(packet, ((struct ip *) packet)->ip_hl) != 0 ) {
      /* Not an IP packet */
      continue;
    }

    /* handle HUP signal */

    if (SigHup)
    {
      struct AllLogsType * pTempLog;
      for (pTempLog = pAllLogs; pTempLog; pTempLog = pTempLog->Next)
	data_flush(pTempLog);

      Clean();
      ReInit();
      SigHup = 0;
    }
    break;
  }
  return (packet);
}



#ifdef __OS_LINUX__

struct ifreq saved_ifr;

void pcap_set_promisc (char *device) {
  struct ifreq ifr;
  int fd;

  fd = socket(PF_INET, SOCK_PACKET, htons(ETH_P_ALL));
  if (fd < 0) {
    fprintf(stderr, "Error oppening RAW linux socket\n");
    exit(0);
  }

  memset(&ifr, 0, sizeof(struct ifreq));
  strcpy(ifr.ifr_name, device);
  if (ioctl(fd, SIOCGIFFLAGS, &ifr) < 0 ) {
    fprintf(stderr, "Can't get IOCTL flags\n");
    exit(0);
  }

  memcpy(&saved_ifr, &ifr, sizeof(struct ifreq));

  ifr.ifr_flags |= IFF_PROMISC;
  if (ioctl(fd, SIOCSIFFLAGS, &ifr) < 0 ) {
    fprintf(stderr, "Can't set promiscuous mode\n");
    exit(0);
  }
}


void pcap_restore_promisc(void) {
	int fd;

	fd = socket(PF_INET, SOCK_PACKET, htons(ETH_P_ALL));
	if (fd < 0)
		fprintf(stderr, "Could not remove promiscuous mode\n");
	else if (ioctl(fd, SIOCSIFFLAGS, &saved_ifr) < 0)
		fprintf(stderr, "Could not remove promiscuous mode\n");
}


#endif /* __OS_LINUX__ */
