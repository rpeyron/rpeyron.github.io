/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef LLIST_H
#define LLIST_H

#include <gtk/gtk.h>

// Error functions
#define gu_error g_error
#define gu_message g_message

// Print functions
#define gu_print g_print
#define gu_snprintf g_snprintf

// Allocation functions
#define gu_malloc g_malloc
#define gu_free g_free

// Doubly-linked list functions
#define gu_list_append g_list_append
#define gu_list_prepend g_list_prepend
#define gu_list_insert g_list_insert
#define gu_list_remove g_list_remove
#define gu_list_free g_list_free
#define gu_list_length g_list_length
#define gu_list_foreach g_list_foreach
#define gu_list_nth g_list_nth
#define gu_list_find g_list_find
#define gu_list_find_custom g_list_find_custom
#define gu_list_reverse g_list_reverse

// General functions
#define gu_get_home_dir g_get_home_dir
#define gu_dirname g_dirname
#define gu_get_tmp_dir g_get_tmp_dir

// String functions
#define gu_strconcat g_strconcat

#endif

