/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __WIN32__
#include <windows.h>
#endif

#include "indep.h"

/***************************************/
/* Some tilink variables and functions */
/***************************************/
#define DFLT_TIMEOUT 20
#define DFLT_DELAY 10

/* A structure of functions to drive a link cable */
struct link_cable link_cable;
/* A structure of functions to drive a calculator */
struct ti_calc ti_calc;
/* A structure of functions to do the refresh of GTK boxes */
struct info_update info_update;

struct goptions options = 
{ 
  300, 400, 
  SORT_BY_NAME, SORT_DOWN, 
  SORT_BY_NAME, SORT_DOWN, 
  CONFIRM_YES, 
  FULL_PATH, HIDE, 
  EXTENDED_FORMAT, 
  NO_SERVER,
  NO_TIDEV,
  PLUGINS_AUTO,
  PCX,
  CLIPPED_SCREEN,
  { CALC_TI92, LINK_TGL, LPT2, TTY1, DFLT_TIMEOUT, DFLT_DELAY, FALSE }
};

int is_active = 0; // Set if a transfer is active

/*
  This function must be the first function to call in your function 'main'.
  It inits some variables and eventually, loads plugins.
*/
int main_init(int argc, char *argv[], char **arge)
{
  int err;
#ifdef __WIN32__
  HMODULE hModule;
  DWORD dWord;
  char sBuffer[4*MAXCHARS];
  char *dirname;
#endif

#ifndef __WIN32__
  textdomain("gtktilink");
#endif

  /* 
     Init the path for the Windows version 
  */
#ifdef __WIN32__
  // Retrieve the directory of the executable */
  hModule = GetModuleHandle("GtkTiLink.exe");
  dWord = GetModuleFileName(hModule, sBuffer, 4*MAXCHARS);
  dirname = gu_dirname(sBuffer);
  //printf("Current path: <%s>\n", dirname);
  strcpy(clist_win.win_dir, dirname);
  gu_free(dirname);
#else
  strcpy(clist_win.win_dir, "");
#endif

  /* 
     Do some initializations and load config 
  */
  // Display program version
  version();
  //gtk_init(&argc, &argv);
  // Init the refresh functions (label, pbar)
  init_refresh_functions();
  // Parse the config file
  read_rc_file();
  // Scan the command line
  scan_cmdline(argc, argv);
  // Init the libTIcable
  if( (err=link_cable.init_port(options.lp.io_addr, options.lp.device)) ) error(err);

  /* 
     List and load plugins 
  */
  if(options.plugins_loading == PLUGINS_AUTO)
    {
      //plugin_directory_list();
      //plugin_getinfo_list();
    } 
  
  return 0;
}

/*
  Display a short help
*/
int help(void)
{

  fprintf(stdout, "\n");
  fprintf(stdout, "GtkTiLink %s, (C) Romain Lievin 1999-2000\n", VERSION);
  fprintf(stdout, "THIS PROGRAM COMES WITH ABSOLUTELY NO WARRANTY\n");
  fprintf(stdout, "PLEASE READ THE DOCUMENTATION FOR DETAILS\n");
  fprintf(stdout, "usage: gtktilink [options]\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "-h, --help    display this information page and exit\n");
  fprintf(stdout, "-v, --version display the version information and exit\n");
  fprintf(stdout, "-calc=...     give the calculator type\n");
  fprintf(stdout, "-link=...     give the link cable type\n");
  fprintf(stdout, "-dev_port=... give the device port (TI Graph Link cable only)\n");
  fprintf(stdout, "-adr_port=... give the address of the port (parallel or serial link cable only)\n");
  fprintf(stdout, "-t=...        give the time out in seconds\n");
  fprintf(stdout, "-d=...        give the delay in microseconds\n");
  fprintf(stdout, "\n");

  exit(0);
  return 0;
}

/*
  Display the program version
*/
int version(void)
{
  fprintf(stdout, "GtkTiLink - %s, (C) Romain Lievin 1999-2000\n", VERSION);
  fprintf(stdout, "THIS PROGRAM COMES WITH ABSOLUTELY NO WARRANTY\n");
  fprintf(stdout, "PLEASE READ THE DOCUMENTATION FOR DETAILS\n");

  return 0;
}

static inline int strexact(char *p1, char *p2)
{
  return (strstr(p1,p2) && strstr(p2,p1));
}

/*
  Scan the command line, extract arguments and init variables
*/
int scan_cmdline(int argc, char **argv)
{
  int cnt;
  char *p;
  char *q;
  char msg[80];

  for(cnt=1; cnt<argc; cnt++)
    {
      p=argv[cnt];
      if(*p=='-' ) p++;
      strcpy(msg, p);

      if(strstr  (msg, "calc="     ))
	{
	  q=msg+5;
	  if(!strcmp(q, "ti92+")) options.lp.calc_type=CALC_TI92P;
	  if(!strcmp(q, "ti92"))  options.lp.calc_type=CALC_TI92;
	  if(!strcmp(q, "ti89"))  options.lp.calc_type=CALC_TI89;
	  if(!strcmp(q, "ti86"))  options.lp.calc_type=CALC_TI86;
	  if(!strcmp(q, "ti85"))  options.lp.calc_type=CALC_TI85;
	  if(!strcmp(q, "ti83+")) options.lp.calc_type=CALC_TI83P;
	  if(!strcmp(q, "ti83"))  options.lp.calc_type=CALC_TI83;
	  if(!strcmp(q, "ti82"))  options.lp.calc_type=CALC_TI82;
	}
      if(strstr  (msg, "link="     )) 
	{
	  q=msg+5;
	  if(!strcmp(q, "par")) options.lp.link_type=LINK_PAR;
	  if(!strcmp(q, "ser")) options.lp.link_type=LINK_SER;
	  if(!strcmp(q, "tig")) options.lp.link_type=LINK_TGL;
	}
      if(strstr  (msg, "dev_port=" )) strcpy(options.lp.device, msg+9);
      if(strstr  (msg, "adr_port=" )) options.lp.io_addr = (int) strtol(msg+9, &q, 16);
      if(strstr  (msg, "timeout="  )) options.lp.timeout = (int) atol(&msg[8]);
      if(strstr  (msg, "delay="    )) options.lp.delay = (int) atol(&msg[6]);
      if(strexact(msg, "h"         )) help();      
      if(strexact(msg, "-help"     )) help();
      if(strexact(msg, "v"         )) { version(); exit(0); }
      if(strexact(msg, "-version"  )) { version(); exit(0); }
    }
  /*
  printf("Command line:\n");
  printf("Calc: %i\n", options.lp.calc_type);
  printf("Link: %i\n", options.lp.link_type);
  printf("Adr_port: %03X\n", options.lp.io_addr);
  printf("Dev_port: %s\n", options.lp.device);
  printf("Delay: %i\n", options.lp.delay);
  printf("Timeout: %i\n", options.lp.timeout);
  */
  setup_link_and_calc(options.server);

  return 0;
}
