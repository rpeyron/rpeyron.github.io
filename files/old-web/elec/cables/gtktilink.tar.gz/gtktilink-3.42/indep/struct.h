/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef STRUCT_H
#define STRUCT_H

#include <gtk/gtk.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#ifndef __WIN32__
  #include <unistd.h>
  #include <ti/cable_interface.h>
  #include <ti/calc_defs.h>
  #include <ti/calc_interface.h>
#else
  #include "unistd.h"
  #include "cables/cable_interface.h"
  #include "calcs/calc_defs.h"
  #include "calcs/calc_interface.h"
#endif

extern struct link_cable link_cable;
extern struct ti_calc ti_calc;
extern struct info_update info_update;

/* Used by the local directory list function */
struct file_info
{
  char *filename;
  time_t date;
  off_t size;
  uid_t user;
  gid_t group;
  mode_t attrib;
};

/* Used for the directory list of plugins */
struct plugin_info
{
  char *name;
  char *var_type;
  char *calc_type;
};

// Temporaire ...
#ifndef GTK
#define GtkWidget void 
#endif

/* This struct is used by the CList window */
extern struct clist_window
{
  GtkWidget *widget;
  GList *dirlist;
  char cur_dir[4*MAXCHARS];
  GList *selection;
  GList *file_selection;
  gint copy_cut;
  char win_dir[4*MAXCHARS];
} clist_win;

/* This struct is used by the CTree window */
extern struct ctree_window
{
  GtkWidget *widget;
  GList *varlist;
  char cur_folder[9];
  GList *selection;
} ctree_win;

/* This struct contains the general options to configure the program */
extern struct goptions
{
  int xsize;
  int ysize;
  int clist_sort;
  int clist_sort_order;
  int ctree_sort;
  int ctree_sort_order;
  int confirm;
  int path_mode;
  int show;
  int file_mode;
  int server; //used for tidev but obsolete...
  int tidev;
  int plugins_loading;
  int screen_format;
  int screen_clipping;

  struct link_param lp;
} options;

/* Not used yet */
struct file_char
{
  char *filename;	// Name of the file
  char *name;		// Name of the file without extension
  char *extension;	// and its extension
  gint file_type;	// Type: GtkTiLink or TIGL
  gint calc_type;	// Type: calculator (82, 83, ...)
  gint nvars;		// Numbers of variables if group or PAK file
  // These fields are defined only if not a PAK or group file
  char local_varname[9];	// Name of the var (local path)
  char full_varname[18];	// Name of the var (full path)
  char parent_folder[9];	// Parent folder of the var
  char vartype[9];			// Type of the var
  byte varlocked;			// Var is locked/archived ?
  longword varsize;			// Size of the var
};

/* Used by the screendump related boxes */
struct screenshot
{
  char **pixmap;
  byte *bitmap;
  struct screen_coord sc;
};

#endif
