/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <malloc.h>
#include <string.h>

#include "indep.h"

struct screenshot ti_screen = { NULL, NULL, {0, 0, 0, 0} };

/*
  Do a screen capture
*/
int cb_screen_capture(void)
{
  int err;
  //clock_t start, stop; // for benchmark test

  if(is_active) 
    return -1;
  
  /* Place a progress bar */
  create_pbar_type1(gettext("Screendump"));
  refresh_gui();

  /* Get a screen capture */
  /*
  if(ti_screen.bitmap != NULL)
    {
      free(ti_screen.bitmap);
      ti_screen.bitmap = NULL;
    }
	*/

  //start=clock();
  err = ti_calc.screendump(&(ti_screen.bitmap), options.screen_clipping, &(ti_screen.sc));
  //stop=clock();
  //fprintf(stdout, "Time: %u %f\n", stop-start, (float)(stop-start)/CLOCKS_PER_SEC);

  destroy_pbar_type1();
  if(error(err)) 
    {
	  /*
	  if(ti_screen.bitmap != NULL)
	  {
      free(ti_screen.bitmap);
      ti_screen.bitmap = NULL;
	  }
	  */
      return 1;
    }

  return 0;
}

/*
  Save the current screen capture the right format according to
  the current GtkTiLink options.
  Returns 0 if successful
*/
int cb_screen_save(char *filename)
{
  FILE *image;
  int i;

  if((image=fopen(filename, "wt")) == NULL)
    {
      gu_error(gettext("Unable to open this file: %s\n"), filename);
    }
  
  switch(options.screen_format)
    {
    case XPM:
      fprintf(image, "/* XPM */\n");
      fprintf(image, "static char * screen_xpm[] = {\n");
      fprintf(image, "\"%s\"", (ti_screen.pixmap)[0]);
      
      /*
      if (options.lp.calc_type == CALC_TI89) 
	for(i=1; ((ti_screen.pixmap)[i]!=NULL) && (i<TI89_ROWS_VISIBLE+4); i++)
	  {
	    strncpy(ti89row, (ti_screen.pixmap)[i], (size_t) TI89_COLS_VISIBLE);
	    ti89row[TI89_COLS_VISIBLE] = '\0';
	    fprintf(image, ",\n\"%s\"", ti89row);
	  }
      else
      */
      for(i=1; (ti_screen.pixmap)[i]!=NULL; i++)
	{
	  fprintf(image, ",\n\"%s\"", (ti_screen.pixmap)[i]);
	}
      fprintf(image, "};");
      break;
    case PCX:
      if(options.screen_clipping == FULL_SCREEN)
	write_pcx_compressed(image, ti_screen.bitmap, 
			     ti_screen.sc.width, 
			     ti_screen.sc.height);
      else
	write_pcx_compressed(image, ti_screen.bitmap, 
			     ti_screen.sc.clipped_width, 
			     ti_screen.sc.clipped_height);
      break;
    }
  fclose(image);
  
  return 0;
}
