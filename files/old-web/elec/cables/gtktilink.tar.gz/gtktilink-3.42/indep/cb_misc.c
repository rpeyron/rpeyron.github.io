/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <string.h>

#include "indep.h"

/*
  Save the configuration file
*/
int cb_save_config_file(void)
{
  write_rc_file();
  msg_box(gettext("Information"), 
	  gettext("Configuration file saved."));

  return 0;
}

/*
  Load the configuration file
*/
int cb_load_config_file(void)
{
  read_rc_file();
  msg_box(gettext("Information"), 
	  gettext("Configuration file saved."));

  return 0;
}

int cb_default_config(void)
{
  return 0;
}

/*
  Try to detect the calculator type and display the result
*/
int cb_probe_calc(void)
{
  int type;
  char text[MAXCHARS];
  
  strcpy(text, gettext("Calculator detected: "));
  
  if(error(detect_calc(&type)))
    {
      strcpy(text, gettext("No calculator found. Check your port and/or cable"));
    }
  else
    {
      printf("Type: %i\n", type);
      switch(type)
	{
	case CALC_TI92P:
	  strcat(text, "TI92+");
	  break;
	case CALC_TI92:
	  strcat(text, "TI92");
	  break;
	case CALC_TI89:
	  strcat(text, "TI89");
	  break;
	case CALC_TI86:
	  strcat(text, "TI86");
	  break;
	case CALC_TI85:
	  strcat(text, "TI85");
	  break;
	case CALC_TI83P:
	  strcat(text, "TI83+");
	  break;
	case CALC_TI83:
	  strcat(text, "TI83");
	  break;
	case CALC_TI82:
	  strcat(text, "TI82");
	  break;
	default:
	  strcpy(text, gettext("No calculator found. Check your port and/or cable"));
	  break;
	}
    }
  msg_box(gettext("Probe results"), text);
  
  return 0;
}

int cb_probe_cable(void)
{
  msg_box(gettext("Information"),
	  gettext("This function is not yet available."));
  
  return 0;
}

int cb_probe_port(void)
{
  msg_box(gettext("Information"),
	  gettext("This function is not yet available."));

  return 0;
}
