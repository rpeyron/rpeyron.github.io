/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef MACROS_H
#define MACROS_H

#define MAXCHARS 256

/* Some macros */
/* These macros are badly defined and obsolete */
#define LSW(w) (unsigned char)((w) & 0x00FF)
#define MSW(w) (unsigned char)(((w) & 0xFF00) >> 8)
#define LSB(b) ((b) & 0x0F)
#define MSB(b) (((b) & 0xF0) >> 4)

#define LSW_(l) (unsigned int) ((l) & 0x0000FFFF)
#define MSW_(l) (unsigned int)(((l) & 0xFFFF0000) >> 16)
#define LSB_(w) (unsigned char) ((w) & 0x00FF)
#define MSB_(w) (unsigned char)(((w) & 0xFF00) >> 8)
#define LSN_(b)  ((b) & 0x0F)
#define MSN_(b) (((b) & 0xF0) >> 4)

#endif




