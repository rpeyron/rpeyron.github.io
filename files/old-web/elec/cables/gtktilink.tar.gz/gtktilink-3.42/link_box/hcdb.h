/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef HCDB_H
#define HCDB_H

//#define NO_CALC

#ifndef __WIN32__
#include <ti/cable_defs.h>
#ifndef NO_CALC
#include <ti/calc_defs.h>
#endif
#else
#include "../../ti_libs/cables/cable_interface.h"
#include "../../ti_libs/calcs/calc_interface.h"
#endif

/* A constant */
#define USE_TIDEV 1

/* 
   This struct contains the general options once the dialog box
   has been validated (a.k.a. the 'OK' button has been pressed).
*/
/* No longer used */
/*
struct hcdb_param
{
  gint calc_type;
  gint link_type;
  unsigned int io_addr;
  char device[16];
  gint timeout;
  gint delay;
  gint tidev;
};
*/

//extern struct hcdb_param result;
extern struct link_param result;

/*
  Contains temporary variables for storing choices
  and the widget to manipulate
*/
struct hcdb
{
  gint calc_type;
  gint link_type;
  unsigned int io_addr;
  char device[16];  
  gint tidev;

  gint blocking;

  GtkWidget *dialog;
  GtkWidget *label21;
  GtkWidget *label22;
  GtkWidget *label23;
  GtkWidget *label24;
  GtkWidget *label25;
  GtkWidget *radiobutton21;
  GtkWidget *radiobutton22;
  GtkWidget *radiobutton23;
  GtkWidget *radiobutton24;
  GtkWidget *radiobutton25;
  GtkWidget *io_entry;
};

#endif



