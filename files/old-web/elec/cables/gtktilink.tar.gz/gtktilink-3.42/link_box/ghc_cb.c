/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>

#include "hcdb.h"
#include "ghc_dbox.h"


/*****************************************************/
/* Callbacks called for the hardware&calc dialog box */
/*****************************************************/
/* Parallel cable */
void
hcdb_radiobutton11_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->link_type = LINK_PAR;
  h->io_addr = LPT2;
  
  refresh_hcdb_frame(h);
}

/* Serial cable */
void
hcdb_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->link_type = LINK_SER;
  h->io_addr = COM1;

  refresh_hcdb_frame(h);
}

/* TIGL cable */
void
hcdb_radiobutton13_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->link_type = LINK_TGL;
  h->io_addr = COM1;

  refresh_hcdb_frame(h);
}


/* AVRlink cable */
void
hcdb_radiobutton14_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->link_type = LINK_AVR;
  h->io_addr = COM1;

  refresh_hcdb_frame(h);
}

/* Virtual cable */
void
hcdb_radiobutton15_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->link_type = LINK_VTL;
  h->io_addr = VLINK1;

  refresh_hcdb_frame(h);
}

/* Use tidev */
void
hcdb_checkbutton_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb     *h)
{
  h->tidev = !(h->tidev);
  refresh_hcdb_frame(h);
}

/* I/O ports below */
void
hcdb_radiobutton21_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  gtk_entry_set_visibility(GTK_ENTRY(h->io_entry), FALSE);
  gtk_entry_set_editable(GTK_ENTRY(h->io_entry), FALSE);

  if(h->tidev != USE_TIDEV)
    {
      switch(h->link_type)
	{
	case LINK_PAR:
	  h->io_addr = LPT3;
	  break;
	case LINK_SER:
	  h->io_addr = COM1;
	  break;
	case LINK_AVR:
	case LINK_TGL:
	  strcpy(h->device, TTY0);
	  break;
	case LINK_VTL:
	  h->io_addr = VLINK0;
	  break;
	}
    }
  else
    {
      switch(h->link_type)
	{
	case LINK_PAR:
	  strcpy(h->device, TIDEV_P0);
	  break;
	case LINK_SER:
	  strcpy(h->device, TIDEV_S0);
	  break;
	case LINK_VTL:
	  strcpy(h->device, TIDEV_V0);
	  break;
	}
    }
}


void
hcdb_radiobutton22_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  gtk_entry_set_visibility(GTK_ENTRY(h->io_entry), FALSE);
  gtk_entry_set_editable(GTK_ENTRY(h->io_entry), FALSE);

  if(h->tidev != USE_TIDEV)
    {
      switch(h->link_type)
	{
	case LINK_PAR:
	  h->io_addr = LPT1;
	  break;
	case LINK_SER:
	  h->io_addr = COM2;
	  break;
	case LINK_AVR:
	case LINK_TGL:
	  strcpy(h->device, TTY1);
	  break;
	case LINK_VTL:
	  h->io_addr = VLINK1;
	  break;
	}
    }
  else
    {
      switch(h->link_type)
	{
	case LINK_PAR:
	  strcpy(h->device, TIDEV_P1);
	  break;
	case LINK_SER:
	  strcpy(h->device, TIDEV_S1);
	  break;
	case LINK_VTL:
	  strcpy(h->device, TIDEV_V1);
	  break;
	}
    }
}


void
hcdb_radiobutton23_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  gtk_entry_set_visibility(GTK_ENTRY(h->io_entry), FALSE);
  gtk_entry_set_editable(GTK_ENTRY(h->io_entry), FALSE);
  
  if(h->tidev != USE_TIDEV)
    {
      switch(h->link_type)
	{
	case LINK_PAR:
	  h->io_addr = LPT2;
	  break;
	case LINK_SER:
	  h->io_addr = COM3;
      break;
	case LINK_AVR:
	case LINK_TGL:
	  strcpy(h->device, TTY2);
	  break;
	case LINK_VTL:
	  break;
	}
    }
  else
    {
      switch(h->link_type)
	{
	case LINK_PAR:
	  strcpy(h->device, TIDEV_P2);
	  break;
	case LINK_SER:
	  strcpy(h->device, TIDEV_S2);
	  break;
	}
    }
}


void
hcdb_radiobutton24_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  gtk_entry_set_visibility(GTK_ENTRY(h->io_entry), FALSE);
  gtk_entry_set_editable(GTK_ENTRY(h->io_entry), FALSE);

  if(h->tidev != USE_TIDEV)
    {
      switch(h->link_type)
	{
	case LINK_PAR:
	  break;
	case LINK_SER:
	  h->io_addr = COM4;
	  break;
	case LINK_AVR:
	case LINK_TGL:
	  strcpy(h->device, TTY3);
	  break;
	case LINK_VTL:
	  break;
	}
    }
  else
    {
      switch(h->link_type)
	{
	case LINK_SER:
	  strcpy(h->device, TIDEV_S3);
	  break;
	}
    }
}


void
hcdb_radiobutton25_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  char buffer[MAXCHARS];

  if(h->tidev != USE_TIDEV)
    {
      gtk_entry_set_visibility(GTK_ENTRY(h->io_entry), TRUE);
      gtk_entry_set_editable(GTK_ENTRY(h->io_entry), TRUE);
      sprintf(buffer, "0x%03X", h->io_addr);
      gtk_entry_set_text(GTK_ENTRY(h->io_entry), buffer);
    }
}

#ifndef NO_CALC
/* Calc type below */
void
hcdb_radiobutton31_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->calc_type = CALC_TI92P;
}


void
hcdb_radiobutton32_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->calc_type = CALC_TI92;
}


void
hcdb_radiobutton33_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->calc_type = CALC_TI89;
}


void
hcdb_radiobutton34_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->calc_type = CALC_TI86;
}


void
hcdb_radiobutton35_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->calc_type = CALC_TI85;
}


void
hcdb_radiobutton36_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->calc_type = CALC_TI83P;
}


void
hcdb_radiobutton37_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->calc_type = CALC_TI83;
}


void
hcdb_radiobutton38_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h)
{
  h->calc_type = CALC_TI82;
}
#endif

/*****************************************************/
/* Callbacks called for the hardware&calc dialog box */
/*****************************************************/
void
io_entry_activate                      (GtkEditable     *editable,
                                        struct hcdb         *h)
{
  char *s;
  
  s=gtk_editable_get_chars(editable, 0, 5);
  if(!sscanf(s, "0x%03X", &(h->io_addr)))
    h->io_addr=LPT1;

  g_free(s);
}

void
io_entry_changed                       (GtkEditable     *editable,
                                        struct hcdb         *h)
{
  char *s;
  
  s=gtk_editable_get_chars(editable, 0, 5);
  if(!sscanf(s, "0x%03X", &(h->io_addr)))
    h->io_addr=LPT1;
  
  g_free(s);
}

/*********************************************************/
/* Hardware&calc dialog box: ok, cancel and help buttons */
/*********************************************************/
void
setup_config_ok                        (GtkButton       *button,
                                        struct hcdb         *h)
{
  /* Free some ressources */
  gtk_widget_destroy(h->dialog);
  h->blocking = 1;

  /* Display some debug informations */
/*
  printf("222\n");
  printf("calc_type: %i\n", h->calc_type);
  printf("link_type: %i\n", h->link_type);
  printf("io_addr: %03X\n", h->io_addr);
  printf("device: %s\n", h->device);
  printf("tidev: %s\n", h->tidev ? "yes" : "no"); 
*/
}


void
setup_config_cancel                    (GtkButton       *button,
                                        struct hcdb     *h)
{
  gtk_widget_destroy(h->dialog);
  h->blocking = 2;
}


void
setup_config_help                      (GtkButton       *button,
                                        struct hcdb     *h)
{

}


