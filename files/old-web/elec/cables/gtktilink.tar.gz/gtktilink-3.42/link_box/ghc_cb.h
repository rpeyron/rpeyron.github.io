/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef GHCCB_H
#define GHCCB_H

#include <gtk/gtk.h>

#include "hcdb.h"

/*****************************************************/
/* Callbacks called for the hardware&calc dialog box */
/*****************************************************/
void
hcdb_radiobutton11_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton13_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton14_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton15_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_checkbutton_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton21_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton22_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton23_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton24_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton25_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton31_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton32_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton33_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton34_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton35_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton36_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton37_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);
void
hcdb_radiobutton38_toggled               (GtkToggleButton *togglebutton,
                                        struct hcdb         *h);

/*****************************************************/
/* Callbacks called for the hardware&calc dialog box */
/*****************************************************/
void
io_entry_activate                      (GtkEditable     *editable,
                                        struct hcdb         *h);
void
io_entry_changed                       (GtkEditable     *editable,
                                        struct hcdb         *h);

/*********************************************************/
/* Hardware&calc dialog box: ok, cancel and help buttons */
/*********************************************************/
void setup_config_ok(GtkButton *button, struct hcdb *h);
void setup_config_cancel(GtkButton *button, struct hcdb *h);
void setup_config_help(GtkButton *button, struct hcdb *h);

#endif
