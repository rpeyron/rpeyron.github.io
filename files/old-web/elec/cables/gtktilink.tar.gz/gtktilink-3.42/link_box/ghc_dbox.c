/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <stdio.h>
#include <strings.h>

#include "hcdb.h"
#include "ghc_cb.h"

#define gettext(x) (x)

/****************************/
/* Hardware&calc dialog box */
/****************************/
/* This function is used to redraw a part of the hardware&calc dialog box */
void refresh_hcdb_frame(struct hcdb *hh)
{
  gtk_widget_show(hh->radiobutton21);
  gtk_widget_show(hh->radiobutton22);
  gtk_widget_show(hh->radiobutton23);
  gtk_widget_show(hh->radiobutton24);
  gtk_widget_show(hh->radiobutton25);


  if(hh->tidev != USE_TIDEV)
    {
      switch(hh->link_type)
	{
	case LINK_PAR:
	  gtk_label_set_text(GTK_LABEL(hh->label21), "0x3BC (LPT3)");
	  gtk_label_set_text(GTK_LABEL(hh->label22), "0x378 (LPT1)");
	  gtk_label_set_text(GTK_LABEL(hh->label23), "0x278 (LPT2)");
	  gtk_widget_hide(hh->radiobutton24);
	  gtk_label_set_text(GTK_LABEL(hh->label25), gettext("custom"));
	  
	  if(hh->io_addr == LPT3)
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton21), TRUE);
	  else if(hh->io_addr == LPT1)
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton22), TRUE);
	  else if(hh->io_addr == LPT2)
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton23), TRUE);
	  else
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton25), TRUE);

	  break;
	case LINK_SER:
	  gtk_label_set_text(GTK_LABEL(hh->label21), "0x3F8 (COM1)");
	  gtk_label_set_text(GTK_LABEL(hh->label22), "0x2F8 (COM2)");
	  gtk_label_set_text(GTK_LABEL(hh->label23), "0x3E8 (COM3)");
	  gtk_label_set_text(GTK_LABEL(hh->label24), "0x2E8 (COM4)");
	  gtk_label_set_text(GTK_LABEL(hh->label25), gettext("custom"));
	  
	  if(hh->io_addr == COM1)
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton21), TRUE);
	  else if(hh->io_addr == COM2)
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton22), TRUE);
	  else if(hh->io_addr == COM3)
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton23), TRUE);
	  else if(hh->io_addr == COM4)
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton24), TRUE);
	  else
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton25), TRUE);

	  break;
	case LINK_AVR:
	case LINK_TGL:
	  gtk_label_set_text(GTK_LABEL(hh->label21), TTY0);
	  gtk_label_set_text(GTK_LABEL(hh->label22), TTY1);
	  gtk_label_set_text(GTK_LABEL(hh->label23), TTY2);
	  gtk_label_set_text(GTK_LABEL(hh->label24), TTY3);
	  gtk_widget_hide(hh->radiobutton25);
	  
	  if(!strcmp(hh->device, TTY0))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton21), TRUE);
	  else if(!strcmp(hh->device, TTY1))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton22), TRUE);
	  else if(!strcmp(hh->device, TTY2))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton23), TRUE);
	  else if(!strcmp(hh->device, TTY3))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton24), TRUE);

	  break;
	case LINK_VTL:
	  gtk_label_set_text(GTK_LABEL(hh->label21), "#0");
	  gtk_label_set_text(GTK_LABEL(hh->label22), "#1");
	  gtk_widget_hide(hh->radiobutton23);
	  gtk_widget_hide(hh->radiobutton24);
	  gtk_widget_hide(hh->radiobutton25);
	  
	  if(hh->io_addr == VLINK0)
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton21), TRUE);
	  else
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton22), TRUE);
	  
	  break;
	}
    }
  else
    {
      switch(hh->link_type)
	{
	case LINK_PAR:
	  gtk_label_set_text(GTK_LABEL(hh->label21), TIDEV_P0);
	  gtk_label_set_text(GTK_LABEL(hh->label22), TIDEV_P1);
	  gtk_label_set_text(GTK_LABEL(hh->label23), TIDEV_P2);
	  gtk_widget_hide(hh->radiobutton24);
	  gtk_widget_hide(hh->radiobutton25);

	  if(!strcmp(hh->device, TIDEV_P0))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton21), TRUE);
	  else if(!strcmp(hh->device, TIDEV_P1))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton22), TRUE);
	  else if(!strcmp(hh->device, TIDEV_P2))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton23), TRUE);

	  break;
	case LINK_SER:
	  gtk_label_set_text(GTK_LABEL(hh->label21), TIDEV_S0);
	  gtk_label_set_text(GTK_LABEL(hh->label22), TIDEV_S1);
	  gtk_label_set_text(GTK_LABEL(hh->label23), TIDEV_S2);
	  gtk_label_set_text(GTK_LABEL(hh->label24), TIDEV_S3);
	  gtk_widget_hide(hh->radiobutton25);
	  
	  if(!strcmp(hh->device, TIDEV_S0))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton21), TRUE);
	  else if(!strcmp(hh->device, TIDEV_S1))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton22), TRUE);
	  else if(!strcmp(hh->device, TIDEV_S2))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton23), TRUE);
	  else if(!strcmp(hh->device, TIDEV_S3))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton23), TRUE);

	  break;
	case LINK_AVR:
	case LINK_TGL:
	  gtk_widget_hide(hh->radiobutton21);
	  gtk_widget_hide(hh->radiobutton22);
	  gtk_widget_hide(hh->radiobutton23);
	  gtk_widget_hide(hh->radiobutton24);
	  gtk_widget_hide(hh->radiobutton25);
	  
	  break;
	case LINK_VTL:	
	  gtk_label_set_text(GTK_LABEL(hh->label21), "#0");
	  gtk_label_set_text(GTK_LABEL(hh->label22), "#1");
	  gtk_widget_hide(hh->radiobutton23);
	  gtk_widget_hide(hh->radiobutton24);
	  gtk_widget_hide(hh->radiobutton25);
	  
	  if(!strcmp(hh->device, TIDEV_V0))
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton21), TRUE);
	  else
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hh->radiobutton22), TRUE);
	  
	  break;
	}
    }
}

struct hcdb hc;
static struct hcdb *h = &hc;

int dlgbox_setup_port_calc(struct link_param *param)
{
  //GtkWidget *dialog;
  GtkWidget *dialog_vbox1;
  GtkWidget *hbox1;
  GtkWidget *vbox2;
  GtkWidget *frame1;
  GtkWidget *vbox3;
  GSList *cable_type_group = NULL;
  GtkWidget *radiobutton11;
  GtkWidget *label11;
  GtkWidget *radiobutton12;
  GtkWidget *vbox7;
  GtkWidget *label121;
  GtkWidget *label122;
  GtkWidget *radiobutton13;
  GtkWidget *vbox8;
  GtkWidget *label131;
  GtkWidget *label132;
  GtkWidget *radiobutton14;
  GtkWidget *label14;
  GtkWidget *radiobutton15;
  GtkWidget *label15;
  GtkWidget *frame3;
  GtkWidget *vbox4;
  GSList *io_port_group = NULL;
  //GtkWidget *radiobutton21;
  //GtkWidget *label21;
  //GtkWidget *radiobutton22;
  //GtkWidget *label22;
  //GtkWidget *radiobutton23;
  //GtkWidget *label23;
  //GtkWidget *radiobutton24;
  //GtkWidget *label24;
  //GtkWidget *radiobutton25;
  //GtkWidget *label25;
  GtkWidget *vbox1;
#ifndef NO_CALC
  GtkWidget *frame2;
  GtkWidget *vbox5;
  GSList *calc_type_group = NULL;
  GtkWidget *radiobutton31;
  GtkWidget *radiobutton32;
  GtkWidget *radiobutton33;
  GtkWidget *radiobutton34;
  GtkWidget *radiobutton35;
  GtkWidget *radiobutton36;
  GtkWidget *radiobutton37;
  GtkWidget *radiobutton38;
#endif
  GtkWidget *frame4;
  GtkWidget *vbox6;
  //GtkWidget *io_entry;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *ok_button;
  GtkWidget *cancel_button;
  GtkWidget *help_button;
  GtkWidget *checkbutton1;
  //struct hcdb *h;

  //h=(struct hcdb *)g_malloc(sizeof(struct hcdb));
  /*
  printf("111\n");
  printf("calc_type: %i\n", param->calc_type);
  printf("link_type: %i\n", param->link_type);
  printf("io_addr: %03X\n", param->io_addr);
  printf("device: %s\n", param->device);
  printf("tidev: %s\n", param->tidev ? "yes" : "no"); 
  */
  /* Initialize the temporary structure */
  h->link_type = param->link_type;
  h->calc_type = param->calc_type;
  h->io_addr = param->io_addr;
  h->tidev = param->tidev;
  strcpy(h->device, param->device);

  /* Draw the dialog box */
  h->dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (h->dialog), "dialog", h->dialog);
  gtk_container_set_border_width (GTK_CONTAINER (h->dialog), 5);
  gtk_window_set_title (GTK_WINDOW (h->dialog), gettext("Configuration"));
  gtk_window_set_modal(GTK_WINDOW(h->dialog), TRUE);

  dialog_vbox1 = GTK_DIALOG (h->dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (h->dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_widget_ref (hbox1);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "hbox1", hbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), hbox1, TRUE, TRUE, 0);

  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox2);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "vbox2", vbox2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox2);
  gtk_box_pack_start (GTK_BOX (hbox1), vbox2, TRUE, TRUE, 0);

  frame1 = gtk_frame_new (gettext("Cable type:"));
  gtk_widget_ref (frame1);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "frame1", frame1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame1);
  gtk_box_pack_start (GTK_BOX (vbox2), frame1, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 5);

  vbox3 = gtk_vbox_new (TRUE, 0);
  gtk_widget_ref (vbox3);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "vbox3", vbox3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox3);
  gtk_container_add (GTK_CONTAINER (frame1), vbox3);

  radiobutton11 = gtk_radio_button_new (cable_type_group);
  cable_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton11));
  gtk_widget_ref (radiobutton11);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton11", radiobutton11,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton11);
  gtk_box_pack_start (GTK_BOX (vbox3), radiobutton11, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton11), 5);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton11), TRUE);

  label11 = gtk_label_new ("Home-made parallel cable");
  gtk_widget_ref (label11);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label11", label11,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label11);
  gtk_container_add (GTK_CONTAINER (radiobutton11), label11);
  gtk_label_set_justify (GTK_LABEL (label11), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label11), 0, 0.5);

  radiobutton12 = gtk_radio_button_new (cable_type_group);
  cable_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton12));
  gtk_widget_ref (radiobutton12);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton12", radiobutton12,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton12);
  gtk_box_pack_start (GTK_BOX (vbox3), radiobutton12, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton12), 5);

  vbox7 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox7);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "vbox7", vbox7,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox7);
  gtk_container_add (GTK_CONTAINER (radiobutton12), vbox7);

  label121 = gtk_label_new ("Home-made serial cable");
  gtk_widget_ref (label121);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label121", label121,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label121);
  gtk_box_pack_start (GTK_BOX (vbox7), label121, FALSE, FALSE, 0);
  gtk_misc_set_alignment (GTK_MISC (label121), 0, 0.5);

  label122 = gtk_label_new ("Black TI Graph Link");
  gtk_widget_ref (label122);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label122", label122,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label122);
  gtk_box_pack_start (GTK_BOX (vbox7), label122, FALSE, FALSE, 0);
  gtk_misc_set_alignment (GTK_MISC (label122), 0, 0.5);

  radiobutton13 = gtk_radio_button_new (cable_type_group);
  cable_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton13));
  gtk_widget_ref (radiobutton13);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton13", radiobutton13,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton13);
  gtk_box_pack_start (GTK_BOX (vbox3), radiobutton13, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton13), 5);

  vbox8 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox8);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "vbox8", vbox8,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox8);
  gtk_container_add (GTK_CONTAINER (radiobutton13), vbox8);

  label131 = gtk_label_new ("Grey TI Graph Link");
  gtk_widget_ref (label131);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label131", label131,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label131);
  gtk_box_pack_start (GTK_BOX (vbox8), label131, FALSE, FALSE, 0);
  gtk_misc_set_alignment (GTK_MISC (label131), 0, 0.5);

  label132 = gtk_label_new ("AVRlink (compatible mode)");
  gtk_widget_ref (label132);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label132", label132,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label132);
  gtk_box_pack_start (GTK_BOX (vbox8), label132, FALSE, FALSE, 0);
  gtk_misc_set_alignment (GTK_MISC (label132), 0, 0.5);

  radiobutton14 = gtk_radio_button_new (cable_type_group);
  cable_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton14));
  gtk_widget_ref (radiobutton14);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton14", radiobutton14,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton14);
  gtk_box_pack_start (GTK_BOX (vbox3), radiobutton14, FALSE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton14), 5);

  label14 = gtk_label_new ("AVRlink (fast mode)");
  gtk_widget_ref (label14);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label14", label14,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label14);
  gtk_container_add (GTK_CONTAINER (radiobutton14), label14);
  gtk_misc_set_alignment (GTK_MISC (label14), 0, 0.5);

  radiobutton15 = gtk_radio_button_new (cable_type_group);
  cable_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton15));
  gtk_widget_ref (radiobutton15);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton15", radiobutton15,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton15);
  gtk_box_pack_start (GTK_BOX (vbox3), radiobutton15, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton15), 5);

  label15 = gtk_label_new ("Virtual link");
  gtk_widget_ref (label15);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label15", label15,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label15);
  gtk_container_add (GTK_CONTAINER (radiobutton15), label15);
  gtk_misc_set_alignment (GTK_MISC (label15), 0, 0.5);

//#ifndef WIN32
  checkbutton1 = gtk_check_button_new_with_label ("Use 'tidev' kernel module");
  gtk_widget_ref (checkbutton1);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "checkbutton1", checkbutton1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (checkbutton1);
  gtk_box_pack_start (GTK_BOX (vbox3), checkbutton1, FALSE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (checkbutton1), 5);
//#endif

  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox1);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "vbox1", vbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox1);
  gtk_box_pack_start (GTK_BOX (hbox1), vbox1, TRUE, TRUE, 0);

  frame3 = gtk_frame_new ("I/O port:");
  gtk_widget_ref (frame3);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "frame3", frame3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame3);
  gtk_box_pack_start (GTK_BOX (vbox1), frame3, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame3), 5);

  vbox4 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox4);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "vbox4", vbox4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox4);
  gtk_container_add (GTK_CONTAINER (frame3), vbox4);

  h->radiobutton21 = gtk_radio_button_new (io_port_group);
  io_port_group = gtk_radio_button_group (GTK_RADIO_BUTTON (h->radiobutton21));
  gtk_widget_ref (h->radiobutton21);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton21", h->radiobutton21,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->radiobutton21);
  gtk_box_pack_start (GTK_BOX (vbox4), h->radiobutton21, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (h->radiobutton21), 5);

  h->label21 = gtk_label_new ("0x3BC");
  gtk_widget_ref (h->label21);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label21", h->label21,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->label21);
  gtk_container_add (GTK_CONTAINER (h->radiobutton21), h->label21);
  gtk_label_set_justify (GTK_LABEL (h->label21), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (h->label21), 0, 0.5);

  h->radiobutton22 = gtk_radio_button_new (io_port_group);
  io_port_group = gtk_radio_button_group (GTK_RADIO_BUTTON (h->radiobutton22));
  gtk_widget_ref (h->radiobutton22);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton22", h->radiobutton22,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->radiobutton22);
  gtk_box_pack_start (GTK_BOX (vbox4), h->radiobutton22, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (h->radiobutton22), 5);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (h->radiobutton22), TRUE);

  h->label22 = gtk_label_new ("0x378");
  gtk_widget_ref (h->label22);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label22", h->label22,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->label22);
  gtk_container_add (GTK_CONTAINER (h->radiobutton22), h->label22);
  gtk_misc_set_alignment (GTK_MISC (h->label22), 0, 0.5);

  h->radiobutton23 = gtk_radio_button_new (io_port_group);
  io_port_group = gtk_radio_button_group (GTK_RADIO_BUTTON (h->radiobutton23));
  gtk_widget_ref (h->radiobutton23);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton23", h->radiobutton23,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->radiobutton23);
  gtk_box_pack_start (GTK_BOX (vbox4), h->radiobutton23, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (h->radiobutton23), 5);

  h->label23 = gtk_label_new ("0x278");
  gtk_widget_ref (h->label23);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label23", h->label23,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->label23);
  gtk_container_add (GTK_CONTAINER (h->radiobutton23), h->label23);
  gtk_misc_set_alignment (GTK_MISC (h->label23), 0, 0.5);

  h->radiobutton24 = gtk_radio_button_new (io_port_group);
  io_port_group = gtk_radio_button_group (GTK_RADIO_BUTTON (h->radiobutton24));
  gtk_widget_ref (h->radiobutton24);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton24", h->radiobutton24,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->radiobutton24);
  gtk_box_pack_start (GTK_BOX (vbox4), h->radiobutton24, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (h->radiobutton24), 5);

  h->label24 = gtk_label_new ("not used");
  gtk_widget_ref (h->label24);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "label24", h->label24,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->label24);
  gtk_container_add (GTK_CONTAINER (h->radiobutton24), h->label24);
  gtk_misc_set_alignment (GTK_MISC (h->label24), 0, 0.5);

  h->radiobutton25 = gtk_radio_button_new (io_port_group);
  io_port_group = gtk_radio_button_group (GTK_RADIO_BUTTON (h->radiobutton25));
  gtk_widget_ref (h->radiobutton25);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton25", h->radiobutton25,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->radiobutton25);
  gtk_box_pack_start (GTK_BOX (vbox4), h->radiobutton25, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (h->radiobutton25), 5);

  h->label25 = gtk_label_new ("other (at right) ->");
  gtk_widget_ref (h->label25);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "h->label25", h->label25,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->label25);
  gtk_container_add (GTK_CONTAINER (h->radiobutton25), h->label25);
  gtk_misc_set_alignment (GTK_MISC (h->label25), 0, 0.5);

#ifndef NO_CALC
  frame2 = gtk_frame_new ("Calculator type:");
  gtk_widget_ref (frame2);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "frame2", frame2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame2);
  gtk_box_pack_start (GTK_BOX (hbox1), frame2, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame2), 5);

  vbox5 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox5);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "vbox5", vbox5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox5);
  gtk_container_add (GTK_CONTAINER (frame2), vbox5);

  radiobutton31 = gtk_radio_button_new_with_label (calc_type_group, "TI92+");
  calc_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton31));
  gtk_widget_ref (radiobutton31);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton31", radiobutton31,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton31);
  gtk_box_pack_start (GTK_BOX (vbox5), radiobutton31, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton31), 5);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton31), TRUE);

  radiobutton32 = gtk_radio_button_new_with_label (calc_type_group, "TI92");
  calc_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton32));
  gtk_widget_ref (radiobutton32);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton32", radiobutton32,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton32);
  gtk_box_pack_start (GTK_BOX (vbox5), radiobutton32, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton32), 5);

  radiobutton33 = gtk_radio_button_new_with_label (calc_type_group, "TI89");
  calc_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton33));
  gtk_widget_ref (radiobutton33);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton33", radiobutton33,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton33);
  gtk_box_pack_start (GTK_BOX (vbox5), radiobutton33, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton33), 5);

  radiobutton34 = gtk_radio_button_new_with_label (calc_type_group, "TI86");
  calc_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton34));
  gtk_widget_ref (radiobutton34);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton34", radiobutton34,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton34);
  gtk_box_pack_start (GTK_BOX (vbox5), radiobutton34, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton34), 5);

  radiobutton35 = gtk_radio_button_new_with_label (calc_type_group, "TI85");
  calc_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton35));
  gtk_widget_ref (radiobutton35);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton35", radiobutton35,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton35);
  gtk_box_pack_start (GTK_BOX (vbox5), radiobutton35, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton35), 5);

  radiobutton36 = gtk_radio_button_new_with_label (calc_type_group, "TI83+");
  calc_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton36));
  gtk_widget_ref (radiobutton36);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton36", radiobutton36,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton36);
  gtk_box_pack_start (GTK_BOX (vbox5), radiobutton36, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton36), 5);

  radiobutton37 = gtk_radio_button_new_with_label (calc_type_group, "TI83");
  calc_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton37));
  gtk_widget_ref (radiobutton37);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton37", radiobutton37,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton37);
  gtk_box_pack_start (GTK_BOX (vbox5), radiobutton37, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton37), 5);

  radiobutton38 = gtk_radio_button_new_with_label (calc_type_group, "TI82");
  calc_type_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton38));
  gtk_widget_ref (radiobutton38);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "radiobutton38", radiobutton38,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton38);
  gtk_box_pack_start (GTK_BOX (vbox5), radiobutton38, TRUE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton38), 5);
#endif
  frame4 = gtk_frame_new ("I/O address (optionnal):");
  gtk_widget_ref (frame4);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "frame4", frame4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame4);
  gtk_box_pack_start (GTK_BOX (vbox1), frame4, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame4), 5);

  vbox6 = gtk_vbox_new (TRUE, 0);
  gtk_widget_ref (vbox6);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "vbox6", vbox6,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox6);
  gtk_container_add (GTK_CONTAINER (frame4), vbox6);
  gtk_container_set_border_width (GTK_CONTAINER (vbox6), 5);

  h->io_entry = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (h->io_entry);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "io_entry", h->io_entry,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (h->io_entry);
  gtk_box_pack_start (GTK_BOX (vbox6), h->io_entry, FALSE, FALSE, 0);
  gtk_entry_set_visibility (GTK_ENTRY (h->io_entry), FALSE);
  gtk_entry_set_editable(GTK_ENTRY(h->io_entry), FALSE);
  gtk_entry_set_text (GTK_ENTRY (h->io_entry), "0x000");

  dialog_action_area1 = GTK_DIALOG (h->dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (h->dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  ok_button = gtk_button_new_with_label ("OK");
  gtk_widget_ref (ok_button);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "ok_button", ok_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (ok_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), ok_button);
  GTK_WIDGET_SET_FLAGS (ok_button, GTK_CAN_DEFAULT);

  cancel_button = gtk_button_new_with_label ("Cancel");
  gtk_widget_ref (cancel_button);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "cancel_button", cancel_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (cancel_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), cancel_button);
  GTK_WIDGET_SET_FLAGS (cancel_button, GTK_CAN_DEFAULT);

  help_button = gtk_button_new_with_label ("Help");
  gtk_widget_ref (help_button);
  gtk_object_set_data_full (GTK_OBJECT (h->dialog), "help_button", help_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (help_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), help_button);
  GTK_WIDGET_SET_FLAGS (help_button, GTK_CAN_DEFAULT);

  /* Activate some buttons */
  if(h->link_type == LINK_PAR)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton11), TRUE);
  if(h->link_type == LINK_SER)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton12), TRUE);
  if(h->link_type == LINK_TGL)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton13), TRUE);
  if(h->link_type == LINK_AVR)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton14), TRUE);
  if(h->link_type == LINK_VTL)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton15), TRUE);

#ifndef WIN32
  if(h->tidev == USE_TIDEV)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (checkbutton1), TRUE);
#endif

#ifndef NO_CALC
  if(h->calc_type == CALC_TI92P)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton31), TRUE);
  if(h->calc_type == CALC_TI92)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton32), TRUE);
  if(h->calc_type == CALC_TI89)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton33), TRUE);
  if(h->calc_type == CALC_TI86)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton34), TRUE);
  if(h->calc_type == CALC_TI85)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton35), TRUE);
  if(h->calc_type == CALC_TI83P)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton36), TRUE);
  if(h->calc_type == CALC_TI83)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton37), TRUE);
  if(h->calc_type == CALC_TI82)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton38), TRUE);
#endif

  /* Installs the signal handlers */
  gtk_signal_connect (GTK_OBJECT (h->dialog), "destroy",
                      GTK_SIGNAL_FUNC (gtk_widget_destroy),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton11), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton11_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton12), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton12_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton13), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton13_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton14), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton14_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton15), "toggled",
		     GTK_SIGNAL_FUNC (hcdb_radiobutton15_toggled),
		     h);
#ifndef WIN32
  gtk_signal_connect (GTK_OBJECT (checkbutton1), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_checkbutton_toggled),
                      h);
#endif
  gtk_signal_connect (GTK_OBJECT (h->radiobutton21), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton21_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (h->radiobutton22), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton22_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (h->radiobutton23), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton23_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (h->radiobutton24), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton24_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (h->radiobutton25), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton25_toggled),
                      h);
#ifndef NO_CALC
  gtk_signal_connect (GTK_OBJECT (radiobutton31), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton31_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton32), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton32_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton33), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton33_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton34), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton34_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton35), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton35_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton36), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton36_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton37), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton37_toggled),
                      h);
  gtk_signal_connect (GTK_OBJECT (radiobutton38), "toggled",
                      GTK_SIGNAL_FUNC (hcdb_radiobutton38_toggled),
                      h);
#endif
  gtk_signal_connect (GTK_OBJECT (h->io_entry), "activate",
                      GTK_SIGNAL_FUNC (io_entry_activate),
                      h);
  gtk_signal_connect (GTK_OBJECT (h->io_entry), "changed",
                      GTK_SIGNAL_FUNC (io_entry_changed),
                      h);
  gtk_signal_connect (GTK_OBJECT (ok_button), "clicked",
                      GTK_SIGNAL_FUNC (setup_config_ok),
                      h);
  gtk_signal_connect (GTK_OBJECT (cancel_button), "clicked",
                      GTK_SIGNAL_FUNC (setup_config_cancel),
                      h);
  gtk_signal_connect (GTK_OBJECT (help_button), "clicked",
                      GTK_SIGNAL_FUNC (setup_config_help),
                      (gpointer)(h->dialog));
  
  gtk_widget_show_all(h->dialog);
  refresh_hcdb_frame(h);

  /* Wait that the user click on a button */
  while(h->blocking == FALSE)
    {
      while(gtk_events_pending())
	gtk_main_iteration();
    }
  /*
  printf("333:\n");
  printf("calc_type: %i\n", h->calc_type);
  printf("link_type: %i\n", h->link_type);
  printf("io_addr: %03X\n", h->io_addr);
  printf("device: %s\n", h->device);
  printf("tidev: %s\n", h->tidev ? "yes" : "no"); 
  */
  switch(h->blocking)
  {
  case 1:
    param->calc_type = h->calc_type;
    param->link_type = h->link_type;
    param->io_addr = h->io_addr;
    param->tidev = h->tidev;
    strcpy(param->device, h->device);
    h->blocking = FALSE;

    return 1;
    break;
  case 2:
    h->blocking = FALSE;

    return 0;
    break;
  }

  return 0;
}
