/* example-start base base.c */

#include <gtk/gtk.h>

#include <ti/cable_defs.h>
#include <ti/calc_defs.h>

#include "hcdb.h"
#include "ghc_dbox.h"

int main( int   argc,
          char *argv[] )
{
    struct link_param param;
    
    gtk_init (&argc, &argv);
 
    param.link_type = LINK_PAR;
    param.calc_type = CALC_TI92;
    param.io_addr = LPT1;
    strcpy(param.device, TIDEV_P1);
    param.tidev = 0;

    printf("000\n");
    printf("calc_type: %i\n", param.calc_type);
    printf("link_type: %i\n", param.link_type);
    printf("io_addr: %03X\n", param.io_addr);
    printf("device: %s\n", param.device);
    printf("tidev: %s\n", param.tidev ? "yes" : "no"); 

    printf("Returned: %i\n", dlgbox_setup_port_calc(&param));

    printf("444\n");
    printf("calc_type: %i\n", param.calc_type);
    printf("link_type: %i\n", param.link_type);
    printf("io_addr: %03X\n", param.io_addr);
    printf("device: %s\n", param.device);
    printf("tidev: %s\n", param.tidev ? "yes" : "no"); 
    
    gtk_main ();
    
    return(0);
}
/* example-end */
