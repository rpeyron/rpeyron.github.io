/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <strings.h>
#include <stdlib.h>

#include "../dep/dep.h"

#include "plugin_interface.h"
#include "rw_92_file.h"

/* 
   This function reads a single variable and places the data part of the
   variable in a dynamically allocated array. 
   It also places some informations about the variable in a varinfo structure which is
   also dynamically allocated.
   You have to allocate a 'byte' buffer, copy the var_content into it (for working on it) and
   next free it. You must work with this copy.
   The varinfo structure must not be freed and can be modified.
   The filename pointer is provided by GtkTiLink thru the run_plugin function and it must be passed
   as is. For the moment, you can not rename a variable.
*/
int read_92_file(char *filename, byte **var_content, struct varinfo **vinfo)
{
  FILE *file;
  int i;
  char str[128];
  int num_entries;
  byte *vc;
  static VARINFO *pvi; // parent folder varinfo
  static VARINFO *vi;

  /* Open the file */
  if( (file = fopen(filename, "rb")) == NULL )
    {
      fprintf(stderr, "Unable to open this file: %s\n", filename);
      exit(-1);
    }
  
  /* Allocate structures */
  vi = (VARINFO *)gu_malloc(sizeof(VARINFO));
  *vinfo = vi;
  pvi = (VARINFO *)gu_malloc(sizeof(VARINFO));

  /* Read file content and extract useful informations */
  fgets(str, 9, file);
  if(strcmp(str, "**TI92**")) return -1;
  for(i=0; i<2; i++) fgetc(file);
  for(i=0; i<8; i++) pvi->varname[i] = fgetc(file);
  pvi->varname[i]='\0';
  strcpy(pvi->translate, pvi->varname);
  vi->folder = pvi;
  for(i=0; i<40; i++) fgetc(file);
  num_entries = fgetc(file);
  num_entries += fgetc(file) << 8;
  if(num_entries != 1) return -1;
  for(i=0; i<4; i++) fgetc(file);
  for(i=0; i<8; i++) vi->varname[i] = fgetc(file);
  vi->varname[i] = '\0';
  strcpy(vi->translate, vi->varname);
  vi->vartype = fgetc(file);
  fgetc(file);
  for(i=0; i<2; i++) fgetc(file);
  for(i=0; i<4; i++) fgetc(file);
  for(i=0; i<2; i++) fgetc(file);
  /* data: raw data part */
  for(i=0; i<4; i++) fgetc(file);
  vi->varsize = fgetc(file) << 8;
  vi->varsize += fgetc(file);
  vi->varsize += 2;

  /* Allocate the var_content buffer */
  *var_content = (byte *)gu_malloc(((vi->varsize)+1) * sizeof(byte));

  /* Fill it */
  vc = *var_content;
  fread(vc+2, sizeof(byte), vi->varsize, file);
  vc[0]=MSB_(vi->varsize - 2);
  vc[1]=LSB_(vi->varsize - 2);
  /*
  for(i=0; i<(vi->varsize); i++)
    printf("%02X ", vc[i]);
  printf("\n");  
  */

  /* Close the file */
  fclose(file);

  return 0;
}

/* 
   This function writes a single variable starting at the var_content buffer.
   You have to allocate this buffer as explained above. Once the function has written 
   the variable, your buffer will be freed.
*/
int write_92_file(char *filename, byte *var_content, struct varinfo *vi)
{
  FILE *file;
  byte header[0x58];
  word sum=0;
  int i;
  
  if( (file=fopen(filename, "rb")) == NULL )
    {
      //fprintf(stderr, "Unable to open this file: %s\n", filename);
      exit(-1);
    }
  /* Get the header file */
  fread(header, sizeof(byte), 0x56, file);
  fclose(file);

  if( (file=fopen(filename, "wb")) == NULL )
    {
      //fprintf(stderr, "Unable to open this file: %s\n", filename);
      exit(-1);
    }

  /* Update and write the header according to the new varsize */
  header[0x4C]=LSB_(LSW_(vi->varsize + 0x58));
  header[0x4D]=MSB_(LSW_(vi->varsize + 0x58));
  header[0x4E]=LSB_(MSW_(vi->varsize + 0x58));
  header[0x4D]=MSB_(MSW_(vi->varsize + 0x58));
  fwrite(header, sizeof(byte), 0x56, file);

  /* Write the content of var */
  fwrite(var_content, sizeof(byte), vi->varsize, file);
  for(i=0; i< vi->varsize; i++)
    sum += var_content[i];
  fprintf(file, "%c%c", LSB_(sum), MSB_(sum));

  /* Close the file */
  fclose(file);

  /* Free allocated memory */
  gu_free(var_content);
  gu_free(vi->folder);
  gu_free(vi);

  return 0;
}


