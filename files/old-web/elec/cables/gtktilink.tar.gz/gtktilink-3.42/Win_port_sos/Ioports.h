/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


#ifndef IOPORTS_H
#define IOPORTS_H

#include <conio.h>

__inline int ioperm(unsigned long from, unsigned long num, int turn_on)
{
  return 0;
}

#if defined(WIN32) & !defined(WINNT)

__inline unsigned char inb (int portid)
{ unsigned char c;
  short int addr=portid;

  __asm 
  { 
    mov dx,addr
    in al,dx
    mov c,al
  }

 return c;
}

__inline void outb (unsigned char value, int portid)
{ 
  short int addr=portid;

  __asm 
    { 
      mov al,value
      mov dx,addr
      out dx,al
    }
}

#elif defined(WINNT)

#include <windows.h>
#include "dlportio.h"
	
__inline unsigned char inb (int portid)
{ 
  return DlPortReadPortUchar(portid);
}

__inline void outb (unsigned char value, int portid)
{ 
  DlPortWritePortUchar(portid, value);
}

#endif

#endif
