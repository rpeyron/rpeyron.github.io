/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef PCX_XPM_H
#define PCX_XPM_H

#include <stdio.h>

#include "misc.h"

/*****************************/
/* PCX file format functions */
/*****************************/

int write_pcx_compressed(FILE *file, byte *bitmap, byte columns, byte rows); // Obsolete, for backwards compatibility
int write_pcx_2_colors(FILE *file, byte *bitmap, 
		       int columns, int rows, int inverted);
int write_pcx_256_colors(FILE *file, byte *bitmap, int columns, int rows, byte *palette);
int read_pcx_2_colors(FILE *file, byte **bitmap, int *columns, int *rows);
int read_pcx_256_colors(FILE *file, byte **bitmap, int *columns, int *rows, byte **palette);

/*****************************/
/* XPM file format functions */
/*****************************/

char **convert_bitmap_to_pixmap(byte *bitmap, byte width, byte height);
void delete_pixmap(char ***pixmap);

#endif

