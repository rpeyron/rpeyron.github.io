#include "../gui_linux/fargo2.h"
#include <unistd.h>

// encore pas mal de  boulot !
// more security checks, more information given to user

int install_result;
char *fargo2_path;
int check_installation(void);
int test_file(char *file, int perm);
int send_92p_file(char *file);

int request_92b_backup(char *backup)
{
affiche_message("saving TI backup to disk...",VERTFONCE);

affiche_message("DONE\n",VERTFONCE);
return 0;
}

int install_fargo_in(char *backup_path);
int send_92b_backup(char *backup)
{
affiche_message("Sending TI backup...",VERTFONCE);	

affiche_message("DONE\n",VERTFONCE);
return 0;
}
void send_needed_files(void);


int start_install_process(void)
{
fargo2_path=(char *)malloc(strlen(SHARE_DIR)+strlen("/fargo2/")+1);
strcpy(fargo2_path,SHARE_DIR);
strcat(fargo2_path,"/fargo2/");
affiche_message("Starting installation process...\n",VERTFONCE);

if (check_installation()!=0)
	return -1;
request_92b_backup("/tmp/temporary_backup.92b");

if (install_fargo_in("/tmp/temporary_backup.92b")!=0)
	return -1;
send_92b_backup("/tmp/temporary_backup.92b");
send_needed_files();
affiche_message("\nFargo II should be on your calculator now,\ntry holding down [shift] and then [on] to see if \nit worked\n",VERTFONCE);

sleep(6);
install_finished();
return 0;
}







int test_file(char *file, int perm)
{
char *path;
char error[2000]; // I am bored of mallocing
//char txt[2000];
int file_access_result;

path=(char *)malloc(strlen(fargo2_path)+1+strlen("file")+1);

strcpy(path, fargo2_path);
strcat(path,file);
file_access_result=access(path, perm);
if (file_access_result!=0)
  {
    printf("%s\n",path);
    sprintf(error,"The file \"%s\" cannot be found or is not readable or executable\n",file);
    affiche_message(error, ROUGE);
    return -1;
    install_result=-1;
  }
return 0; // ok file exists and is executable
}

int check_installation()
{
install_result=0;
#ifndef __WIN32__
test_file("flinker", X_OK | F_OK);
#else
test_file("flinker.exe", X_OK | F_OK);
#endif

test_file("kernel.o", R_OK | F_OK);
test_file("tios.o", R_OK | F_OK);
test_file("flib.92p", R_OK | F_OK);
//test_file("flib.92p", R_OK | F_OK);
affiche_message("Requested programms where found\n",VERTFONCE);
return install_result;
}
int install_fargo_in(char *backup_path)
{
char error[2000]; // I am bored of mallocing
char *cmd;
int size_of_cmd;
affiche_message("installation of fargo2 in TI's backup...",VERTFONCE);
if (access(backup_path, W_OK | R_OK)!=0)
  {
    sprintf(error,"\nThe backup \"%s\" cannot be accessed \n",backup_path);
    affiche_message(error, ROUGE);
    //return -1;  // if no backup was created ( taken off form the moment for debug )
    
  }
  
  /*
  je pr�pare l'�xecution de la commande magique qui installera fargo dans le backup
  */

size_of_cmd=	strlen("flinker -vb ")
		+strlen(backup_path)
		+1
		+strlen("kernel.o")
		+1
		+strlen("tios.o")
		+3*strlen(fargo2_path)
		+1;
		
cmd=(char *)malloc(size_of_cmd);
sprintf(cmd,"%sflinker -vb %s %skernel.o %stios.o",fargo2_path,backup_path,fargo2_path,fargo2_path);
/*
hop j'install fargo2 dans le backup
*/
system(cmd);
affiche_message("DONE\n",VERTFONCE);
return 0;
}

void send_needed_files(void)
{
send_92p_file("flib.92p");
send_92p_file("hexlib.92p");
send_92p_file("gray7lib.92p");
send_92p_file("gray4lib.92p");
send_92p_file("shell.92p");
send_92p_file("hufflib.92p");
}
int send_92p_file(char *file)
{
char *complet_path=(char *)malloc(strlen(fargo2_path)+strlen(file)+1);
char msg[2000];

sprintf(msg,"sending file \"%s\"...",file);
affiche_message(msg,VERTFONCE);

strcpy(complet_path,fargo2_path);
strcat(complet_path,file);
sleep(1);
// send_function_92p(complet_path);
affiche_message("DONE\n",VERTFONCE);
return 0;
}
