/*  GtkTiLink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#else
#include "unistd.h"
#endif

#include "misc.h"
#include "../indep/paths.h"

#define LSW_l(l) (unsigned int) ((l) & 0x0000FFFF)
#define MSW_l(l) (unsigned int)(((l) & 0xFFFF0000) >> 16)
#define LSB_w(w) (unsigned char) ((w) & 0x00FF)
#define MSB_w(w) (unsigned char)(((w) & 0xFF00) >> 8)
#define LSN_b(b)  ((b) & 0x0F)
#define MSN_b(b) (((b) & 0xF0) >> 4)

/*
  Beware: the number of columns must be an EVEN number
*/
int write_pcx_2_colors(FILE *file, byte *bitmap, 
		       int columns, int rows, int inverted)
{
  int i, j;
  unsigned char count;
  unsigned char data;
  unsigned char last_data;
  
  /* Write the PCX header (128 bytes) */
  fputc(0x0A, file);                      // Signature of image format
  fputc(0x00, file);                      // Version
  fputc(0x01, file);                      // No compression
  fputc(0x01, file);                      // 1 bit by pixel
  for(i=0; i<4; i++) fputc(0x00, file);   // Left top corner: (0,0)
  fputc(LSB_w(columns-1), file);            // Right bottom corner: (x,y)
  fputc(MSB_w(columns-1), file);
  fputc(LSB_w(rows-1), file);
  fputc(MSB_w(rows-1), file);
  fputc(300, file);                      // Horizontal resolution in dpi
  fputc(0x00, file);
  fputc(300, file);                      // Vertical resolution in dpi
  fputc(0x00, file);
  for(i=0; i<3; i++) fputc(0x00, file);   // Palette
  for(i=0; i<3; i++) fputc(0xFF, file);
  for(i=0; i<42; i++) fputc(0xFF, file);
  fputc(0x00, file);                      // Reserved
  fputc(0x01, file);                      // Number of layers
  fputc(LSB_w(columns >> 3), file);         // Number of bytes by rows
  fputc(MSB_w(columns >> 3), file);
  fputc(0x01, file);                      // Palette type: B&W
  fputc(0x00, file);
  for(i=0; i<58; i++) fputc(0x00, file);  // Reserved
  /* Initialize some variables */
  
  /* Compress and write data line by lines */
  for(j=0; j<rows; j++)
    {
      last_data = *(bitmap+(columns >> 3)*j);
      if(inverted)
	last_data = ~last_data;
	
      count=0;
      for(i=0; i<(columns >> 3); i++)  // Data
        { 
	  data = *(bitmap+(columns >> 3)*j+i);
	  if(inverted)
	    data = ~data;
	  if(data == last_data)
	    { // if data repeated, count
	      count++;
	      if(count == 63) // if max reached, write counter and data
		{
		  fputc(0xC0 | count, file);
		  fputc(last_data, file);
		  count=0;
		}
	    }
	  else
	    { // the first byte or data > 64, write it.
	      if((count) || (last_data & 0xC0))
		{
		  fputc(0xC0 | count, file);
		  fputc(last_data, file);
		  last_data=data;
		  count=1;
		}
	      else
		{
		  fputc(last_data, file);
		  last_data=data;
		}
	    }
        }
      // flush
      if((count) || (last_data & 0xC0))
	{
	  fputc(0xC0 | count, file);
	  fputc(last_data, file);
	  last_data=data;
	  count=1;
        }
      else
        {
	  fputc(last_data, file);
	  last_data=data;
        }
    }
  
  return 0;
}

int write_pcx_256_colors(FILE *file, byte *bitmap, int columns, int rows, byte *palette)
{
  int i, j;
  unsigned char count;
  unsigned char data;
  unsigned char last_data;
  
  /* Write the PCX header (128 bytes) */
  fputc(0x0A, file);                      // Signature of image format
  fputc(0x05, file);                      // Version: there is a palette
  fputc(0x01, file);                      // RLE compression
  fputc(0x08, file);                      // 8 bits by pixel
  for(i=0; i<4; i++) fputc(0x00, file);   // Left top corner: (0,0)
  fputc(LSB_w(columns-1), file);            // Right bottom corner: (x,y)
  fputc(MSB_w(columns-1), file);
  fputc(LSB_w(rows-1), file);
  fputc(MSB_w(rows-1), file);
  fputc(LSB_w(300), file);               // Horizontal resolution in dpi
  fputc(MSB_w(300), file);
  fputc(LSB_w(300), file);               // Vertical resolution in dpi
  fputc(MSB_w(300), file);
  for(i=0; i<3; i++) fputc(0x00, file);   // Palette
  for(i=0; i<3; i++) fputc(0xFF, file);
  for(i=0; i<42; i++) fputc(0xFF, file);
  fputc(0x00, file);                      // Reserved
  fputc(0x01, file);                      // Number of layers (1 color plane)
  fputc(LSB_w(columns), file);            // Number of bytes by rows
  fputc(MSB_w(columns), file);
  fputc(0x01, file);                      // Palette type: color
  fputc(0x00, file);
  for(i=0; i<58; i++) fputc(0x00, file);  // Reserved
  
  /* Compress and write data line by lines */
  for(j=0; j<rows; j++)
    {
      last_data = *(bitmap+columns*j);
      count=0;
      for(i=0; i<columns; i++)  // Data
        { 
	  data=*(bitmap+columns*j+i);
	  if(data == last_data)
	    { // if data repeated, count
	      count++;
	      if(count == 63) // if max reached, write counter and data
		{
		  fputc(0xC0 | count, file);
		  fputc(last_data, file);
		  count=0;
		}
	    }
	  else
	    { // the first byte or data > 64, write it.
	      if((count) || (last_data & 0xC0))
		{
		  fputc(0xC0 | count, file);
		  fputc(last_data, file);
		  last_data=data;
		  count=0;
		}
	      else
		{
		  fputc(last_data, file);
		  last_data=data;
		}
	    }
        }
      // flush
      if((count) || (last_data & 0xC0))
	{
	  fputc(0xC0 | count, file);
	  fputc(last_data, file);
	  last_data=data;
	  count=0;
        }
      else
        {
	  fputc(last_data, file);
	  last_data=data;
        }
    }
  
  /* Write the palette (256 colors in rrggbb format) */
  fputc(12, file);	// palette ID
  for(i=0; i<3*256; i++)
    fputc(palette[i], file);

  return 0;
}
int read_pcx_2_colors(FILE *file, byte **bitmap, int *columns, int *rows)
{
  return 0;
}
int read_pcx_256_colors(FILE *file, byte **bitmap, int *columns, int *rows, byte **palette)
{
  return 0;
}

/* Write the image stored in the 'bitmap' variable  */
/* PCX format with 1 bit/pixel and with compression */
int write_pcx_compressed(FILE *file, byte *bitmap,
                         byte columns, byte rows)
{
  return write_pcx_2_colors(file, bitmap, columns, rows, 0);
}
