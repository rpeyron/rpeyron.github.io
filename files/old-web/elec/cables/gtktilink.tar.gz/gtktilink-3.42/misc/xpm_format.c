/*  GtkTiLink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../dep/dep.h"

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#else
#include "unistd.h"
#endif

#include "../indep/paths.h"

#define LSW_l(l) (unsigned int) ((l) & 0x0000FFFF)
#define MSW_l(l) (unsigned int)(((l) & 0xFFFF0000) >> 16)
#define LSB_w(w) (unsigned char) ((w) & 0x00FF)
#define MSB_w(w) (unsigned char)(((w) & 0xFF00) >> 8)
#define LSN_b(b)  ((b) & 0x0F)
#define MSN_b(b) (((b) & 0xF0) >> 4)

/* Convert the image stored in the 'bitmap' variable into a pixmap */
char **convert_bitmap_to_pixmap(byte *bitmap, 
				byte width, byte height)
{
  char **pixmap;
  char buffer[257];
  int col, row, bit;
  unsigned char mask, data;
  int pixel;
#ifdef DEBUG
  FILE *out;
#endif

#ifdef DEBUG
  out=fopen("test.xpm", "wt");
  if(out==NULL)
    {
      fprintf(stderr, "Unable to open the file test.xpm\n");
      exit(0);
    }
#endif

  pixmap=(char **)malloc((height+5)*sizeof(char *));
  if(pixmap==NULL)
    {
      fprintf(stderr, "Unable to allocate memory.\n");
      exit(0);
    }

  sprintf(buffer, "%i %i %i %i", width, height, 3, 1);
  pixmap[0]=(char *)malloc((strlen(buffer)+1)*sizeof(char));
  if(pixmap[0]==NULL)
    {
      fprintf(stderr, "Unable to allocate memory.\n");
      exit(0);
    }
  strcpy(pixmap[0], buffer);
#ifdef DEBUG
  fprintf(out, "\"%s\",\n", buffer);
#endif

  sprintf(buffer, " \tc None");
  pixmap[1]=(char *)malloc((strlen(buffer)+1)*sizeof(char));
  if(pixmap[1]==NULL)
    {
      fprintf(stderr, "Unable to allocate memory.\n");
      exit(0);
    }
  strcpy(pixmap[1], buffer);
#ifdef DEBUG
  fprintf(out, "\"%s\",\n", buffer);
#endif

  sprintf(buffer, ".\tc #000000000000");
  pixmap[2]=(char *)malloc((strlen(buffer)+1)*sizeof(char));
  if(pixmap[2]==NULL)
    {
      fprintf(stderr, "Unable to allocate memory.\n");
      exit(0);
    }
  strcpy(pixmap[2], buffer);
#ifdef DEBUG
  fprintf(out, "\"%s\",\n", buffer);
#endif

  sprintf(buffer, "+\tc #FFFFFFFFFFFF");
  pixmap[3]=(char *)malloc((strlen(buffer)+1)*sizeof(char));
  if(pixmap[3]==NULL)
    {
      fprintf(stderr, "Unable to allocate memory.\n");
      exit(0);
    }
  strcpy(pixmap[3], buffer);
#ifdef DEBUG
  fprintf(out, "\"%s\",\n", buffer);
#endif

  for(row=0; row<height; row++)
    {
      for(col=0; col<width>>3; col++)
	{
	  data=bitmap[(width>>3)*row+col];
	  mask=0x80;
	  for(bit=0; bit<8; bit++)
	    {
	      pixel=data & mask;
	      if(pixel) buffer[8*col+bit]='+'; else buffer[8*col+bit]='.';
	      mask>>=1;
	    }
	}
      buffer[width]='\0';
      pixmap[row+4]=(char *)malloc((strlen(buffer)+1)*sizeof(char));
      if(pixmap[row+4]==NULL)
	{
	  fprintf(stderr, "Unable to allocate memory.\n");
	  exit(0);
	}
      strcpy(pixmap[row+4], buffer);
#ifdef DEBUG
      fprintf(out, "\"%s\",\n", buffer);
#endif
    }
  pixmap[height+4]=NULL;

#ifdef DEBUG
  fclose(out);
#endif
  return pixmap;
}

/* Destroy the pixmap created with the previous function */
void delete_pixmap(char ***pixmap)
{
  int i;

  for(i=0; (*pixmap)[i]!=NULL; i++)
    {
      free((*pixmap)[i]);
    }
  free(*pixmap);
  *pixmap=NULL;
}
