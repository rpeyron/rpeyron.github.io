/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

#include "../indep/struct.h"
#include "../indep/error.h"
#include "so_dll.h"
#include "../indep/version.h"

/* 
   A remark: the cable lib is loaded by this file (explicitly linking) whereas
   the calc lib is is loaded at startup (implicitly linking). I implicitly
   linked it because there are too many functions and symbols to share.
*/

/* Cable functions */
const char * (*fp_get_cable_version) (void);
void (*fp_set_timeout) (int);
int  (*fp_get_timeout) (void);
void (*fp_set_delay)   (int);
int  (*fp_get_delay)   (void);
void (*fp_set_cable)   (int type, struct link_cable *lc);

/* Library handles */
static void *handle  = NULL;

/* Configure some variables depending on the link cable type */
void setup_link_and_calc(int use_server)
{
  /* Close the libraries if already opened */
  if(handle != NULL)
    {
      lib_close (handle);
      //fprintf(stdout, "libti_cables library unloaded\n");
      //fprintf(stdout, "libti_calcs library unloaded\n");      
    }  

  /* Open the cable and calc libraries */
#ifdef HAVE_LIBDL
  handle = lib_open ("libti_cables.so.1");
#else
  handle = lib_open ("ti_cables.dll");
#endif
 
  /* Load the cable symbols */
  fp_get_cable_version = lib_symbol (handle, "get_cable_version");
  fp_set_timeout = lib_symbol (handle, "set_timeout");
  fp_get_timeout = lib_symbol (handle, "get_timeout");
  fp_set_delay = lib_symbol (handle, "set_delay");
  fp_get_delay = lib_symbol (handle, "get_delay");
  fp_set_cable = lib_symbol (handle, "set_cable");

  /* Do initialization */
  fp_set_timeout(options.lp.timeout);
  fp_set_delay(options.lp.delay);
  fp_set_cable(options.lp.link_type, &link_cable);
  set_calc(options.lp.calc_type, &ti_calc, &link_cable);

  /* Dislay miscellenaous informations */
  fprintf(stdout, "libti_cables library loaded, version %s\n",
	  fp_get_cable_version());
  fprintf(stdout, "libti_calcs library loaded, version %s\n",
          get_calc_version());

  /* Check the version of libs */
  if(strcmp(get_cable_version(), LIB_CABLE_VERSION_REQUIRED) < 0)
    {
      fprintf(stdout, "libti_cables library loaded, version: <%s>\n",
	      fp_get_cable_version());
      fprintf(stderr, "Library version <%s> mini required.\n", 
	      LIB_CABLE_VERSION_REQUIRED);
      exit(-1);
    }
  if(strcmp(get_calc_version(), LIB_CALC_VERSION_REQUIRED) < 0)
    {
      fprintf(stdout, "libti_calcs library loaded, version: <%s>\n",
	      get_calc_version());
      fprintf(stderr, "Library version <%s> mini required.\n",
              LIB_CALC_VERSION_REQUIRED);
      exit(-1);
    }
  
  return;
}

void remove_link_type(cable_type)
{
  lib_close(handle);
}
