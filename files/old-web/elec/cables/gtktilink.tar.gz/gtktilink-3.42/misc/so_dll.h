/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef SO_DLL_H
#define SO_DLL_H

/*
#ifdef __BEOS__ // BeOS
#define LIBHANDLE void*
#define LIBFNCT	void*
#endif

#ifdef __WIN32__ // Windows
#include <windows.h>
#define LIBHANDLE HINSTANCE
#define LIBFNCT CALLBACK*
#endif

#ifdef HAVE_LIBDL // Linux
#include <gtk/gtk.h>
#define LIBHANDLE gpointer
#define LIBFNCT gpointer
#endif
*/
#define LIBHANDLE void*
#define LIBFNCT	void*

//void check_lib_error();
LIBHANDLE lib_open(const char *filename);
LIBFNCT lib_symbol(LIBHANDLE handle, char *symbol);
int lib_close(LIBHANDLE handle);

#endif
