/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

// Beware: this file is not used for the moment but will be used for plugins

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#ifdef HAVE_LIBDL
#include <dlfcn.h>
#elif defined(__WIN32__)
#include <windows.h>
#endif

#include "so_dll.h"
#include "../indep/error.h"

/* Chech if the symbol can not be loaded */
/*
  Linux: const char *dlerror(void);
  Windows: there is nothing
*/
static void check_lib_error()
{
#ifdef HAVE_LIBDL
  char *error;
  
  if ((error = dlerror()) != NULL)
    {
      fputs(error, stderr);
      fprintf(stderr, "\n");
      exit(1);
    }
  return;
#elif defined(__WIN32__)
  char error[100];
  
  sprintf (error, "Error code %d", GetLastError ());
  fputs(error, stderr);
  exit(1);
  return;
#endif
}

/*
  Linux: void *dlopen (const char *filename, int flag);
  Windows: HINSTANCE  LoadLibrary(const char *filename);
*/
LIBHANDLE lib_open(const char *filename)
{
  LIBHANDLE handle;

#ifdef HAVE_LIBDL
  handle = dlopen(filename, RTLD_NOW); // | RTLD_GLOBAL);
  if (!handle)
    {
      fputs (dlerror(), stderr);
      exit(1);
    }
#elif defined(__WIN32__)
  handle = LoadLibrary(filename);
  if(!handle)
    {
      check_lib_error();
    }
#endif

  return handle;
}

/*
  Linux: void *dlsym(void *handle, char *symbol);
  Windows: ?? GetProcAddress(HINSTANCE handle, char *symbol);
*/
LIBFNCT lib_symbol(LIBHANDLE handle, char *symbol)
{
  LIBFNCT f;
#ifdef HAVE_LIBDL
  f = dlsym(handle, symbol);
  check_lib_error();
#elif defined(__WIN32__)
  f = GetProcAddress (handle, symbol);
  if (!f)
    {
      check_lib_error();
    }
#endif
  return f;
}

/*
  Linux: int dlclose (void *handle);
  Windows: ?? FreeLibrary(HINSTANCE handle);
*/
int lib_close(LIBHANDLE handle)
{
#ifdef HAVE_LIBDL
  return dlclose(handle);
  check_lib_error();
#elif defined(__WIN32__)
  if (!FreeLibrary (handle))
    {
      check_lib_error();
    }
  return 0;
#endif
}




