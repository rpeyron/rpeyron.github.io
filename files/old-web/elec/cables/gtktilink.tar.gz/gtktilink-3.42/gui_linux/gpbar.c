/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>

#include "defines.h"

/* For Windows9x platform, it is better to use discrete pbar because they are faster */
#ifdef __WIN32__
#define PROGRESS_TYPE GTK_PROGRESS_DISCRETE
#else
#define PROGRESS_TYPE GTK_PROGRESS_CONTINUOUS
#endif

void cancel_cb(GtkWidget *widget, gpointer data)
{
  info_update.cancel = 1;

  return;
}

/* Create a window with one progress bar */
void create_pbar_type1(const gchar *title)
{
  GtkWidget *vbox;
  GtkWidget *label;
  GtkWidget *button;

  p_win.is_active=LOCK;
  is_active = LOCK;
  info_update.percentage=0.0;
  info_update.cancel=0;
  p_win.window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(p_win.window), title);
  gtk_window_position(GTK_WINDOW(p_win.window), GTK_WIN_POS_CENTER);  

  vbox = gtk_vbox_new(FALSE, 1);
  gtk_container_border_width(GTK_CONTAINER(vbox), 5);
  gtk_container_add(GTK_CONTAINER(p_win.window), vbox);
  gtk_widget_show(vbox);  
  
  label=gtk_label_new(gettext("Transfer status:  "));
  gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0);
  gtk_widget_show(label);  
  p_win.pbar=gtk_progress_bar_new();
  gtk_progress_bar_update(GTK_PROGRESS_BAR (p_win.pbar), 0.0);
  gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR (p_win.pbar),
								  PROGRESS_TYPE);
  gtk_box_pack_start(GTK_BOX(vbox), p_win.pbar, FALSE, FALSE, 0); 
  gtk_widget_show(p_win.pbar); 

  button=gtk_button_new_with_label(gettext("Cancel"));
  gtk_box_pack_start(GTK_BOX (vbox), button, TRUE, TRUE, 10);
  gtk_signal_connect(GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (cancel_cb), NULL);
  gtk_widget_show(button);

  gtk_widget_show(p_win.window);

  return;
}

/* Destroy the previous window */
void destroy_pbar_type1(void)
{
  p_win.pbar=NULL;
  p_win.pbar2=NULL;
  p_win.label=NULL;
  gtk_widget_destroy(p_win.window);
  p_win.is_active=UNLOCK;
  is_active = UNLOCK;
}

/* Create a window with one label */
void create_pbar_type2(const gchar *title, const gchar *text)
{
  GtkWidget *vbox;
  GtkWidget *button;

  p_win.is_active=LOCK;
  is_active = LOCK;
  info_update.percentage=0.0;
  info_update.cancel=0;
  p_win.window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(p_win.window), title);
  gtk_window_position(GTK_WINDOW(p_win.window), GTK_WIN_POS_CENTER);  

  vbox = gtk_vbox_new(FALSE, 1);
  gtk_container_border_width(GTK_CONTAINER(vbox), 5);
  gtk_container_add(GTK_CONTAINER(p_win.window), vbox);
  gtk_widget_show(vbox);  
  
  p_win.label=gtk_label_new(gettext(text));
  gtk_box_pack_start(GTK_BOX (vbox), p_win.label, TRUE, TRUE, 5);
  gtk_widget_show(p_win.label);

  button=gtk_button_new_with_label(gettext("Cancel"));
  gtk_box_pack_start(GTK_BOX (vbox), button, TRUE, TRUE, 10);
  gtk_signal_connect(GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (cancel_cb), NULL);
  gtk_widget_show(button);
  
  gtk_widget_show(p_win.window);

  return;
}

/* Destroy the previous window */
void destroy_pbar_type2(void)
{
  p_win.pbar=NULL;
  p_win.pbar2=NULL;
  p_win.label=NULL;
  gtk_widget_destroy(p_win.window);  
  p_win.is_active=UNLOCK;
  is_active = UNLOCK;
}

/* Create a window with two progress bars */
void create_pbar_type3(const gchar *title)
{
  GtkWidget *vbox;
  GtkWidget *label;
  GtkWidget *button;

  p_win.is_active=LOCK;
  is_active = LOCK;
  info_update.main_percentage=0.0;
  info_update.percentage=0.0;
  info_update.cancel=0;
  p_win.window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(p_win.window), title);
  gtk_window_position(GTK_WINDOW(p_win.window), GTK_WIN_POS_CENTER);  

  vbox = gtk_vbox_new(FALSE, 1);
  gtk_container_border_width(GTK_CONTAINER(vbox), 5);
  gtk_container_add(GTK_CONTAINER(p_win.window), vbox);
  gtk_widget_show(vbox);  

  label=gtk_label_new(gettext("Total transfer:  "));
  gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0);
  gtk_widget_show(label);
  p_win.pbar2=gtk_progress_bar_new();
  gtk_progress_bar_update(GTK_PROGRESS_BAR (p_win.pbar2), 0.0);
  gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR (p_win.pbar2),
				  GTK_PROGRESS_DISCRETE);
  gtk_box_pack_start(GTK_BOX(vbox), p_win.pbar2, FALSE, FALSE, 0);
  gtk_widget_show(p_win.pbar2);
  
  label=gtk_label_new(gettext("Transfer status:  "));
  gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0);
  gtk_widget_show(label);  
  p_win.pbar=gtk_progress_bar_new();
  gtk_progress_bar_update(GTK_PROGRESS_BAR (p_win.pbar), 0.0);
  gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR (p_win.pbar),
								  PROGRESS_TYPE);
  gtk_box_pack_start(GTK_BOX(vbox), p_win.pbar, FALSE, FALSE, 0); 
  gtk_widget_show(p_win.pbar);

  button=gtk_button_new_with_label(gettext("Cancel"));
  gtk_box_pack_start(GTK_BOX (vbox), button, TRUE, TRUE, 10);
  gtk_signal_connect(GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (cancel_cb), NULL);
  gtk_widget_show(button);

  gtk_widget_show(p_win.window);

  return;
}

/* Destroy the previous window */
void destroy_pbar_type3(void)
{
  p_win.pbar=NULL;
  p_win.pbar2=NULL;
  p_win.label=NULL;
  gtk_widget_destroy(p_win.window);  
  p_win.is_active=UNLOCK;
  is_active = UNLOCK;
}

/* Create a window with a one progress bar and one label */
void create_pbar_type4(const gchar *title, const gchar *text)
{
  GtkWidget *vbox;
  GtkWidget *label;
  GtkWidget *button;

  p_win.is_active=LOCK;
  is_active = LOCK;
  info_update.percentage=0.0;
  info_update.cancel=0;
  p_win.window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(p_win.window), title);
  gtk_window_position(GTK_WINDOW(p_win.window), GTK_WIN_POS_CENTER);  

  vbox = gtk_vbox_new(FALSE, 1);
  gtk_container_border_width(GTK_CONTAINER(vbox), 5);
  gtk_container_add(GTK_CONTAINER(p_win.window), vbox);
  gtk_widget_show(vbox);  
  
  label=gtk_label_new(gettext("Transfer status:  "));
  gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0);
  gtk_widget_show(label);  
  p_win.pbar=gtk_progress_bar_new();
  gtk_progress_bar_update(GTK_PROGRESS_BAR (p_win.pbar), 0.0);
  gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR (p_win.pbar),
								  PROGRESS_TYPE);
  gtk_box_pack_start(GTK_BOX(vbox), p_win.pbar, FALSE, FALSE, 0); 
  gtk_widget_show(p_win.pbar); 
  
  p_win.label=gtk_label_new(text);
  gtk_box_pack_start(GTK_BOX (vbox), p_win.label, TRUE, TRUE, 5);
  gtk_widget_show(p_win.label);

  button=gtk_button_new_with_label(gettext("Cancel"));
  gtk_box_pack_start(GTK_BOX (vbox), button, TRUE, TRUE, 10);
  gtk_signal_connect(GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (cancel_cb), NULL);
  gtk_widget_show(button);
  
  gtk_widget_show(p_win.window);

  return;
}

/* Destroy the previous window */
void destroy_pbar_type4(void)
{
  p_win.pbar=NULL;
  p_win.pbar2=NULL;
  p_win.label=NULL;
  gtk_widget_destroy(p_win.window);
  p_win.is_active=UNLOCK;
  is_active = UNLOCK;
}

/* Create a window with two progress bars and one label */
void create_pbar_type5(const gchar *title, const gchar *text)
{
  GtkWidget *vbox;
  GtkWidget *label;
  GtkWidget *button;

  p_win.is_active=LOCK;
  is_active = LOCK;
  info_update.main_percentage=0.0;
  info_update.percentage=0.0;
  info_update.cancel=0;
  p_win.window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(p_win.window), title);
  gtk_window_position(GTK_WINDOW(p_win.window), GTK_WIN_POS_CENTER);  

  vbox = gtk_vbox_new(FALSE, 1);
  gtk_container_border_width(GTK_CONTAINER(vbox), 5);
  gtk_container_add(GTK_CONTAINER(p_win.window), vbox);
  gtk_widget_show(vbox);  

  label=gtk_label_new(gettext("Total transfer:  "));
  gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0);
  gtk_widget_show(label);
  p_win.pbar2=gtk_progress_bar_new();
  gtk_progress_bar_update(GTK_PROGRESS_BAR (p_win.pbar2), 0.0);
  gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR (p_win.pbar2),
				  GTK_PROGRESS_DISCRETE);
  gtk_box_pack_start(GTK_BOX(vbox), p_win.pbar2, FALSE, FALSE, 0);
  gtk_widget_show(p_win.pbar2);
  
  label=gtk_label_new(gettext("Transfer status:  "));
  gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 0);
  gtk_widget_show(label);  
  p_win.pbar=gtk_progress_bar_new();
  gtk_progress_bar_update(GTK_PROGRESS_BAR (p_win.pbar), 0.0);
  gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR (p_win.pbar),
								  PROGRESS_TYPE);
  gtk_box_pack_start(GTK_BOX(vbox), p_win.pbar, FALSE, FALSE, 0); 
  gtk_widget_show(p_win.pbar);

  p_win.label=gtk_label_new(text);
  gtk_box_pack_start(GTK_BOX (vbox), p_win.label, TRUE, TRUE, 5);
  gtk_widget_show(p_win.label);

  button=gtk_button_new_with_label(gettext("Cancel"));
  gtk_box_pack_start(GTK_BOX (vbox), button, TRUE, TRUE, 10);
  gtk_signal_connect(GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (cancel_cb), NULL);
  gtk_widget_show(button);
  
  gtk_widget_show(p_win.window);

  return;
}

/* Destroy the previous window */
void destroy_pbar_type5(void)
{
  p_win.pbar=NULL;
  p_win.pbar2=NULL;
  p_win.label=NULL;
  gtk_widget_destroy(p_win.window);  
  p_win.is_active=UNLOCK;
  is_active = UNLOCK;
}

/* 
   Destroy a pbar window: more general, replaces the 
   previous 'destroy_pbar_typeX' functions 
*/
void destroy_pbar(void)
{
  p_win.pbar=NULL;
  p_win.pbar2=NULL;
  p_win.label=NULL;
  gtk_widget_destroy(p_win.window);
  p_win.is_active=UNLOCK;
  is_active = UNLOCK;
}
