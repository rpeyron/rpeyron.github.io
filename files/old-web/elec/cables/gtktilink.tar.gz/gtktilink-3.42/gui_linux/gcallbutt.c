/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <string.h>

#include "defines.h"


/*****************************************************/
/* Callbacks called for the ROM dump size dialog box */
/*****************************************************/

void
rds_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  gint *i = (int *)user_data;

  *i = 1;
}


void
rds_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  gint *i = (int *)user_data;

  *i = 2;
}

/******************************************************/
/* Callbacks called for the screen setup dialog box */
/******************************************************/
void
ssdb_radiobutton11_toggled              (GtkToggleButton *togglebutton,
                                        struct ssdb         *s)
{
  s->image_format = PCX;
}

void
ssdb_radiobutton12_toggled              (GtkToggleButton *togglebutton,
                                        struct ssdb         *s)
{
  s->image_format = XPM;
}

void
ssdb_radiobutton13_toggled              (GtkToggleButton *togglebutton,
                                        struct ssdb         *s)
{
  s->image_format = JPG;
}

void
ssdb_radiobutton21_toggled              (GtkToggleButton *togglebutton,
                                        struct ssdb         *s)
{
  s->clipping = FULL_SCREEN;
}

void
ssdb_radiobutton22_toggled              (GtkToggleButton *togglebutton,
                                        struct ssdb         *s)
{
  s->clipping = CLIPPED_SCREEN;
}

/****************************************************/
/* The following cb are used for the general dlgbox */
/****************************************************/
void
gdb_radiobutton51_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->clist_sort_order=SORT_UP;
}


void
gdb_radiobutton52_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->clist_sort_order=SORT_DOWN;
}


void
gdb_radiobutton31_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->ctree_sort_order=SORT_UP;
}


void
gdb_radiobutton32_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->ctree_sort_order=SORT_DOWN;
}


void
gdb_checkbutton2_toggled               (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->file_mode=togglebutton->active;
}


void
gdb_checkbutton1_toggled               (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->show=togglebutton->active;
}


void
gdb_checkbutton3_toggled               (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->confirm=togglebutton->active;
}


void
gdb_radiobutton41_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->clist_sort=SORT_BY_NAME;
}

void
gdb_radiobutton42_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->clist_sort=SORT_BY_SIZE;
}

void
gdb_radiobutton43_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->clist_sort=SORT_BY_GROUP;
}


void
gdb_radiobutton44_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->clist_sort=SORT_BY_DATE;
}


void
gdb_radiobutton45_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->clist_sort=SORT_BY_ATTRB;
}


void
gdb_radiobutton46_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->clist_sort=SORT_BY_USER;
}


void
gdb_radiobutton11_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->path_mode=FULL_PATH;
}


void
gdb_radiobutton12_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->path_mode=LOCAL_PATH;
}


void
gdb_radiobutton21_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->ctree_sort=SORT_BY_NAME;
}


void
gdb_radiobutton22_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->ctree_sort=SORT_BY_TYPE;
}


void
gdb_radiobutton23_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->ctree_sort=SORT_BY_INFO;
}


void
gdb_radiobutton24_toggled              (GtkToggleButton *togglebutton,
                                        struct gdb         *s)
{
  s->ctree_sort=SORT_BY_SIZE;
}


void
gdb_spinbutton1_changed                (GtkEditable     *editable,
                                        struct gdb         *s)
{
  //Nothing to do  
}


void
gdb_spinbutton2_changed                (GtkEditable     *editable,
                                        struct gdb         *s)
{
  // Nothing to do
}
