/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>

#include "defines.h"

static gint last_status=0;

/* Cb called when a row of the clist is clicked */ 
void clist_button_press(GtkWidget *widget, GdkEventButton *event)
{
  gchar *name, *attrib;
  gint row, column;
  GdkEventButton *bevent;
  
  if (!gtk_clist_get_selection_info (GTK_CLIST (widget), event->x, event->y, &row, &column)) return;
  gtk_clist_get_text(GTK_CLIST(widget), row, 1, &name);
  gtk_clist_get_text(GTK_CLIST(widget), row, 6, &attrib);
  switch(event->type)
    {
    case GDK_BUTTON_PRESS:
      if(event->button==3)
	{
	  //gtk_clist_select_row(GTK_CLIST(widget), row, column);
	  bevent=(GdkEventButton *)(event);
	  gtk_menu_popup(GTK_MENU(create_right_button_menu()), NULL, NULL, NULL, NULL, bevent->button, bevent->time);
	}
      break;
    case GDK_2BUTTON_PRESS:
      if(attrib[1]=='d')
	{
	  last_status=1;
	  //gtk_clist_freeze(GTK_CLIST (widget));
	  if(chdir(name)==-1)
	    {
	      gu_error(gettext("Chdir error.\n"));
	    }
	  if(getcwd(clist_win.cur_dir, 255) == NULL)
	    {
	      gu_error(gettext("Directory name too long.\n"));
	    }
	  l_directory_list();
	  refresh_clist(widget);
	  refresh_info(widget);
	}
      break;
    default:
      break;        
    }
  
  return;
}

gint GCompareStrings (gconstpointer a, gconstpointer b)
{
  return strcmp((gchar *)a, (gchar *)b);
}

/* Callback function called when a row of the clist is unselected */
void clist_unselect_row( GtkWidget      *widget,
			 gint            row,
			 gint            column,
			 GdkEventButton *event,
			 gpointer        data )
{
  gchar *name, *attrib;
  gchar *full_name;

  //gtk_clist_thaw(GTK_CLIST (widget));  
  gtk_clist_get_text(GTK_CLIST(widget), row, 1, &name);
  gtk_clist_get_text(GTK_CLIST(widget), row, 6, &attrib);
  
  //printf("Unselected row %i: <%s> <%s>, selectable: %i\n", row, name, attrib, gtk_clist_get_selectable(GTK_CLIST (widget), row));

  if(gtk_clist_get_selectable(GTK_CLIST (widget), row))
    {
      clist_win.selection=gu_list_remove(clist_win.selection, gtk_clist_get_row_data(GTK_CLIST (widget), row));
      
      full_name=(gchar *)gu_malloc((strlen(clist_win.cur_dir)+1+strlen(name)+1)*sizeof(gchar));
      strcpy(full_name, clist_win.cur_dir);
#ifndef WIN32
      strcat(full_name, "/");
#else
      strcat(full_name, "\\");
#endif
      strcat(full_name, name);
      //printf("<%s>\n", full_name);
      //printf("<<%s>>\n", (char *)(gu_list_find_custom(clist_win.file_selection, full_name, GCompareStrings)->data));
      clist_win.file_selection=gu_list_remove(clist_win.file_selection, gu_list_find_custom(clist_win.file_selection, full_name, GCompareStrings)->data);
      gu_free(full_name);
    }
  refresh_info(main_window);

  return;
}

/* Callback function called when a row of the clist is selected */
void clist_select_row( GtkWidget      *widget,
		       gint            row,
		       gint            column,
		       GdkEventButton *event,
		       gpointer        data )
{
  gchar *name, *attrib;
  gchar *full_name;

  gtk_clist_get_text(GTK_CLIST(widget), row, 1, &name);
  gtk_clist_get_text(GTK_CLIST(widget), row, 6, &attrib);
  
  //printf("Selected row %i: <%s> <%s>, selectable: %i\n", row, name, attrib, gtk_clist_get_selectable(GTK_CLIST (widget), row));

  //gtk_clist_thaw(GTK_CLIST (widget));
  ctree_selection_destroy();
  ctree_selection_refresh();

  if(gtk_clist_get_selectable(GTK_CLIST (widget), row))
    {
      clist_win.selection=gu_list_append(clist_win.selection, gtk_clist_get_row_data(GTK_CLIST (widget), row));

      full_name=(gchar *)gu_malloc((strlen(clist_win.cur_dir)+1+strlen(name)+1)*sizeof(gchar));
      strcpy(full_name, clist_win.cur_dir);
#ifndef WIN32
      strcat(full_name, "/");
#else
      strcat(full_name, "\\");
#endif
      strcat(full_name, name);
      //printf("<%s>\n", full_name);
      clist_win.file_selection=gu_list_append(clist_win.file_selection, (gpointer)full_name);
    }

  if(last_status)
    {
      last_status=0;
      gtk_clist_unselect_row(GTK_CLIST (widget), row, 1);
    }
  refresh_info(main_window);

  return;
}

/* Callback function called when a column button is clicked */
void clist_click_column( GtkWidget      *widget,
			 gint            column,
			 gpointer        data )
{
  switch(column)
    {
    case 0:
      options.clist_sort_order=!options.clist_sort_order; 
      break;
    case 1:
      options.clist_sort=SORT_BY_NAME;
      break;
    case 2:
      options.clist_sort=SORT_BY_DATE;
      break;
    case 3:
      options.clist_sort=SORT_BY_SIZE;
      break;
    case 4:
      options.clist_sort=SORT_BY_USER;
      break;
    case 5:
      options.clist_sort=SORT_BY_GROUP;
      break;
    case 6:
      options.clist_sort=SORT_BY_ATTRB;
      break; 
    }

  refresh_clist(widget);
  refresh_info(widget);

  return;
}
