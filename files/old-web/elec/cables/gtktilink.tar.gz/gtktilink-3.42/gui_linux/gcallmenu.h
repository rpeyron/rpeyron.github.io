/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef GCALLMENU_H
#define GCALLMENU_H

#include <gtk/gtk.h>

/* File menu */
void item_file_open(GtkWidget *widget, gpointer data);
void item_file_save(GtkWidget *widget, gpointer data);
void item_file_saveas(GtkWidget *widget, gpointer data);
void item_file_convert(GtkWidget *widget, gpointer data);
void item_file_unzip(GtkWidget *widget, gpointer data);
void item_file_unpack(GtkWidget *widget, gpointer data);
void item_file_saveconfig(GtkWidget *widget, gpointer data);
void item_file_loadconfig(GtkWidget *widget, gpointer data);
void item_file_defaultconfig(GtkWidget *widget, gpointer data);

/* Setup menu */
void item_setup_general(GtkWidget *widget, gpointer data);
void item_setup_port_calc(GtkWidget *widget, gpointer data);
void item_setup_delay(GtkWidget *widget, gpointer data);
void item_setup_timeout(GtkWidget *widget, gpointer data);
void item_setup_screen(GtkWidget *widget, gpointer data);

void item_setup_probe_calc(GtkWidget *widget, gpointer data);
void item_setup_probe_cable(GtkWidget *widget, gpointer data);
void item_setup_probe_ports(GtkWidget *widget, gpointer data);

/* Functions menu */
void item_fncts_ready(GtkWidget *widget, gpointer data);
void item_fncts_terminal(GtkWidget *widget, gpointer data);
void item_fncts_screen(GtkWidget *widget, gpointer data);
void item_fncts_dirlist(GtkWidget *widget, gpointer data);
void item_fncts_sbackup(GtkWidget *widget, gpointer data);
void item_fncts_rbackup(GtkWidget *widget, gpointer data);
void item_fncts_svar(GtkWidget *widget, gpointer data);
void item_fncts_rvar(GtkWidget *widget, gpointer data);
void item_fncts_sendFLASHapp(GtkWidget *widget, gpointer data);
void item_fncts_sendFLASHos(GtkWidget *widget, gpointer data);
void item_fncts_IDlist(GtkWidget *widget, gpointer data);

/* Misc menu */
void item_misc_ROMdump(GtkWidget *widget, gpointer data);
void item_misc_ROMversion(GtkWidget *wdiget, gpointer data);

/* Plug-ins menu */
void item_plugins_options(GtkWidget *widget, gpointer data);
void item_plugins_load(GtkWidget *widget, gpointer data);
void item_plugins_list(GtkWidget *widget, gpointer data);

/* Help menu */
void item_help_about(GtkWidget *widget, gpointer data);
void item_help_help(GtkWidget *widget, gpointer data);
void item_help_thanks(GtkWidget *widget, gpointer data);

/* Menu of the remote control window */
//void item2_mode_quit(GtkWidget *widget, gpointer data);
//void item2_mode_remote(GtkWidget *widget, gpointer data);
//void item2_mode_term(GtkWidget *widget, gpointer data);

/* Right button menu */
void
rbm_cut_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_copy_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_paste_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_move_to_parent_dir_activate        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_select_all1_activate               (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_unzip_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_ungroup_or_unpack_activate         (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_convert_tigl_gtktilink_activate    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_view_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_properties_activate                (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_properties1_activate               (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_update_window1_activate            (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_make_new_directory1_activate       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_delete_file1_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_insert_fargo_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
rbm_change_drive_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

#endif
