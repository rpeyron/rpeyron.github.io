/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"

//extern struct screenshot ti_screen;
extern const gchar PAK_NAME[9][10];

/* Save a screendump */
void file_ok_sel_1(GtkWidget *widget, gpointer data)
{
  char filename[MAXCHARS];
  gint ret, skip=0;
  gchar buffer[MAXCHARS];
  gchar *dirname;

  strcpy(filename, 
	 gtk_file_selection_get_filename(GTK_FILE_SELECTION (data)));

  if(options.confirm == CONFIRM_YES)
    {
      if( access(filename, F_OK) == 0 )
	{
	  sprintf(buffer, gettext("The file %s already exists.\n\n"),
		  filename);
	  ret=user3_box(gettext("Warning"), buffer,
			gettext(" Overwrite "), gettext(" Rename "),
			gettext(" Skip "));
	  switch(ret)
	    {
	    case BUTTON2:
	      dirname=dlgbox_entry(gettext("Rename the file"),
					   gettext("New name: "), filename);
	      if(dirname == NULL) return;
	      strcpy(filename, dirname);
	      gu_free(dirname);
	    case BUTTON1:
	      skip=0;
	      break;
	    case BUTTON3:
	      skip=1;
	      break;
	    default:
	      break;
	    }
	}
    }
  if(skip == 0)
    {
      if(cb_screen_save(filename) != 0)
		  return;
    }

  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);

  gtk_widget_destroy(data);
}

/* Open a backup to send */
void file_ok_sel_2(GtkWidget *widget, gpointer data)
{
  char filename[MAXCHARS];

  strcpy(filename, gtk_file_selection_get_filename (GTK_FILE_SELECTION (data)));
  gtk_widget_destroy(data);

  if(cb_send_backup(filename) != 0)
	  return;

  return;
}

/* Save the received backup */
void file_ok_sel_3(GtkWidget *widget, gpointer data)
{
  gchar filename[MAXCHARS];
  gchar tmp_filename[MAXCHARS];
  gint ret, skip=0;
  gchar buffer[MAXCHARS];
  gchar *dirname;

  strcpy(filename, 
	 gtk_file_selection_get_filename (GTK_FILE_SELECTION (data)));

  strcpy(tmp_filename, gu_get_tmp_dir());
  strcat(tmp_filename, "/gtktilink.backup");

  if(options.confirm == CONFIRM_YES)
    {
      if( access(filename, F_OK) == 0 )
	{
	  sprintf(buffer, gettext("The file %s already exists.\n\n"),
		  filename);
	  ret=user3_box(gettext("Warning"), buffer,
			gettext(" Overwrite "), gettext(" Rename "),
			gettext(" Skip "));
	  switch(ret)
	    {
	    case BUTTON2:
	      dirname=dlgbox_entry(gettext("Rename the file"),
				   gettext("New name: "), filename);
	      if(dirname == NULL) return;
	      strcpy(filename, dirname);
	      gu_free(dirname);
	    case BUTTON1:
	      skip=0;
	      break;
	    case BUTTON3:
	      skip=1;
	      break;
	    default:
	      break;
	    }
	}
    }
  if(skip == 0)
    {
      if(move_file(tmp_filename, filename))
	{
	  msg_box(gettext("Error"), gettext("Unable to move the temporary file.\n"));  
	}
    }
  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);  

  gtk_widget_destroy(data);
}

void file_cancel_sel_3(GtkWidget *widget, gpointer data)
{
  gchar tmp_filename[MAXCHARS];

  strcpy(tmp_filename, gu_get_tmp_dir());
  strcat(tmp_filename, "/gtktilink.backup");
  if(unlink(tmp_filename))
    {
      gu_message(gettext("Unable to remove the temporary file.\n"));
    }

  gtk_widget_destroy(data);
}

/* Save the received variable(s) */
void file_ok_sel_4(GtkWidget *widget, gpointer data)
{
  gchar filename[MAXCHARS];
  gchar tmp_filename[MAXCHARS];
  gint ret, skip=0;
  gchar buffer[MAXCHARS];
  gchar *dirname;

  strcpy(filename, gtk_file_selection_get_filename (GTK_FILE_SELECTION (data)));
  //gu_print ("%s\n", gtk_file_selection_get_filename (GTK_FILE_SELECTION (data)));

  strcpy(tmp_filename, gu_get_tmp_dir());
  strcat(tmp_filename, "/gtktilink.PAK");

  if(options.confirm == CONFIRM_YES)
    {
      if( access(filename, F_OK) == 0 )
	{
	  sprintf(buffer, gettext("The file %s already exists.\n\n"),
		  filename);
	  ret=user3_box(gettext("Warning"), buffer,
			gettext(" Overwrite "), gettext(" Rename "),
			gettext(" Skip "));

	  switch(ret)
	    {
	    case BUTTON2:
	      dirname=dlgbox_entry(gettext("Rename the file"),
				   gettext("New name: "), filename);
	      if(dirname == NULL) return;
	      strcpy(filename, dirname);
	      gu_free(dirname);
	    case BUTTON1:
	      skip=0;
	      break;
	    case BUTTON3:
	      skip=1;
	      break;
	    default:
	      break;
	    }
	}
    }

  if(skip == 0)
    {
      if(move_file(tmp_filename, filename))
	{
	  gu_print(gettext("Unable to rename the temporary file.\n"));
	}
    }
  gtk_widget_destroy(data);
  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);
}

/* Cancel the operation */
void file_cancel_sel_4(GtkWidget *widget, gpointer data)
{
  gchar tmp_filename[MAXCHARS];

  strcpy(tmp_filename, gu_get_tmp_dir());
  strcat(tmp_filename, "/gtktilink.PAK");
  if(unlink(tmp_filename))
    {
      gu_print(gettext("Unable to remove the temporary file.\n"));
    }

  gtk_widget_destroy(data);
}

/* Open a PAK file to explode */
void file_ok_sel_5(GtkWidget *widget, gpointer data)
{
  char filename[MAXCHARS];

  strcpy(filename, gtk_file_selection_get_filename (GTK_FILE_SELECTION (data)));
  gtk_widget_destroy(data);
  while(g_main_iteration(FALSE));
  explode_pak_file(filename);

  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);

  return;
}

void file_ok_sel_6(GtkWidget *widget, gpointer data)
{
  char filename[MAXCHARS];
  char buffer[MAXCHARS];
  
  strcpy(filename, gtk_file_selection_get_filename (GTK_FILE_SELECTION (data)));
  printf("<%s>\n", filename);
  printf("Error: %i\n", ti82_gtl_to_tigl(filename, buffer));
  
  gtk_widget_destroy(data);
  
  return ;  
}

/* Save the received ROM dump */
void file_ok_sel_7(GtkWidget *widget, gpointer data)
{
  gchar filename[MAXCHARS];
  gchar tmp_filename[MAXCHARS];
  gint ret, skip=0;
  gchar buffer[MAXCHARS];
  gchar *dirname;

  strcpy(filename, 
	 gtk_file_selection_get_filename (GTK_FILE_SELECTION (data)));

  strcpy(tmp_filename, gu_get_tmp_dir());
  strcat(tmp_filename, "/gtktilink.ROMdump");

  if(options.confirm == CONFIRM_YES)
    {
      if( access(filename, F_OK) == 0 )
	{
	  sprintf(buffer, gettext("The file %s already exists.\n\n"),
		  filename);
	  ret=user3_box(gettext("Warning"), buffer,
			gettext(" Overwrite "), gettext(" Rename "),
			gettext(" Skip "));
	  switch(ret)
	    {
	    case BUTTON2:
	      dirname=dlgbox_entry(gettext("Rename the file"),
				   gettext("New name: "), filename);
	      if(dirname == NULL) return;
	      strcpy(filename, dirname);
	      gu_free(dirname);
	    case BUTTON1:
	      skip=0;
	      break;
	    case BUTTON3:
	      skip=1;
	      break;
	    default:
	      break;
	    }
	}
    }
  if(skip == 0)
    {
      if(move_file(tmp_filename, filename))
	{
	  msg_box(gettext("Error"), gettext("Unable to move the temporary file.\n"));  
	}
    }
  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);  

  gtk_widget_destroy(data);
}

void file_cancel_sel_7(GtkWidget *widget, gpointer data)
{
  gchar tmp_filename[MAXCHARS];

  strcpy(tmp_filename, gu_get_tmp_dir());
  strcat(tmp_filename, "/gtktilink.ROMdump");
  if(unlink(tmp_filename))
    {
      gu_message(gettext("Unable to remove the temporary file.\n"));
    }

  gtk_widget_destroy(data);
}

/* Open a FLASH app to send */
void file_ok_sel_8(GtkWidget *widget, gpointer data)
{
  char filename[MAXCHARS];

  strcpy(filename, gtk_file_selection_get_filename (GTK_FILE_SELECTION (data)));
  gtk_widget_destroy(data);

  if(cb_send_flash_app(filename) != 0)
	  return;

  return;
}

/* Open a FLASH OS to send */
void file_ok_sel_9(GtkWidget *widget, gpointer data)
{
  char filename[MAXCHARS];

  strcpy(filename, gtk_file_selection_get_filename (GTK_FILE_SELECTION (data)));
  gtk_widget_destroy(data);

  if(cb_send_flash_os(filename) != 0)
	  return;

  return;
}