/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>

#include "defines.h"

static gint last_status=0;

/* Cb called whenever a row is clicked */
void ctree_button_press(GtkWidget *widget, GdkEventButton *event)
{
  GtkCList *clist;
  GtkCTree *ctree;
  GtkCTreeNode *node;
  gint x;
  gint y;
  gint row;
  gint column;
  static GList *selected_dir=NULL;

  x = event->x;
  y = event->y;

  clist = GTK_CLIST (widget);
  ctree = GTK_CTREE (widget);
  if (!gtk_clist_get_selection_info (clist, x, y, &row, &column)) return;
  node=GTK_CTREE_NODE (gu_list_nth (clist->row_list, row));

  //printf("Button pressed on column %i\n", column);
  //printf("<<%i>>\n", GTK_CTREE_ROW(node)->expanded);

  if( (GTK_CTREE_ROW(node)->children != NULL) && (last_status == 0) )
    {
      if(gu_list_find(selected_dir, (gpointer)node)!=NULL)
	{
	  selected_dir=gu_list_remove(selected_dir, (gpointer)node);
	  gtk_ctree_unselect_recursive(ctree, node);
	}
      else
	{
	  gtk_ctree_select_recursive(ctree, node);
	  selected_dir=gu_list_append(selected_dir, (gpointer)node);
	}
    }
  last_status=0;
  /*
  printf("<<%p %p %p>>\n", GTK_CTREE_ROW(node)->parent, 
	 GTK_CTREE_ROW(node)->sibling,
	 GTK_CTREE_ROW(node)->children);
  */
  return;
}

/* Function called when a row is unselected */
void ctree_unselect_row( GtkWidget      *widget,
			 GtkCTreeNode   *node,
			 gint            column,
			 gpointer        data)
{
  GtkCList *clist;
  GtkCTree *ctree;

  clist = GTK_CLIST (widget);
  ctree = GTK_CTREE (widget);

  //printf("Unselection on column: %i, id: %i\n", column, *(gint *)gtk_ctree_node_get_row_data (ctree, node));

  if(GTK_CTREE_ROW(node)->children == NULL)
    {
      ctree_win.selection=gu_list_remove(ctree_win.selection, gtk_ctree_node_get_row_data(ctree, node));
    }
  refresh_info(main_window);

  return;
}

/* Function called when a row is selected */
void ctree_select_row( GtkWidget    *widget,
		       GtkCTreeNode *node,
		       gint          column,
		       gpointer      data)
{
  GtkCList *clist;
  GtkCTree *ctree;

  clist = GTK_CLIST (widget);
  ctree = GTK_CTREE (widget);
 
  clist_selection_destroy();
  clist_selection_refresh();
  if(GTK_CTREE_ROW(node)->children == NULL)
    {
      ctree_win.selection=gu_list_append(ctree_win.selection, gtk_ctree_node_get_row_data(ctree, node));
    }
  //printf("data: <%p>\n", gtk_ctree_node_get_row_data(ctree, node));
  /*  
  printf("<<%p %p %p>>\n", GTK_CTREE_ROW(node)->parent, 
	 GTK_CTREE_ROW(node)->sibling,
	 GTK_CTREE_ROW(node)->children);
  */
  refresh_info(main_window);

  return;
}

/* Called when a column is clicked */
void ctree_click_col( GtkWidget      *widget,
		      gint            column,
		      gpointer        data )
{
  //printf("Column clicked\n");
  switch(column)
    {
    case 0:
      options.ctree_sort=SORT_BY_NAME;
      break;
    case 1:
      options.ctree_sort=SORT_BY_INFO;
      break;
    case 2:
      options.ctree_sort=SORT_BY_TYPE;
      break;
    case 3:
      options.ctree_sort=SORT_BY_SIZE;
      break;
    }

  refresh_ctree(widget);
 
  return;
}

/* Called when a tree is expanded */
void ctree_expand_tree (GtkWidget *widget, GtkCTreeNode *node, gpointer data)
{
  //printf("CTree expanded\n");
  last_status=1;

  return;
}

/* Called when a tree is collapsed */
void ctree_collapse_tree (GtkWidget *item, GtkCTreeNode *node, gpointer data)
{
  //printf("CTree collapsed\n");
  last_status=1;

  return;
}
