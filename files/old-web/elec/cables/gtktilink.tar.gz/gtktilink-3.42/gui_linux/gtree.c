/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <stdio.h>
#include <strings.h>

#include "defines.h"

/* Create the ctree window (left window) */
void create_ctree (GtkWidget *widget)
{
  //GtkCTreeNode *parent_node;
  //GtkCTreeNode *sibling=NULL;
  GdkPixmap *pixmap;
  GdkBitmap *mask;

  //int i, j;
  gchar *titles[] = {
    gettext_noop("Varname"),
    gettext_noop("Attr"),
    gettext_noop("Type"),
    gettext_noop("Size") };
  
  //gchar *txt[][128] = { { "Item 1" }, { "Item 2" }, { "Item 3" }, { "Item 4" }, { "Item 5"} };
  //gchar *txt3[5][128] = { { "Sous item 1", "Size", "Type"},
  //		  { "Sous item 2", "Size", "Type"},
  //		  { "Sous item 3", "Size", "Type"},
  //		  { "Sous item 4", "Size", "Type"}, 
  //		  { "Sous item 5", "Size", "Type"} };
  
  ctree_win.widget=gtk_ctree_new_with_titles(4, 0, titles);
  
  gtk_clist_set_column_width(GTK_CLIST (ctree_win.widget), 0, 135);
  gtk_clist_set_column_justification(GTK_CLIST (ctree_win.widget), 0, GTK_JUSTIFY_LEFT);
  gtk_clist_set_column_width(GTK_CLIST (ctree_win.widget), 1, 16);
  gtk_clist_set_column_justification(GTK_CLIST (ctree_win.widget), 1, GTK_JUSTIFY_CENTER);
  gtk_clist_set_column_width(GTK_CLIST (ctree_win.widget), 2, 45);
  gtk_clist_set_column_justification(GTK_CLIST (ctree_win.widget), 2, GTK_JUSTIFY_LEFT);
  gtk_clist_set_column_width(GTK_CLIST (ctree_win.widget), 3, 20);
  gtk_clist_set_column_justification(GTK_CLIST (ctree_win.widget), 3, GTK_JUSTIFY_RIGHT);
  gtk_clist_set_selection_mode(GTK_CLIST (ctree_win.widget), GTK_SELECTION_MULTIPLE);
  gtk_ctree_set_line_style (GTK_CTREE(ctree_win.widget), GTK_CTREE_LINES_SOLID);
  //gtk_ctree_set_indent (GTK_CTREE (ctree_win.widget), 17);
  gtk_clist_set_row_height(GTK_CLIST (ctree_win.widget), 16);
  
  gtk_signal_connect_after(GTK_OBJECT (ctree_win.widget), "button_press_event", 
			   GTK_SIGNAL_FUNC (ctree_button_press), NULL);
  gtk_signal_connect_after(GTK_OBJECT (ctree_win.widget), "click_column",
			   GTK_SIGNAL_FUNC(ctree_click_col), NULL);
  gtk_signal_connect(GTK_OBJECT(ctree_win.widget), "tree_expand",
		     GTK_SIGNAL_FUNC(ctree_expand_tree), NULL);
  gtk_signal_connect(GTK_OBJECT(ctree_win.widget), "tree_collapse",
		     GTK_SIGNAL_FUNC(ctree_collapse_tree), NULL);
  gtk_signal_connect_after(GTK_OBJECT(ctree_win.widget), "tree_select_row",
			   GTK_SIGNAL_FUNC(ctree_select_row), NULL);
  gtk_signal_connect_after(GTK_OBJECT(ctree_win.widget), "tree_unselect_row",
			   GTK_SIGNAL_FUNC(ctree_unselect_row), NULL);
  
  gtk_widget_realize(widget);
  open_xpm ("dir.xpm", widget, &pixmap, &mask);
  gdk_pixmap_unref(pixmap);
  /*
    for(i=0; i<4; i++)
    {
    parent_node=gtk_ctree_insert_node (GTK_CTREE (ctree_win.widget), NULL, NULL, txt[i], 5, pixmap,
    mask, pixmap, mask, FALSE, TRUE);
    gtk_ctree_node_set_row_data (GTK_CTREE(ctree_win.widget), parent_node, *txt[i]);
    for(j=0; j<4; j++)
    {
    sibling = gtk_ctree_insert_node(GTK_CTREE (ctree_win.widget), parent_node, sibling, txt3[j], 5,
    pixmap, mask, pixmap, mask, FALSE, TRUE);
    gtk_ctree_node_set_row_data (GTK_CTREE(ctree_win.widget), sibling, *txt3[j]);
    }
    sibling=NULL;
    }
    gtk_ctree_select_recursive(GTK_CTREE (ctree_win.widget), parent_node);
    gtk_ctree_collapse(GTK_CTREE (ctree_win.widget), parent_node);
  */
  return;
}

/* Refresh the ctree */
void refresh_ctree(GtkWidget *widget)
{
  GdkPixmap *pixmap1, *pixmap2, *pixmap3, *pixmap4, *pixmap5;
  GdkBitmap *mask1, *mask2, *mask3, *mask4, *mask5;
  GtkCTreeNode *tifs_node, *parent_node, *child_node;
  GList *p;
  struct varinfo *q;
  gchar *tab[4];
  char buffer[16];
  int i;
  gchar *screen[]=
  {
    gettext_noop("Screen"),
    "",
    "" ,
    "" 
  };
  gchar *mem[]= 
  {
    gettext_noop("Memory"),
    gettext_noop(""),
    gettext_noop(""),
    gettext_noop("") 
  };
  gchar *tifs[]=
  {
    gettext_noop("TI variables"),
    gettext_noop(""),
    gettext_noop(""),
    gettext_noop("") 
  };
  tab[1]=NULL;

  switch(options.ctree_sort)
    {
    case SORT_BY_NAME:
      //sort_cfiles_by_name(ctree_win.varlist);
    case SORT_BY_INFO:
      sort_cfiles_by_info(ctree_win.varlist);
      break;
    case SORT_BY_TYPE:
      sort_cfiles_by_type(ctree_win.varlist);
      break;
    case SORT_BY_SIZE:
      sort_cfiles_by_size(ctree_win.varlist);
      break;
    }

  gtk_clist_freeze(GTK_CLIST (ctree_win.widget));
  gtk_clist_clear(GTK_CLIST (ctree_win.widget));

  gtk_widget_realize(widget);
  open_xpm("dir_c.xpm", widget, &pixmap1, &mask1);
  open_xpm("doc.xpm", widget, &pixmap2, &mask2);
  open_xpm("dir_o.xpm", widget, &pixmap3, &mask3);
  open_xpm("lock.xpm", widget, &pixmap4, &mask4);
  open_xpm("arch.xpm", widget, &pixmap5, &mask5);

  tifs_node=gtk_ctree_insert_node (GTK_CTREE (ctree_win.widget), NULL, NULL, screen, 5, 
				   pixmap1, mask1, pixmap2, mask2, FALSE, TRUE);
  gtk_ctree_node_set_row_data (GTK_CTREE(ctree_win.widget), tifs_node, (gpointer)NULL);
  gtk_ctree_node_set_selectable(GTK_CTREE(ctree_win.widget), tifs_node, 0);
  tifs_node=gtk_ctree_insert_node (GTK_CTREE (ctree_win.widget), NULL, NULL, mem, 5, 
				   pixmap1, mask1, pixmap2, mask2, FALSE, TRUE);
  gtk_ctree_node_set_row_data (GTK_CTREE(ctree_win.widget), tifs_node, (gpointer)NULL);
  gtk_ctree_node_set_selectable(GTK_CTREE(ctree_win.widget), tifs_node, 0);
  tifs_node=gtk_ctree_insert_node (GTK_CTREE (ctree_win.widget), NULL, NULL, tifs, 5, 
				   pixmap1, mask1, pixmap3, mask3, FALSE, TRUE);
  gtk_ctree_node_set_row_data (GTK_CTREE(ctree_win.widget), tifs_node, (gpointer)NULL);
  gtk_ctree_node_set_selectable(GTK_CTREE(ctree_win.widget), tifs_node, 0);
  
  p=ctree_win.varlist;
  parent_node=tifs_node;
  //printf("tifs node: %p\n", tifs_node);
  while(p != NULL)
    {
      q=(struct varinfo *)(p->data);
      /* Skip varnames with FLASH apps */
      if( (q->vartype) == TI89_FLASH ) 
	{
	  p=p->next;
	  continue;
	}
      //printf("<%8s> ", q->translate);
      tab[0]=(gchar *)gu_malloc((strlen(q->translate)+1)*sizeof(gchar));
      strcpy(tab[0], q->translate);
      //printf("<%8s> ", tab[0]);
      sprintf(buffer, "%s", ti_calc.byte2type(q->vartype));
      //printf("<%02X %8s>\n", q->vartype, buffer);
      //if( (q->vartype) == ti_calc.tixx_dir(options.lp.calc_type))
      if(q->is_folder == FOLDER)
	{
	  /*
	  tab[2]=(gchar *)gu_malloc((strlen(buffer)+1)*sizeof(gchar));
	  strcpy(tab[2], buffer);
	  */
	  tab[2]=NULL;
	  tab[3]=NULL;
	  parent_node=gtk_ctree_insert_node (GTK_CTREE (ctree_win.widget), tifs_node, NULL, tab, 5, 
				 pixmap1, mask1, pixmap3, mask3, FALSE, TRUE);
	  //printf("dir node: %p\n", parent_node);
	  gtk_ctree_node_set_row_data (GTK_CTREE(ctree_win.widget), parent_node, (gpointer)q);
	  gtk_ctree_node_set_selectable(GTK_CTREE(ctree_win.widget), tifs_node, 0);
	}
      else
	{
	  tab[2]=(gchar *)gu_malloc((strlen(buffer)+1)*sizeof(gchar));
	  strcpy(tab[2], buffer);
	  sprintf(buffer, "%u", (int)(q->varsize));
	  tab[3]=(gchar *)gu_malloc((strlen(buffer)+1)*sizeof(gchar));
	  strcpy(tab[3], buffer);	  
	  child_node=gtk_ctree_insert_node (GTK_CTREE (ctree_win.widget), parent_node, NULL, tab, 5, 
				 pixmap1, mask1, pixmap2, mask2, FALSE, TRUE);
	  //printf("child node: %p\n", child_node);
	  switch(q->varlocked)
	    {
	    case 1:
	      gtk_ctree_node_set_pixmap(GTK_CTREE (ctree_win.widget), child_node, 1, pixmap4, mask4);
	      break;
	    case 3:
	      gtk_ctree_node_set_pixmap(GTK_CTREE (ctree_win.widget), child_node, 1, pixmap5, mask5);
	      break;
	    }
	  gtk_ctree_node_set_row_data (GTK_CTREE(ctree_win.widget), child_node, (gpointer)q);
	}
      
      p=p->next;
      for(i=0; i<4; i++) gu_free(tab[i]);
    }

  gdk_pixmap_unref(pixmap1);
  gdk_pixmap_unref(pixmap2);
  gdk_pixmap_unref(pixmap3);
  gdk_pixmap_unref(pixmap4);
  gdk_pixmap_unref(pixmap5);

  gtk_clist_thaw(GTK_CLIST (ctree_win.widget));
}



