/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <gtk/gtk.h>

#include "defines.h"

void refresh_pbar()
{
  if(p_win.pbar != NULL) 
    {
      gtk_progress_bar_update(GTK_PROGRESS_BAR (p_win.pbar), 
			      info_update.percentage);
      while( gtk_events_pending() ) { gtk_main_iteration(); }
    }
  if(p_win.pbar2 != NULL)
    {
      gtk_progress_bar_update(GTK_PROGRESS_BAR (p_win.pbar2), 
			      info_update.main_percentage);
      while( gtk_events_pending() ) { gtk_main_iteration(); }
    }
}

void refresh_label()
{
  if(p_win.label == NULL) return;
  gtk_label_set(GTK_LABEL (p_win.label), info_update.label_text);
  while( gtk_events_pending() ) { gtk_main_iteration(); }
}

void refresh_gtk()
{
  while( gtk_events_pending() ) { gtk_main_iteration(); }
}

void refresh_gui()
{
  refresh_gtk();
}

void init_refresh_functions(void)
{
  set_update(&info_update, msg_box, refresh_pbar, 
	     refresh_label, refresh_gtk);

  return;
}
