/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <strings.h>
#include <stdlib.h>

/*
  !!! A very important remark !!!
  If a block has been allocated with g_malloc,
  it must be freed with g_free, NOT with free else it will 
  provoke a memory fault under Windows.
*/

#include "defines.h"

extern struct screenshot ti_screen;

/*
  This function create the screen capture window and do a first screen dump
*/
void screen_window(GtkWidget *widget, gpointer data)
{
  GtkWidget *window;
  GtkWidget *vbox;
  GtkWidget *toolbar;
  GtkWidget *pixmapwid;
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GtkStyle *style;
  GtkWidget *frame;
  //char buffer[MAXCHARS];

  /* Create the main window */
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_signal_connect_object(GTK_OBJECT(window), "destroy",
                     GTK_SIGNAL_FUNC(toolbar_button_22), GTK_OBJECT (window));
  gtk_window_set_title(GTK_WINDOW(window), gettext("Screen capture"));

  vbox = gtk_vbox_new(FALSE, 1);
  gtk_container_border_width(GTK_CONTAINER(vbox), 1);
  gtk_container_add(GTK_CONTAINER(window), vbox);
  gtk_widget_show(vbox);

  gtk_widget_realize (window);

  /* Create the toolbar */
  toolbar = gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_ICONS);
  gtk_toolbar_set_button_relief(GTK_TOOLBAR (toolbar), GTK_RELIEF_NONE);
  gtk_container_set_border_width(GTK_CONTAINER (toolbar), 5);
  gtk_toolbar_set_space_size(GTK_TOOLBAR (toolbar), 5);
  gtk_box_pack_start(GTK_BOX (vbox), toolbar, FALSE, FALSE, 0);

  /* Place a nice frame */
  frame=gtk_frame_new(gettext("Calculator screen"));
  gtk_container_set_border_width(GTK_CONTAINER(frame), 5);
  gtk_box_pack_start(GTK_BOX (vbox), frame, FALSE, FALSE, 5);
  gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_ETCHED_OUT);
  gtk_widget_show(frame);

  /* Get a screen capture */
  if(cb_screen_capture() != 0)
    return;

  /* Convert it into a pixmap and displays it */
  if(options.screen_clipping == FULL_SCREEN)
    ti_screen.pixmap=convert_bitmap_to_pixmap(ti_screen.bitmap, 
					      ti_screen.sc.width, 
					      ti_screen.sc.height);
  else
    ti_screen.pixmap=convert_bitmap_to_pixmap(ti_screen.bitmap, 
					      ti_screen.sc.clipped_width, 
					      ti_screen.sc.clipped_height);

  /* Display it */
  gtk_widget_realize(frame);
  style=gtk_widget_get_style(frame);
  pixmap=gdk_pixmap_create_from_xpm_d(frame->window, &mask, 
				      &style->bg[GTK_STATE_NORMAL], 
				      (gchar **)(ti_screen.pixmap));
  pixmapwid=gtk_pixmap_new(pixmap, mask);
  gtk_container_add(GTK_CONTAINER(frame), pixmapwid);
  gtk_widget_show(pixmapwid);

  /* Place the toolbar buttons */
  append_toolbar_button(window, &toolbar, "refresh.xpm",
                        gettext("Refresh"), gettext("Recapture"),
                        GTK_SIGNAL_FUNC (toolbar_button_20), pixmapwid);
  append_toolbar_button(window, &toolbar, "floppy.xpm",
                        gettext("Save"), gettext("Save capture"),
                        GTK_SIGNAL_FUNC (toolbar_button_21), 
			(ti_screen.pixmap));
  append_toolbar_button(window, &toolbar, "exit.xpm",
                        gettext("Quit"), gettext("Quit window"),
                        GTK_SIGNAL_FUNC (toolbar_button_22),
                        GTK_WINDOW(window));
  append_toolbar_button(window, &toolbar, "help.xpm",
                        gettext("Help"), gettext("Help me !!!"),
                        GTK_SIGNAL_FUNC (toolbar_button_23), NULL);
  gtk_widget_show(toolbar);
  gtk_widget_show(window);

  return;
}

/* 
   Screendump window: recapture button 
*/
void toolbar_button_20(GtkWidget *widget, gpointer data)
{
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GtkStyle *style;
  //char buffer[128];

  /* Get a screen capture */
  //free(ti_screen.bitmap);
  if(cb_screen_capture() != 0)
    return;

  /* Redisplays the pixmap */
  delete_pixmap(&(ti_screen.pixmap));

  if(options.screen_clipping == FULL_SCREEN)
    ti_screen.pixmap=convert_bitmap_to_pixmap(ti_screen.bitmap, 
					      ti_screen.sc.width, 
					      ti_screen.sc.height);
  else
    ti_screen.pixmap=convert_bitmap_to_pixmap(ti_screen.bitmap, 
					      ti_screen.sc.clipped_width, 
					      ti_screen.sc.clipped_height);
 
  gtk_widget_realize(widget);
  style=gtk_widget_get_style(widget);
  pixmap=gdk_pixmap_create_from_xpm_d(widget->window, &mask, 
				      &style->bg[GTK_STATE_NORMAL], 
				      (gchar **)(ti_screen.pixmap));
  gtk_pixmap_set(data, pixmap, mask);

  return; 
}

/* Screendump window: save button */
void toolbar_button_21(GtkWidget *widget, gpointer data)
{
  GtkWidget *filew;

  filew=gtk_file_selection_new(gettext("Save file"));
  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
		     "clicked", GTK_SIGNAL_FUNC (file_ok_sel_1), filew);
  gtk_signal_connect_object(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
			    "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			    GTK_OBJECT (filew));

  if(options.screen_format == XPM)
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), "screendump.xpm");
  else
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), "screendump.pcx");

  gtk_widget_show(filew);
}

/* Screendump window: quit button */
void toolbar_button_22(GtkWidget *widget, gpointer data)
{
  if((ti_screen.pixmap) != NULL)
    {
      delete_pixmap(&(ti_screen.pixmap));
    }  

  gtk_widget_destroy(data);
}

/* Screendump window: help button */
void toolbar_button_23(GtkWidget *widget, gpointer data)
{
  item_help_help(widget, data);
}



