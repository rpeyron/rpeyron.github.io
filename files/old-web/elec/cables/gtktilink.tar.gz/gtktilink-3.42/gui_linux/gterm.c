/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/* See <gdk/gdkkeysyms.h> for the definitions of the keys */

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

#include "defines.h"

#define REMOTE 1
#define TERM 2

static GtkWidget *term_window;
static GtkWidget *table;
static GdkColormap *cmap;
static GdkColor colour;
static GdkFont *fixed_font;
static GtkWidget *text;
static gint mode=REMOTE;

void item2_mode_exit(GtkWidget *widget, gpointer data)
{
  gtk_widget_destroy(term_window);
}

void item2_mode_remote(GtkWidget *widget, gpointer data)
{
  mode=REMOTE;
  gtk_text_freeze (GTK_TEXT (text));
  gtk_text_insert (GTK_TEXT (text), fixed_font, &colour, NULL,
		   "\nYou are in remote control mode.\nPress any key but for:\n- Shift, press the left Shift key\n- diamond, press the left Ctrl key\n- 2nd, press the right Alt key\n- APPS, press the F9 key\n- STO, press the F10 key\n- MODE, press the F11 key\n- CLEAR, press the F12 key\n- (-) negative, press the right enter key\nPlease click the text window to focus it.\n\n", -1);
  gtk_text_thaw (GTK_TEXT (text));

  return;
}

void item2_mode_term(GtkWidget *widget, gpointer data)
{
  mode=TERM;
  gtk_text_freeze (GTK_TEXT (text));
  gtk_text_insert (GTK_TEXT (text), fixed_font, &colour, NULL,
		   "\nYou are in terminal mode.\nPress any key but for:\n- Shift, press the left Shift key\n- diamond, press the left Ctrl key\n- 2nd, press the right Alt key\n- APPS, press the F9 key\n- STO, press the F10 key\n- MODE, press the F11 key\n- CLEAR, press the F12 key\n- (-) negative, press the right enter key\nPlease click the text window to focus it.\n\n", -1);
  gtk_text_thaw (GTK_TEXT (text));
  
  ti_calc.send_key(KEY92_F5);
  ti_calc.send_key(KEY92_CTRL);
  ti_calc.send_key(KEY92_LP);
  ti_calc.send_key(KEY92_r);

  return;
}

void item2_mode_leave(GtkWidget *widget, gpointer data)
{
  gtk_text_freeze (GTK_TEXT (text));
  gtk_text_insert (GTK_TEXT (text), fixed_font, &colour, NULL,
		   "\nYou are not in terminal mode any longer.\n\n", -1);
  gtk_text_thaw (GTK_TEXT (text));
  
  ti_calc.send_key(KEY92_F5);
  ti_calc.send_key(KEY92_CTRL);
  ti_calc.send_key(KEY92_LP);
  ti_calc.send_key(KEY92_r);

  return;
}

#ifdef __WIN32__
#include "../../ti_libs/calcs/keys89.h"
#include "../../ti_libs/calcs/keys92.h"
#endif
extern const struct ti_key TI89_KEYS[];

void key_pressed89(GtkWidget *widget, GdkEvent *event)
{
  GdkEventKey *key_event;
  static guint key=0;
  static guint subkey;
  static gint b=0;
  int err;

  gtk_text_freeze (GTK_TEXT (text));
  key_event=(GdkEventKey *) event;
  key=key_event->keyval;
  //printf("Key value: %8s %04X\n", gdk_keyval_name(key), key);

  switch(key)
    {
    case GDK_Shift_L:
      b=1;
      break;
    case GDK_Control_L:
      b=3;
      break;
    case GDK_Alt_L:
      b=2;
      break;
    default:
      break;
    }

  if(key & 0xFF00)
    {
      switch(key)
	{
	case GDK_BackSpace:
	  subkey=key & 0x00FF;
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI89_KEYS[subkey].key1, -1);
	  if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	  b=0;
	  break;
	case GDK_Return:
	  subkey=key & 0x00FF;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key((word)subkey))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_F1:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F1", -1);
	  if(error(err=ti_calc.send_key(KEY89_F1))) return;
	  b=0;
	  break;
	case GDK_F2:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F2", -1);
	  if(error(err=ti_calc.send_key(KEY89_F2))) return;
	  b=0;
	  break;
	case GDK_F3:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F3", -1);
	  if(error(err=ti_calc.send_key(KEY89_F3))) return;
	  b=0;
	  break;
	case GDK_F4:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F4", -1);
	  if(error(err=ti_calc.send_key(KEY89_F4))) return;
	  b=0;
	  break;
	case GDK_F5:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F5", -1);
	  if(error(err=ti_calc.send_key(KEY89_F5))) return;
	  b=0;
	  break;
	case GDK_F6:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F6", -1);
	  if(error(err=ti_calc.send_key(KEY89_F6))) return;
	  b=0;
	  break;
	case GDK_F7:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F7", -1);
	  if(error(err=ti_calc.send_key(KEY89_F7))) return;
	  b=0;
	  break;
	case GDK_F8:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F8", -1);
	  if(error(err=ti_calc.send_key(KEY89_F8))) return;
	  b=0;
	  break;
	case GDK_F9:
	  subkey=0x83;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY89_APPS))) return;
	      break;
	    }
	  b=0;
	  break;
	case GDK_F10:
	  subkey=0x87;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY89_STO))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_F11:
	  subkey=0x80;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY89_MODE))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_F12:
	  subkey=0x81;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY89_CLEAR))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Escape:
	  subkey=key & 0x00FF;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key((word)subkey))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Up:
	  subkey=0x90;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY89_UP))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Down:
	subkey=0x91;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY89_DOWN))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Left:
	  subkey=0x89;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY89_LEFT))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Right:
	  subkey=0x93;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY89_RIGHT))) return;
	      break;
	    } 
	  b=0;
	  break;
	default:
	  break;
	}
      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
		       " ", -1);      
      switch(key)
	{
	case GDK_KP_Decimal:
	  key=GDK_period;
	  break;
	case GDK_KP_Divide:
	  key=GDK_slash;
	  break;
	case GDK_KP_Multiply:
	  key=GDK_asterisk;
	  break;
	case GDK_KP_Subtract:
	  key=GDK_minus;
	  break;
	case GDK_KP_Add:
	  key=GDK_plus;
	  break;
	case GDK_KP_0:
	  key=GDK_0;
	  break;
	case GDK_KP_1:
	  key=GDK_1;
	  break;
	case GDK_KP_2:
	  key=GDK_2;
	  break;
	case GDK_KP_3:
	  key=GDK_3;
	  break;
	case GDK_KP_4:
	  key=GDK_4;
	  break;
	case GDK_KP_5:
	  key=GDK_5;
	  break;
	case GDK_KP_6:
	  key=GDK_6;
	  break;
	case GDK_KP_7:
	  key=GDK_7;
	  break;
	case GDK_KP_8:
	  key=GDK_8;
	  break;
	case GDK_KP_9:
	  key=GDK_9;
	  break;
	case GDK_KP_Enter:
	  subkey=0x89;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI89_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY89_NEG))) return;
	      break;
	    } 
	  b=0;
	  break;
	default:
	  break;
	}
    }
  if(!(key & 0xFF00))
    {
      if(key>=0x80) return;
      subkey=key & 0x00FF;
      switch(b)
	{
	case 1:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI89_KEYS[subkey].key1, -1);
	  if(error(err=ti_calc.send_key(TI89_KEYS[subkey].shift))) return;
	  break;
	case 2: 
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI89_KEYS[subkey].key2, -1);
	  if(error(err=ti_calc.send_key(TI89_KEYS[subkey].second))) return;
	  break;
	case 3: 
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI89_KEYS[subkey].key3, -1);
	  if(error(err=ti_calc.send_key(TI89_KEYS[subkey].diamond))) return;
	  break;
	default:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI89_KEYS[subkey].key_name, -1);
	  if(error(err=ti_calc.send_key((word)subkey))) return;
	 break;
       } 
      b=0;
    }
  
  gtk_text_thaw (GTK_TEXT (text));
  return; 
}

extern const struct ti_key TI92_KEYS[];

void key_pressed92(GtkWidget *widget, GdkEvent *event)
{
  GdkEventKey *key_event;
  static guint key=0;
  static guint subkey;
  static gint b=0;
  int err;

  gtk_text_freeze (GTK_TEXT (text));
  key_event=(GdkEventKey *) event;
  key=key_event->keyval;
  //printf("Key value: %8s %04X\n", gdk_keyval_name(key), key);

  switch(key)
    {
    case GDK_Shift_L:
      b=1;
      break;
    case GDK_Control_L:
      b=3;
      break;
    case GDK_Alt_L:
      b=2;
      break;
    default:
      break;
    }

  if(key & 0xFF00)
    {
      switch(key)
	{
	case GDK_BackSpace:
	  subkey=key & 0x00FF;
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI92_KEYS[subkey].key1, -1);
	  if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	  b=0;
	  break;
	case GDK_Return:
	  subkey=key & 0x00FF;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key((word)subkey))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_F1:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F1", -1);
	  if(error(err=ti_calc.send_key(KEY92_F1))) return;
	  b=0;
	  break;
	case GDK_F2:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F2", -1);
	  if(error(err=ti_calc.send_key(KEY92_F2))) return;
	  b=0;
	  break;
	case GDK_F3:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F3", -1);
	  if(error(err=ti_calc.send_key(KEY92_F3))) return;
	  b=0;
	  break;
	case GDK_F4:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F4", -1);
	  if(error(err=ti_calc.send_key(KEY92_F4))) return;
	  b=0;
	  break;
	case GDK_F5:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F5", -1);
	  if(error(err=ti_calc.send_key(KEY92_F5))) return;
	  b=0;
	  break;
	case GDK_F6:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F6", -1);
	  if(error(err=ti_calc.send_key(KEY92_F6))) return;
	  b=0;
	  break;
	case GDK_F7:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F7", -1);
	  if(error(err=ti_calc.send_key(KEY92_F7))) return;
	  b=0;
	  break;
	case GDK_F8:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   "F8", -1);
	  if(error(err=ti_calc.send_key(KEY92_F8))) return;
	  b=0;
	  break;
	case GDK_F9:
	  subkey=0x83;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY92_APPS))) return;
	      break;
	    }
	  b=0;
	  break;
	case GDK_F10:
	  subkey=0x87;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY92_STO))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_F11:
	  subkey=0x80;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY92_MODE))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_F12:
	  subkey=0x81;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY92_CLEAR))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Escape:
	  subkey=key & 0x00FF;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key((word)subkey))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Up:
	  subkey=0x90;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY92_UP))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Down:
	subkey=0x91;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY92_DOWN))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Left:
	  subkey=0x92;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY92_LEFT))) return;
	      break;
	    } 
	  b=0;
	  break;
	case GDK_Right:
	  subkey=0x93;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY92_RIGHT))) return;
	      break;
	    } 
	  b=0;
	  break;
	default:
	  break;
	}
      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
		       " ", -1);      
      switch(key)
	{
	case GDK_KP_Decimal:
	  key=GDK_period;
	  break;
	case GDK_KP_Divide:
	  key=GDK_slash;
	  break;
	case GDK_KP_Multiply:
	  key=GDK_asterisk;
	  break;
	case GDK_KP_Subtract:
	  key=GDK_minus;
	  break;
	case GDK_KP_Add:
	  key=GDK_plus;
	  break;
	case GDK_KP_0:
	  key=GDK_0;
	  break;
	case GDK_KP_1:
	  key=GDK_1;
	  break;
	case GDK_KP_2:
	  key=GDK_2;
	  break;
	case GDK_KP_3:
	  key=GDK_3;
	  break;
	case GDK_KP_4:
	  key=GDK_4;
	  break;
	case GDK_KP_5:
	  key=GDK_5;
	  break;
	case GDK_KP_6:
	  key=GDK_6;
	  break;
	case GDK_KP_7:
	  key=GDK_7;
	  break;
	case GDK_KP_8:
	  key=GDK_8;
	  break;
	case GDK_KP_9:
	  key=GDK_9;
	  break;
	case GDK_KP_Enter:
	  subkey=0x89;
	  switch(b)
	    {
	    case 1:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key1, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	      break;
	    case 2: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key2, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	      break;
	    case 3: 
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key3, -1);
	      if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	      break;
	    default:
	      gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			       TI92_KEYS[subkey].key_name, -1);
	      if(error(err=ti_calc.send_key(KEY92_NEG))) return;
	      break;
	    } 
	  b=0;
	  break;
	default:
	  break;
	}
    }
  if(!(key & 0xFF00))
    {
      if(key>=0x80) return;
      subkey=key & 0x00FF;
      switch(b)
	{
	case 1:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI92_KEYS[subkey].key1, -1);
	  if(error(err=ti_calc.send_key(TI92_KEYS[subkey].shift))) return;
	  break;
	case 2: 
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI92_KEYS[subkey].key2, -1);
	  if(error(err=ti_calc.send_key(TI92_KEYS[subkey].second))) return;
	  break;
	case 3: 
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI92_KEYS[subkey].key3, -1);
	  if(error(err=ti_calc.send_key(TI92_KEYS[subkey].diamond))) return;
	  break;
	default:
	  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
			   TI92_KEYS[subkey].key_name, -1);
	  if(error(err=ti_calc.send_key((word)subkey))) return;
	 break;
       } 
      b=0;
    }
  
  gtk_text_thaw (GTK_TEXT (text));
  return;
}

void terminal_window()
{
  GtkWidget *vbox;
  GtkWidget *vscrollbar;
  GtkWidget *menubar;
  /*
  GtkWidget *quit_menu;
  GtkWidget *mode_menu;
  GtkWidget *menu_bar;
  GtkWidget *root_quit_menu;
  GtkWidget *root_mode_menu;
  GtkWidget *exit_item;
  GtkWidget *remote_item;
  GtkWidget *term_item;
  */

  /* Create the window */
  term_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_usize (term_window, 600, 500);
  gtk_window_set_policy (GTK_WINDOW(term_window), TRUE, TRUE, FALSE); 
  gtk_signal_connect_object(GTK_OBJECT(term_window), "destroy",
			    gtk_widget_destroy, GTK_OBJECT (term_window));
  gtk_window_set_title(GTK_WINDOW(term_window), gettext("Remote control/terminal"));
  
  /* Create the vbox container */
  vbox = gtk_vbox_new(FALSE, 1);
  gtk_container_border_width(GTK_CONTAINER(vbox), 1);
  gtk_container_add(GTK_CONTAINER(term_window), vbox);
  gtk_widget_show(vbox);
  
  /* Place the menubar */

  get_main_menu2(main_window, &menubar);
  gtk_box_pack_start(GTK_BOX(vbox), menubar, FALSE, TRUE, 0);
  gtk_widget_show(menubar);

  /*
  quit_menu=gtk_menu_new();
  exit_item=gtk_menu_item_new_with_label("Exit");
  gtk_menu_append(GTK_MENU (quit_menu), exit_item);
  gtk_signal_connect(GTK_OBJECT (exit_item), "activate",
		     GTK_SIGNAL_FUNC (item_mode_exit), (gpointer)term_window);
  gtk_widget_show(exit_item);

  mode_menu=gtk_menu_new();
  remote_item=gtk_radio_menu_item_new_with_label(NULL, "Remote control");
  //gtk_toggle_button_set_active (GTK_RADIO_MENU_ITEM (remote_item), TRUE);
  term_item=gtk_radio_menu_item_new_with_label(gtk_radio_menu_item_group(GTK_RADIO_MENU_ITEM (remote_item)), "Terminal");
  gtk_menu_append(GTK_MENU (mode_menu), remote_item);
  gtk_menu_append(GTK_MENU (mode_menu), term_item);
  gtk_signal_connect_object(GTK_OBJECT (remote_item), "activate",
			    GTK_SIGNAL_FUNC (item_mode_remote), (gpointer)remote_item);
  gtk_signal_connect_object(GTK_OBJECT (term_item), "activate",
			    GTK_SIGNAL_FUNC (item_mode_term), (gpointer)term_item);
  gtk_widget_show(remote_item);
  gtk_widget_show(term_item);

  root_quit_menu = gtk_menu_item_new_with_label("Quit");
  gtk_widget_show(root_quit_menu);
  gtk_menu_item_set_submenu(GTK_MENU_ITEM (root_quit_menu), quit_menu);
  root_mode_menu = gtk_menu_item_new_with_label("Mode");
  gtk_widget_show(root_mode_menu);
  gtk_menu_item_set_submenu(GTK_MENU_ITEM (root_mode_menu), mode_menu);

  menu_bar = gtk_menu_bar_new();
  gtk_box_pack_start(GTK_BOX(vbox), menu_bar, FALSE, TRUE, 0);
  gtk_widget_show(menu_bar);

  gtk_menu_bar_append(GTK_MENU_BAR (menu_bar), root_quit_menu);
  gtk_menu_bar_append(GTK_MENU_BAR (menu_bar), root_mode_menu);
  */

  /* Create a table */
  table = gtk_table_new (2, 2, FALSE);
  gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
  gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
  gtk_box_pack_start (GTK_BOX (vbox), table, TRUE, TRUE, 0);
  gtk_widget_show (table);
  
  /* Create the GtkText widget */
  text = gtk_text_new (NULL, NULL);
  gtk_text_set_editable (GTK_TEXT (text), FALSE);
  gtk_text_set_word_wrap(GTK_TEXT (text), TRUE);
  gtk_table_attach (GTK_TABLE (table), text, 0, 1, 0, 1,
		    GTK_EXPAND | GTK_SHRINK | GTK_FILL,
		    GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  if( (options.lp.calc_type == CALC_TI92P) || 
      (options.lp.calc_type == CALC_TI92) )
    {
      gtk_signal_connect (GTK_OBJECT (text), "key_press_event",
			  GTK_SIGNAL_FUNC (key_pressed92), NULL);
    }
  else
    {
      gtk_signal_connect (GTK_OBJECT (text), "key_press_event",
			  GTK_SIGNAL_FUNC (key_pressed89), NULL);
    }
      gtk_widget_show (text);

  /* Add a vertical scrollbar to the GtkText widget */
  vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
  gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
		    GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_show (vscrollbar);

  /* Get the system colour map and allocate the colour red */
  cmap = gdk_colormap_get_system();
  colour.red = 0xffff;
  colour.green = 0;
  colour.blue = 0;
  if (!gdk_color_alloc(cmap, &colour)) 
    {
      gu_error("couldn't allocate colour");
    }

  /* Load a fixed font */
  //  fixed_font = gdk_font_load ("-misc-fixed-medium-r-*-*-*-140-*-*-*-*-*-*");
  fixed_font=gdk_font_load("-rli-ti92-calc-r-expanded--10-100-75-75-m-80-iso8859-1");

  /* Realizing a widget creates a window for it, ready for us to insert some text */
  gtk_widget_realize (text);

  /* Freeze the text widget, ready for multiple updates */
  gtk_text_freeze (GTK_TEXT (text));

  /* Insert some coloured text */
  /*
  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
		   "Supports ", -1);
  gtk_text_insert (GTK_TEXT (text), NULL, &colour, NULL,
		   "colored ", -1);
  gtk_text_insert (GTK_TEXT (text), NULL, &text->style->black, NULL,
		   "text and different ", -1);
  gtk_text_insert (GTK_TEXT (text), fixed_font, &text->style->black, NULL,
		   "fonts\n\n", -1);
  */
  item2_mode_remote(NULL, NULL);

  gtk_text_thaw (GTK_TEXT (text));

  gtk_widget_show(term_window);
}

