/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <strings.h>
#include <gtk/gtk.h>

#include "defines.h"

/* Create the info window */
void create_info(GtkWidget *widget)
{
  clabel_win.widget = gtk_table_new (5, 2, TRUE);
  gtk_widget_ref (clabel_win.widget);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.widget", clabel_win.widget,
                            (GtkDestroyNotify) gtk_widget_unref);
  //gtk_widget_show (clabel_win.widget);
  //gtk_container_add (GTK_CONTAINER (frame3), clabel_win.widget);

  clabel_win.label12 = gtk_label_new ("Number of folders:");
  gtk_widget_ref (clabel_win.label12);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label12", clabel_win.label12,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label12);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label12, 0, 1, 1, 2,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label12), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label12), 5, 0);

  clabel_win.label13 = gtk_label_new ("Number of variables:");
  gtk_widget_ref (clabel_win.label13);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label13", clabel_win.label13,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label13);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label13, 0, 1, 2, 3,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label13), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label13), 5, 0);

  clabel_win.label14 = gtk_label_new ("Memory used:");
  gtk_widget_ref (clabel_win.label14);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label14", clabel_win.label14,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label14);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label14, 0, 1, 3, 4,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label14), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label14), 5, 0);

  clabel_win.label15 = gtk_label_new ("Memory selected:");
  gtk_widget_ref (clabel_win.label15);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label15", clabel_win.label15,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label15);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label15, 0, 1, 4, 5,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label15), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label15), 5, 0);

  clabel_win.label22 = gtk_label_new ("Number of directories:");
  gtk_widget_ref (clabel_win.label22);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label22", clabel_win.label22,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label22);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label22, 1, 2, 1, 2,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label22), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label22), 5, 0);

  clabel_win.label23 = gtk_label_new ("Number of files");
  gtk_widget_ref (clabel_win.label23);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label23", clabel_win.label23,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label23);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label23, 1, 2, 2, 3,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label23), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label23), 5, 0);

  clabel_win.label24 = gtk_label_new ("Disk used:");
  gtk_widget_ref (clabel_win.label24);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label24", clabel_win.label24,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label24);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label24, 1, 2, 3, 4,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label24), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label24), 5, 0);

  clabel_win.label25 = gtk_label_new ("Memory selected:");
  gtk_widget_ref (clabel_win.label25);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label25", clabel_win.label25,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label25);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label25, 1, 2, 4, 5,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label25), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label25), 5, 0);

  clabel_win.label11 = gtk_label_new ("Current folder:");
  gtk_widget_ref (clabel_win.label11);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label11", clabel_win.label11,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label11);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label11, 0, 1, 0, 1,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_label_set_justify (GTK_LABEL (clabel_win.label11), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label11), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label11), 5, 0);

  clabel_win.label21 = gtk_label_new ("Current directory:");
  gtk_widget_ref (clabel_win.label21);
  gtk_object_set_data_full (GTK_OBJECT (widget), "clabel_win.label21", clabel_win.label21,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.label21);
  gtk_table_attach (GTK_TABLE (clabel_win.widget), clabel_win.label21, 1, 2, 0, 1,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (clabel_win.label21), 0, 0.5);
  gtk_misc_set_padding (GTK_MISC (clabel_win.label21), 5, 0);

  gtk_widget_show_all(clabel_win.widget);
}

/* Refresh the info window */
void refresh_info(GtkWidget *widget)
{
  gchar buffer[MAXCHARS];
  gint d=0, v=0;
  longword m=0;

  if(ctree_win.varlist != NULL)
    gu_snprintf(buffer, MAXCHARS, gettext("Current folder: %s"), ctree_win.cur_folder);
  else
    gu_snprintf(buffer, MAXCHARS, gettext("Current folder:"));
  gtk_label_set(GTK_LABEL (clabel_win.label11), buffer);
  /*
  p=ctree_win.varlist;
  d=0; v=0; m=0;
  while(p != NULL)
    {
      vi=(struct varinfo *)(p->data);
      //if( (vi->vartype) == ti_calc.tixx_dir(options.lp.calc_type))
      if(vi->is_folder == FOLDER)
	d++;
      else 
	v++;
      m+=(vi->varsize);

      p=p->next;
    }
  */
  number_of_folders_vars_and_mem(&d, &v, &m);
  gu_snprintf(buffer, MAXCHARS, gettext("Number of folders: %i"), d);
  gtk_label_set(GTK_LABEL (clabel_win.label12), buffer);
  gu_snprintf(buffer, MAXCHARS, gettext("Number of variables: %i"),v );
  gtk_label_set(GTK_LABEL (clabel_win.label13), buffer);
  gu_snprintf(buffer, MAXCHARS, gettext("Memory used: %i"), m);
  gtk_label_set(GTK_LABEL (clabel_win.label14), buffer);
  //gu_snprintf(buffer, MAXCHARS, gettext("Memory selected: %i"), gu_list_length(ctree_win.selection));
  //gtk_label_set(GTK_LABEL (clabel_win.label15), buffer);
  /*
  p=clist_win.dirlist;
  d=0; v=0; m=0; 
  while(p != NULL)
    {
      fi=(struct file_info *)(p->data);
      if( (fi->attrib & S_IFMT) == S_IFDIR ) d++;
      else v++;
      m+=(fi->size);      

      p=p->next;
    }
  d--;
  */
  number_of_directories_vars_and_mem(&d, &v, &m);
  gu_snprintf(buffer, MAXCHARS, gettext("Current directory: %s"), clist_win.cur_dir);
  gtk_label_set(GTK_LABEL (clabel_win.label21), buffer);
  gu_snprintf(buffer, MAXCHARS, gettext("Number of directories: %i"), d);
  gtk_label_set(GTK_LABEL (clabel_win.label22), buffer);
  gu_snprintf(buffer, MAXCHARS, gettext("Number of files: %i"), v);
  gtk_label_set(GTK_LABEL (clabel_win.label23), buffer);
  gu_snprintf(buffer, MAXCHARS, gettext("Disk used: %i"), m);
  gtk_label_set(GTK_LABEL (clabel_win.label24), buffer);
  //gu_snprintf(buffer, MAXCHARS, gettext("Memory selected: %i"), gu_list_length(clist_win.selection));
  //gtk_label_set(GTK_LABEL (clabel_win.label25), buffer);
}

/* Update the info window */
void update_info(GtkWidget *widget)
{

}

