/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>

#include "defines.h"

/****************************************/
/* User dialog boxes: 1, 2 or 3 buttons */
/****************************************/
void user_box_b1(GtkWidget *widget, int *i)
{
  *i=BUTTON1;
}

void user_box_b2(GtkWidget *widget, int *i)
{
  *i=BUTTON2;
}

void user_box_b3(GtkWidget *widget, int *i)
{
  *i=BUTTON3;
}

/********************************************************/
/* Config delay dialog box: ok, cancel and help buttons */
/********************************************************/
void entry_ok(GtkWidget *widget, struct edb *s)
{
  s->button=BUTTON1;
  s->text=gtk_entry_get_text(GTK_ENTRY(s->entry));
}

void entry_cancel(GtkWidget *widget, struct edb *s)
{
  s->button=BUTTON2;
}

/********************************************************/
/* Config delay dialog box: ok, cancel and help buttons */
/********************************************************/
void setup_delay_ok(GtkWidget *widget, struct dtdb *s)
{
  options.lp.delay=gtk_spin_button_get_value_as_int (
						  GTK_SPIN_BUTTON (s->spinbutton));
  set_delay(options.lp.timeout);
  gtk_widget_destroy(s->dialog);
  gu_free(s);
}

void setup_delay_cancel(GtkWidget *widget, struct dtdb *s)
{
  gtk_widget_destroy(s->dialog);
  gu_free(s);
}

/**********************************************************/
/* Config timeout dialog box: ok, cancel and help buttons */
/**********************************************************/
void setup_timeout_ok(GtkWidget *widget, struct dtdb *s)
{
  options.lp.timeout=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (s->spinbutton));
  set_timeout(options.lp.timeout);
  gtk_widget_destroy(s->dialog);
  gu_free(s);
}

void setup_timeout_cancel(GtkWidget *widget, struct dtdb *s)
{
  gtk_widget_destroy(s->dialog);
  gu_free(s);
}

/**********************************************************/
/* Config screen dialog box: ok, cancel and help buttons */
/**********************************************************/
void setup_screen_ok(GtkWidget *widget, struct ssdb *s)
{
  options.screen_format = s->image_format;
  options.screen_clipping = s->clipping;

  gtk_widget_destroy(s->dialog);
  gu_free(s);
}

void setup_screen_cancel(GtkWidget *widget, struct ssdb *s)
{
  gtk_widget_destroy(s->dialog);
  gu_free(s);
}

/*********************************************************/
/* General dialog box: ok, cancel and help buttons */
/*********************************************************/
void gdb_button1_clicked                     (GtkButton       *button, struct gdb *s)
{
  options.xsize=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (s->spinbutton1));
  options.ysize=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (s->spinbutton2));
  options.clist_sort=s->clist_sort;
  options.clist_sort_order=s->clist_sort_order;
  options.ctree_sort=s->ctree_sort;
  options.ctree_sort_order=s->ctree_sort_order;
  options.confirm=s->confirm;
  options.path_mode=s->path_mode;
  options.show=s->show;
  options.file_mode=s->file_mode;
  
  gtk_widget_destroy(s->dialog);
  gu_free(s);
}

void gdb_button2_clicked                     (GtkButton       *button, struct gdb *s)
{
  gtk_widget_destroy(s->dialog);
  gu_free(s);
}

void gdb_button3_clicked                     (GtkButton       *button, struct gdb *s)
{

}
