/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <strings.h>
#include <gtk/gtk.h>

#include "defines.h"

extern GtkWidget *log_list;
struct clist_window clist_win;

/* Add an item to the log list (bottom window) */
/*
void add_msg_to_log_list(char *msg)
{
  GtkWidget *list_item;

  list_item = gtk_list_item_new_with_label (msg);
  gtk_container_add (GTK_CONTAINER(log_list), list_item);
  gtk_widget_show (list_item);
}
*/

/* Create the clist window (right window) */
void create_clist (GtkWidget *widget)
{
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GtkWidget *pixmapwid;

  gchar *titles[] = {
      gettext_noop(""),
      gettext_noop("Filename"),
      gettext_noop("Date"),
      gettext_noop("Size"),
      gettext_noop("User"),
      gettext_noop("Group"),
      gettext_noop("Attributes") };
  int indx;
  gchar *drink[4][MAXCHARS] = { { "", "Toto", "3", "4", "5", "6", "7"},
				{ "", "Titi", "3", "4", "5", "6", "7"},
				{ "", "Tata", "3", "4", "5", "6", "7"},
				{ "", "Tutu", "3", "4", "5", "6", "7"} };
  
  //clist_win.sort=SORT_BY_NAME;
  clist_win.widget = gtk_clist_new_with_titles(7, titles);
  gtk_clist_set_shadow_type (GTK_CLIST (clist_win.widget), GTK_SHADOW_OUT);
  gtk_clist_set_column_width (GTK_CLIST (clist_win.widget), 0, 150);
  gtk_clist_set_selection_mode(GTK_CLIST (clist_win.widget), GTK_SELECTION_MULTIPLE);
  /*
  get_right_button_menu(&right_menu);
  gtk_signal_connect_object(GTK_OBJECT(clist_win.widget), "event",
                            GTK_SIGNAL_FUNC (right_button_event),
                            GTK_OBJECT(right_menu));
  */
  gtk_signal_connect (GTK_OBJECT (clist_win.widget), "button_press_event",
		      GTK_SIGNAL_FUNC (clist_button_press), NULL);
  gtk_signal_connect(GTK_OBJECT (clist_win.widget), "click_column", 
		     GTK_SIGNAL_FUNC(clist_click_column), NULL);
  gtk_signal_connect(GTK_OBJECT (clist_win.widget), "select_row", 
		     GTK_SIGNAL_FUNC(clist_select_row), NULL);
  gtk_signal_connect(GTK_OBJECT (clist_win.widget), "unselect_row", 
		     GTK_SIGNAL_FUNC(clist_unselect_row), NULL);

  gtk_clist_set_column_width(GTK_CLIST (clist_win.widget), 0, 16);
  gtk_clist_set_column_justification(GTK_CLIST (clist_win.widget), 0, GTK_JUSTIFY_LEFT);
  gtk_clist_set_column_width(GTK_CLIST (clist_win.widget), 1, 100);
  gtk_clist_set_column_justification(GTK_CLIST (clist_win.widget), 1, GTK_JUSTIFY_LEFT);
  gtk_clist_set_column_width(GTK_CLIST (clist_win.widget), 2, 85);
  gtk_clist_set_column_justification(GTK_CLIST (clist_win.widget), 2, GTK_JUSTIFY_LEFT);
  gtk_clist_set_column_width(GTK_CLIST (clist_win.widget), 3, 65);
  gtk_clist_set_column_justification(GTK_CLIST (clist_win.widget), 3, GTK_JUSTIFY_RIGHT);
  gtk_clist_set_column_width(GTK_CLIST (clist_win.widget), 4, 65);
  gtk_clist_set_column_justification(GTK_CLIST (clist_win.widget), 4, GTK_JUSTIFY_CENTER);
  gtk_clist_set_column_width(GTK_CLIST (clist_win.widget), 5, 80);
  gtk_clist_set_column_justification(GTK_CLIST (clist_win.widget), 5, GTK_JUSTIFY_CENTER);
  gtk_clist_set_column_width(GTK_CLIST (clist_win.widget), 6, 80);
  gtk_clist_set_column_justification(GTK_CLIST (clist_win.widget), 6, GTK_JUSTIFY_LEFT);

  open_xpm ("up.xpm", widget, &pixmap, &mask);
  pixmapwid=gtk_pixmap_new(pixmap, mask);
  gdk_pixmap_unref(pixmap);  
  gtk_widget_show(pixmapwid);
  gtk_clist_set_column_widget (GTK_CLIST (clist_win.widget), 0, pixmapwid);
    
  for (indx=0; indx<4; indx++)
    {
      gtk_clist_append( (GtkCList *) clist_win.widget, drink[indx]);
    }
}

/* Refresh the clist */
void refresh_clist(GtkWidget *widget)
{
  GdkPixmap *pixmap1, *pixmap2;
  GdkBitmap *mask1, *mask2;
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GtkWidget *pixmapwid;

  char *row_text[7];
  int i;
  char buffer[MAXCHARS];
  int row=0;
  struct file_info *fi;
  GList *dirlist;

  gtk_clist_freeze((GtkCList *)clist_win.widget);
  gtk_clist_clear((GtkCList *)clist_win.widget);
  gtk_signal_handler_block_by_func(GTK_OBJECT (clist_win.widget), clist_select_row, NULL);

  switch(options.clist_sort)
    {
    case SORT_BY_NAME:
      sort_lfiles_by_name(clist_win.dirlist);
      break;
    case SORT_BY_DATE:
      sort_lfiles_by_date(clist_win.dirlist);
      break;
    case SORT_BY_SIZE:
      sort_lfiles_by_size(clist_win.dirlist);
      break;
    case SORT_BY_USER:
      sort_lfiles_by_user(clist_win.dirlist);
      break;
    case SORT_BY_GROUP:
      sort_lfiles_by_group(clist_win.dirlist);
      break;
    case SORT_BY_ATTRB:
      sort_lfiles_by_attrib(clist_win.dirlist);
      break; 
    }

  pixmapwid = gtk_clist_get_column_widget (GTK_CLIST (clist_win.widget), 0);
  gtk_widget_destroy (pixmapwid);

  if(options.clist_sort_order)
    {
      clist_win.dirlist=gu_list_reverse(clist_win.dirlist);
      open_xpm ("down.xpm", widget, &pixmap, &mask);
      pixmapwid=gtk_pixmap_new(pixmap, mask);
      gdk_pixmap_unref(pixmap);
      gtk_widget_show(pixmapwid);
      gtk_clist_set_column_widget (GTK_CLIST (clist_win.widget), 0, pixmapwid);
    }
  else
    {
      open_xpm ("up.xpm", widget, &pixmap, &mask);
      pixmapwid=gtk_pixmap_new(pixmap, mask);
      gdk_pixmap_unref(pixmap);
      gtk_widget_show(pixmapwid);
      gtk_clist_set_column_widget (GTK_CLIST (clist_win.widget), 0, pixmapwid);
    }

  open_xpm("dir.xpm", widget, &pixmap1, &mask1);
  open_xpm("doc.xpm", widget, &pixmap2, &mask2);
  open_xpm("dotdot.xpm", widget, &pixmap, &mask);

  dirlist=clist_win.dirlist;
  while(dirlist!=NULL)
    {
      fi=dirlist->data;
      for(i=0; i<7; i++) { row_text[i]=NULL; }

      row_text[1]=(char *)gu_malloc((strlen(fi->filename)+1)*sizeof(char));
      strcpy(row_text[1], fi->filename);
      get_date(*fi, &row_text[2]);
      sprintf(buffer, "%ld", fi->size);
      row_text[3]=(char *)gu_malloc((strlen(buffer)+1)*sizeof(char));
      strcpy(row_text[3], buffer);
      get_user_name(*fi, &row_text[4]);
      get_group_name(*fi, &row_text[5]);
      row_text[6]=get_attributes(*fi);
      gtk_clist_append((GtkCList *)clist_win.widget, row_text);
      gtk_clist_set_row_data(GTK_CLIST (clist_win.widget), row, (gpointer)fi);
       
      if(row_text[6][1]=='d' && strcmp(fi->filename, ".."))
	{
	  gtk_clist_set_pixmap((GtkCList *)clist_win.widget, row, 0, pixmap1, mask1);
	  gtk_clist_set_selectable(GTK_CLIST (clist_win.widget), row, FALSE);
	}      
      else if(strcmp(fi->filename, ".."))
	{
	  gtk_clist_set_pixmap((GtkCList *)clist_win.widget, row, 0, pixmap2, mask2);
	}
      else
	{
	  gtk_clist_set_pixmap((GtkCList *)clist_win.widget, row, 0, pixmap, mask);
	  gtk_clist_set_selectable(GTK_CLIST (clist_win.widget), row, FALSE);
	}
      row++;
      for(i=0; i<7; i++) { g_free(row_text[i]); }

      dirlist=dirlist->next;
    }
  clist_selection_refresh();
  gtk_signal_handler_unblock_by_func(GTK_OBJECT (clist_win.widget), clist_select_row, NULL);
  gtk_clist_thaw((GtkCList *)clist_win.widget);
  gdk_pixmap_unref(pixmap);
  gdk_pixmap_unref(pixmap1);
  gdk_pixmap_unref(pixmap2);

}

/* Update the clist */
void update_clist(GtkWidget *widget)
{

}
