/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
  This file manages the main menu and the popup menu
*/

#include <gtk/gtk.h>
#include <stdio.h>

//#include <direct.h>

#include "defines.h"

/* This is the GtkItemFactoryEntry structure used to generate new menus.
   Item 1: The menu path. The letter after the underscore indicates an
           accelerator key once the menu is open.
   Item 2: The accelerator key for the entry
   Item 3: The callback function.
   Item 4: The callback action.  This changes the parameters with
           which the function is called.  The default is 0.
   Item 5: The item type, used to define what kind of an item it is.
           Here are the possible values:

           NULL               -> "<Item>"
           ""                 -> "<Item>"
           "<Title>"          -> create a title item
           "<Item>"           -> create a simple item
           "<CheckItem>"      -> create a check item
           "<ToggleItem>"     -> create a toggle item
           "<RadioItem>"      -> create a radio item
           <path>             -> path of a radio item to link against
           "<Separator>"      -> create a separator
           "<Branch>"         -> create an item to hold sub items
           "<LastBranch>"     -> create a right justified branch
*/

/****************************/
/* Menus of the main window */
/****************************/

/* Name of the menu */
static gchar *name_menu_items[] =
{
  gettext_noop("/_File"),
  gettext_noop("/File/_Open..."),
  gettext_noop("/File/_Save..."),
  gettext_noop("/File/Save _as..."),
  "/File/sep1",
  gettext_noop("/File/_Convert old files"),
  gettext_noop("/File/Un_zip archive"), 
  gettext_noop("/File/Un_group"),
  "/File/sep2",
  gettext_noop("/File/Save _config"),
  gettext_noop("/File/Reload confi_g"),
  gettext_noop("/File/_Default config"),
  "/File/sep3",
  gettext_noop("/File/_Quit"),

  gettext_noop("/_Setup"),
  gettext_noop("/_Setup/_General"),
  "/Setup/sep4",  
  gettext_noop("/_Setup/_Hardware & Calc"),
  gettext_noop("/_Setup/_Delay"),
  gettext_noop("/_Setup/_Timeout"),
  gettext_noop("/_Setup/_Screen capture"),
  "/Setup/sep5",
  gettext_noop("/_Setup/Probe _IO ports"),
  gettext_noop("/_Setup/Probe _link cable"),
  gettext_noop("/_Setup/Probe _calc type"),

  gettext_noop("/Func_tions"),
  gettext_noop("/Functions/_Ready ???"),
  gettext_noop("/Functions/_Terminal&Remote"),
  gettext_noop("/Functions/_Screen dump"),
  gettext_noop("/Functions/_Directory list"),
  "/Functions/sep6",
  gettext_noop("/Functions/Send backup..."),
  gettext_noop("/Functions/Receive backup"),
  "/Functions/sep7",
  gettext_noop("/Functions/Send variable"),
  gettext_noop("/Functions/Receive variable"),
  "/Functions/sep8",
  gettext_noop("/Functions/Send _FLASH..."),
  gettext_noop("/Functions/Send FLASH.../Send (free) _application..."),
  gettext_noop("/Functions/Send FLASH.../Send _Operating System..."),
  gettext_noop("/Functions/Get _IDlist"),

  gettext_noop("/_Misc"),
  gettext_noop("/Misc/ROM dump..."),
  gettext_noop("/Misc/ROM version"),
  "/Misc/sep1",
  gettext_noop("/Misc/Install FARGO II"),

  gettext_noop("/_Plug-ins"),
  gettext_noop("/Plug-ins/_Options"),
  gettext_noop("/Plug-ins/_Load"),
  gettext_noop("/Plug-ins/Lis_t..."),

  gettext_noop("/_Help"),
  gettext_noop("/Help/_Help"),
  "/Help/sep8",
  gettext_noop("/Help/_Thanks"),
  gettext_noop("/Help/_About")
};

/* Menu callbacks */
static GtkItemFactoryEntry menu_items[] = 
{
  /* File menu */
  {
    /* File parent item */
    NULL,
    NULL,         NULL,                 0, "<Branch>"
  },
  {
    /* File|open */
    NULL,
    "<control>O", item_file_open,       0, NULL
  },
  {
    /* File|save */
    NULL,   
    "<control>S", item_file_save,       0, NULL
  },
  {
    /* File|save as */
    NULL,
    NULL,         item_file_saveas,     0, NULL
  },
  {
    /* Separator */
    NULL,
    NULL,         NULL,                 0, "<Separator>"
  },
  {
    /* File|convert */
    NULL,
    NULL,         item_file_convert,    0, NULL
  },
  {
    /* File|unzip */
    NULL,   
    NULL,         item_file_unzip,      0, NULL
  },
  {
    /* File|ungroup */
    NULL,
    NULL,         item_file_unpack,     0, NULL
  },
  {
    /* Separator */
    NULL,
    NULL,         NULL,                 0, "<Separator>"
  },
  {
    /* File|Save Config */
    NULL,
    NULL,         item_file_saveconfig,     0, NULL
  },
  {
    /* File|Reload Config */
    NULL,
    NULL,         item_file_loadconfig,     0, NULL
  },
  {
    /* File|Default Config */
    NULL,
    NULL,         item_file_defaultconfig,     0, NULL
  },
  {
    /* Separator */
    NULL,
    NULL,         NULL,                 0, "<Separator>"
  },
  {
    /* File|Quit */
    NULL,
    "<control>Q", gtk_main_quit,        0, NULL
  },
  
  /* Setup menu */
  
  {
    /* Setup parent item */
    NULL,
    NULL,         NULL,                 0, "<Branch>"
  },
  {
    /* Setup|General */
    NULL,   
    NULL,         item_setup_general,   0, NULL
  },
  {
    /* Separator */
    NULL,  
    NULL,         NULL,                 0, "<Separator>"
  },
  {
    /* Setup|port */
    NULL,      
    NULL,         item_setup_port_calc,      0, NULL
  },
  {
    /* Setup|delay */
    NULL,    
    NULL,         item_setup_delay,     0, NULL
  },
  {
    /* Setup|timeout */
    NULL,
    NULL,         item_setup_timeout,   0, NULL
  },
  {
    /* Setup|screen capture */
    NULL,
    NULL,         item_setup_screen,   0, NULL
  },
  {
    /* Separator */
    NULL,
    NULL,         NULL,                 0, "<Separator>"
  },
  {
    /* Probe port */
    NULL,
    NULL,         item_setup_probe_ports,            0, NULL
  },
  {
    /* Probe link */
    NULL, 
    NULL,         item_setup_probe_cable,      0, NULL
  },
  {
    /* Probe calc */
    NULL,
    NULL,         item_setup_probe_calc,      0, NULL
  },
  
  /* Functions menu */
  
  {
    /* Function parent item */
    NULL,
    NULL, NULL,                         0, "<Branch>"
  },
  {
    /* Functions|ready */
    NULL,
    NULL, item_fncts_ready,             0, NULL
  },
  {
    /* Functions|terminal */
    NULL,
    NULL, item_fncts_terminal,            0, NULL
  },
  {
    /* Functions|screen */
    NULL,
    NULL, item_fncts_screen,            0, NULL
  },
  {
    /* Functions|dirlist */
    NULL,
    NULL, item_fncts_dirlist,           0, NULL
  },
  {
    /* Separator */
    NULL,
    NULL, NULL,                         0, "<Separator>"
  },
  {
    /* Functions|send backup */
    NULL,
    NULL, item_fncts_sbackup,           0, NULL
  },
  {
    /* Functions|receive backup */
    NULL,
    NULL, item_fncts_rbackup,           0, NULL
  },
  {
    /* Separator */
    NULL,
    NULL, NULL,                         0, "<Separator>"
  },
  {
    /* Functions|send var */
    NULL,
    NULL, item_fncts_svar,              0, NULL
  },
  {
    /* Functions|receive var */
    NULL,
    NULL, item_fncts_rvar,              0, NULL
  },
  {
    /* Separator */
    NULL,
    NULL, NULL,                         0, "<Separator>"
  },
  {
    /* Functions|send FLASH parent item */
    NULL,
    NULL,         NULL,                 0, "<Branch>"
  },
  {
    /* Functions|send FLASH app */
    NULL,
    NULL, item_fncts_sendFLASHapp,              0, NULL
  },
  {
    /* Functions|send FLASH OS */
    NULL,
    NULL, item_fncts_sendFLASHos,              0, NULL
  },
  {
    /* Functions|get ID */
    NULL,
    NULL, item_fncts_IDlist,              0, NULL
  },
  
  /* Misc menu */
  {
    /* Misc parent item */
    NULL,
    NULL,         NULL,                 0, "<Branch>"},
  {
    /* Misc|ROM dump */
    NULL,
    NULL, item_misc_ROMdump,              0, NULL
  },
  {
    /* Misc|ROM version */
    NULL,
    NULL, item_misc_ROMversion,              0, NULL
  },
  {
    /* Separator */
    NULL,
    NULL,         NULL,                 0, "<Separator>"
  },
#ifndef __WIN32__
  {
    /* Misc|Install Fargo2 */
    NULL,
    NULL, install_fargo,              0, NULL
  },
#else
  {
    /* Misc|Install Fargo2 */
    NULL,
    NULL, NULL,              0, NULL
  },
#endif
  
  /* Plug-ins menu */
  {
    /* Plugins parent item */
    /* Help parent item */
    NULL,
    NULL,         NULL,                 0, "<Branch>"
  },
  {
    /* Plugins|Options */
    NULL,
    NULL, item_plugins_options,       0, NULL
  },
  { 
    /* Plugins|Load */
    NULL,
    NULL, item_plugins_load,       0, NULL
  },
  {
    /* Plugins|List */
    NULL,
    NULL, item_plugins_list,       0, NULL
  },
  
  /* Help menu */
  
  {
    /* Help parent item */
    NULL,
    NULL,         NULL,                 0, "<LastBranch>"
  },
  {
    /* Help|help */
    NULL,
    "<control>H", item_help_help,       0, NULL
  },
  {
    /* Separator */
    NULL,
    NULL,         NULL,                 0, "<Separator>"
  },
  {
    /* Help|thanks */
    NULL,
    NULL,         item_help_thanks,      0, NULL
  },
  {
    /* Help|about */
    NULL,
    NULL,         item_help_about,      0, NULL
  }
};

/* Implementation of the menu */
void get_main_menu(GtkWidget *window, GtkWidget ** menubar) 
{
  int nmenu_items = sizeof(menu_items) / sizeof(menu_items[0]);
  GtkItemFactory *item_factory;
  GtkAccelGroup *accel_group;
  gint i; 
  
  for(i=0; i<nmenu_items; i++)
      {
          (menu_items[i]).path=name_menu_items[i];
      }
  
  accel_group = gtk_accel_group_new();
  item_factory = gtk_item_factory_new(GTK_TYPE_MENU_BAR, "<main>",
                                       accel_group);
  gtk_item_factory_create_items(item_factory, nmenu_items, menu_items, NULL);
  gtk_accel_group_attach (accel_group, GTK_OBJECT (window));
  if (menubar)
    {
      *menubar = gtk_item_factory_get_widget(item_factory, "<main>");
    }
}

/********************************/
/* Menus of the terminal window */
/********************************/
/* Name of menus */
static gchar *name_menu_items2[] =
{
  gettext_noop("/_Quit"),
  gettext_noop("/_Mode"),
  gettext_noop("/_Mode/_Remote control"),
  gettext_noop("/_Mode/_Terminal"),
  gettext_noop("/_Mode/_Leave"),
  gettext_noop("/_Help"),
  gettext_noop("/Help/_Help"),
  "/Help/sep8",
  gettext_noop("/Help/_About")
};

/* Menu callbacks */
static GtkItemFactoryEntry menu_items2[] = 
{
  /* Quit menu */
  {
    /* Quit */
    NULL,
    NULL,         item2_mode_exit,      0, "<Item>"},
  
  /* Mode menu */
  {
    /* Mode */
    NULL,
    NULL,         NULL,                 0, "<Branch>"},
  {
    /* Mode|remote */
    NULL,   
    NULL,         item2_mode_remote,    0, "<Item>"},
  {
    /* Mode|terminal */
    NULL,
    NULL,         item2_mode_term,      0, "<Item>"},
  { 
    /* Mode|leave */
    NULL,
    NULL,         item2_mode_leave,     0, "<Item>"},          
  /* Help menu */
  {
    /* Help parent item */
    NULL,
    NULL,         NULL,                 0, "<LastBranch>"},
  {
    /* Help|help */
    NULL,
    "<control>H", item_help_help,       0, NULL},
  {
    /* Separator */
    NULL,
    NULL,         NULL,                 0, "<Separator>"},
  {
    /* Help|about */
    NULL,
    NULL,         item_help_about,      0, NULL},
};

/* Implementation of the menu */
void get_main_menu2(GtkWidget *window, GtkWidget ** menubar) 
{
  int nmenu_items = sizeof(menu_items2) / sizeof(menu_items2[0]);
  GtkItemFactory *item_factory;
  GtkAccelGroup *accel_group;
  gint i; 
  
  for(i=0; i<nmenu_items; i++)
      {
	(menu_items2[i]).path=name_menu_items2[i];
      }
  
  accel_group = gtk_accel_group_new();
  item_factory = gtk_item_factory_new(GTK_TYPE_MENU_BAR, "<main>",
                                       accel_group);
  gtk_item_factory_create_items(item_factory, nmenu_items, menu_items2, NULL);
  gtk_accel_group_attach (accel_group, GTK_OBJECT (window));
  if (menubar)
    {
      *menubar = gtk_item_factory_get_widget(item_factory, "<main>");
    }

  accel_group = gtk_accel_group_new();
  item_factory = gtk_item_factory_new(GTK_TYPE_MENU_BAR, "<main>",
                                       accel_group);
  gtk_item_factory_create_items(item_factory, nmenu_items, menu_items2, NULL);
  gtk_accel_group_attach (accel_group, GTK_OBJECT (window));
  if (menubar)
    {
      *menubar = gtk_item_factory_get_widget(item_factory, "<main>");
    }
}

/*********************/
/* Right button menu */
/*********************/

GtkWidget* create_right_button_menu (void)
{
  GtkWidget *menu;
  GtkAccelGroup *menu_accels;
  GtkWidget *edit;
  GtkWidget *edit_menu;
  GtkAccelGroup *edit_menu_accels;
  GtkWidget *cut;
  GtkWidget *copy;
  GtkWidget *paste;
  GtkWidget *separator3;
  GtkWidget *move_to_parent_dir;
  GtkWidget *select_all1;
  GtkWidget *file;
  GtkWidget *file_menu;
  GtkAccelGroup *file_menu_accels;
  GtkWidget *unzip;
  GtkWidget *ungroup_or_unpack;
  GtkWidget *convert_tigl_gtktilink;
  GtkWidget *view;
  GtkWidget *separator4;
  GtkWidget *properties;
  GtkWidget *properties1;
  GtkWidget *update_window1;
  GtkWidget *make_new_directory1;
  GtkWidget *delete_file1;
  GtkWidget *calc;
  GtkWidget *calc_menu;
  GtkAccelGroup *calc_menu_accels;
  GtkWidget *insert_fargo;
  GtkWidget *change_drive;
#ifdef __WIN32__
  GtkWidget *change_drive_menu;
  GtkAccelGroup *change_drive_menu_accels;
  GtkWidget *c_drive;
  int ch, drive, curdrive;
  gchar buffer[8];
  gint available_drives[27]; // A..Z -> 26 letters
#endif

  menu = gtk_menu_new ();
  gtk_object_set_data (GTK_OBJECT (menu), "menu", menu);
  menu_accels = gtk_menu_ensure_uline_accel_group (GTK_MENU (menu));

  edit = gtk_menu_item_new_with_label ("Edit");
  gtk_widget_ref (edit);
  gtk_object_set_data_full (GTK_OBJECT (menu), "edit", edit,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (edit);
  gtk_container_add (GTK_CONTAINER (menu), edit);

  edit_menu = gtk_menu_new ();
  gtk_widget_ref (edit_menu);
  gtk_object_set_data_full (GTK_OBJECT (menu), "edit_menu", edit_menu,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (edit), edit_menu);
  edit_menu_accels = gtk_menu_ensure_uline_accel_group (GTK_MENU (edit_menu));

  cut = gtk_menu_item_new_with_label ("Cut");
  gtk_widget_ref (cut);
  gtk_object_set_data_full (GTK_OBJECT (menu), "cut", cut,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (cut);
  gtk_container_add (GTK_CONTAINER (edit_menu), cut);

  copy = gtk_menu_item_new_with_label ("Copy");
  gtk_widget_ref (copy);
  gtk_object_set_data_full (GTK_OBJECT (menu), "copy", copy,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (copy);
  gtk_container_add (GTK_CONTAINER (edit_menu), copy);

  paste = gtk_menu_item_new_with_label ("Paste");
  gtk_widget_ref (paste);
  gtk_object_set_data_full (GTK_OBJECT (menu), "paste", paste,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (paste);
  gtk_container_add (GTK_CONTAINER (edit_menu), paste);

  separator3 = gtk_menu_item_new ();
  gtk_widget_ref (separator3);
  gtk_object_set_data_full (GTK_OBJECT (menu), "separator3", separator3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (separator3);
  gtk_container_add (GTK_CONTAINER (edit_menu), separator3);
  gtk_widget_set_sensitive (separator3, FALSE);

  move_to_parent_dir = gtk_menu_item_new_with_label ("Move to parent dir");
  gtk_widget_ref (move_to_parent_dir);
  gtk_object_set_data_full (GTK_OBJECT (menu), "move_to_parent_dir", move_to_parent_dir,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (move_to_parent_dir);
  gtk_container_add (GTK_CONTAINER (edit_menu), move_to_parent_dir);

  select_all1 = gtk_menu_item_new_with_label ("Select all");
  gtk_widget_ref (select_all1);
  gtk_object_set_data_full (GTK_OBJECT (menu), "select_all1", select_all1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (select_all1);
  gtk_container_add (GTK_CONTAINER (edit_menu), select_all1);

  file = gtk_menu_item_new_with_label ("File");
  gtk_widget_ref (file);
  gtk_object_set_data_full (GTK_OBJECT (menu), "file", file,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (file);
  gtk_container_add (GTK_CONTAINER (menu), file);

  file_menu = gtk_menu_new ();
  gtk_widget_ref (file_menu);
  gtk_object_set_data_full (GTK_OBJECT (menu), "file_menu", file_menu,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (file), file_menu);
  file_menu_accels = gtk_menu_ensure_uline_accel_group (GTK_MENU (file_menu));

  unzip = gtk_menu_item_new_with_label ("Unzip");
  gtk_widget_ref (unzip);
  gtk_object_set_data_full (GTK_OBJECT (menu), "unzip", unzip,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (unzip);
  gtk_container_add (GTK_CONTAINER (file_menu), unzip);

  ungroup_or_unpack = gtk_menu_item_new_with_label ("Ungroup or Unpack");
  gtk_widget_ref (ungroup_or_unpack);
  gtk_object_set_data_full (GTK_OBJECT (menu), "ungroup_or_unpack", ungroup_or_unpack,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (ungroup_or_unpack);
  gtk_container_add (GTK_CONTAINER (file_menu), ungroup_or_unpack);

  convert_tigl_gtktilink = gtk_menu_item_new_with_label ("Convert TIGL|GtkTiLink");
  gtk_widget_ref (convert_tigl_gtktilink);
  gtk_object_set_data_full (GTK_OBJECT (menu), "convert_tigl_gtktilink", convert_tigl_gtktilink,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (convert_tigl_gtktilink);
  gtk_container_add (GTK_CONTAINER (file_menu), convert_tigl_gtktilink);

  view = gtk_menu_item_new_with_label ("View");
  gtk_widget_ref (view);
  gtk_object_set_data_full (GTK_OBJECT (menu), "view", view,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (view);
  gtk_container_add (GTK_CONTAINER (file_menu), view);

  separator4 = gtk_menu_item_new ();
  gtk_widget_ref (separator4);
  gtk_object_set_data_full (GTK_OBJECT (menu), "separator4", separator4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (separator4);
  gtk_container_add (GTK_CONTAINER (file_menu), separator4);
  gtk_widget_set_sensitive (separator4, FALSE);

  properties = gtk_menu_item_new_with_label ("Rename");
  gtk_widget_ref (properties);
  gtk_object_set_data_full (GTK_OBJECT (menu), "properties", properties,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (properties);
  gtk_container_add (GTK_CONTAINER (file_menu), properties);

  properties1 = gtk_menu_item_new_with_label ("Properties");
  gtk_widget_ref (properties1);
  gtk_object_set_data_full (GTK_OBJECT (menu), "properties1", properties1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (properties1);
  gtk_container_add (GTK_CONTAINER (file_menu), properties1);

  update_window1 = gtk_menu_item_new_with_label ("Update window");
  gtk_widget_ref (update_window1);
  gtk_object_set_data_full (GTK_OBJECT (menu), "update_window1", update_window1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (update_window1);
  gtk_container_add (GTK_CONTAINER (file_menu), update_window1);

  make_new_directory1 = gtk_menu_item_new_with_label ("Make new directory");
  gtk_widget_ref (make_new_directory1);
  gtk_object_set_data_full (GTK_OBJECT (menu), "make_new_directory1", make_new_directory1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (make_new_directory1);
  gtk_container_add (GTK_CONTAINER (file_menu), make_new_directory1);

  delete_file1 = gtk_menu_item_new_with_label ("Delete file");
  gtk_widget_ref (delete_file1);
  gtk_object_set_data_full (GTK_OBJECT (menu), "delete_file1", delete_file1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (delete_file1);
  gtk_container_add (GTK_CONTAINER (file_menu), delete_file1);

  calc = gtk_menu_item_new_with_label ("Calc");
  gtk_widget_ref (calc);
  gtk_object_set_data_full (GTK_OBJECT (menu), "calc", calc,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (calc);
  gtk_container_add (GTK_CONTAINER (menu), calc);

  calc_menu = gtk_menu_new ();
  gtk_widget_ref (calc_menu);
  gtk_object_set_data_full (GTK_OBJECT (menu), "calc_menu", calc_menu,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (calc), calc_menu);
  calc_menu_accels = gtk_menu_ensure_uline_accel_group (GTK_MENU (calc_menu));

  insert_fargo = gtk_menu_item_new_with_label ("Insert FARGO");
  gtk_widget_ref (insert_fargo);
  gtk_object_set_data_full (GTK_OBJECT (menu), "insert_fargo", insert_fargo,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (insert_fargo);
  gtk_container_add (GTK_CONTAINER (calc_menu), insert_fargo);

  change_drive = gtk_menu_item_new_with_label ("Change drive");
  gtk_widget_ref (change_drive);
  gtk_object_set_data_full (GTK_OBJECT (menu), "change_drive", change_drive,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (change_drive);
  gtk_container_add (GTK_CONTAINER (menu), change_drive);
#ifdef __WIN32__
  change_drive_menu = gtk_menu_new ();
  gtk_widget_ref (change_drive_menu);
  gtk_object_set_data_full (GTK_OBJECT (menu), "change_drive_menu", change_drive_menu,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (change_drive), change_drive_menu);
  change_drive_menu_accels = gtk_menu_ensure_uline_accel_group (GTK_MENU (change_drive_menu));
  
  curdrive = _getdrive();
  for(drive=1; drive<= 26; drive++) 
    available_drives[drive]=0;
  for( drive = 3; drive <= 26; drive++ )
    {
      if( !_chdrive( drive ) )
	{
	  g_snprintf(buffer, 8, "%c:", drive + 'A' - 1);
	  available_drives[drive] = drive + 'A' - 1;
	  c_drive = gtk_menu_item_new_with_label (buffer);
	  gtk_widget_ref (c_drive);
	  gtk_object_set_data_full (GTK_OBJECT (menu), "c_drive", c_drive,
				    (GtkDestroyNotify) gtk_widget_unref);
	  gtk_widget_show (c_drive);
	  gtk_container_add (GTK_CONTAINER (change_drive_menu), c_drive);
	  
	  gtk_signal_connect (GTK_OBJECT (c_drive), "activate",
			      GTK_SIGNAL_FUNC (rbm_change_drive_activate),
			      available_drives[drive]);
	}
    }
  _chdrive( curdrive );
#else
  gtk_signal_connect (GTK_OBJECT (change_drive), "activate",
		      GTK_SIGNAL_FUNC (rbm_change_drive_activate),
		      NULL);
#endif
  
  gtk_signal_connect (GTK_OBJECT (cut), "activate",
                      GTK_SIGNAL_FUNC (rbm_cut_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (copy), "activate",
                      GTK_SIGNAL_FUNC (rbm_copy_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (paste), "activate",
                      GTK_SIGNAL_FUNC (rbm_paste_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (move_to_parent_dir), "activate",
                      GTK_SIGNAL_FUNC (rbm_move_to_parent_dir_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (select_all1), "activate",
                      GTK_SIGNAL_FUNC (rbm_select_all1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (unzip), "activate",
                      GTK_SIGNAL_FUNC (rbm_unzip_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (ungroup_or_unpack), "activate",
                      GTK_SIGNAL_FUNC (rbm_ungroup_or_unpack_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (convert_tigl_gtktilink), "activate",
                      GTK_SIGNAL_FUNC (rbm_convert_tigl_gtktilink_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (view), "activate",
                      GTK_SIGNAL_FUNC (rbm_view_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (properties), "activate",
                      GTK_SIGNAL_FUNC (rbm_properties_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (properties1), "activate",
                      GTK_SIGNAL_FUNC (rbm_properties1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (update_window1), "activate",
                      GTK_SIGNAL_FUNC (rbm_update_window1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (make_new_directory1), "activate",
                      GTK_SIGNAL_FUNC (rbm_make_new_directory1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (delete_file1), "activate",
                      GTK_SIGNAL_FUNC (rbm_delete_file1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (insert_fargo), "activate",
                      GTK_SIGNAL_FUNC (rbm_insert_fargo_activate),
                      NULL);

  return menu;
}
