/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef WIN32
#include <direct.h>
#endif

#include "defines.h"

/* File menu */

void item_file_open(GtkWidget *widget, gpointer data)
{
  msg_box(gettext("Information"), 
  gettext("This function is not yet available."));

}

void item_file_save(GtkWidget *widget, gpointer data)
{
  msg_box(gettext("Information"), 
	  gettext("This function is not yet available."));
}

void item_file_saveas(GtkWidget *widget, gpointer data)
{
  msg_box(gettext("Information"), 
	  gettext("This function is not yet available."));
}

void item_file_convert(GtkWidget *widget, gpointer data)
{
  GList *ptr;
  struct file_info *f=NULL;
  char buffer[256];
  
  if(clist_win.selection==NULL) return;

  ptr=clist_win.selection;
  while(ptr!=NULL)
    {
      f=(struct file_info *)ptr->data;
      printf("<%s>\n", f->filename);
      switch(options.lp.calc_type)
	{
	case CALC_TI82:
	  error(ti82_gtl_to_tigl(f->filename, buffer));
	  break;
	case CALC_TI83:
	  error(ti83_gtl_to_tigl(f->filename, buffer));
	case CALC_TI85:
	  msg_box(gettext("Information"), 
		  gettext("This function is not yet available."));
	  //error(ti85_gtl_to_tigl(f->filename, buffer));
	  break;
	case CALC_TI86:
	  msg_box(gettext("Information"), 
		  gettext("This function is not yet available."));
	  //error(ti86_gtl_to_tigl(f->filename, buffer));
	default:
		break;
	}
      
      ptr=ptr->next;
    }
  /*
    filew=gtk_file_selection_new(gettext("Open a file"));
    
    gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
    "clicked", GTK_SIGNAL_FUNC (file_ok_sel_6), filew);
    gtk_signal_connect_object(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
    "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (filew));
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), "test.PAK");
    gtk_widget_show(filew);
  */
  
  return;
}

void item_file_unzip(GtkWidget *widget, gpointer data)
{
#ifndef WIN32
  gchar cmdline[MAXCHARS];
  gchar buffer[MAXCHARS];
  gint n;
  FILE *p;
  GList *ptr;
  struct file_info *f;
  int ret;

  if(clist_win.selection==NULL) return;

  ptr=clist_win.selection;
  while(ptr!=NULL)
    {
      f=(struct file_info *)ptr->data;
      printf("File to unzip: <%s>\n", f->filename);
      /* Unzip file and overwrite it if exists */
      /*
	if(options.confirm == CONFIRM_YES)
	{
	sprintf(cmdline, "unzip %s", f->filename);
	p = popen(cmdline,"r");
	
	while( (n = fread(buffer, sizeof(gchar), 255, p)) > 0 )
	{  
	buffer[n-1] ='\0';
	printf("%s", buffer);
	}
	}
	else
	{
	}
      */
      sprintf(cmdline, "unzip -o %s", f->filename);
      p = popen(cmdline,"r");
      if(p == NULL)
	{
	  msg_box(gettext("Error"), 
		  gettext("Unable to unzip the file."));
	  return;
	}
      
      while( (n = fread(buffer, sizeof(gchar), 255, p)) > 0 )
	{  
	  buffer[n-1] ='\0';
	  printf("%s", buffer);
	}
      ret = pclose(p);
      if(ret == -1)
	{
	  msg_box(gettext("Error"), 
		  gettext("There was some errors with unzip."));
	  return;
	}
      
      ptr=ptr->next;
    }
#else
  msg_box(gettext("Information"), 
	  gettext("This function is not yet available in the Windows version."));
#endif
  refresh_clist(main_window);

  return;
}

void item_file_unpack(GtkWidget *widget, gpointer data)
{
  GtkWidget *filew;

  filew=gtk_file_selection_new(gettext("Open a file"));
  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
                     "clicked", GTK_SIGNAL_FUNC (file_ok_sel_5), filew);
  gtk_signal_connect_object(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
                            "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (filew));
  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), "*.PAK");
  gtk_widget_show(filew);
}

void item_file_saveconfig(GtkWidget *widget, gpointer data)
{
  cb_save_config_file();
}

void item_file_loadconfig(GtkWidget *widget, gpointer data)
{
  cb_load_config_file();
}

void item_file_defaultconfig(GtkWidget *widget, gpointer data)
{
  cb_default_config();
}

/* Setup menu */

void item_setup_general(GtkWidget *widget, gpointer data)
{
  dlgbox_setup_general(widget, data);
}

void item_setup_port_calc(GtkWidget *widget, gpointer data)
{
  gint valid = FALSE;
  
  /* Display the box and wait a button action */
  valid = dlgbox_setup_port_calc(&(options.lp));
  if(valid)
    {
      /* and setup the link & calc */
      if( (error(link_cable.term_port(options.lp.io_addr, options.lp.device))) ) 
	return;
      set_cable(options.lp.link_type, &link_cable);
      set_calc(options.lp.calc_type, &ti_calc, &link_cable);
      check_access();
      if( (error(link_cable.init_port(options.lp.io_addr, options.lp.device))) ) 
	return;
      refresh_sensitive_toolbar_buttons();
    }
}

void item_setup_delay(GtkWidget *widget, gpointer data)
{
  dlgbox_setup_delay(widget, data);
}

void item_setup_timeout(GtkWidget *widget, gpointer data)
{
  dlgbox_setup_timeout(widget, data);
}

void item_setup_screen(GtkWidget *widget, gpointer data)
{
  dlgbox_setup_screen(widget, data);
}

void item_setup_probe_calc(GtkWidget *widget, gpointer data)
{
  cb_probe_calc();
}
void item_setup_probe_cable(GtkWidget *widget, gpointer data)
{
  cb_probe_cable();
}
void item_setup_probe_ports(GtkWidget *widget, gpointer data)
{
  cb_probe_port();
}

/* Functions menu */

void item_fncts_ready(GtkWidget *widget, gpointer data)
{
  if(cb_calc_is_ready() != 0)
	  return;
}

void item_fncts_terminal(GtkWidget *widget, gpointer data)
{
	/*
  if(p_win.is_active) 
	  return;
	  */
	if(is_active)
		return;
  terminal_window();
  
  return;    
}

void item_fncts_screen(GtkWidget *widget, gpointer data)
{
  if(p_win.is_active) return;
  toolbar_button_02(widget, data);
}

void item_fncts_dirlist(GtkWidget *widget, gpointer data)
{
  if(cb_dirlist() != 0)
	  return;

  refresh_ctree(main_window);
  refresh_info(main_window);
}

void item_fncts_sbackup(GtkWidget *widget, gpointer data)
{
  GtkWidget *filew;
  gchar buffer[MAXCHARS];

  if(p_win.is_active) return;  
  filew=gtk_file_selection_new(gettext("Open a file"));
  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
		     "clicked", GTK_SIGNAL_FUNC (file_ok_sel_2), filew);
  gtk_signal_connect_object(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
			    "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (filew));
  
  strcpy(buffer, "*.");
  strcat(buffer, ti_calc.backup_file_ext(options.lp.calc_type));
  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), buffer);
  gtk_widget_show(filew);
}

void item_fncts_rbackup(GtkWidget *widget, gpointer data)
{
  GtkWidget *filew;
  gchar buffer[MAXCHARS];

  if(cb_receive_backup() != 0)
	  return;

  filew=gtk_file_selection_new(gettext("Save file"));
  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
		     "clicked", GTK_SIGNAL_FUNC (file_ok_sel_3), filew);
  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
		     "clicked", GTK_SIGNAL_FUNC (file_cancel_sel_3), filew);
  strcpy(buffer, "backup.");
  strcat(buffer, ti_calc.backup_file_ext(options.lp.calc_type));
  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), buffer);
  gtk_widget_show(filew);

  return;
}

void item_fncts_svar(GtkWidget *widget, gpointer data)
{
  if(cb_send_var() != 0)
	  return;

  clist_selection_destroy(); // GUI independant
  clist_selection_refresh(); // GUI dependant

  return;
}

void item_fncts_rvar(GtkWidget *widget, gpointer data)
{
  GtkWidget *filew;
  gchar buffer[MAXCHARS];
  gchar varname[MAXCHARS];
  int to_save;

  if(cb_receive_var(&to_save) != 0)
	  return;
  
  if(to_save)
    {
      switch(options.lp.calc_type)
	{
	case CALC_TI83:
	case CALC_TI83P:
	case CALC_TI86:
	case CALC_TI89:
	case CALC_TI92:
	case CALC_TI92P:
	  filew=gtk_file_selection_new(gettext("Save a file"));
	  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
			     "clicked", GTK_SIGNAL_FUNC (file_ok_sel_4), filew);
	  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
			     "clicked", GTK_SIGNAL_FUNC (file_cancel_sel_4), filew);
	  
	  strcpy(buffer, "group.");
	  strcat(buffer, ti_calc.group_file_ext(options.lp.calc_type));
	  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), buffer);
	  gtk_widget_show(filew);      
	  break;
	case CALC_TI82:
	case CALC_TI85:
	  if(varname[0] != '\0')
	    break;
	  filew=gtk_file_selection_new(gettext("Save a file"));
	  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
			     "clicked", GTK_SIGNAL_FUNC (file_ok_sel_4), filew);
	  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
			     "clicked", GTK_SIGNAL_FUNC (file_cancel_sel_4), filew);
	  
	  strcpy(buffer, "group.");
	  strcat(buffer, ti_calc.group_file_ext(options.lp.calc_type));
	  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), buffer);
	  gtk_widget_show(filew);
	  break;
	}
    }
  
  ctree_selection_destroy();
  ctree_selection_refresh();
  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);

  return;
}

void item_fncts_sendFLASHapp(GtkWidget *widget, gpointer data)
{
  GtkWidget *filew;
  gchar buffer[MAXCHARS];
  char *msg="You are going to send a FLASH application on your calculator.\nHe is strongly recommended (especially Windows users, Linux users do not have to worry !) to close any application, to maximise the GtkTiLink main window and eventually turn off your screen saver. Tests have been made on a PC350 Mhz & Grey TIGL without any problems.";
  gint ret;
  
  if(is_active) 
    return;  

  ret=user2_box(gettext("Warning"), msg,
		gettext(" Continue "), gettext(" Cancel "));
  if(ret == BUTTON2)
    return;
  
  filew=gtk_file_selection_new(gettext("Open a file"));
  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
		     "clicked", GTK_SIGNAL_FUNC (file_ok_sel_8), filew);
  gtk_signal_connect_object(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
			    "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (filew));
  
  strcpy(buffer, "*.");
  strcat(buffer, ti_calc.flash_app_file_ext(options.lp.calc_type));
  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), buffer);
  gtk_widget_show(filew);
} 

void item_fncts_sendFLASHos(GtkWidget *widget, gpointer data)
{
  GtkWidget *filew;
  gchar buffer[MAXCHARS];
  char *msg="You are going to FLASH the Operating System of your calculator.\nHe is strongly recommended (especially Windows users, Linux users do not have to worry !) to close any application, to maximise the GtkTiLink main windowand to turn off your screen saver. Tests have been made on a PC350 Mhz & Grey TIGL without any problems. If the transfer crashes, wait until the TI89 displays 'Waiting to receive' and try the transfer again.";
  gint ret;

  if(is_active) 
    return;  
  
  ret=user2_box(gettext("Warning"), msg,
		gettext(" Continue "), gettext(" Cancel "));
  if(ret == BUTTON2)
    return;
  
  filew=gtk_file_selection_new(gettext("Open a file"));
  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
		     "clicked", GTK_SIGNAL_FUNC (file_ok_sel_9), filew);
  gtk_signal_connect_object(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
			    "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (filew));
  
  strcpy(buffer, "*.");
  strcat(buffer, ti_calc.flash_os_file_ext(options.lp.calc_type));
  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), buffer);
  gtk_widget_show(filew);
} 

void item_fncts_IDlist(GtkWidget *widget, gpointer data)
{
  if(cb_id_list() != 0)
    return;
}

/* Misc menu */

void item_misc_ROMdump(GtkWidget *widget, gpointer data)
{
  gint ret;
  gint rom_size;
  GtkWidget *filew;
  FILE *dump;
  int err=0;
  gchar tmp_filename[MAXCHARS];
  gchar buffer[MAXCHARS];

  if(p_win.is_active) return;
  
  /* Display an information dialog box */
  ret = user2_box(gettext("Information"), gettext("You must have FARGO to be installed on your calculator as well as the romdump1() program in order to do a ROM dump."),
		gettext(" Next > "), gettext(" Cancel "));
  switch(ret)
    {
    case BUTTON1: // OK/Next
      /* Ask for the ROM size */
      ret = rom_dump_choose_size();
      if(!ret)
	return;
      else
	{
	  printf("ROM size: %i Mb\n", ret);
	  rom_size = 1024 * 1024 * ret;
	  /* Display progression */
	  //rom_dump_receive();
	  switch(options.lp.calc_type)
	    {
	    case CALC_TI89:
	    case CALC_TI92P:
	    case CALC_TI92:
	      create_pbar_type4(gettext("ROM dump"), 
				gettext("Receiving bytes"));
	      break;
	    } 
	  
	  strcpy(tmp_filename, gu_get_tmp_dir());
	  strcat(tmp_filename, DIR_SEPARATOR);
	  strcat(tmp_filename, "gtktilink.ROMdump");
	  do
	    {
	      while( gtk_events_pending() ) { gtk_main_iteration(); }
	      if(info_update.cancel) break;
		err = open_ti_file(tmp_filename, "wb", &dump);
	  if(error(err)) return;
/*
	      if( ((dump=fopen(tmp_filename, "wb")) == NULL) )
		{
		  gu_error(gettext("Unable to open a temporary file\n"));
		}
		*/
	      err=ti_calc.dump_rom(dump, ret);
	      fclose(dump);
	    }
	  while( ((err == 35) || (err == 3)) );
	  
	  switch(options.lp.calc_type)
	    {
	    case CALC_TI89:
	    case CALC_TI92P:
	    case CALC_TI92:
	      destroy_pbar_type4();
	      break;
		}
	  if(error(err)) return;
	  
	  filew=gtk_file_selection_new(gettext("Save file"));
	  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button), 
			     "clicked", GTK_SIGNAL_FUNC (file_ok_sel_7), filew);
	  gtk_signal_connect(GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
			     "clicked", GTK_SIGNAL_FUNC (file_cancel_sel_7), filew);
	  strcpy(buffer, "romdump");
	  strcat(buffer, ".rom");
	  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), buffer);
	  gtk_widget_show(filew);
	  
	}
      break;
    default: // Cancel */
      return;
      break;
    }

  return;
}

void item_misc_ROMversion(GtkWidget *wdiget, gpointer data)
{
  if(cb_rom_version() != 0)
	  return;
}

/* Plug-ins menu */

void item_plugins_options(GtkWidget *widget, gpointer data)
{
  create_plugins_options_dbox ();  
}

void item_plugins_load(GtkWidget *widget, gpointer data)
{

}

void item_plugins_list(GtkWidget *widget, gpointer data)
{
  create_list_plugins();
}

/* Help menu */

void item_help_help(GtkWidget *widget, gpointer data)
{
  dlgbox_help_help(widget, data);
}

void item_help_thanks(GtkWidget *widget, gpointer data)
{
  dlgbox_help_thanks(widget, data);
}

void item_help_about(GtkWidget *widget, gpointer data)
{
  dlgbox_help_about(widget, data);
}

/* Right button menu */

void item_rb_view(GtkWidget *widget, gpointer data)
{
  msg_box(gettext("Information"), 
	  gettext("This function is not yet available."));
}


void item_rb_unpack(GtkWidget *widget, gpointer data)
{
  GList *p;
  struct file_info *f;

  if(clist_win.selection==NULL) return;  
  p=clist_win.selection;
  while(p != NULL)
    {
      f=(struct file_info *)(p->data);
      explode_pak_file(f->filename);

      p=p->next;
    }

  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);

  return;
}

/* No longer used */
/* Search if the variable is already in the calc and if yes, give a choice */
gint send_variable(FILE *txt, GList *ptr, gint mvar)
{
  int err;
  gchar buffer[MAXCHARS];
  gint ret, skip=0;
  gchar *dirname;
  gchar tmp_filename[MAXCHARS];
  gchar varname[18];
  
  if( (options.confirm == CONFIRM_YES) && (options.lp.calc_type != CALC_TI82) && (options.lp.calc_type != CALC_TI85) )
    {
      /* Retrieve the varname of the variable contained in the file */
      varname_in_file(txt, varname);
      //printf("Varname in file: <%s>\n", varname);
      if(is_varname_in_ctree(varname))
	{
	  sprintf(buffer, gettext("The variable %s already exists."), 
		  varname);
	  ret=user3_box(gettext("Warning"), buffer, 
			gettext(" Overwrite "), gettext(" Rename "),
			gettext(" Skip "));
	  switch(ret)
	    {
	    case BUTTON1:
	      skip=0;
	      break;
	    case BUTTON2:
	      dirname=dlgbox_entry(gettext("Rename the file"), 
				   gettext("New name: "), varname);
	      if(dirname == NULL) return -1;
	      strcpy(tmp_filename, gu_get_tmp_dir());
		  strcat(tmp_filename, DIR_SEPARATOR);
	      strcat(tmp_filename, "gtktilink.tmp");
	      rename_variable(txt, tmp_filename, dirname);
		  err = open_ti_file(tmp_filename, "rb", &txt);
	  if(error(err)) return err;
		  /*
	      if((txt=fopen(tmp_filename, "rb")) == NULL)
		{
		  gu_error(gettext("Unable to open this file: %s.\n"), tmp_filename);
		}   
		*/
	      gu_free(dirname);
	      skip=0;
	      break;
	    case BUTTON3:
	      skip=1;
	      break;
	    }
	}
    }
  if(skip == 0)
    {      
      if(options.lp.calc_type != CALC_TI82 && options.lp.calc_type != CALC_TI85)
	{
	  err=ti_calc.send_var(txt, MODE_LOCAL_PATH & options.path_mode);
	}
      else
	{
	  err=ti_calc.send_var(txt, MODE_LOCAL_PATH & options.path_mode);
	}
      if(error(err))
	{
	  //fclose(txt);
		  close_ti_file();
	  return err;
	}
    }  
  //usleep(100000);

  return 0;
}

/*******************************/
/* Right button menu callbacks */
/*******************************/
void
rbm_cut_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  clist_win.copy_cut = CUT_FILE;

  return;
}


void
rbm_copy_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  clist_win.copy_cut = COPY_FILE;

  return;
}


void
rbm_paste_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  GList *ptr;
  gchar *src;
  gchar *dest;
  
  /* If no selection, quits */
  if(clist_win.file_selection == NULL) return;
  /* Move every file */
  ptr=clist_win.file_selection;
  while(ptr != NULL)
    {
      src=(gchar *)(ptr->data);
      dest = (gchar *)g_malloc((strlen(clist_win.cur_dir)+1+strlen(src)+1)*sizeof(gchar));
      strcpy(dest, clist_win.cur_dir);
#ifndef WIN32
      strcat(dest, "/");
#else
      strcat(dest, "\\");
#endif
      strcat(dest, g_basename(src));

      if(clist_win.copy_cut == COPY_FILE)
	{
	  copy_file(src, dest);
	}
      else
	{
	  move_file(src, dest); 
	}
      gu_free(dest);

      ptr=ptr->next;
    }
  /* Destroy the file selection */
  if(clist_win.file_selection != NULL)
    {
      gu_list_foreach(clist_win.file_selection, (GFunc) gu_free, NULL);
      gu_list_free(clist_win.file_selection);
      clist_win.file_selection=NULL;
    }
  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);

  return;
}


void
rbm_move_to_parent_dir_activate        (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  msg_box(gettext("Information"), 
	gettext("This function is not yet available."));
}


void
rbm_select_all1_activate               (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  msg_box(gettext("Information"), 
	gettext("This function is not yet available."));
}


void
rbm_unzip_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  item_file_unzip(NULL, user_data);
}


void
rbm_ungroup_or_unpack_activate         (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  msg_box(gettext("Information"), 
	gettext("This function is not yet available."));
}


void
rbm_convert_tigl_gtktilink_activate    (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  item_file_convert(NULL, user_data);
}

void
rbm_view_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  gint err=0;
  GList *ptr;
  struct file_info *f;
  
  if(clist_win.selection==NULL) return;
  ptr=clist_win.selection;
  while(ptr!=NULL)
    {
      f=(struct file_info *)ptr->data;
      
	  (f->filename)[strlen(f->filename)-1] = tolower(f->filename[strlen(f->filename)-1]);
      //printf("extension: %s\n", ti_calc.byte2type(ti_calc.fext2byte(file_extension(f->filename))));
      err = search_and_load_plugin(f->filename, 
				   options.lp.calc_type, 
				   ti_calc.byte2type(ti_calc.fext2byte(file_extension(f->filename))));
      if(!err)
	msg_box(gettext("Error"), 
		gettext("Unable to find a plugin for editing this variable."));
      
      ptr=ptr->next;
    }
  clist_selection_destroy();
  clist_selection_refresh();
}


void
rbm_properties_activate                (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  msg_box(gettext("Information"), 
	gettext("This function is not yet available."));
}


void
rbm_properties1_activate               (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  msg_box(gettext("Information"), 
	gettext("This function is not yet available."));
}


void
rbm_update_window1_activate            (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  msg_box(gettext("Information"), 
	gettext("This function is not yet available."));
}


void
rbm_make_new_directory1_activate       (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  msg_box(gettext("Information"), 
	gettext("This function is not yet available."));
}


void
rbm_delete_file1_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  msg_box(gettext("Information"), 
	gettext("This function is not yet available."));
}


void
rbm_insert_fargo_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  msg_box(gettext("Information"), 
	gettext("This function is not yet available."));
}


void
rbm_change_drive_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  cb_change_drive((char)user_data);
  
  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);
  /*
    #ifdef WIN32
    gchar buffer[MAXCHARS];
    
    //printf("Drive: <%c:>\n", (gchar)user_data);
    //_chdrive( (gint)user_data );
    gu_snprintf(clist_win.cur_dir, 8, "%c:\\", (gchar)user_data);
    _chdir(clist_win.cur_dir);
    //printf("New path: <%s>\n", clist_win.cur_dir);
    l_directory_list();
    refresh_clist(main_window);
    refresh_info(main_window);
    #else
    msg_box(gettext("Information"),
    gettext("This function is not available in the Win version."));
    #endif
  */
}
