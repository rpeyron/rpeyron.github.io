#include <stdlib.h>
#include <stdio.h>
#include <string.h>






#define NOIR 0
#define VERTFONCE 1
#define ROUGEFONCE 2
#define BLEUFONCE 3
#define VERT 4
#define ROUGE 5
#define BLEU 6



void install_fargo(void);
void write_output_message(char *text);
int start_install_process(void);
void affiche_message(char *txt, int couleur);
void install_finished(void);