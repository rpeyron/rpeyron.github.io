/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

#include "defines.h"


/**************/
/* My widgets */
/**************/
GtkWidget *main_window=NULL;
struct toolbar_window toolbar_win={ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL };
struct clist_window clist_win={ NULL, NULL, "", NULL, NULL, 0 };
struct ctree_window ctree_win={ NULL, NULL, "", NULL };
struct clabel_window clabel_win={ NULL, NULL, NULL, NULL,
				  NULL, NULL, NULL, NULL };
struct progress_window p_win={ NULL, NULL, NULL, NULL, NULL , UNLOCK, NULL, NULL };


/*********************/
/* The main function */
/*********************/
int main(int argc, char *argv[], char **arge)
{
  GtkWidget *vbox1;
  GtkWidget *vbox14;
  GtkWidget *frame3;
  GtkWidget *frame4;
  GtkWidget *frame5;
  GtkWidget *hpaned;
  GtkWidget *scrolledwindow1;
  GtkWidget *scrolledwindow2;
  GtkWidget *menubar;

  /* Init GtkTiLink */
  gtk_init(&argc, &argv); // GTK specific
  main_init(argc, argv, arge); // general

  /* Create the main window */
  main_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_signal_connect(GTK_OBJECT(main_window), "destroy",
                     GTK_SIGNAL_FUNC(gtk_main_quit),
                     NULL);
  gtk_object_set_data (GTK_OBJECT (main_window), "window", main_window);
  gtk_window_set_title (GTK_WINDOW (main_window), "GtkTiLink");
  gtk_widget_set_usize(main_window, 600, 400);

  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox1);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "vbox1", vbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (main_window), vbox1);
  
  /* Place the menubar */
  get_main_menu(main_window, &menubar);
  gtk_widget_ref (menubar);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "menubar", menubar,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (menubar);
  gtk_box_pack_start (GTK_BOX (vbox1), menubar, FALSE, FALSE, 0);
  gtk_widget_realize (main_window);
 
 /* Create the toolbar */
  toolbar_win.toolbar = gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);/* BOTH or ICONS */
  gtk_toolbar_set_button_relief(GTK_TOOLBAR (toolbar_win.toolbar), GTK_RELIEF_NONE);
  gtk_toolbar_set_space_size(GTK_TOOLBAR (toolbar_win.toolbar), 5);
  gtk_widget_ref (toolbar_win.toolbar);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "toolbar", toolbar_win.toolbar,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (toolbar_win.toolbar);
  gtk_box_pack_start (GTK_BOX (vbox1), toolbar_win.toolbar, FALSE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (toolbar_win.toolbar), 5);

  /* Place the toolbar buttons */
  toolbar_win.button1=append_toolbar_button(main_window, &toolbar_win.toolbar, "ready.xpm",
					    gettext("Ready ?"),
					    gettext("Test if calculator is ready"),
					    GTK_SIGNAL_FUNC (toolbar_button_00), NULL);
  toolbar_win.button2=append_toolbar_button(main_window, &toolbar_win.toolbar, "remote.xpm",
					    gettext("Remote"),
					    gettext("Remote control"),
					    GTK_SIGNAL_FUNC (toolbar_button_01), NULL);
  toolbar_win.button3=append_toolbar_button(main_window, &toolbar_win.toolbar, "screen.xpm",
					    gettext("Screen"), 
					    gettext("Screen capture"),
					    GTK_SIGNAL_FUNC (toolbar_button_02), NULL);
  toolbar_win.button4=append_toolbar_button(main_window, &toolbar_win.toolbar, "dir_list.xpm",
					    gettext("Dir"), 
					    gettext("Directory list"),
					    GTK_SIGNAL_FUNC (toolbar_button_03), NULL);
  toolbar_win.button5=append_toolbar_button(main_window, &toolbar_win.toolbar, "receive.xpm",
					    gettext("Backup"),
					    gettext("Receive backup"),
					    GTK_SIGNAL_FUNC (toolbar_button_05), NULL);
  toolbar_win.button6=append_toolbar_button(main_window, &toolbar_win.toolbar, "send.xpm",
					    gettext("Restore"), 
					    gettext("Send backup"),
					    GTK_SIGNAL_FUNC (toolbar_button_04), NULL);
  toolbar_win.button7=append_toolbar_button(main_window, &toolbar_win.toolbar, "sendrec.xpm",
					    gettext("<->"), 
					    gettext("Send/receive variable"),
					    GTK_SIGNAL_FUNC (toolbar_button_06), NULL);
  gtk_toolbar_append_space(GTK_TOOLBAR (toolbar_win.toolbar));
  gtk_toolbar_append_space(GTK_TOOLBAR (toolbar_win.toolbar));
  toolbar_win.button8=append_toolbar_button(main_window, &toolbar_win.toolbar, "folder.xpm",
					    gettext("Mkdir"),
					    gettext("Make a new directory"),
					    GTK_SIGNAL_FUNC (toolbar_button_10), NULL);
  toolbar_win.button9=append_toolbar_button(main_window, &toolbar_win.toolbar, "full_trash.xpm",
					    gettext("Trash"), 
					    gettext("Trash a local file"),
					    GTK_SIGNAL_FUNC (toolbar_button_07), NULL);
  toolbar_win.button10=append_toolbar_button(main_window, &toolbar_win.toolbar, "refresh.xpm",
					     gettext("Update"), 
					     gettext("Refresh the right window"),
					     GTK_SIGNAL_FUNC (toolbar_button_08), NULL);
  toolbar_win.button11=append_toolbar_button(main_window, &toolbar_win.toolbar, "help.xpm",
					     gettext("Help"), 
					     "Help me !!!",
					     GTK_SIGNAL_FUNC (toolbar_button_09), NULL);
  refresh_sensitive_toolbar_buttons();
  gtk_widget_show(toolbar_win.toolbar);

  /* Create a vbox */
  vbox14 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox14);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "vbox14", vbox14,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox14);
  gtk_box_pack_start (GTK_BOX (vbox1), vbox14, TRUE, TRUE, 5);
  
  /* Create the horizontal paned window */
  hpaned = gtk_hpaned_new ();
  gtk_widget_ref (hpaned);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "hpaned", hpaned,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hpaned);
  gtk_box_pack_start (GTK_BOX (vbox14), hpaned, TRUE, TRUE, 0);
  gtk_paned_set_gutter_size (GTK_PANED (hpaned), 5);
  gtk_paned_set_position (GTK_PANED (hpaned), 0);

  /* The left frame contains a tree with a scrolled window */
  frame4 = gtk_frame_new ("Calculator files");
  gtk_widget_ref (frame4);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "frame4", frame4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame4);
  gtk_paned_pack1(GTK_PANED(hpaned), frame4, TRUE, FALSE);
  gtk_widget_set_usize(frame4, options.xsize, options.ysize); /* Default value for 800x600 screen */
  gtk_container_set_border_width (GTK_CONTAINER (frame4), 5);

  scrolledwindow1 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_ref (scrolledwindow1);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "scrolledwindow1", scrolledwindow1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (scrolledwindow1);
  gtk_container_add (GTK_CONTAINER (frame4), scrolledwindow1);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow1), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

  create_ctree(main_window);
  gtk_widget_ref (ctree_win.widget);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "ctree_win.widget", ctree_win.widget,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (ctree_win.widget);
  gtk_container_add (GTK_CONTAINER (scrolledwindow1), ctree_win.widget);
  gtk_widget_show(ctree_win.widget);
  //  refresh_ctree(main_window);
  
  /* The right frame contains a clist with a scrolled window */
  frame5 = gtk_frame_new ("Local files");
  gtk_widget_ref (frame5);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "frame5", frame5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame5);
  gtk_paned_pack2(GTK_PANED(hpaned), frame5, TRUE, FALSE);
  gtk_container_set_border_width (GTK_CONTAINER (frame5), 5);

  scrolledwindow2 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_ref (scrolledwindow2);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "scrolledwindow2", scrolledwindow2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (scrolledwindow2);
  gtk_container_add (GTK_CONTAINER (frame5), scrolledwindow2);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow2), GTK_POLICY_ALWAYS, GTK_POLICY_AUTOMATIC);

  create_clist(main_window);
  gtk_widget_ref (clist_win.widget);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "ctree_win.widget", clist_win.widget,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clist_win.widget);
  gtk_container_add (GTK_CONTAINER (scrolledwindow2), clist_win.widget);
  gtk_clist_set_shadow_type (GTK_CLIST (ctree_win.widget), GTK_SHADOW_OUT);
  if(getcwd(clist_win.cur_dir, 255) == NULL)
    {
      printf(gettext("Directory name too long.\n"));
      exit(1);
    }
  l_directory_list();
  refresh_clist(main_window);

  /* At last, some labels */
  frame3 = gtk_frame_new ("Informations");
  gtk_widget_ref (frame3);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "frame3", frame3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame3);
  gtk_box_pack_start (GTK_BOX (vbox14), frame3, FALSE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame3), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (frame3), GTK_SHADOW_IN);

  create_info(main_window);
  gtk_widget_ref (clabel_win.widget);
  gtk_object_set_data_full (GTK_OBJECT (main_window), "clabel_win.widget", clabel_win.widget,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clabel_win.widget);
  gtk_container_add (GTK_CONTAINER (frame3), clabel_win.widget);
  refresh_info(main_window);

  gtk_widget_show(main_window);

  gtk_main();

  return 0;
}
