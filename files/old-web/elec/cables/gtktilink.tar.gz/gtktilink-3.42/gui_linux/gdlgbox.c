/*  gtktilink - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>
#include <locale.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "defines.h"

#ifdef __WIN32__
#define PROGRESS_TYPE GTK_PROGRESS_DISCRETE
#else
#define PROGRESS_TYPE GTK_PROGRESS_CONTINUOUS
#endif

/************************/
/* General dialog boxes */
/************************/
/* This is a general function used to display a message box */
void msg_box(const gchar *title, gchar *message)
{
  GtkWidget *dialog;
  GtkWidget *dialog_vbox1;
  GtkWidget *label;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *button;

  dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog", dialog);
  gtk_window_set_title (GTK_WINDOW (dialog), title);
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (dialog), FALSE, FALSE, TRUE);
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);

  dialog_vbox1 = GTK_DIALOG (dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  label = gtk_label_new (message);
  gtk_widget_ref (label);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "label", label,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), label, FALSE, FALSE, 5);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_FILL);
  gtk_label_set_line_wrap (GTK_LABEL (label), TRUE);
  gtk_misc_set_padding (GTK_MISC (label), 10, 0);

  dialog_action_area1 = GTK_DIALOG (dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  button = gtk_button_new_with_label (gettext("OK"));
  gtk_widget_ref (button);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "button", button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button);
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);

  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
			     GTK_SIGNAL_FUNC (gtk_widget_destroy),
			     GTK_OBJECT(dialog));

  gtk_widget_show_all(dialog);
}

extern gint dbox_button;

/* This a general function used to display a message with a 1 button */
gint user1_box(const char *title, char *message, const char *b1)
{
  GtkWidget *dialog;
  GtkWidget *dialog_vbox1;
  GtkWidget *label;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *button;
  gint i=0;

  dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog", dialog);
  gtk_window_set_title (GTK_WINDOW (dialog), title);
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (dialog), FALSE, FALSE, TRUE);
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);

  dialog_vbox1 = GTK_DIALOG (dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  label = gtk_label_new (message);
  gtk_widget_ref (label);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "label", label,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), label, FALSE, FALSE, 5);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_FILL);
  gtk_label_set_line_wrap (GTK_LABEL (label), TRUE);
  gtk_misc_set_padding (GTK_MISC (label), 10, 0);

  dialog_action_area1 = GTK_DIALOG (dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  button = gtk_button_new_with_label (b1);
  gtk_widget_ref (button);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "button", button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button);
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);

  gtk_signal_connect (GTK_OBJECT (button), "clicked",
		      GTK_SIGNAL_FUNC (user_box_b1),
		      &i);

  gtk_widget_show_all(dialog);

  while(!i)
    {
      while( gtk_events_pending() ) { gtk_main_iteration(); }
    }
  gtk_widget_destroy(dialog);
 
  return i;
}

/* This a general function used to display a message with 2 buttons */
gint user2_box(const char *title, char *message, const char *b1, const char *b2)
{
  GtkWidget *dialog;
  GtkWidget *vbox1;
  GtkWidget *label1;
  GtkWidget *hbox1;
  GtkWidget *hbuttonbox1;
  GtkWidget *ok_button;
  GtkWidget *cancel_button;
  gint i=0;

  dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog", dialog);
  gtk_window_set_title (GTK_WINDOW (dialog), title);
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (dialog), FALSE, FALSE, TRUE);
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);

  vbox1 = GTK_DIALOG (dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (dialog), "vbox1", vbox1);
  gtk_widget_show (vbox1);

  label1 = gtk_label_new (message);
  gtk_widget_ref (label1);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "label1", label1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label1);
  gtk_box_pack_start (GTK_BOX (vbox1), label1, FALSE, FALSE, 5);
  gtk_label_set_justify (GTK_LABEL (label1), GTK_JUSTIFY_FILL);
  gtk_label_set_line_wrap (GTK_LABEL (label1), TRUE);
  gtk_misc_set_padding (GTK_MISC (label1), 10, 0);

  hbox1 = GTK_DIALOG (dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (dialog), "hbox1", hbox1);
  gtk_widget_show (hbox1);
  gtk_container_set_border_width (GTK_CONTAINER (hbox1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (hbox1), hbuttonbox1, TRUE, TRUE, 0);

  ok_button = gtk_button_new_with_label (b1);
  gtk_widget_ref (ok_button);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "ok_button", ok_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (ok_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), ok_button);
  GTK_WIDGET_SET_FLAGS (ok_button, GTK_CAN_DEFAULT);

  cancel_button = gtk_button_new_with_label (b2);
  gtk_widget_ref (cancel_button);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "cancel_button", cancel_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (cancel_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), cancel_button);
  GTK_WIDGET_SET_FLAGS (cancel_button, GTK_CAN_DEFAULT);

  gtk_signal_connect (GTK_OBJECT (ok_button), "clicked",
                      GTK_SIGNAL_FUNC (user_box_b1),
                      &i);
  gtk_signal_connect (GTK_OBJECT (cancel_button), "clicked",
                      GTK_SIGNAL_FUNC (user_box_b2),
                      &i);

  gtk_widget_show_all(dialog);
  
  while(!i)
    {
      while( gtk_events_pending() ) { gtk_main_iteration(); }
    }
  gtk_widget_destroy(dialog);
  
  return i;
}

/* This a general function used to display a message with 3 buttons */
gint user3_box(const char *title, char *message, const char *b1, const char *b2, const char *b3)
{
  GtkWidget *dialog;
  GtkWidget *vbox1;
  GtkWidget *label1;
  GtkWidget *hbox1;
  GtkWidget *hbuttonbox1;
  GtkWidget *button1;
  GtkWidget *button2;
  GtkWidget *button3;
  gint i=0;

  dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog", dialog);
  gtk_window_set_title (GTK_WINDOW (dialog), title);
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (dialog), FALSE, FALSE, TRUE);
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);

  vbox1 = GTK_DIALOG (dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (dialog), "vbox1", vbox1);
  gtk_widget_show (vbox1);

  label1 = gtk_label_new (message);
  gtk_widget_ref (label1);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "label1", label1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label1);
  gtk_box_pack_start (GTK_BOX (vbox1), label1, FALSE, FALSE, 5);
  gtk_label_set_justify (GTK_LABEL (label1), GTK_JUSTIFY_FILL);
  gtk_label_set_line_wrap (GTK_LABEL (label1), TRUE);
  gtk_misc_set_padding (GTK_MISC (label1), 10, 0);

  hbox1 = GTK_DIALOG (dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (dialog), "hbox1", hbox1);
  gtk_widget_show (hbox1);
  gtk_container_set_border_width (GTK_CONTAINER (hbox1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (hbox1), hbuttonbox1, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label (b1);
  gtk_widget_ref (button1);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "button1", button1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button1);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button1);
  GTK_WIDGET_SET_FLAGS (button1, GTK_CAN_DEFAULT);

  button2 = gtk_button_new_with_label (b2);
  gtk_widget_ref (button2);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "button2", button2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button2);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button2);
  GTK_WIDGET_SET_FLAGS (button2, GTK_CAN_DEFAULT);

  button3 = gtk_button_new_with_label (b3);
  gtk_widget_ref (button3);
  gtk_object_set_data_full (GTK_OBJECT (dialog), "button3", button3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button3);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button3);
  GTK_WIDGET_SET_FLAGS (button3, GTK_CAN_DEFAULT);

  gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                      GTK_SIGNAL_FUNC (user_box_b1),
                      &i);
  gtk_signal_connect (GTK_OBJECT (button2), "clicked",
                      GTK_SIGNAL_FUNC (user_box_b2),
                      &i);
  gtk_signal_connect (GTK_OBJECT (button3), "clicked",
                      GTK_SIGNAL_FUNC (user_box_b3),
                      &i);
  gtk_widget_show_all(dialog);
  
  while(!i)
    {
      while( gtk_events_pending() ) { gtk_main_iteration(); }
    }
  gtk_widget_destroy(dialog);
  
  return i;
}

/*********************************/
/* Transmission delay dialog box */
/*********************************/
/* Display the setup_delay dlgbox */
void dlgbox_setup_delay(GtkWidget *widget, gpointer data)
{
  //GtkWidget *dialog;
  GtkWidget *dialog_vbox1;
  GtkWidget *frame1;
  GtkWidget *hbox1;
  GtkWidget *label1;
  GtkObject *spinbutton1_adj;
  //GtkWidget *spinbutton1;
  GtkWidget *label2;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *button1;
  GtkWidget *button2;
  GtkTooltips *tooltips;
  struct dtdb *s;

  s=(struct dtdb *)g_malloc(sizeof(struct dtdb));

  tooltips = gtk_tooltips_new ();

  s->dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog", s->dialog);
  gtk_window_set_title (GTK_WINDOW (s->dialog), gettext("Transmission delay"));
  gtk_window_set_policy (GTK_WINDOW (s->dialog), TRUE, FALSE, TRUE);
  gtk_window_set_position (GTK_WINDOW (s->dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_modal(GTK_WINDOW(s->dialog), TRUE);

  dialog_vbox1 = GTK_DIALOG (s->dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  frame1 = gtk_frame_new (gettext("Delay value"));
  gtk_widget_ref (frame1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame1", frame1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), frame1, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 5);

  hbox1 = gtk_hbox_new (FALSE, 3);
  gtk_widget_ref (hbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbox1", hbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox1);
  gtk_container_add (GTK_CONTAINER (frame1), hbox1);
  gtk_container_set_border_width (GTK_CONTAINER (hbox1), 5);

  label1 = gtk_label_new (gettext("Delay:"));
  gtk_widget_ref (label1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "label1", label1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label1);
  gtk_box_pack_start (GTK_BOX (hbox1), label1, FALSE, FALSE, 0);
  gtk_misc_set_padding (GTK_MISC (label1), 5, 5);

  spinbutton1_adj = gtk_adjustment_new (10, 1, 100, 1, 10, 10);
  s->spinbutton = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton1_adj), 1, 0);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(s->spinbutton), options.lp.delay);
  gtk_widget_ref (s->spinbutton);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "spinbutton1", s->spinbutton,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (s->spinbutton);
  gtk_box_pack_start (GTK_BOX (hbox1), s->spinbutton, FALSE, TRUE, 0);
  gtk_tooltips_set_tip (tooltips, s->spinbutton, gettext("This value represents the time between 2 bits"), NULL);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (s->spinbutton), TRUE);

  label2 = gtk_label_new (gettext("microseconds"));
  gtk_widget_ref (label2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "label2", label2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label2);
  gtk_box_pack_start (GTK_BOX (hbox1), label2, FALSE, FALSE, 0);
  gtk_misc_set_padding (GTK_MISC (label2), 5, 5);

  dialog_action_area1 = GTK_DIALOG (s->dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label (gettext("OK"));
  gtk_widget_ref (button1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "button1", button1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button1);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button1);
  GTK_WIDGET_SET_FLAGS (button1, GTK_CAN_DEFAULT);

  button2 = gtk_button_new_with_label (gettext("Cancel"));
  gtk_widget_ref (button2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "button2", button2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button2);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button2);
  GTK_WIDGET_SET_FLAGS (button2, GTK_CAN_DEFAULT);

  //gtk_signal_connect (GTK_OBJECT (s->spinbutton), "changed",
  //                  GTK_SIGNAL_FUNC (setup_delay_changed),
  //                  NULL);
  gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                      GTK_SIGNAL_FUNC (setup_delay_ok),
                      s);
  gtk_signal_connect (GTK_OBJECT (button2), "clicked",
                      GTK_SIGNAL_FUNC (setup_delay_cancel),
                      s);

  gtk_object_set_data (GTK_OBJECT (s->dialog), "tooltips", tooltips);
  gtk_widget_show_all(s->dialog);
}

/**********************/
/* Timeout dialog box */
/**********************/
/* Display the setup_timeout dlgbox */
void dlgbox_setup_timeout(GtkWidget *widget, gpointer data)
{
  //GtkWidget *dialog;
  GtkWidget *dialog_vbox1;
  GtkWidget *frame1;
  GtkWidget *hbox1;
  GtkWidget *label1;
  GtkObject *spinbutton1_adj;
  //GtkWidget *spinbutton1;
  GtkWidget *label2;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *button1;
  GtkWidget *button2;
  GtkTooltips *tooltips;
  struct dtdb *s;

  s=(struct dtdb *)g_malloc(sizeof(struct dtdb));

  tooltips = gtk_tooltips_new ();

  s->dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog", s->dialog);
  gtk_window_set_title (GTK_WINDOW (s->dialog), gettext("Timeout"));
  gtk_window_set_policy (GTK_WINDOW (s->dialog), TRUE, FALSE, TRUE);
  gtk_window_set_position (GTK_WINDOW (s->dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_modal(GTK_WINDOW(s->dialog), TRUE);

  dialog_vbox1 = GTK_DIALOG (s->dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  frame1 = gtk_frame_new (gettext("Timeout value"));
  gtk_widget_ref (frame1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame1", frame1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), frame1, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 5);

  hbox1 = gtk_hbox_new (FALSE, 3);
  gtk_widget_ref (hbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbox1", hbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox1);
  gtk_container_add (GTK_CONTAINER (frame1), hbox1);
  gtk_container_set_border_width (GTK_CONTAINER (hbox1), 5);

  label1 = gtk_label_new (gettext("Timeout:"));
  gtk_widget_ref (label1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "label1", label1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label1);
  gtk_box_pack_start (GTK_BOX (hbox1), label1, FALSE, FALSE, 0);
  gtk_misc_set_padding (GTK_MISC (label1), 5, 5);

  spinbutton1_adj = gtk_adjustment_new (10, 1, 100, 1, 10, 10);
  s->spinbutton = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton1_adj), 1, 0);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(s->spinbutton), options.lp.timeout);
  gtk_widget_ref (s->spinbutton);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "spinbutton1", s->spinbutton,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (s->spinbutton);
  gtk_box_pack_start (GTK_BOX (hbox1), s->spinbutton, FALSE, TRUE, 0);
  gtk_tooltips_set_tip (tooltips, s->spinbutton, gettext("This value is the timeout value"), NULL);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (s->spinbutton), TRUE);

  label2 = gtk_label_new (gettext("tenth of seconds"));
  gtk_widget_ref (label2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "label2", label2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label2);
  gtk_box_pack_start (GTK_BOX (hbox1), label2, FALSE, FALSE, 0);
  gtk_misc_set_padding (GTK_MISC (label2), 5, 5);

  dialog_action_area1 = GTK_DIALOG (s->dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label (gettext("OK"));
  gtk_widget_ref (button1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "button1", button1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button1);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button1);
  GTK_WIDGET_SET_FLAGS (button1, GTK_CAN_DEFAULT);

  button2 = gtk_button_new_with_label (gettext("Cancel"));
  gtk_widget_ref (button2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "button2", button2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button2);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button2);
  GTK_WIDGET_SET_FLAGS (button2, GTK_CAN_DEFAULT);

  //gtk_signal_connect (GTK_OBJECT (s->spinbutton), "changed",
  //                  GTK_SIGNAL_FUNC (setup_timeout_changed),
  //                  NULL);
  gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                      GTK_SIGNAL_FUNC (setup_timeout_ok),
                      s);
  gtk_signal_connect (GTK_OBJECT (button2), "clicked",
                      GTK_SIGNAL_FUNC (setup_timeout_cancel),
                      s);

  gtk_object_set_data (GTK_OBJECT (s->dialog), "tooltips", tooltips);
  gtk_widget_show_all(s->dialog);
}

/***************************/
/* Screen setup dialog box */
/***************************/
/* Display the setup_screen dlgbox */
void dlgbox_setup_screen(GtkWidget *widget, gpointer data)
{
  //GtkWidget *dbox;
  GtkWidget *dialog_vbox1;
  GtkWidget *frame1;
  GtkWidget *vbox1;
  GSList *group1_group = NULL;
  GtkWidget *radiobutton11;
  GtkWidget *radiobutton12;
  GtkWidget *radiobutton13;
  GtkWidget *frame2;
  GtkWidget *vbox2;
  GSList *group2_group = NULL;
  GtkWidget *radiobutton21;
  GtkWidget *radiobutton22;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *ok_button;
  GtkWidget *cancel_button;
  struct ssdb *s;

  s=(struct ssdb *)g_malloc(sizeof(struct ssdb));

  s->clipping = options.screen_clipping;
  s->image_format = options.screen_format;

  s->dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (s->dialog), "s->dialog", s->dialog);
  gtk_window_set_title (GTK_WINDOW (s->dialog), "Screen capture options");
  gtk_window_set_position (GTK_WINDOW (s->dialog), GTK_WIN_POS_MOUSE);
  gtk_window_set_modal (GTK_WINDOW (s->dialog), TRUE);
  gtk_window_set_policy (GTK_WINDOW (s->dialog), FALSE, FALSE, TRUE);

  dialog_vbox1 = GTK_DIALOG (s->dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  frame1 = gtk_frame_new ("Image format");
  gtk_widget_ref (frame1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame1", frame1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), frame1, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 5);

  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "vbox1", vbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (frame1), vbox1);
  gtk_container_set_border_width (GTK_CONTAINER (vbox1), 5);

  radiobutton11 = gtk_radio_button_new_with_label (group1_group, "PCX (RLE compressed)");
  group1_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton11));
  gtk_widget_ref (radiobutton11);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton11", radiobutton11,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton11);
  gtk_box_pack_start (GTK_BOX (vbox1), radiobutton11, FALSE, FALSE, 0);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton11), TRUE);

  radiobutton12 = gtk_radio_button_new_with_label (group1_group, "XPM (Unix format)");
  group1_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton12));
  gtk_widget_ref (radiobutton12);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton12", radiobutton12,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton12);
  gtk_box_pack_start (GTK_BOX (vbox1), radiobutton12, FALSE, FALSE, 0);

  radiobutton13 = gtk_radio_button_new_with_label (group1_group, "JPEG (not yet available)");
  group1_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton13));
  gtk_widget_ref (radiobutton13);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton13", radiobutton13,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton13);
  gtk_box_pack_start (GTK_BOX (vbox1), radiobutton13, FALSE, FALSE, 0);

  frame2 = gtk_frame_new ("Screen mode");
  gtk_widget_ref (frame2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame2", frame2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame2);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), frame2, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame2), 5);

  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "vbox2", vbox2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox2);
  gtk_container_add (GTK_CONTAINER (frame2), vbox2);
  gtk_container_set_border_width (GTK_CONTAINER (vbox2), 5);

  radiobutton21 = gtk_radio_button_new_with_label (group2_group, "full screen");
  group2_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton21));
  gtk_widget_ref (radiobutton21);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton21", radiobutton21,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton21);
  gtk_box_pack_start (GTK_BOX (vbox2), radiobutton21, FALSE, FALSE, 0);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton21), TRUE);

  radiobutton22 = gtk_radio_button_new_with_label (group2_group, "clipped screen (TI89)");
  group2_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton22));
  gtk_widget_ref (radiobutton22);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton22", radiobutton22,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton22);
  gtk_box_pack_start (GTK_BOX (vbox2), radiobutton22, FALSE, FALSE, 0);

  dialog_action_area1 = GTK_DIALOG (s->dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  ok_button = gtk_button_new_with_label ("OK");
  gtk_widget_ref (ok_button);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "ok_button", ok_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (ok_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), ok_button);
  GTK_WIDGET_SET_FLAGS (ok_button, GTK_CAN_DEFAULT);

  cancel_button = gtk_button_new_with_label ("Cancel");
  gtk_widget_ref (cancel_button);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "cancel_button", cancel_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (cancel_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), cancel_button);
  GTK_WIDGET_SET_FLAGS (cancel_button, GTK_CAN_DEFAULT);

  if(s->image_format == PCX)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton11), TRUE);
  if(s->image_format == XPM)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton12), TRUE);
  if(s->image_format == JPG)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton13), TRUE);
  if(s->clipping == FULL_SCREEN)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton21), TRUE);
  if(s->clipping == CLIPPED_SCREEN)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton22), TRUE);

  gtk_signal_connect (GTK_OBJECT (radiobutton11), "toggled",
                      GTK_SIGNAL_FUNC (ssdb_radiobutton11_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton12), "toggled",
                      GTK_SIGNAL_FUNC (ssdb_radiobutton12_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton13), "toggled",
                      GTK_SIGNAL_FUNC (ssdb_radiobutton13_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton21), "toggled",
                      GTK_SIGNAL_FUNC (ssdb_radiobutton21_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton22), "toggled",
                      GTK_SIGNAL_FUNC (ssdb_radiobutton22_toggled),
                      s);
 
  gtk_signal_connect (GTK_OBJECT (ok_button), "clicked",
                      GTK_SIGNAL_FUNC (setup_screen_ok),
                      s);
  gtk_signal_connect (GTK_OBJECT (cancel_button), "clicked",
                      GTK_SIGNAL_FUNC (setup_screen_cancel),
                      s);

  gtk_widget_show_all(s->dialog);
}

char *string_lower(char *s);

/*******************/
/* Help dialog box */
/*******************/
/* Display a dlgbox which provide some help */
void dlgbox_help_help(GtkWidget *widget, gpointer data)
{
  GtkWidget *dialog;
  GtkWidget *text;
  GtkWidget *vscrollbar;
  GtkWidget *table;
  GtkWidget *button;
  gchar buffer[MAXCHARS];
  FILE *fd;
  const char no_help_available[] = gettext_noop("Cannot find the help file HELP_FILE.");
  char *loc;
  gchar locale[MAXCHARS];

  dialog = gtk_dialog_new ();
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_title (GTK_WINDOW (dialog), gettext("GtkTiLink help"));
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
  gtk_widget_set_usize(GTK_WIDGET (dialog), 400, 400);
  gtk_container_border_width (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), 10);
  gtk_container_border_width (GTK_CONTAINER (GTK_DIALOG (dialog)->action_area), 5);
  gtk_box_set_spacing (GTK_BOX (GTK_DIALOG (dialog)->vbox), 5);
  gtk_box_set_homogeneous (GTK_BOX (GTK_DIALOG (dialog)->action_area), TRUE);
  gtk_signal_connect_object (GTK_OBJECT (dialog), "delete_event", GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			     GTK_OBJECT (dialog));
  gtk_signal_connect_object (GTK_OBJECT (dialog), "destroy", GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			     GTK_OBJECT (dialog));  

  button = gtk_button_new_with_label (gettext(" Close "));
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area), button, FALSE, FALSE, FALSE);
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			     GTK_OBJECT (dialog));
  gtk_widget_grab_default (button);
  gtk_widget_show (button);

  table = gtk_table_new (2, 2, FALSE);
  gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
  gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), table, TRUE, TRUE, 0);
  gtk_widget_show (table);
  
  text = gtk_text_new (NULL, NULL);
  gtk_text_set_editable (GTK_TEXT (text), FALSE);
  gtk_text_set_word_wrap (GTK_TEXT (text), TRUE);
  gtk_table_attach (GTK_TABLE (table), text, 0, 1, 0, 1,
		    GTK_EXPAND | GTK_SHRINK | GTK_FILL,
		    GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_show (text);

  vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
  gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
		    GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_show (vscrollbar);

  gtk_widget_realize(text);
  gtk_text_freeze (GTK_TEXT (text));

  strcpy(buffer, clist_win.win_dir);
  /*
#ifdef __WIN32__
  strcat(buffer, SHARE_DIR "\\");
#else
  strcat(buffer, SHARE_DIR "/");
#endif
  */
  strcat(buffer, SHARE_DIR DIR_SEPARATOR);
  strcat(buffer, "help_");


  /* Choose the help file according to the language of the user */
  loc=setlocale(LC_ALL, "");
  strcpy(locale, loc);
  string_lower(locale);
  strcat(buffer, locale);

  if( access(buffer, F_OK) != 0 )
    {
	  strcpy(buffer, clist_win.win_dir);
#ifndef __WIN32__
	  strcat(buffer, SHARE_DIR "/");
	  buffer[strlen(buffer) - strlen(locale)] = '\0';
#else
	  strcat(buffer, SHARE_DIR "\\");
#endif
	  strcat(buffer, "help_");
      strcat(buffer, "en_us");
    }
  
  if( access(buffer, F_OK) != 0 ) 
    {
      if( access(buffer, F_OK) != 0 ) 
	{
	  gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, no_help_available, strlen (no_help_available));
	  gtk_widget_show (dialog);
	  return;
	}
    }
  if( (fd=fopen (buffer, "r")) == NULL) 
    {
      gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, no_help_available, strlen (no_help_available));
      gtk_widget_show (dialog);
      return;
    }
  memset (buffer, 0, sizeof(buffer));
  while(fread (buffer, 1, sizeof(buffer)-1, fd)) 
    {
      gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, buffer, strlen (buffer));
      memset (buffer, 0, sizeof(buffer));
    }
  fclose (fd);  

  gtk_text_thaw (GTK_TEXT (text));
  gtk_widget_show(dialog);
}

/********************/
/* About dialog box */
/********************/
/* Display an about dialog box */
void dlgbox_help_about(GtkWidget *widget, gpointer data)
{
  const char no_license_agreement[] = gettext_noop("Cannot find the license agreement file COPYING.");
  GtkWidget *dialog;
  GtkWidget *tempwid;
  GtkWidget *notebook;
  GtkWidget *box;
  GtkWidget *label;
  GtkWidget *view;
  GtkWidget *vscroll;
  //GdkPixmap *logo_pixmap; /* Logo removed: too big ! */
  //GdkBitmap *logo_mask;
  char tempstr[256];
  FILE *fd;

  dialog = gtk_dialog_new ();
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_title (GTK_WINDOW (dialog), gettext("About GtkTiLink"));
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
  gtk_container_border_width (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), 10);
  gtk_container_border_width (GTK_CONTAINER (GTK_DIALOG (dialog)->action_area), 5);
  gtk_box_set_spacing (GTK_BOX (GTK_DIALOG (dialog)->vbox), 5);
  gtk_box_set_homogeneous (GTK_BOX (GTK_DIALOG (dialog)->action_area), TRUE);
  gtk_signal_connect_object (GTK_OBJECT (dialog), "delete_event", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (dialog));
  gtk_signal_connect_object (GTK_OBJECT (dialog), "destroy", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (dialog));
  gtk_widget_realize (dialog);
   
  notebook = gtk_notebook_new ();
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), notebook, TRUE, TRUE, TRUE);
  gtk_widget_show (notebook);
  
  box = gtk_vbox_new (TRUE, 5);
  gtk_container_border_width (GTK_CONTAINER(box), 10);
  gtk_widget_show (box);
   
  /* logo removed because too big (~400 Ko) ! */
  /*
  open_xpm ("logo.xpm", dialog, &logo_pixmap, &logo_mask);
  tempwid = gtk_pixmap_new (logo_pixmap, logo_mask);
  gdk_pixmap_unref(logo_pixmap);
  gtk_box_pack_start (GTK_BOX(box), tempwid, FALSE, FALSE, FALSE);
  gtk_widget_show (tempwid);
  */
  g_snprintf (tempstr, sizeof (tempstr), "%s\n(C) Copyright 1999, 2000 Romain Lievin <roms@gtktilink.ticalc.org>\nOfficial Homepage: http://gtktilink.ticalc.org\nWeb site managed by Russel G. Howe <rhowe@wiss.co.uk>\nLogo by Laminoir", VERSION);
  tempstr[sizeof (tempstr) - 1] = '\0';
  tempwid = gtk_label_new (tempstr);
  gtk_box_pack_start (GTK_BOX (box), tempwid, FALSE, FALSE, FALSE);
  gtk_widget_show (tempwid);
   
  label = gtk_label_new (gettext("About"));
  gtk_widget_show (label);
  
  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), box, label);
  
  box = gtk_vbox_new (FALSE, 5);
  gtk_container_border_width (GTK_CONTAINER (box), 10);
  gtk_widget_show (box);
  
  tempwid = gtk_table_new (1, 2, FALSE);
  gtk_box_pack_start (GTK_BOX (box), tempwid, TRUE, TRUE, TRUE);
  gtk_widget_show (tempwid);
  
  view = gtk_text_new (NULL, NULL);
  gtk_text_set_editable (GTK_TEXT (view), FALSE);
  gtk_text_set_word_wrap (GTK_TEXT (view), TRUE);
  gtk_table_attach (GTK_TABLE (tempwid), view, 0, 1, 0, 1, GTK_FILL | GTK_EXPAND, GTK_FILL | GTK_EXPAND | GTK_SHRINK, 0, 0);
  gtk_widget_show (view);
  
  vscroll = gtk_vscrollbar_new (GTK_TEXT (view)->vadj);
  gtk_table_attach (GTK_TABLE (tempwid), vscroll, 1, 2, 0, 1, GTK_FILL, GTK_EXPAND | GTK_FILL | GTK_SHRINK, 0, 0);
  gtk_widget_show (vscroll);

  label = gtk_label_new (gettext("License Agreement"));
  gtk_widget_show (label);

  gtk_notebook_append_page (GTK_NOTEBOOK (notebook), box, label);
  
  tempwid = gtk_button_new_with_label (gettext(" Close "));
  GTK_WIDGET_SET_FLAGS (tempwid, GTK_CAN_DEFAULT);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area), tempwid, FALSE, FALSE, FALSE);
  gtk_signal_connect_object (GTK_OBJECT (tempwid), "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), GTK_OBJECT (dialog));
  gtk_widget_grab_default (tempwid);
  gtk_widget_show (tempwid);

 strcpy(tempstr, clist_win.win_dir);
 /*
#ifndef __WIN32__
  strcat(tempstr, SHARE_DIR "/");
#else
  strcat(tempstr, SHARE_DIR "\\");
#endif
 */
 strcat(tempstr, SHARE_DIR DIR_SEPARATOR);
  strcat(tempstr, "COPYING");

  if (access (tempstr, F_OK) != 0) 
    {
      if (access (tempstr, F_OK) != 0) 
	{
	  gtk_text_insert (GTK_TEXT (view), NULL, NULL, NULL, no_license_agreement, strlen (no_license_agreement));
	  gtk_widget_show (dialog);
	  return;
	}
    }
  if ((fd = fopen (tempstr, "r")) == NULL) 
    {
      gtk_text_insert (GTK_TEXT (view), NULL, NULL, NULL, no_license_agreement, strlen (no_license_agreement));
      gtk_widget_show (dialog);
      return;
    }
  memset (tempstr, 0, sizeof (tempstr));
  while (fread (tempstr, 1, sizeof (tempstr) - 1, fd)) 
    {
      gtk_text_insert (GTK_TEXT (view), NULL, NULL, NULL, tempstr, strlen (tempstr));
      memset (tempstr, 0, sizeof (tempstr));
    }
  fclose (fd);
  gtk_widget_show (dialog);
}

/********************/
/* Entry dialog box */
/********************/
gchar *dlgbox_entry(const char *title, const char *message, const char *content)
{
  //GtkWidget *entry_dialog;
  GtkWidget *dialog_vbox1;
  GtkWidget *frame;
  GtkWidget *vbox1;
  //GtkWidget *entry;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *button1;
  GtkWidget *button2;
  struct edb *s;
  gchar *ret;

  s=(struct edb *)g_malloc(sizeof(struct edb));
  s->button=0;

  s->dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (s->dialog), "s->dialog", s->dialog);
  gtk_window_set_title (GTK_WINDOW (s->dialog), title);
  gtk_window_set_position (GTK_WINDOW (s->dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (s->dialog), FALSE, FALSE, FALSE);
  gtk_window_set_modal(GTK_WINDOW(s->dialog), TRUE);

  dialog_vbox1 = GTK_DIALOG (s->dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  frame = gtk_frame_new (message);
  gtk_widget_ref (frame);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame", frame,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), frame, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame), 5);

  vbox1 = gtk_vbox_new (TRUE, 0);
  gtk_widget_ref (vbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "vbox1", vbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (frame), vbox1);
  gtk_container_set_border_width (GTK_CONTAINER (vbox1), 5);

  //s->entry = gtk_entry_new_with_max_length (32);
  s->entry = gtk_entry_new();
  gtk_widget_ref (s->entry);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "entry", s->entry,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (s->entry);
  gtk_box_pack_start (GTK_BOX (vbox1), s->entry, FALSE, FALSE, 0);
  gtk_entry_set_text (GTK_ENTRY (s->entry), content);

  dialog_action_area1 = GTK_DIALOG (s->dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label (gettext("OK"));
  gtk_widget_ref (button1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "button1", button1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button1);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button1);
  GTK_WIDGET_SET_FLAGS (button1, GTK_CAN_DEFAULT);

  button2 = gtk_button_new_with_label (gettext("Cancel"));
  gtk_widget_ref (button2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "button2", button2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button2);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button2);
  GTK_WIDGET_SET_FLAGS (button2, GTK_CAN_DEFAULT);

  //gtk_signal_connect (GTK_OBJECT (s->entry), "changed",
  //                    GTK_SIGNAL_FUNC (on_entry1_changed),
  //                    s);
  //gtk_signal_connect (GTK_OBJECT (s->entry), "activate",
  //                    GTK_SIGNAL_FUNC (on_entry1_activate),
  //                    s);
  gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                      GTK_SIGNAL_FUNC (entry_ok),
                      s);
  gtk_signal_connect (GTK_OBJECT (button2), "clicked",
                      GTK_SIGNAL_FUNC (entry_cancel),
                      s);

  gtk_widget_grab_focus (s->entry);  
  gtk_widget_show_all(s->dialog);

  while(!(s->button))
    {
      while( gtk_events_pending() ) { gtk_main_iteration(); }
    }
  switch(s->button)
    {
    case BUTTON1:
      ret=(gchar *)g_malloc((strlen(s->text)+1)*sizeof(gchar));
      strcpy(ret, s->text);
      break;
    case BUTTON2:
      ret=NULL;
      break;
    default:
      ret=NULL;
      break;
    }
  gtk_widget_destroy(s->dialog);
  g_free(s);

  return ret;
}

/****************************/
/* General setup dialog box */
/****************************/
/* Display a dlgbox in order to configure some options */
void dlgbox_setup_general(GtkWidget *widget, gpointer data)
{
  //GtkWidget *dialog;
  GtkWidget *dialog_vbox1;
  GtkWidget *table1;
  GtkWidget *frame1;
  GtkWidget *label1;
  GtkWidget *frame2;
  GtkWidget *label2;
  GtkWidget *frame9;
  GtkWidget *hbox4;
  GSList *right_order_grp_group = NULL;
  GtkWidget *radiobutton51;
  GtkWidget *radiobutton52;
  GtkWidget *frame10;
  GtkWidget *hbox5;
  GSList *left_order_grp_group = NULL;
  GtkWidget *radiobutton31;
  GtkWidget *radiobutton32;
  GtkWidget *frame14;
  GtkWidget *checkbutton2;
  GtkWidget *frame16;
  GtkWidget *checkbutton1;
  GtkWidget *frame3;
  GtkWidget *hbox1;
  GtkWidget *vbox1;
  GtkWidget *label3;
  GtkObject *spinbutton1_adj;
  //GtkWidget *spinbutton1;
  GtkWidget *vbox2;
  GtkWidget *label4;
  GtkObject *spinbutton2_adj;
  //GtkWidget *spinbutton2;
  GtkWidget *frame13;
  GtkWidget *checkbutton3;
  GtkWidget *frame19;
  GtkWidget *table5;
  GSList *right_sort_grp_group = NULL;
  GtkWidget *radiobutton41;
  GtkWidget *radiobutton43;
  GtkWidget *radiobutton44;
  GtkWidget *radiobutton46;
  GtkWidget *radiobutton42;
  GtkWidget *radiobutton45;
  GtkWidget *frame4;
  GtkWidget *hbox2;
  GSList *path_mode_grp_group = NULL;
  GtkWidget *radiobutton11;
  GtkWidget *radiobutton12;
  GtkWidget *frame18;
  GtkWidget *table4;
  GSList *left_sort_grp_group = NULL;
  GtkWidget *radiobutton23;
  GtkWidget *radiobutton24;
  GtkWidget *radiobutton22;
  GtkWidget *radiobutton21;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *button1;
  GtkWidget *button2;
  GtkWidget *button3;
  struct gdb *s;

  s=(struct gdb *)g_malloc(sizeof(struct gdb));

  /* Initialize the temporary structure */
  s->xsize=options.xsize;
  s->ysize=options.ysize;
  s->clist_sort=options.clist_sort;
  s->clist_sort_order=options.clist_sort_order;
  s->ctree_sort=options.ctree_sort;
  s->ctree_sort_order=options.ctree_sort_order;
  s->confirm=options.confirm;
  s->path_mode=options.path_mode;
  s->show=options.show;
  s->file_mode=options.file_mode;

  /* Draw the box */
  s->dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog", s->dialog);
  gtk_window_set_title (GTK_WINDOW (s->dialog), gettext("General options"));
  gtk_window_set_policy (GTK_WINDOW (s->dialog), FALSE, FALSE, TRUE);
  gtk_window_set_modal(GTK_WINDOW(s->dialog), TRUE);

  dialog_vbox1 = GTK_DIALOG (s->dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  table1 = gtk_table_new (6, 2, FALSE);
  gtk_widget_ref (table1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "table1", table1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (table1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), table1, TRUE, TRUE, 0);

  frame1 = gtk_frame_new (NULL);
  gtk_widget_ref (frame1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame1", frame1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame1);
  gtk_table_attach (GTK_TABLE (table1), frame1, 0, 1, 0, 1,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 5);

  label1 = gtk_label_new (gettext("Left window"));
  gtk_widget_ref (label1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "label1", label1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label1);
  gtk_container_add (GTK_CONTAINER (frame1), label1);

  frame2 = gtk_frame_new (NULL);
  gtk_widget_ref (frame2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame2", frame2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame2);
  gtk_table_attach (GTK_TABLE (table1), frame2, 1, 2, 0, 1,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame2), 5);

  label2 = gtk_label_new (gettext("Right window"));
  gtk_widget_ref (label2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "label2", label2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label2);
  gtk_container_add (GTK_CONTAINER (frame2), label2);

  frame9 = gtk_frame_new (gettext("Order"));
  gtk_widget_ref (frame9);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame9", frame9,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame9);
  gtk_table_attach (GTK_TABLE (table1), frame9, 1, 2, 5, 6,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame9), 5);

  hbox4 = gtk_hbox_new (FALSE, 0);
  gtk_widget_ref (hbox4);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbox4", hbox4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox4);
  gtk_container_add (GTK_CONTAINER (frame9), hbox4);

  radiobutton51 = gtk_radio_button_new_with_label (right_order_grp_group, gettext("increasing"));
  right_order_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton51));
  gtk_widget_ref (radiobutton51);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton51", radiobutton51,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton51);
  gtk_box_pack_start (GTK_BOX (hbox4), radiobutton51, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton51), 3);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton51), TRUE);

  radiobutton52 = gtk_radio_button_new_with_label (right_order_grp_group, gettext("decreasing"));
  right_order_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton52));
  gtk_widget_ref (radiobutton52);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton52", radiobutton52,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton52);
  gtk_box_pack_start (GTK_BOX (hbox4), radiobutton52, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton52), 3);

  frame10 = gtk_frame_new (gettext("Order"));
  gtk_widget_ref (frame10);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame10", frame10,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame10);
  gtk_table_attach (GTK_TABLE (table1), frame10, 0, 1, 5, 6,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame10), 5);

  hbox5 = gtk_hbox_new (FALSE, 0);
  gtk_widget_ref (hbox5);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbox5", hbox5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox5);
  gtk_container_add (GTK_CONTAINER (frame10), hbox5);

  radiobutton31 = gtk_radio_button_new_with_label (left_order_grp_group, gettext("increasing"));
  left_order_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton31));
  gtk_widget_ref (radiobutton31);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton31", radiobutton31,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton31);
  gtk_box_pack_start (GTK_BOX (hbox5), radiobutton31, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton31), 3);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton31), TRUE);

  radiobutton32 = gtk_radio_button_new_with_label (left_order_grp_group, gettext("decreasing"));
  left_order_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton32));
  gtk_widget_ref (radiobutton32);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton32", radiobutton32,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton32);
  gtk_box_pack_start (GTK_BOX (hbox5), radiobutton32, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton32), 3);

  frame14 = gtk_frame_new (gettext("Keep archive attribute (89/92+ only)"));
  gtk_widget_ref (frame14);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame14", frame14,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame14);
  gtk_table_attach (GTK_TABLE (table1), frame14, 1, 2, 2, 3,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame14), 5);

  checkbutton2 = gtk_check_button_new_with_label (gettext("Use extended file format"));
  gtk_widget_ref (checkbutton2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "checkbutton2", checkbutton2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (checkbutton2);
  gtk_container_add (GTK_CONTAINER (frame14), checkbutton2);
  gtk_container_set_border_width (GTK_CONTAINER (checkbutton2), 3);

  frame16 = gtk_frame_new (gettext("Show/hide"));
  gtk_widget_ref (frame16);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame16", frame16,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame16);
  gtk_table_attach (GTK_TABLE (table1), frame16, 1, 2, 1, 2,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame16), 5);

  checkbutton1 = gtk_check_button_new_with_label (gettext("Display hidden files"));
  gtk_widget_ref (checkbutton1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "checkbutton1", checkbutton1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (checkbutton1);
  gtk_container_add (GTK_CONTAINER (frame16), checkbutton1);
  gtk_container_set_border_width (GTK_CONTAINER (checkbutton1), 3);

  frame3 = gtk_frame_new (gettext("Window size"));
  gtk_widget_ref (frame3);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame3", frame3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame3);
  gtk_table_attach (GTK_TABLE (table1), frame3, 0, 1, 1, 3,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame3), 5);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_widget_ref (hbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbox1", hbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox1);
  gtk_container_add (GTK_CONTAINER (frame3), hbox1);

  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "vbox1", vbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox1);
  gtk_box_pack_start (GTK_BOX (hbox1), vbox1, TRUE, TRUE, 5);
  gtk_container_set_border_width (GTK_CONTAINER (vbox1), 5);

  label3 = gtk_label_new (gettext("Width:"));
  gtk_widget_ref (label3);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "label3", label3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label3);
  gtk_box_pack_start (GTK_BOX (vbox1), label3, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label3), GTK_JUSTIFY_LEFT);

  spinbutton1_adj = gtk_adjustment_new (300, 1, 1024, 1, 10, 10);
  s->spinbutton1 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton1_adj), 1, 0);
  gtk_widget_ref (s->spinbutton1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "spinbutton1", s->spinbutton1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (s->spinbutton1);
  gtk_box_pack_start (GTK_BOX (vbox1), s->spinbutton1, FALSE, FALSE, 0);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (s->spinbutton1), TRUE);

  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "vbox2", vbox2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox2);
  gtk_box_pack_start (GTK_BOX (hbox1), vbox2, TRUE, TRUE, 5);
  gtk_container_set_border_width (GTK_CONTAINER (vbox2), 5);

  label4 = gtk_label_new (gettext("Height:"));
  gtk_widget_ref (label4);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "label4", label4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label4);
  gtk_box_pack_start (GTK_BOX (vbox2), label4, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label4), GTK_JUSTIFY_LEFT);

  spinbutton2_adj = gtk_adjustment_new (400, 0, 768, 1, 10, 10);
  s->spinbutton2 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton2_adj), 1, 0);
  gtk_widget_ref (s->spinbutton2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "spinbutton2", s->spinbutton2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (s->spinbutton2);
  gtk_box_pack_start (GTK_BOX (vbox2), s->spinbutton2, FALSE, FALSE, 0);

  frame13 = gtk_frame_new (gettext("Confirm/rename mode"));
  gtk_widget_ref (frame13);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame13", frame13,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame13);
  gtk_table_attach (GTK_TABLE (table1), frame13, 1, 2, 3, 4,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame13), 5);

  checkbutton3 = gtk_check_button_new_with_label (gettext("Confirm deleting or overwriting"));
  gtk_widget_ref (checkbutton3);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "checkbutton3", checkbutton3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (checkbutton3);
  gtk_container_add (GTK_CONTAINER (frame13), checkbutton3);
  gtk_container_set_border_width (GTK_CONTAINER (checkbutton3), 3);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (checkbutton3), TRUE);

  frame19 = gtk_frame_new (gettext("Sort by"));
  gtk_widget_ref (frame19);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame19", frame19,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame19);
  gtk_table_attach (GTK_TABLE (table1), frame19, 1, 2, 4, 5,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame19), 5);

  table5 = gtk_table_new (2, 3, FALSE);
  gtk_widget_ref (table5);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "table5", table5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (table5);
  gtk_container_add (GTK_CONTAINER (frame19), table5);

  radiobutton41 = gtk_radio_button_new_with_label (right_sort_grp_group, gettext("name"));
  right_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton41));
  gtk_widget_ref (radiobutton41);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton41", radiobutton41,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton41);
  gtk_table_attach (GTK_TABLE (table5), radiobutton41, 0, 1, 0, 1,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton41), 3);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton41), TRUE);

  radiobutton43 = gtk_radio_button_new_with_label (right_sort_grp_group, gettext("group"));
  right_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton43));
  gtk_widget_ref (radiobutton43);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton43", radiobutton43,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton43);
  gtk_table_attach (GTK_TABLE (table5), radiobutton43, 2, 3, 0, 1,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton43), 3);

  radiobutton44 = gtk_radio_button_new_with_label (right_sort_grp_group, gettext("date"));
  right_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton44));
  gtk_widget_ref (radiobutton44);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton44", radiobutton44,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton44);
  gtk_table_attach (GTK_TABLE (table5), radiobutton44, 0, 1, 1, 2,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton44), 3);

  radiobutton46 = gtk_radio_button_new_with_label (right_sort_grp_group, gettext("user"));
  right_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton46));
  gtk_widget_ref (radiobutton46);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton46", radiobutton46,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton46);
  gtk_table_attach (GTK_TABLE (table5), radiobutton46, 2, 3, 1, 2,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton46), 3);

  radiobutton42 = gtk_radio_button_new_with_label (right_sort_grp_group, gettext("size"));
  right_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton42));
  gtk_widget_ref (radiobutton42);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton42", radiobutton42,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton42);
  gtk_table_attach (GTK_TABLE (table5), radiobutton42, 1, 2, 0, 1,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton42), 3);

  radiobutton45 = gtk_radio_button_new_with_label (right_sort_grp_group, gettext("attributes"));
  right_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton45));
  gtk_widget_ref (radiobutton45);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton45", radiobutton45,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton45);
  gtk_table_attach (GTK_TABLE (table5), radiobutton45, 1, 2, 1, 2,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton45), 3);

  frame4 = gtk_frame_new (gettext("Path mode (TI89,92, 92+ only)"));
  gtk_widget_ref (frame4);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame4", frame4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame4);
  gtk_table_attach (GTK_TABLE (table1), frame4, 0, 1, 3, 4,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame4), 5);

  hbox2 = gtk_hbox_new (FALSE, 0);
  gtk_widget_ref (hbox2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbox2", hbox2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox2);
  gtk_container_add (GTK_CONTAINER (frame4), hbox2);

  radiobutton11 = gtk_radio_button_new_with_label (path_mode_grp_group, gettext("full path"));
  path_mode_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton11));
  gtk_widget_ref (radiobutton11);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton11", radiobutton11,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton11);
  gtk_box_pack_start (GTK_BOX (hbox2), radiobutton11, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton11), 3);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton11), TRUE);

  radiobutton12 = gtk_radio_button_new_with_label (path_mode_grp_group, gettext("local path"));
  path_mode_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton12));
  gtk_widget_ref (radiobutton12);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton12", radiobutton12,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton12);
  gtk_box_pack_start (GTK_BOX (hbox2), radiobutton12, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton12), 3);

  frame18 = gtk_frame_new (gettext("Sort by"));
  gtk_widget_ref (frame18);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "frame18", frame18,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame18);
  gtk_table_attach (GTK_TABLE (table1), frame18, 0, 1, 4, 5,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame18), 5);

  table4 = gtk_table_new (2, 2, FALSE);
  gtk_widget_ref (table4);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "table4", table4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (table4);
  gtk_container_add (GTK_CONTAINER (frame18), table4);

  radiobutton23 = gtk_radio_button_new_with_label (left_sort_grp_group, gettext("info"));
  left_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton23));
  gtk_widget_ref (radiobutton23);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton23", radiobutton23,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton23);
  gtk_table_attach (GTK_TABLE (table4), radiobutton23, 0, 1, 1, 2,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton23), 3);

  radiobutton24 = gtk_radio_button_new_with_label (left_sort_grp_group, gettext("size"));
  left_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton24));
  gtk_widget_ref (radiobutton24);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton24", radiobutton24,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton24);
  gtk_table_attach (GTK_TABLE (table4), radiobutton24, 1, 2, 1, 2,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton24), 3);

  radiobutton22 = gtk_radio_button_new_with_label (left_sort_grp_group, gettext("type"));
  left_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton22));
  gtk_widget_ref (radiobutton22);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton22", radiobutton22,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton22);
  gtk_table_attach (GTK_TABLE (table4), radiobutton22, 1, 2, 0, 1,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton22), 3);

  radiobutton21 = gtk_radio_button_new_with_label (left_sort_grp_group, gettext("name"));
  left_sort_grp_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton21));
  gtk_widget_ref (radiobutton21);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "radiobutton21", radiobutton21,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (radiobutton21);
  gtk_table_attach (GTK_TABLE (table4), radiobutton21, 0, 1, 0, 1,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton21), 3);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton21), TRUE);

  dialog_action_area1 = GTK_DIALOG (s->dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (s->dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label (gettext("OK"));
  gtk_widget_ref (button1);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "button1", button1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button1);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button1);
  GTK_WIDGET_SET_FLAGS (button1, GTK_CAN_DEFAULT);

  button2 = gtk_button_new_with_label (gettext("Cancel"));
  gtk_widget_ref (button2);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "button2", button2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button2);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button2);
  GTK_WIDGET_SET_FLAGS (button2, GTK_CAN_DEFAULT);

  button3 = gtk_button_new_with_label (gettext("Help"));
  gtk_widget_ref (button3);
  gtk_object_set_data_full (GTK_OBJECT (s->dialog), "button3", button3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button3);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button3);
  GTK_WIDGET_SET_FLAGS (button3, GTK_CAN_DEFAULT);

  /* Activate some buttons */
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(s->spinbutton1), s->xsize);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(s->spinbutton2), s->ysize);
  if(s->clist_sort == SORT_BY_NAME)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton41), TRUE);
  if(s->clist_sort == SORT_BY_SIZE)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton42), TRUE);
  if(s->clist_sort == SORT_BY_GROUP)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton43), TRUE);
  if(s->clist_sort == SORT_BY_DATE)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton44), TRUE);
  if(s->clist_sort == SORT_BY_ATTRB)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton45), TRUE);
  if(s->clist_sort == SORT_BY_USER)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton46), TRUE);
  if(s->clist_sort_order == SORT_UP)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton51), TRUE);
  else
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton52), TRUE);
  if(s->ctree_sort == SORT_BY_NAME)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton21), TRUE);
  if(s->ctree_sort == SORT_BY_TYPE)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton22), TRUE);
  if(s->ctree_sort == SORT_BY_INFO)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton23), TRUE);
  if(s->ctree_sort == SORT_BY_SIZE)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton24), TRUE);
  if(s->ctree_sort_order == SORT_UP)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton31), TRUE);
  else
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton32), TRUE);
  if(s->path_mode == FULL_PATH)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton11), TRUE);
  if(s->path_mode == LOCAL_PATH)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton12), TRUE);  

  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (checkbutton1), s->show);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (checkbutton2), s->file_mode);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (checkbutton3), s->confirm);


  /* Install callbacks */
  gtk_signal_connect (GTK_OBJECT (radiobutton51), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton51_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton52), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton52_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton31), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton31_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton32), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton32_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (checkbutton2), "toggled",
                      GTK_SIGNAL_FUNC (gdb_checkbutton2_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (checkbutton1), "toggled",
                      GTK_SIGNAL_FUNC (gdb_checkbutton1_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (s->spinbutton1), "changed",
                      GTK_SIGNAL_FUNC (gdb_spinbutton1_changed),
                      s);
  gtk_signal_connect (GTK_OBJECT (s->spinbutton2), "changed",
                      GTK_SIGNAL_FUNC (gdb_spinbutton2_changed),
                      s);
  gtk_signal_connect (GTK_OBJECT (checkbutton3), "toggled",
                      GTK_SIGNAL_FUNC (gdb_checkbutton3_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton41), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton41_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton43), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton43_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton44), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton44_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton46), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton46_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton42), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton42_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton45), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton45_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton11), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton11_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton12), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton12_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton23), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton23_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton24), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton24_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton22), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton22_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (radiobutton21), "toggled",
                      GTK_SIGNAL_FUNC (gdb_radiobutton21_toggled),
                      s);
  gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                      GTK_SIGNAL_FUNC (gdb_button1_clicked),
                      s);
  gtk_signal_connect (GTK_OBJECT (button2), "clicked",
                      GTK_SIGNAL_FUNC (gdb_button2_clicked),
                      s);
  gtk_signal_connect (GTK_OBJECT (button3), "clicked",
                      GTK_SIGNAL_FUNC (gdb_button3_clicked),
                      s);

  gtk_widget_show_all(s->dialog);
}

/*********************/
/* Thanks dialog box */
/*********************/
/* Display a dlgbox which provide some help */
void dlgbox_help_thanks(GtkWidget *widget, gpointer data)
{
  GtkWidget *dialog;
  GtkWidget *text;
  GtkWidget *vscrollbar;
  GtkWidget *table;
  GtkWidget *button;
  gchar buffer[MAXCHARS];
  FILE *fd;
  const char no_help_available[] = gettext_noop("Cannot find the thanks file THANKS");

  dialog = gtk_dialog_new ();
  gtk_window_set_title (GTK_WINDOW (dialog), gettext("GtkTiLink thanks"));
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
  gtk_widget_set_usize(GTK_WIDGET (dialog), 400, 400);
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
  gtk_container_border_width (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), 10);
  gtk_container_border_width (GTK_CONTAINER (GTK_DIALOG (dialog)->action_area), 5);
  gtk_box_set_spacing (GTK_BOX (GTK_DIALOG (dialog)->vbox), 5);
  gtk_box_set_homogeneous (GTK_BOX (GTK_DIALOG (dialog)->action_area), TRUE);
  gtk_signal_connect_object (GTK_OBJECT (dialog), "delete_event", GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			     GTK_OBJECT (dialog));
  gtk_signal_connect_object (GTK_OBJECT (dialog), "destroy", GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			     GTK_OBJECT (dialog));  

  button = gtk_button_new_with_label (gettext(" Close "));
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->action_area), button, FALSE, FALSE, FALSE);
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked", GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			     GTK_OBJECT (dialog));
  gtk_widget_grab_default (button);
  gtk_widget_show (button);

  table = gtk_table_new (2, 2, FALSE);
  gtk_table_set_row_spacing (GTK_TABLE (table), 0, 2);
  gtk_table_set_col_spacing (GTK_TABLE (table), 0, 2);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), table, TRUE, TRUE, 0);
  gtk_widget_show (table);
  
  text = gtk_text_new (NULL, NULL);
  gtk_text_set_editable (GTK_TEXT (text), FALSE);
  gtk_text_set_word_wrap (GTK_TEXT (text), TRUE);
  gtk_table_attach (GTK_TABLE (table), text, 0, 1, 0, 1,
		    GTK_EXPAND | GTK_SHRINK | GTK_FILL,
		    GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_show (text);

  vscrollbar = gtk_vscrollbar_new (GTK_TEXT (text)->vadj);
  gtk_table_attach (GTK_TABLE (table), vscrollbar, 1, 2, 0, 1,
		    GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_show (vscrollbar);

  gtk_widget_realize(text);
  gtk_text_freeze (GTK_TEXT (text));

  strcpy(buffer, clist_win.win_dir);
  /*
#ifndef __WIN32__
  strcat(buffer, SHARE_DIR "/");
#else
  strcat(buffer, SHARE_DIR "\\");
#endif
  */
  strcat(buffer, SHARE_DIR DIR_SEPARATOR);
  strcat(buffer, "thanks");

  /* Choose the help file according to the language of the user */
  if( access(buffer, F_OK) != 0 ) 
    {
      if( access(buffer, F_OK) != 0 ) 
	{
	  gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, no_help_available, strlen (no_help_available));
	  gtk_widget_show (dialog);
	  return;
	}
    }
  if( (fd=fopen (buffer, "r")) == NULL) 
    {
      gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, no_help_available, strlen (no_help_available));
      gtk_widget_show (dialog);
      return;
    }
  memset (buffer, 0, sizeof(buffer));
  while(fread (buffer, 1, sizeof(buffer)-1, fd)) 
    {
      gtk_text_insert (GTK_TEXT (text), NULL, NULL, NULL, buffer, strlen (buffer));
      memset (buffer, 0, sizeof(buffer));
    }
  fclose (fd);  

  gtk_text_thaw (GTK_TEXT (text));
  gtk_widget_show(dialog);
}

/* Converts a string in lowercase */
char *string_lower(char *s)
{
  int i;

  for(i=0; i<strlen(s); i++) s[i]=tolower(s[i]);

  return s;
}

/****************************/
/* ROM dump size dialog box */
/****************************/

/* Returns 0 for cancel, 1 for 1 Mb size or 2 for 2 Mb size */
gint rom_dump_choose_size()
{
  GtkWidget *dialog;
  GtkWidget *dialog_vbox1;
  GtkWidget *frame1;
  GtkWidget *vbox1;
  GSList *rom_group_group = NULL;
  GtkWidget *radiobutton1;
  GtkWidget *radiobutton2;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *ok_button;
  GtkWidget *cancel_button;
  gint i=0;
  gint rom_size = 1; // 1 Mb (default choice)

  dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog", dialog);
  gtk_window_set_title (GTK_WINDOW (dialog), gettext("ROM size"));
  gtk_window_set_policy (GTK_WINDOW (dialog), TRUE, TRUE, TRUE);
  gtk_window_set_position (GTK_WINDOW (dialog), GTK_WIN_POS_CENTER);
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);

  dialog_vbox1 = GTK_DIALOG (dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  frame1 = gtk_frame_new (gettext("ROM size"));
  gtk_object_set_data (GTK_OBJECT (dialog), "frame1", frame1);
  gtk_widget_show (frame1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), frame1, TRUE, TRUE, 5);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 5);

  vbox1 = gtk_vbox_new (TRUE, 0);
  gtk_object_set_data (GTK_OBJECT (dialog), "vbox1", vbox1);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (frame1), vbox1);
  gtk_container_set_border_width (GTK_CONTAINER (vbox1), 5);

  radiobutton1 = gtk_radio_button_new_with_label (rom_group_group, gettext("1 Mb"));
  rom_group_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton1));
  gtk_object_set_data (GTK_OBJECT (dialog), "radiobutton1", radiobutton1);
  gtk_widget_show (radiobutton1);
  gtk_box_pack_start (GTK_BOX (vbox1), radiobutton1, TRUE, TRUE, 5);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton1), 5);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton1), TRUE);

  radiobutton2 = gtk_radio_button_new_with_label (rom_group_group, gettext("2 Mb"));
  rom_group_group = gtk_radio_button_group (GTK_RADIO_BUTTON (radiobutton2));
  gtk_object_set_data (GTK_OBJECT (dialog), "radiobutton2", radiobutton2);
  gtk_widget_show (radiobutton2);
  gtk_box_pack_start (GTK_BOX (vbox1), radiobutton2, TRUE, TRUE, 5);
  gtk_container_set_border_width (GTK_CONTAINER (radiobutton2), 5);

  dialog_action_area1 = GTK_DIALOG (dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "hbuttonbox1", hbuttonbox1);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  ok_button = gtk_button_new_with_label (gettext("Next >"));
  gtk_object_set_data (GTK_OBJECT (dialog), "ok_button", ok_button);
  gtk_widget_show (ok_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), ok_button);
  GTK_WIDGET_SET_FLAGS (ok_button, GTK_CAN_DEFAULT);

  cancel_button = gtk_button_new_with_label (gettext("Cancel"));
  gtk_object_set_data (GTK_OBJECT (dialog), "cancel_button", cancel_button);
  gtk_widget_show (cancel_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), cancel_button);
  GTK_WIDGET_SET_FLAGS (cancel_button, GTK_CAN_DEFAULT);
  
  gtk_signal_connect (GTK_OBJECT (radiobutton1), "toggled",
                      GTK_SIGNAL_FUNC (rds_radiobutton1_toggled),
                      &rom_size);
  gtk_signal_connect (GTK_OBJECT (radiobutton2), "toggled",
                      GTK_SIGNAL_FUNC (rds_radiobutton2_toggled),
                      &rom_size);

  gtk_signal_connect (GTK_OBJECT (ok_button), "clicked",
                      GTK_SIGNAL_FUNC (user_box_b1),
                      &i);
  gtk_signal_connect (GTK_OBJECT (cancel_button), "clicked",
                      GTK_SIGNAL_FUNC (user_box_b2),
                      &i);
  
  gtk_widget_show_all(dialog);
  
  while(!i)
    {
      while( gtk_events_pending() ) { gtk_main_iteration(); }
    }
  gtk_widget_destroy(dialog);

  if(i == BUTTON1)
    return rom_size;
  else
    return 0;
}

/*********************************/
/* ROM dump receiving dialog box */
/*********************************/

gint rom_dump_receive()
{
  GtkWidget *dialog;
  GtkWidget *dialog_vbox1;
  GtkWidget *frame;
  GtkWidget *vbox1;
  GtkWidget *table1;
  GtkWidget *label1;
  GtkWidget *label3;
  GtkWidget *label4;
  GtkWidget *label5;
  GtkWidget *label6;
  GtkWidget *vseparator;
  GtkWidget *label2;
  GtkWidget *progressbar;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *cancel_button;

  dialog = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog", dialog);
  gtk_window_set_title (GTK_WINDOW (dialog), gettext("dialog"));
  gtk_window_set_policy (GTK_WINDOW (dialog), TRUE, TRUE, TRUE);
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);

  dialog_vbox1 = GTK_DIALOG (dialog)->vbox;
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  frame = gtk_frame_new (gettext("Ready..."));
  gtk_object_set_data (GTK_OBJECT (dialog), "frame", frame);
  gtk_widget_show (frame);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), frame, TRUE, TRUE, 5);
  gtk_container_set_border_width (GTK_CONTAINER (frame), 5);

  vbox1 = gtk_vbox_new (FALSE, 5);
  gtk_object_set_data (GTK_OBJECT (dialog), "vbox1", vbox1);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (frame), vbox1);
  gtk_container_set_border_width (GTK_CONTAINER (vbox1), 10);

  table1 = gtk_table_new (2, 4, TRUE);
  gtk_object_set_data (GTK_OBJECT (dialog), "table1", table1);
  gtk_widget_show (table1);
  gtk_box_pack_start (GTK_BOX (vbox1), table1, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (table1), 3);

  label1 = gtk_label_new (gettext("Remaining:"));
  gtk_object_set_data (GTK_OBJECT (dialog), "label1", label1);
  gtk_widget_show (label1);
  gtk_table_attach (GTK_TABLE (table1), label1, 0, 1, 0, 1,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (0), 0, 0);
  gtk_label_set_justify (GTK_LABEL (label1), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label1), 0, 0.5);

  label3 = gtk_label_new (gettext("0/1048576"));
  gtk_object_set_data (GTK_OBJECT (dialog), "label3", label3);
  gtk_widget_show (label3);
  gtk_table_attach (GTK_TABLE (table1), label3, 0, 1, 1, 2,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (0), 0, 0);
  gtk_label_set_justify (GTK_LABEL (label3), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label3), 0, 0.5);

  label4 = gtk_label_new (gettext("Time to go:"));
  gtk_object_set_data (GTK_OBJECT (dialog), "label4", label4);
  gtk_widget_show (label4);
  gtk_table_attach (GTK_TABLE (table1), label4, 2, 3, 1, 2,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (0), 0, 0);
  gtk_label_set_justify (GTK_LABEL (label4), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label4), 0, 0.5);

  label5 = gtk_label_new (gettext(" 00:00:00"));
  gtk_object_set_data (GTK_OBJECT (dialog), "label5", label5);
  gtk_widget_show (label5);
  gtk_table_attach (GTK_TABLE (table1), label5, 3, 4, 0, 1,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (0), 0, 0);
  gtk_label_set_justify (GTK_LABEL (label5), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label5), 1, 0.5);

  label6 = gtk_label_new (gettext(" 00:00:00"));
  gtk_object_set_data (GTK_OBJECT (dialog), "label6", label6);
  gtk_widget_show (label6);
  gtk_table_attach (GTK_TABLE (table1), label6, 3, 4, 1, 2,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (0), 0, 0);
  gtk_label_set_justify (GTK_LABEL (label6), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label6), 1, 0.5);

  vseparator = gtk_vseparator_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "vseparator", vseparator);
  gtk_widget_show (vseparator);
  gtk_table_attach (GTK_TABLE (table1), vseparator, 1, 2, 0, 2,
                    (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
                    (GtkAttachOptions) (GTK_FILL), 0, 0);

  label2 = gtk_label_new (gettext("Time elapsed:"));
  gtk_object_set_data (GTK_OBJECT (dialog), "label2", label2);
  gtk_widget_show (label2);
  gtk_table_attach (GTK_TABLE (table1), label2, 2, 3, 0, 1,
                    (GtkAttachOptions) (GTK_FILL),
                    (GtkAttachOptions) (0), 0, 0);
  gtk_label_set_justify (GTK_LABEL (label2), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label2), 0, 0.5);

  progressbar = gtk_progress_bar_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "progressbar", progressbar);
  gtk_widget_show (progressbar);
  gtk_box_pack_start (GTK_BOX (vbox1), progressbar, TRUE, FALSE, 5);
  gtk_progress_set_show_text (GTK_PROGRESS (progressbar), TRUE);
  gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR (progressbar), 
				  PROGRESS_TYPE);

  dialog_action_area1 = GTK_DIALOG (dialog)->action_area;
  gtk_object_set_data (GTK_OBJECT (dialog), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_object_set_data (GTK_OBJECT (dialog), "hbuttonbox1", hbuttonbox1);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  cancel_button = gtk_button_new_with_label (gettext("Cancel"));
  gtk_object_set_data (GTK_OBJECT (dialog), "cancel_button", cancel_button);
  gtk_widget_show (cancel_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), cancel_button);
  GTK_WIDGET_SET_FLAGS (cancel_button, GTK_CAN_DEFAULT);
  /*
  gtk_signal_connect (GTK_OBJECT (cancel_button), "clicked",
                      GTK_SIGNAL_FUNC (rcv_cancel_button_clicked),
                      NULL);
  */
  return 0;
}
