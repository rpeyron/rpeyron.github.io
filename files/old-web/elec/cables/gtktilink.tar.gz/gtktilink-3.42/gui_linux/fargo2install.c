
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

//#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>
#include "fargo2.h"

GtkWidget *window1;
GtkWidget *window2;
GtkWidget *fixed2;
GtkWidget *outputtext;

typedef struct
{
	char *texte;
	int couleur;
}	message;

typedef struct
{
	int nombre;
	message *msg;
}	messages;

messages msgs;
pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;

void end_of_install(void)
{
gtk_widget_destroy (window2);
}
GdkColor *palette(int indexe)
{
GdkColor *gcouleur=(GdkColor *)malloc(sizeof(GdkColor));
gcouleur->pixel=0;
switch(indexe)
{

case ROUGE: {gcouleur->red=60000;gcouleur->green=0;gcouleur->blue=0;break;}
case VERT: {gcouleur->red=0;gcouleur->green=60000;gcouleur->blue=0;break;}
case BLEU: {gcouleur->red=0;gcouleur->green=0;gcouleur->blue=60000;break;}
case NOIR: {gcouleur->red=0;gcouleur->green=0;gcouleur->blue=0;break;}
case ROUGEFONCE: {gcouleur->red=30000;gcouleur->green=0;gcouleur->blue=0;break;}
case VERTFONCE: {gcouleur->red=0;gcouleur->green=30000;gcouleur->blue=0;break;} 
                                
case BLEUFONCE: {gcouleur->red=0;gcouleur->green=0;gcouleur->blue=30000;break;}
default :{gcouleur->red=0;gcouleur->green=0;gcouleur->blue=0;}
}

return gcouleur;
}
void affiche_message(char *txt, int couleur)
{
/*
 pourquoi ne pas afficher directement ?
 demande a celui qui a fait gtk pourquoi it IS NOT thread safe
gtk_text_insert (GTK_TEXT (TextOutput), NULL, palette(couleur), NULL, txt, -1);
 moralit� je remplis des strucutres qu'un fonction "en timer" va vider au fur et
 � mesure.
*/	
char *texte=(char *)malloc(strlen(txt)+1+1);
strcpy(texte,txt);strcat(texte,"\n");

pthread_mutex_lock(&mut);
msgs.nombre++;
msgs.msg=(message  *)realloc(msgs.msg, msgs.nombre*sizeof(message));
msgs.msg[msgs.nombre-1].couleur=couleur;
msgs.msg[msgs.nombre-1].texte=texte;
/*
i=0;
while (i<=(msgs.nombre-1))
{
	printf("n�%d dans le buffer : \"%s\"\n",i,msgs.msg[i].texte);
	i++;
}
*/
	
pthread_mutex_unlock(&mut);
}
int affichage_des_messages()
{
	char *txt;
	int couleur;
	int i=0;
	pthread_mutex_lock(&mut);
	//printf("Y a-t-il qqchose a �crire ?\n");
	if (msgs.nombre>10)
		{
			printf("!!! WARNING !!! \n Flooding du serveur, limitation des messages\n");
			msgs.nombre=10;
		}
	while (i<msgs.nombre)
		{
			txt=msgs.msg[i].texte;
			couleur=msgs.msg[i].couleur;
			//printf("oui, �a : %s\n",txt);
			
			gtk_text_insert (GTK_TEXT (outputtext), NULL, palette(couleur), NULL, txt, -1);		
			i++;
			free(txt);
		}
	msgs.nombre=0;
	pthread_mutex_unlock(&mut);		
return(TRUE);
}
void create_window2(void);

void begin_install()
{
pthread_t p;
gtk_widget_destroy (window1);
create_window2();
pthread_create(&p, NULL, (void *) &start_install_process, NULL);

}
void install_finished(void)
{

  GtkWidget *button_end;
  button_end = gtk_button_new_with_label ("Installation finished");
  gtk_widget_ref (button_end);
  gtk_object_set_data_full (GTK_OBJECT (window2), "button_end", button_end,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_signal_connect (GTK_OBJECT (button_end), "clicked",
                        GTK_SIGNAL_FUNC (end_of_install), NULL);

                         
  gtk_widget_show (button_end);
  gtk_fixed_put (GTK_FIXED (fixed2), button_end, 96, 256);
  gtk_widget_set_uposition (button_end, 96, 256);
  gtk_widget_set_usize (button_end, 224, 32);
  printf("install finished\n");
}

void
install_fargo (void)
{
  
  GtkWidget *fixed1;
  GtkWidget *shell_button;
  GtkWidget *start_install;
  GtkWidget *cancel;
  GtkWidget *hexlib_button;
  GtkWidget *warning_label;
  GtkWidget *flib_button;
  
  
/*
 a partir d'ici on ne touche plus, c'est glade qui s'en occupe
*/
 window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_object_set_data (GTK_OBJECT (window1), "window1", window1);
  gtk_window_set_title (GTK_WINDOW (window1), "installation of fargo2");
  gtk_window_set_default_size (GTK_WINDOW (window1), 460, 360);

  fixed1 = gtk_fixed_new ();
  gtk_widget_ref (fixed1);
  gtk_object_set_data_full (GTK_OBJECT (window1), "fixed1", fixed1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fixed1);
  gtk_container_add (GTK_CONTAINER (window1), fixed1);

  shell_button = gtk_check_button_new_with_label ("install the original fargo shell ( recomended)");
  gtk_widget_ref (shell_button);
  gtk_object_set_data_full (GTK_OBJECT (window1), "shell_button", shell_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (shell_button);
  gtk_fixed_put (GTK_FIXED (fixed1), shell_button, 32, 192);
  gtk_widget_set_uposition (shell_button, 32, 192);
  gtk_widget_set_usize (shell_button, 304, 24);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (shell_button), TRUE);

  start_install = gtk_button_new_with_label ("Begin installation of FARGO 2");
  gtk_widget_ref (start_install);
  gtk_object_set_data_full (GTK_OBJECT (window1), "start_install", start_install,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (start_install);
  gtk_fixed_put (GTK_FIXED (fixed1), start_install, 24, 296);
  gtk_widget_set_uposition (start_install, 24, 296);
  gtk_widget_set_usize (start_install, 208, 40);

  cancel = gtk_button_new_with_label ("I am scared I'll try later");
  gtk_widget_ref (cancel);
  gtk_object_set_data_full (GTK_OBJECT (window1), "cancel", cancel,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (cancel);
  gtk_fixed_put (GTK_FIXED (fixed1), cancel, 256, 296);
  gtk_widget_set_uposition (cancel, 256, 296);
  gtk_widget_set_usize (cancel, 160, 40);

  hexlib_button = gtk_check_button_new_with_label ("install the hexlib ( recommended )");
  gtk_widget_ref (hexlib_button);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hexlib_button", hexlib_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hexlib_button);
  gtk_fixed_put (GTK_FIXED (fixed1), hexlib_button, 32, 168);
  gtk_widget_set_uposition (hexlib_button, 32, 168);
  gtk_widget_set_usize (hexlib_button, 296, 24);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (hexlib_button), TRUE);

  warning_label = gtk_label_new ("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWARNING !!\nThe installation of FARGO 2\non your calculator is not bullet proof\nI suggest you to make a backup of the TI before proceding\n");
  gtk_widget_ref (warning_label);
  gtk_object_set_data_full (GTK_OBJECT (window1), "warning_label", warning_label,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_label);
  gtk_fixed_put (GTK_FIXED (fixed1), warning_label, 56, 32);
  gtk_widget_set_uposition (warning_label, 56, 32);
  gtk_widget_set_usize (warning_label, 360, 96);
  gtk_label_set_justify (GTK_LABEL (warning_label), GTK_JUSTIFY_LEFT);

  flib_button = gtk_check_button_new_with_label ("intall flib ( without, you won't be able to do much )");
  gtk_widget_ref (flib_button);
  gtk_object_set_data_full (GTK_OBJECT (window1), "flib_button", flib_button,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (flib_button);
  gtk_fixed_put (GTK_FIXED (fixed1), flib_button, 32, 144);
  gtk_widget_set_uposition (flib_button, 32, 144);
  gtk_widget_set_usize (flib_button, 400, 24);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (flib_button), TRUE);

  gtk_signal_connect (GTK_OBJECT (start_install), "clicked",
                      GTK_SIGNAL_FUNC (begin_install),
                      NULL);
   gtk_signal_connect_object (GTK_OBJECT (cancel), "clicked",
                             GTK_SIGNAL_FUNC (gtk_widget_destroy),
                             GTK_OBJECT (window1));

/*
 stop copying from glade here
*/
  gtk_widget_show (window1);
}

void
create_window2 (void)
{

  
  GtkWidget *process_label;
  GtkWidget *fargo_install;
  GtkWidget *outputs;
  GtkWidget *outputscrolledwindow;

  
  window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_object_set_data (GTK_OBJECT (window2), "window2", window2);
  gtk_window_set_title (GTK_WINDOW (window2), "Processing the FARGO 2 installation");
  gtk_window_set_default_size (GTK_WINDOW (window2), 480, 300);

  fixed2 = gtk_fixed_new ();
  gtk_widget_ref (fixed2);
  gtk_object_set_data_full (GTK_OBJECT (window2), "fixed2", fixed2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fixed2);
  gtk_container_add (GTK_CONTAINER (window2), fixed2);

  process_label = gtk_label_new ("processing ...");
  gtk_widget_ref (process_label);
  gtk_object_set_data_full (GTK_OBJECT (window2), "process_label", process_label,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (process_label);
  gtk_fixed_put (GTK_FIXED (fixed2), process_label, 16, 16);
  gtk_widget_set_uposition (process_label, 16, 16);
  gtk_widget_set_usize (process_label, 144, 40);

  fargo_install = gtk_progress_bar_new ();
  gtk_widget_ref (fargo_install);
  gtk_object_set_data_full (GTK_OBJECT (window2), "fargo_install", fargo_install,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fargo_install);
  gtk_fixed_put (GTK_FIXED (fixed2), fargo_install, 160, 24);
  gtk_widget_set_uposition (fargo_install, 160, 24);
  gtk_widget_set_usize (fargo_install, 296, 24);
  gtk_progress_configure (GTK_PROGRESS (fargo_install), 2, 0, 100);

 


  outputs = gtk_label_new ("Installation output :");
  gtk_widget_ref (outputs);
  gtk_object_set_data_full (GTK_OBJECT (window2), "outputs", outputs,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (outputs);
  gtk_fixed_put (GTK_FIXED (fixed2), outputs, 16, 72);
  gtk_widget_set_uposition (outputs, 16, 72);
  gtk_widget_set_usize (outputs, 168, 24);


 outputscrolledwindow = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_ref (outputscrolledwindow);
  gtk_object_set_data_full (GTK_OBJECT (window2), "outputscrolledwindow", outputscrolledwindow,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (outputscrolledwindow);
  gtk_fixed_put (GTK_FIXED (fixed2), outputscrolledwindow, 40, 128);
  gtk_widget_set_uposition (outputscrolledwindow, 40, 128);
  gtk_widget_set_usize (outputscrolledwindow, 408, 112);
  gtk_container_set_border_width (GTK_CONTAINER (outputscrolledwindow), 2);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (outputscrolledwindow), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);

  outputtext = gtk_text_new (NULL, NULL);
  gtk_widget_ref (outputtext);
  gtk_object_set_data_full (GTK_OBJECT (window2), "outputtext", outputtext,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (outputtext);
  gtk_container_add (GTK_CONTAINER (outputscrolledwindow), outputtext);

  gtk_widget_show (window2);
  msgs.nombre=0;
gtk_timeout_add (300, affichage_des_messages, NULL);
}

