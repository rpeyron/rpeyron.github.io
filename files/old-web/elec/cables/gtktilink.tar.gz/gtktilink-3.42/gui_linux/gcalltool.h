/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef GCALLTOOL_H
#define GCALLTOOL_H

#include <gtk/gtk.h>

void toolbar_button_00(GtkWidget *widget, gpointer data);
void toolbar_button_01(GtkWidget *widget, gpointer data);
void toolbar_button_02(GtkWidget *widget, gpointer data);
void toolbar_button_03(GtkWidget *widget, gpointer data);
void toolbar_button_04(GtkWidget *widget, gpointer data);
void toolbar_button_05(GtkWidget *widget, gpointer data);
void toolbar_button_06(GtkWidget *widget, gpointer data);
void toolbar_button_07(GtkWidget *widget, gpointer data);
void toolbar_button_08(GtkWidget *widget, gpointer data);
void toolbar_button_09(GtkWidget *widget, gpointer data);
void toolbar_button_10(GtkWidget *widget, gpointer data);

void toolbar_button_20(GtkWidget *widget, gpointer data);
void toolbar_button_21(GtkWidget *widget, gpointer data);
void toolbar_button_22(GtkWidget *widget, gpointer data);
void toolbar_button_23(GtkWidget *widget, gpointer data);

#endif
