/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#ifdef HAVE_DIRENT_H
#include <dirent.h>
#include <dlfcn.h>
#else
#include "dirent.h"
#endif
#include <gmodule.h> // for plug-ins

#include "../indep/paths.h"
#include "defines.h"

GList *plugin_info_list = NULL;

static char *concat(const char **l, char **s);

/*****************************/
/* Cb for the function below */
/*****************************/
static gint temp;

void
on_checkbutton1_toggled                (GtkWidget       *widget,
                                        gpointer data)
{  if(temp == PLUGINS_AUTO)
    temp = PLUGINS_MANUAL;
  else
    temp = PLUGINS_AUTO; 
}

void
on_button11_clicked                     (GtkWidget       *widget,
                                        gpointer data)
{
  options.plugins_loading = temp;
  gtk_widget_destroy(GTK_WIDGET(data));
}

void
on_button12_clicked                     (GtkWidget       *widget,
                                        gpointer data)
{
  gtk_widget_destroy(GTK_WIDGET(data));
}

/*************************************************************/
/* This functions creates the dialog box for plugins options */
/*************************************************************/
GtkWidget*
create_plugins_options_dbox (void)
{
  GtkWidget *plugins_options_dbox;
  GtkWidget *dialog_vbox1;
  GtkWidget *frame;
  GtkWidget *vbox1;
  GtkWidget *checkbutton1;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *button1;
  GtkWidget *button2;

  temp = options.plugins_loading;
  plugins_options_dbox = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (plugins_options_dbox), "plugins_options_dbox", plugins_options_dbox);
  gtk_window_set_title (GTK_WINDOW (plugins_options_dbox), "Options");
  gtk_window_set_position (GTK_WINDOW (plugins_options_dbox), GTK_WIN_POS_MOUSE);
  gtk_window_set_policy (GTK_WINDOW (plugins_options_dbox), FALSE, FALSE, FALSE);

  dialog_vbox1 = GTK_DIALOG (plugins_options_dbox)->vbox;
  gtk_object_set_data (GTK_OBJECT (plugins_options_dbox), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  frame = gtk_frame_new ("Options:");
  gtk_widget_ref (frame);
  gtk_object_set_data_full (GTK_OBJECT (plugins_options_dbox), "frame", frame,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), frame, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame), 5);

  vbox1 = gtk_vbox_new (TRUE, 0);
  gtk_widget_ref (vbox1);
  gtk_object_set_data_full (GTK_OBJECT (plugins_options_dbox), "vbox1", vbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (frame), vbox1);
  gtk_container_set_border_width (GTK_CONTAINER (vbox1), 5);

  checkbutton1 = gtk_check_button_new_with_label ("Load plug-ins at startup");
  gtk_widget_ref (checkbutton1);
  gtk_object_set_data_full (GTK_OBJECT (plugins_options_dbox), "checkbutton1", checkbutton1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (checkbutton1);
  gtk_box_pack_start (GTK_BOX (vbox1), checkbutton1, FALSE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (checkbutton1), 5);

  dialog_action_area1 = GTK_DIALOG (plugins_options_dbox)->action_area;
  gtk_object_set_data (GTK_OBJECT (plugins_options_dbox), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (plugins_options_dbox), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label ("OK");
  gtk_widget_ref (button1);
  gtk_object_set_data_full (GTK_OBJECT (plugins_options_dbox), "button1", button1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button1);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button1);
  GTK_WIDGET_SET_FLAGS (button1, GTK_CAN_DEFAULT);

  button2 = gtk_button_new_with_label ("Cancel");
  gtk_widget_ref (button2);
  gtk_object_set_data_full (GTK_OBJECT (plugins_options_dbox), "button2", button2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button2);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button2);
  GTK_WIDGET_SET_FLAGS (button2, GTK_CAN_DEFAULT);

  temp=options.plugins_loading;
  if(options.plugins_loading == PLUGINS_AUTO)
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (checkbutton1), TRUE);

  gtk_signal_connect (GTK_OBJECT (checkbutton1), "toggled",
                      GTK_SIGNAL_FUNC (on_checkbutton1_toggled),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                      GTK_SIGNAL_FUNC (on_button11_clicked),
                      plugins_options_dbox);
  gtk_signal_connect (GTK_OBJECT (button2), "clicked",
                      GTK_SIGNAL_FUNC (on_button12_clicked),
                      plugins_options_dbox);

  gtk_widget_show_all(plugins_options_dbox);

  return plugins_options_dbox;
}

/*********************************/
/* Cb used by the function below */
/*********************************/
void
on_clist1_click_column                 (GtkCList        *clist,
                                        gint             column,
                                        gpointer         user_data)
{

}


void
on_clist1_select_row                   (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{

}


void
on_clist1_unselect_row                 (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{

}


gboolean
on_clist1_button_press_event           (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data)
{

  return FALSE;
}


void
on_button21_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_widget_destroy(GTK_WIDGET(user_data));
}


void
on_button22_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}

/*********************************************/
/* This function lists the available plugins */
/*********************************************/
GtkWidget*
create_list_plugins (void)
{
  GtkWidget *list_plugins;
  GtkWidget *dialog_vbox1;
  GtkWidget *scrolledwindow1;
  GtkWidget *clist1;
  GtkWidget *label1;
  GtkWidget *label2;
  GtkWidget *label3;
  GtkWidget *dialog_action_area1;
  GtkWidget *hbuttonbox1;
  GtkWidget *button1;
  GtkWidget *button2;

  list_plugins = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (list_plugins), "list_plugins", list_plugins);
  gtk_window_set_title (GTK_WINDOW (list_plugins), "List of available plug-ins");
  gtk_window_set_position (GTK_WINDOW (list_plugins), GTK_WIN_POS_MOUSE);
  gtk_window_set_modal (GTK_WINDOW (list_plugins), TRUE);
  gtk_window_set_default_size (GTK_WINDOW (list_plugins), 500, 300);

  dialog_vbox1 = GTK_DIALOG (list_plugins)->vbox;
  gtk_object_set_data (GTK_OBJECT (list_plugins), "dialog_vbox1", dialog_vbox1);
  gtk_widget_show (dialog_vbox1);

  scrolledwindow1 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_ref (scrolledwindow1);
  gtk_object_set_data_full (GTK_OBJECT (list_plugins), "scrolledwindow1", scrolledwindow1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (scrolledwindow1);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), scrolledwindow1, TRUE, TRUE, 0);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow1), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  clist1 = gtk_clist_new (3);
  gtk_widget_ref (clist1);
  gtk_object_set_data_full (GTK_OBJECT (list_plugins), "clist1", clist1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clist1);
  gtk_container_add (GTK_CONTAINER (scrolledwindow1), clist1);
  gtk_clist_set_column_width (GTK_CLIST (clist1), 0, 150);
  gtk_clist_set_column_width (GTK_CLIST (clist1), 1, 150);
  gtk_clist_set_column_width (GTK_CLIST (clist1), 2, 80);
  gtk_clist_set_selection_mode (GTK_CLIST (clist1), GTK_SELECTION_BROWSE);
  gtk_clist_column_titles_show (GTK_CLIST (clist1));

  label1 = gtk_label_new (gettext("Name"));
  gtk_widget_ref (label1);
  gtk_object_set_data_full (GTK_OBJECT (list_plugins), "label1", label1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label1);
  gtk_clist_set_column_widget (GTK_CLIST (clist1), 0, label1);

  label2 = gtk_label_new (gettext("Calculator(s)"));
  gtk_widget_ref (label2);
  gtk_object_set_data_full (GTK_OBJECT (list_plugins), "label2", label2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label2);
  gtk_clist_set_column_widget (GTK_CLIST (clist1), 1, label2);

  label3 = gtk_label_new (gettext("Var type(s)"));
  gtk_widget_ref (label3);
  gtk_object_set_data_full (GTK_OBJECT (list_plugins), "label3", label3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label3);
  gtk_clist_set_column_widget (GTK_CLIST (clist1), 2, label3);

  dialog_action_area1 = GTK_DIALOG (list_plugins)->action_area;
  gtk_object_set_data (GTK_OBJECT (list_plugins), "dialog_action_area1", dialog_action_area1);
  gtk_widget_show (dialog_action_area1);
  gtk_container_set_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_ref (hbuttonbox1);
  gtk_object_set_data_full (GTK_OBJECT (list_plugins), "hbuttonbox1", hbuttonbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), hbuttonbox1, TRUE, TRUE, 0);

  button1 = gtk_button_new_with_label (gettext("OK"));
  gtk_widget_ref (button1);
  gtk_object_set_data_full (GTK_OBJECT (list_plugins), "button1", button1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button1);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button1);
  GTK_WIDGET_SET_FLAGS (button1, GTK_CAN_DEFAULT);

  button2 = gtk_button_new_with_label (gettext("Help"));
  gtk_widget_ref (button2);
  gtk_object_set_data_full (GTK_OBJECT (list_plugins), "button2", button2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button2);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), button2);
  GTK_WIDGET_SET_FLAGS (button2, GTK_CAN_DEFAULT);

  gtk_signal_connect (GTK_OBJECT (clist1), "click_column",
                      GTK_SIGNAL_FUNC (on_clist1_click_column),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (clist1), "select_row",
                      GTK_SIGNAL_FUNC (on_clist1_select_row),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (clist1), "unselect_row",
                      GTK_SIGNAL_FUNC (on_clist1_unselect_row),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (clist1), "button_press_event",
                      GTK_SIGNAL_FUNC (on_clist1_button_press_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                      GTK_SIGNAL_FUNC (on_button21_clicked),
                      (gpointer)list_plugins);
  gtk_signal_connect (GTK_OBJECT (button2), "clicked",
                      GTK_SIGNAL_FUNC (on_button22_clicked),
                      (gpointer)list_plugins);
  
  /* Displays the window */
  gtk_widget_show_all(list_plugins);

  plugin_directory_list();
  plugin_getinfo_list();
  plugin_update_clist(clist1);

  return list_plugins;
}

/******************/
/* Misc functions */
/******************/
/* Make a directory list of the plug-ins directory */
void plugin_directory_list(void)
{
  DIR *dir;
  struct dirent *file;
  struct plugin_info *pi;
  char plugin_dir[4*MAXCHARS];

  if(plugin_info_list != NULL)
    {
      plugin_destroy_list();
    }
  strcpy(plugin_dir, clist_win.win_dir);
  strcat(plugin_dir, PLUGINS_DIR);
  //printf("plugin_dir: <<%s>>\n", plugin_dir);
  if( (dir=opendir(plugin_dir)) == NULL) 
    {
      g_error(gettext("Opendir error\n"));
    }
  while( (file=readdir(dir)) != NULL) 
    {
      if(strcmp(file->d_name, ".")==0 || strcmp(file->d_name, "..")==0) { continue; }
      //printf("%s\n", file->d_name);
      pi=(struct plugin_info *)g_malloc(sizeof(struct plugin_info));
      pi->name=(char *)g_malloc((strlen(file->d_name)+1)*sizeof(char));
      strcpy(pi->name, file->d_name);
 
      plugin_info_list=gu_list_prepend(plugin_info_list, (gpointer)pi);
    }
  if(closedir(dir)==-1)
    {
      g_error(gettext("Closedir error\n"));
    }
}

/* Retrieve some informations about plug-ins */
void plugin_getinfo_list(void)
{
  GList *ptr;
  struct plugin_info *pi;
  GModule *module;
  gboolean bool;
  gpointer symb;
  gchar full_name[MAXCHARS];
  const char *version;
  const char **supp_calcs;
  const char **supp_types;

  const char*  (*get_plugin_version) (void) = NULL;
  const char** (*get_supp_calcs)     (void) = NULL;
  const char** (*get_supp_types)     (void) = NULL;

  ptr=plugin_info_list;
  while(ptr != NULL)
    {
      pi=(struct plugin_info *)(ptr->data);
      //printf("%s\n", pi->name);

	  strcpy(full_name, clist_win.win_dir);
      strcat(full_name, PLUGINS_DIR);
      strcat(full_name, pi->name);
	  //printf("plugin: <%s>\n", full_name);
      module=g_module_open(full_name, 0);
      if(module == NULL)
	{
	  fprintf(stderr, g_module_error());
	  pi->var_type=(char *)g_malloc((2)*sizeof(char));
	  strcpy(pi->var_type, "?");
	  pi->calc_type=(char *)g_malloc((2)*sizeof(char));
	  strcpy(pi->calc_type, "?");
	  ptr=ptr->next;
	  continue;
	}
      bool=g_module_symbol(module, "get_plugin_version", &symb);
      get_plugin_version=symb;
      if(bool == FALSE)
	{
	  fprintf(stderr, g_module_error());
	  pi->var_type=(char *)g_malloc((2)*sizeof(char));
	  strcpy(pi->var_type, "?");
	  pi->calc_type=(char *)g_malloc((2)*sizeof(char));
	  strcpy(pi->calc_type, "?");
	  g_module_close(module);
	  ptr=ptr->next;
	  continue;
	}
      bool=g_module_symbol(module, "get_supp_calcs", &symb);
      get_supp_calcs=symb;
      bool=g_module_symbol(module, "get_supp_types", &symb);
      get_supp_types=symb;

      version=get_plugin_version();
      supp_calcs=get_supp_calcs();
      supp_types=get_supp_types();

      concat(supp_types, &(pi->var_type));
      concat(supp_calcs, &(pi->calc_type));

      bool=g_module_close(module);
      if(bool == FALSE)
	fprintf(stderr, g_module_error());
      ptr=ptr->next;
    }
}

/* Display all in the clist */
void plugin_update_clist(GtkWidget *clist)
{
  GList *ptr;
  struct plugin_info *pi;
  gint i=0;
  gchar *row_text[3];

  ptr=plugin_info_list;
  gtk_clist_freeze((GtkCList *)clist_win.widget);
  
  while(ptr != NULL)
    {
      pi=(struct plugin_info *)(ptr->data);

      for(i=0; i<3; i++) { row_text[i]=NULL; }
      row_text[0]=(gchar *)g_malloc((strlen(pi->name)+1)*sizeof(gchar));
      strcpy(row_text[0], pi->name);
      row_text[1]=(gchar *)g_malloc((strlen(pi->calc_type)+1)*sizeof(gchar));
      strcpy(row_text[1], pi->calc_type);
      row_text[2]=(gchar *)g_malloc((strlen(pi->var_type)+1)*sizeof(gchar));
      strcpy(row_text[2], pi->var_type);
      gtk_clist_append((GtkCList *)clist, row_text);

      for(i=0; i<3; i++) { gu_free(row_text[i]); }
      ptr=ptr->next;
      i++;
    } 

  gtk_clist_thaw((GtkCList *)clist_win.widget);
}

/* Free the list */
void plugin_destroy_list()
{
  GList *ptr;
  struct plugin_info *pi;  

  ptr=plugin_info_list;
  while(ptr != NULL)
    {
      pi=(struct plugin_info *)(ptr->data);
      gu_free(pi->name);
      gu_free(pi->calc_type);
      gu_free(pi->var_type);
      gu_free(pi);
  
      ptr=ptr->next;
    }
  gu_list_free(plugin_info_list);
  plugin_info_list = NULL;

  return;
}

/* 
   Search a plugin and load it if success. The function returns:
- 1 if a plugin has been found
- 0 else
*/
int search_and_load_plugin(char *filename, int calc_type, const char *var_type)
{
  GList *ptr;
  struct plugin_info *pi;
  const char *c;
  gchar full_name[MAXCHARS];
  GModule *module;
  gboolean bool;
  gpointer symb;
  PLUGIN_FNCTS pf;
  int (*run_plugin) (PLUGIN_FNCTS, GTKTILINK_SETTINGS, TICALC_FNCTS);
  GTKTILINK_SETTINGS gs;

  fprintf(stdout, "current directory: <%s>\n", clist_win.cur_dir);
  fprintf(stdout, "filename: <%s>\n", filename);
  fprintf(stdout, "vartype: <%s>\n", var_type);

  /* Copy the GtkTiLink settings */
  gs.calc_type = options.lp.calc_type;
  gs.link_type = options.lp.link_type;
  gs.io_addr = options.lp.io_addr;
  strcpy(gs.device, options.lp.device);
  gs.path_mode = options.path_mode;
  gs.file_mode = options.file_mode;
  gs.show = options.show;
  gs.screen_format = options.screen_format;
  gs.timeout = options.lp.timeout;
  gs.delay = options.lp.delay;
  gs.plugins_loading = options.plugins_loading;
  gs.tidev = options.lp.tidev;

  /* Retrieve the calculator type */
  c = type2calc(calc_type);
  ptr = plugin_info_list;  
  while(ptr != NULL)
    {
      pi=(struct plugin_info *)(ptr->data);

      if(strstr(pi->calc_type, c) != NULL)
	{
	  if(strstr(pi->var_type, var_type) != NULL)
	    {
	      /* Load the plugin */
	      strcpy(full_name, clist_win.win_dir);
	      strcat(full_name, PLUGINS_DIR);
	      strcat(full_name, pi->name);	      
	      module=g_module_open(full_name, 0);
	      if(module == NULL)
		{
		  fprintf(stderr, g_module_error());
		  return 1;
		}
	
	      /* Launch the plugin */
	      bool=g_module_symbol(module, "run_plugin", &symb);
	      run_plugin=symb;
	      if(bool == FALSE)
		{
		  fprintf(stderr, g_module_error());
		  return 1;      
		}
	      pf.filename = g_strconcat(clist_win.cur_dir, 
					DIR_SEPARATOR,
					filename, NULL);
	      switch(options.lp.calc_type)
		{
		case CALC_TI92P:
		  pf.load_var_content = read_92p_file;
		  pf.save_var_content = write_92p_file;
		  run_plugin(pf, gs, ti_calc);
		  break;
		case CALC_TI92:
		  pf.load_var_content = read_92p_file;
		  pf.save_var_content = write_92p_file;
		  run_plugin(pf, gs, ti_calc);
		  break;
		case CALC_TI89:
		  pf.load_var_content = read_92p_file;
		  pf.save_var_content = write_92p_file;
		  run_plugin(pf, gs, ti_calc);
		  break;
		case CALC_TI86:
		  break;
		case CALC_TI85:
		  break;
		case CALC_TI83P:
		  break;
		case CALC_TI83:
		  break;
		case CALC_TI82:
		  break;
		default:
		  break;
		}
	      bool=g_module_close(module);
	      if(bool == FALSE)
		{
		  fprintf(stderr, g_module_error());
		  return 1;
		}
	      gu_free(pf.filename);
	      return 1;
	    }
	}
      
      ptr=ptr->next;
    }
  
  return 0;
}

/* Returns a string according to the calculator type */
const char *type2calc(int calc_type)
{
  switch(calc_type)
    {
    case CALC_TI92P:
      return "92+";
      break;
    case CALC_TI92:
      return "92";
      break;
    case CALC_TI89:
      return "89";
      break;
    case CALC_TI86:
      return "86";
      break;
    case CALC_TI85:
      return "85";
      break;
    case CALC_TI83P:
      return "83+";
      break;
    case CALC_TI83:
      return "83";
      break;
    case CALC_TI82:
      return "82";
      break;
    }
  return "UNKNOWN CALC";
}

/* Concatenate ?? */
static char *concat(const char **t, char **s)
{
  const char **p;
  int l;
  int i;

  p=t;
  l=0;
  for(i=0; p[i] != NULL; i++)
    {
      l+=strlen(p[i]);
    }
  l+=2*i;
  l+=1;
  *s=(char *)g_malloc(l*sizeof(char));
  strcpy(*s, "");
  p=t;
  for(i=0; p[i] != NULL; i++)
    {
      strcat(*s, p[i]);
      strcat(*s, " ");
    }

  return *s;
}



