/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <gtk/gtk.h>

#include "defines.h"

/* Main window: 'ready' button */
void toolbar_button_00(GtkWidget *widget, gpointer data)
{
  item_fncts_ready(widget, data);
}

/* Main window: remote button */
void toolbar_button_01(GtkWidget *widget, gpointer data)
{
  item_fncts_terminal(widget, data);
}

/* Main window: 'screendump' button */
void toolbar_button_02(GtkWidget *widget, gpointer data)
{
  screen_window(widget, data);
}

/* Main window: 'directory list' button */
void toolbar_button_03(GtkWidget *widget, gpointer data)
{
  item_fncts_dirlist(widget, data);
}

/* Main window: 'send backup' button */
void toolbar_button_04(GtkWidget *widget, gpointer data)
{
  item_fncts_sbackup(widget, data);
}

/* Main window: 'receive backup' button */
void toolbar_button_05(GtkWidget *widget, gpointer data)
{
  item_fncts_rbackup(widget, data);
}

/* Main window: 'send/receive' button */
void toolbar_button_06(GtkWidget *widget, gpointer data)
{
  if(ctree_win.selection != NULL)
    {
      item_fncts_rvar(widget, data);
    }
  else if(clist_win.selection != NULL)
    {
      item_fncts_svar(widget, data);
    }
  else if( (options.lp.calc_type == CALC_TI82) | 
	   (options.lp.calc_type == CALC_TI85) )
    {
      item_fncts_rvar(widget, data);
    }
}

/* Main window: 'mkdir' button */
void toolbar_button_10(GtkWidget *widget, gpointer data)
{
  gchar *dirname;

  dirname=dlgbox_entry(gettext("Make a new directory"), gettext("Name: "), gettext("new_directory"));
  if(dirname == NULL) return;
  if(mkdir(dirname, 255)!=0)
    {
      msg_box(gettext("Information"), 
	      gettext("Unable to create the directory.\n\n"));
      gu_free(dirname);
    }
  gu_free(dirname);
  l_directory_list();
  refresh_clist(main_window);
  refresh_info(main_window);
}

/* Main window: 'trash' button */
void toolbar_button_07(GtkWidget *widget, gpointer data)
{
  GList *ptr;
  struct file_info *f;
  gint ret;

  if(clist_win.file_selection != NULL)
    {
      /* Destroy the file selection */
      if(clist_win.file_selection != NULL)
	{
	  gu_list_foreach(clist_win.file_selection, (GFunc) gu_free, NULL);
	  gu_list_free(clist_win.file_selection);
	  clist_win.file_selection=NULL;
	}
    }

  if(clist_win.selection==NULL) return;
  if(gu_list_length(clist_win.selection)==1)
    {
      ret=user2_box(gettext("Warning"),
		    gettext("Are you sure you want to remove this file ?\n\n"),
		    gettext(" Yes "), gettext(" No "));
    }
  else
    {
      ret=user2_box(gettext("Warning"),
		    gettext("Are you sure you want to remove these files ?\n\n"), gettext(" Yes "), gettext(" No "));
    }
  if(ret == BUTTON2) return; 

  ptr=clist_win.selection;
  while(ptr!=NULL)
    {
      f=(struct file_info *)ptr->data;
      if(unlink(f->filename))
	{
	  msg_box(gettext("Information"), 
		  gettext("Unable to remove a file.\n\n"));
	}
      ptr=ptr->next;
    }
  l_directory_list();
  refresh_clist(widget);
  refresh_info(widget);
}

/* Main window: 'update' button */
void toolbar_button_08(GtkWidget *widget, gpointer data)
{
  l_directory_list();
  refresh_clist(widget);
  refresh_info(widget);
}

/* Main window: 'help' button */
void toolbar_button_09(GtkWidget *widget, gpointer data)
{
  item_help_help(widget, data);
}





