/*  ti_link - link program for TI calculators
 *  Copyright (C) 1999, 2000  Romain Lievin
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DEFINES_H
#define DEFINES_H

#include "../libs/cables/cable_interface.h"
#include "../libs/calcs/calc_interface.h"
#include "../misc/setup_link.h"
#include "../misc/setup_calc.h"
#include "../misc/pcx_xpm.h"

#include "gcallfsel.h"
#include "gdlgbox.h"
#include "gpakfile.h"
#include "gterm.h"
#include "paths.h"
#include "g_defs.h"
#include "gcalllist.h"
#include "gfiles.h"
#include "gpbar.h"
#include "struct.h"
#include "gcallbutt.h"
#include "gcallmenu.h"  
#include "ginfo.h"    
#include "grcfile.h"   
#include "gtoolbar.h"  
#include "typedefs.h"
#include "gcalldbox.h"  
#include "gcalltool.h"  
#include "glist.h"    
#include "gscreen.h"   
#include "gtree.h"
#include "gcallent.h"   
#include "gcalltree.h"  
#include "gmenus.h"   
#include "gselect.h"   
#include "intl.h"


#endif

