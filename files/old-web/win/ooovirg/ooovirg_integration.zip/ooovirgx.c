/* Created by Anjuta version 0.1.9 */
/*	This file will not be overwritten */

// gcc -o ooovirgx ooovirgx.c -lX11 (you may have to put a symbolic link to find libX11.so)

#include <stdio.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <X11/keysymdef.h>
#include <X11/Xlocale.h>

// XGrabKey

int main()
{
	Display * display;
	KeySym keySimComma, keySimPoint, * keySimPrevious;
	int i, rc, count;
	char buf[256];
	printf("Hello world\n");
	display = XOpenDisplay(NULL);
	keySimComma = XK_comma;
	keySimPoint = XK_period;
    // XGetKeyboardMapping
    keySimPrevious = XGetKeyboardMapping(display, 0x5B, 1, &count);
    printf("\nXGetKeyboardMapping - count = %d ; (Point is %d, Comma is %d) KeySim : ", count, XK_period, XK_comma);
    for(i=0;i<count;i++) { printf("%d, ",keySimPrevious[i]); }
    
	printf("\nChange the keyboard mapping...\n");
    // XChangeKeyboardMapping
    // XRebindKeySim(display, 
	rc = XChangeKeyboardMapping(display, 0x5B, 1, &keySimComma, 1);

    // XGetKeyboardMapping - THIS CALL SEEM TO BE MANDATORY, TO REFRESH KEY MAPPING IN APPS...
    keySimPrevious = XGetKeyboardMapping(display, 0x5B, 1, &count);
    printf("\nXGetKeyboardMapping - count = %d ; (Point is %d, Comma is %d) KeySim : ", count, XK_period, XK_comma);
    for(i=0;i<count;i++) { printf("%d, ",keySimPrevious[i]); }
        
    printf("\n(rc = %d) Try it ! : ", rc);
	gets(buf);
	printf("Revert the keyboard mapping...\n");
	XChangeKeyboardMapping(display, 0x5B, 1, &keySimPoint, 1);

    // XGetKeyboardMapping - THIS CALL SEEM TO BE MANDATORY, TO REFRESH KEY MAPPING IN APPS...
    keySimPrevious = XGetKeyboardMapping(display, 0x5B, 1, &count);
    printf("\nXGetKeyboardMapping - count = %d ; (Point is %d, Comma is %d) KeySim : ", count, XK_period, XK_comma);
    for(i=0;i<count;i++) { printf("%d, ",keySimPrevious[i]); }
	printf("\n");
    XCloseDisplay(display);
	return (0);
}

