// ConfigDlg.h : Declaration of the CConfigDlg

#ifndef __CONFIGDLG_H_
#define __CONFIGDLG_H_

#include "resource.h"       // main symbols
#include "registry.h"
#include "BandToolBarCtrl.h"
#include "commdlg.h"
#include "bkm.h"

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg
class CConfigDlg : 
	public CAxDialogImpl<CConfigDlg>
{
public:
    CConfigDlg() : m_pToolBar(NULL)
	{
	}

	~CConfigDlg()
	{
	}

    void SetToolBar(CBandToolBarCtrl* pToolBar) {m_pToolBar = pToolBar;}

    enum { IDD = IDD_CONFIGDLG };

BEGIN_MSG_MAP(CConfigDlg)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	COMMAND_HANDLER(IDC_BROWSE, BN_CLICKED, OnClickedBrowse)
	COMMAND_HANDLER(IDOK, BN_CLICKED, OnOK)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnClickedBrowse(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);


protected:
    CBandToolBarCtrl* m_pToolBar;
};

#endif //__CONFIGDLG_H_
