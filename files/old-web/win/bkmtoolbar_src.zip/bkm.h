//#include "BCMenu.h"

#ifndef __BKM_H__
#define __BKM_H__

#include "StdAfx.h"

//typedef CMenu BCMenu;

#define ID_BOOKMARK 21242
#define ID_BKM_FOLDER 31242
#define ID_BKM_ADD 21200

int populateMenu(CMenu &menu);
char * getUrl(int index);
int addUrl(const char * url, const char * name, int index=-1);

extern int bkm_num;
extern int bkm_folder_num;
extern int bkm_allow_write;
extern int bkm_convert_utf;
extern char bkm_filename[];

#endif