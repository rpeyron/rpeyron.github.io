#include "bkm.h"
#include "registry.h"
#include "resource.h"
#include <string.h>
#include <stdio.h>

int bkm_num = 0;
int bkm_folder_num = 0;
int bkm_allow_write = 1;
int bkm_convert_utf = 1;
char bkm_filename[1024];

// Stack Menu
class stack_menu
{
public:
	HMENU hMenu;
	class stack_menu * prev_menu;
	stack_menu(HMENU hMenu, class stack_menu * prev_menu)
	{
		this->hMenu = hMenu;
		this->prev_menu = prev_menu;
	}
	~stack_menu() {}
};

// This function creates the menu structure from the file
int populateMenu(CMenu &menu)
{
	FILE * bkf;
	char line[2048],temp[2048];
	WCHAR wline[2048];
	char *cur, *url, *desc;
	HMENU hMenu, hMenuTemp, hFileMenu;
	class stack_menu * root_menu, * cur_menu, * temp_menu;
	class stack_menu * root_file_menu, * cur_file_menu, * temp_file_menu;
	int count, countfolder, depth;

	// Get Value from the registry
	CRegistry reg;
	reg.SetRootKey(HKEY_CURRENT_USER);
	reg.SetKey("Software\\RPSoft\\BookmarkToolbar",TRUE);
	bkm_allow_write=(reg.ReadBool("AllowWrite",FALSE))?1:0;
	bkm_convert_utf=(reg.ReadBool("ConvertUTF",TRUE))?1:0;
	strcpy(bkm_filename,reg.ReadString("FileName","C:\\Program Files\\Netscape\\Users\\default\\bookmark.htm"));

	// Load the bitmaps
	static CBitmap sheet, closed, open;
	sheet.Detach(); 	sheet.LoadBitmap(IDB_SHEET);
	closed.Detach();    closed.LoadBitmap(IDB_CLOSED);
	open.Detach();		open.LoadBitmap(IDB_OPEN);

	bkf = fopen(bkm_filename,"r");

	// Handles the Add Bookmark & Bookmark menu
	hMenu = menu.GetSubMenu(0).m_hMenu;
	if (bkm_allow_write)
	{
		InsertMenu(hMenu,0,MF_BYPOSITION | MF_STRING,ID_BKM_ADD,"Add Bookmark");
	}
	if (bkf == NULL)
	{
		//::MessageBox(NULL,"Unable to open the Bookmark file.\nPlease check the path.","Unable to open the file", MB_OK);
		AppendMenu(hMenu,MF_SEPARATOR,0,"");
		AppendMenu(hMenu,MF_STRING | MF_DISABLED | MF_GRAYED ,0,"File Not Found !");
		AppendMenu(hMenu,MF_STRING | MF_DISABLED | MF_GRAYED ,0,"A new file will be created.");
		return 1;
	}

	if (bkm_allow_write)
	{
		hFileMenu = CreatePopupMenu();
		InsertMenu(hMenu,1,MF_BYPOSITION |MF_POPUP,(UINT)hFileMenu,"Bookmark");
	}

	// Initialize the menus and vars used
	AppendMenu(hMenu,MF_SEPARATOR,0,"");
	root_file_menu = new stack_menu(hFileMenu, NULL);
	cur_file_menu = root_file_menu;
	root_menu = new stack_menu(hMenu, NULL);
	cur_menu = root_menu;
	count = 0;
	depth = 0;
	countfolder = 0;

	while (!feof(bkf))
	{
		fgets(line,sizeof(line),bkf);
		// Convert from UTF-8
		if (bkm_convert_utf)
		{
			int ret;
			ret = MultiByteToWideChar(CP_UTF8, 0, line, -1, wline, 2047);
			// if (ret == 0)  ret = GetLastError();
			// line[0] = '\0';
			ret = WideCharToMultiByte(CP_ACP, 0, wline, -1, line, 2047, NULL, NULL);
			// if (ret == 0)  ret = GetLastError();
		}

		// Parse the string
		cur = line;
		while ((*cur != '\0') && (*cur == ' ')) cur++;
		if (strncmp(cur,"<DT><H3",7) == 0)
		{
			// Folder
			depth++;  countfolder++;
			cur += 7;
			desc = strchr(cur,'>')+1;
			*strchr(desc,'<') = '\0';

			// Create Menu
			hMenuTemp = CreatePopupMenu();
			if (hMenuTemp == NULL) 
			{
				// Too Much Bookmarks !
				// Should set allow_write to nul
			}
			AppendMenu(cur_menu->hMenu, MF_POPUP, (UINT)hMenuTemp, desc);
			SetMenuItemBitmaps(cur_menu->hMenu,
			GetMenuItemCount(cur_menu->hMenu)-1,MF_BYPOSITION,closed,open);
			cur_menu = new stack_menu(hMenuTemp, cur_menu);

			// Create AddBookmark Menu if allowed
			if (bkm_allow_write)
			{
				hMenuTemp = CreatePopupMenu();
				if (hMenuTemp == NULL) ::MessageBox(NULL,"CreateMenu failed",NULL,MB_OK);
				AppendMenu(cur_file_menu->hMenu, MF_POPUP, (UINT)hMenuTemp, desc);
				cur_file_menu = new stack_menu(hMenuTemp, cur_file_menu);
				AppendMenu(cur_file_menu->hMenu, MF_STRING, ID_BKM_FOLDER+countfolder, desc);
				AppendMenu(cur_file_menu->hMenu, MF_SEPARATOR, 0, NULL);
			}
		}

		if (strncmp(cur,"</DL>",4) == 0)
		{
			// End of the folder
			depth--;
			// Pop the menu
			temp_menu = cur_menu->prev_menu;
			if (temp_menu != NULL) 
			{
				delete cur_menu;
				cur_menu=temp_menu;
			}
			// If the AddBookmark menu is empty, deletes the MF_POPUP and creates a simple MF_STRING
			if (bkm_allow_write)
			{
				if (GetMenuItemCount(cur_file_menu->hMenu) == 2)
				{
					GetMenuString(cur_file_menu->prev_menu->hMenu, 
						ID_BKM_FOLDER+countfolder,
						desc,1024,MF_BYCOMMAND);
					RemoveMenu(cur_file_menu->prev_menu->hMenu, 
						GetMenuItemCount(cur_file_menu->prev_menu->hMenu)-1,MF_BYPOSITION);
					AppendMenu(cur_file_menu->prev_menu->hMenu, 
						MF_STRING,ID_BKM_FOLDER+countfolder, desc);
					DestroyMenu(cur_file_menu->hMenu);
				}
				temp_file_menu = cur_file_menu->prev_menu;
				if (temp_file_menu != NULL) 
				{
					delete cur_file_menu;
					cur_file_menu=temp_file_menu;
				}
			}
		}
		if (strncmp(cur,"<HR>",4) == 0)
		{
			// Separator
			AppendMenu(cur_menu->hMenu, MF_SEPARATOR, 0, NULL);
		}
		if (strncmp(cur,"<DT><A",6) == 0)
		{
			// Bookmark
			count++;
			cur += 7;
			desc = strchr(cur,'>')+1;
			*strchr(desc,'<') = '\0';
			url = strchr(cur,'"')+1;
			*strchr(url,'"') = '\0';
			if (strlen(desc) > 55)
			{
				strncpy(temp,desc,25); temp[25]='\0';
				strcat(temp," ... "); temp[30]='\0';
				strcat(temp,desc+strlen(desc)-26);
				strcpy(desc,temp);
			}
			AppendMenu(cur_menu->hMenu, MF_STRING, ID_BOOKMARK+count, desc);
			SetMenuItemBitmaps(cur_menu->hMenu,
				ID_BOOKMARK+count,MF_BYCOMMAND,sheet,sheet);
		}
	}
	// Store usefull data
	bkm_num = count;
	bkm_folder_num = countfolder;
	fclose(bkf);
	return 0;
}

// This function gets the url at the provided index.
// It reparses the file.
char * getUrl(int index)
{
	//static char url[1024];
	FILE * bkf;
	static char line[1024];
	char *cur, *url, *desc;

	int count;
	count = 0;
	bkf = fopen(bkm_filename,"rt");
	if (bkf == NULL)
	{
		//::MessageBox(NULL,"Unable to open the Bookmark file.\nPlease check the path.","Unable to open the file", MB_OK);
		return NULL;
	}

	while (!feof(bkf))
	{
		fgets(line,sizeof(line),bkf);
		// Parse the string
		cur = line;
		while ((*cur != '\0') && (*cur == ' ')) cur++;
		if (strncmp(cur,"<DT><A",6) == 0)
		{
			count++;
			if (count == index)
			{
				// Bookmark
				cur += 7;
				desc = strchr(cur,'>')+1;
				*strchr(desc,'<') = '\0';
				url = strchr(cur,'"')+1;
				*strchr(url,'"') = '\0';
				fclose(bkf);
				return url;
			}
		}
	}
	fclose(bkf);
	return(NULL);
}

// Add a Url in the bookmark file
// The file is completely written from scratch, and the the previous file is deleted
int addUrl(const char * url, const char * name, int index)
{
	FILE * bkf, *nbkf;
	char line[2048], bkmstr[4096];
	WCHAR wline[2048];
	char *cur;
	char nbkm_filename[1024];
	int countfolder,depth;

	// Check file 
	bkf = fopen(bkm_filename,"rt");
	if (bkf == NULL)
	{
		bkf = fopen(bkm_filename,"wt");
		// Create an empty file
		fprintf(bkf,"<!DOCTYPE NETSCAPE-Bookmark-file-1>\r\n" \
			        "<!-- This is an automatically generated file.\r\n" \
					"It will be read and overwritten.\r\nDo Not Edit! -->\r\n" \
					"<TITLE>Bookmarks for R�mi Peyronnet</TITLE>\r\n" \
					"<H1>Bookmarks for R�mi Peyronnet</H1>\r\n\r\n" \
					"<DL><p>\r\n</DL><p>\r\n");
	}
	fclose(bkf);

	sprintf(bkmstr,"    <DT><A HREF=\"%s\">%s</A>\n",url,name);
	// Convert to UTF-8
	if (bkm_convert_utf)
	{
		MultiByteToWideChar(CP_ACP, 0, bkmstr, -1, wline, 2047);
		WideCharToMultiByte(CP_UTF8, 0, wline, -1, bkmstr, 2047, NULL, NULL);
	}

	if (index != -1)
	{
		strcpy(nbkm_filename,bkm_filename);
		strcat(nbkm_filename,".new");
		nbkf = fopen(nbkm_filename,"w");
		bkf = fopen(bkm_filename,"r");
		if (bkf == NULL)	return 1;
		countfolder = 0;
		depth=-1;
		while (!feof(bkf))
		{
			fgets(line,sizeof(line),bkf);
			// Parse the string
			cur = line;
			while ((*cur != '\0') && (*cur == ' ')) cur++;
			if (strncmp(cur,"<DT><H3",7) == 0)
			{
				// Folder
				countfolder++;
				if (depth>=0) depth++;
				if (countfolder == index)
				{
					depth=1;
				}
			}
			if (strncmp(cur,"</DL>",4) == 0)
			{
				// End of the folder
				if (depth>0) depth--;
				// If this is the folder we want : insert the item
				if (depth==0)
				{
					// Restore the indentation
					while (cur-- != line) fprintf(nbkf," ");
					// Add the bookmark
					fprintf(nbkf,"%s",bkmstr);
					depth=-1;
				}
			}
			fputs(line,nbkf);
		}
		fclose(bkf);
		fclose(nbkf);
		DeleteFile(bkm_filename);
		MoveFile(nbkm_filename,bkm_filename);
	}
	else
	{
		bkf = fopen(bkm_filename,"rt");
		if (bkf == NULL)   return 1;
		fseek(bkf,-15,SEEK_END);
		fgets(line,sizeof(line),bkf);
		depth = ftell(bkf);
		fclose(bkf);
		bkf = fopen(bkm_filename,"rt+"); // RPe - fseek not allowed in append mode - replaced 'a' by 'r+'
		fseek(bkf,depth,SEEK_SET);
		fprintf(bkf,"%s</DL><p>\n",bkmstr);
		fflush(bkf);
		fclose(bkf);
	}
	return 0;
}