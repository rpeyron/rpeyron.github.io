#ifndef __BANDEDITCTRL_H_
#define __BANDEDITCTRL_H_


class CToolBandObj;
/////////////////////////////////////////////////////////////////////////////
// CBandEditCtrl
class CBandEditCtrl : public CWindowImpl<CBandEditCtrl, CEdit>,
                      public IDropTarget  

{
public:	
	CBandEditCtrl();
	virtual ~CBandEditCtrl();
    void SetWebBrowser(IWebBrowser2* pWebBrowser) {m_pWebBrowser = pWebBrowser;}

// Operations
public:
    STDMETHOD(TranslateAcceleratorIO)(LPMSG pMsg);

    // Support Drag and Drop
	STDMETHODIMP QueryInterface(REFIID, VOID**);
	STDMETHODIMP_(ULONG) AddRef(void);
	STDMETHODIMP_(ULONG) Release(void);

    STDMETHODIMP DragEnter(LPDATAOBJECT, DWORD, POINTL, LPDWORD);
	STDMETHODIMP DragOver(DWORD, POINTL, LPDWORD);
	STDMETHODIMP DragLeave(void);
	STDMETHODIMP Drop(LPDATAOBJECT, DWORD, POINTL, LPDWORD);

    DECLARE_WND_SUPERCLASS(NULL, TEXT("EDIT"))

	BEGIN_MSG_MAP(CBandEditCtrl)
        OCM_COMMAND_CODE_HANDLER(EN_SETFOCUS, OnSetFocus)
        MESSAGE_HANDLER(WM_CHAR, OnChar)
        MESSAGE_HANDLER(WM_KEYUP, OnKeyUp)
	END_MSG_MAP()

	CToolBandObj* m_pBand;
    LPDATAOBJECT m_pIDataObject;

protected:
    LRESULT OnSetFocus(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
    LRESULT OnChar(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled);
	LRESULT OnKeyUp(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

protected:
	ULONG m_cRef;
    IWebBrowser2* m_pWebBrowser;

};

#endif //__BANDEDITCTRL_H_