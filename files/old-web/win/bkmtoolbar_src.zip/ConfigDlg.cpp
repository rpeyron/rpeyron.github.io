// ConfigDlg.cpp : Implementation of CConfigDlg
#include "stdafx.h"
#include "ConfigDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg
LRESULT CConfigDlg::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CenterWindow(GetParent());
	CheckDlgButton(IDC_UTF, !bkm_convert_utf);
	CheckDlgButton(IDC_CHECK1, !bkm_allow_write);
	SetDlgItemText(IDC_FILEEDIT, bkm_filename);
    //::CheckDlgButton(m_hWnd, IDC_RADIO_NO_TEXT_RIGHT, BST_CHECKED); 
    //_Module.m_nToolBarButtonType = 1;

	return 1;  // Let the system set the focus
}

LRESULT CConfigDlg::OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	CRegistry reg;
	bkm_allow_write=!IsDlgButtonChecked(IDC_CHECK1);
	bkm_convert_utf=!IsDlgButtonChecked(IDC_UTF);
	GetDlgItemText(IDC_FILEEDIT, bkm_filename, 1024);
	reg.SetRootKey(HKEY_CURRENT_USER);
	reg.SetKey("Software\\RPSoft\\BookmarkToolbar",TRUE);
	reg.WriteBool("AllowWrite",bkm_allow_write);
	reg.WriteBool("ConvertUTF",bkm_convert_utf);
	reg.WriteString("FileName", bkm_filename);
	EndDialog(wID);
	return 0;
}

LRESULT CConfigDlg::OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	EndDialog(wID);
	return 0;
}
LRESULT CConfigDlg::OnClickedBrowse(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
		
	OPENFILENAME OpenFileName;
	TCHAR   szFile[1024]      = "\0";

	GetDlgItemText(IDC_FILEEDIT, szFile, 1024);


	// Fill in the OPENFILENAME structure to support a template and hook.
	OpenFileName.lStructSize       = sizeof(OPENFILENAME);
	OpenFileName.hwndOwner         = m_hWnd;
	OpenFileName.hInstance         = NULL;
	OpenFileName.lpstrFilter       = "Netscape Bookmarks\0*.htm;*.html\0";
	OpenFileName.lpstrCustomFilter = NULL;
	OpenFileName.nMaxCustFilter    = 0;
	OpenFileName.nFilterIndex      = 1;
	OpenFileName.lpstrFile         = szFile;
	OpenFileName.nMaxFile          = sizeof(szFile);
	OpenFileName.lpstrFileTitle    = NULL;
	OpenFileName.nMaxFileTitle     = 0;
	OpenFileName.lpstrInitialDir   = NULL;
	OpenFileName.lpstrTitle        = "Open Netscape Bookmark File";
	OpenFileName.nFileOffset       = 0;
	OpenFileName.nFileExtension    = 0;
	OpenFileName.lpstrDefExt       = "htm";
	OpenFileName.lCustData         = (LPARAM)NULL;
	OpenFileName.Flags             = OFN_SHOWHELP | OFN_EXPLORER /*| OFN_FILEMUSTEXIST*/;
	if (IsDlgButtonChecked(IDC_CHECK1))
	{
		OpenFileName.Flags |= OFN_READONLY;
	}

	// Call the common dialog function.
	if (GetOpenFileName(&OpenFileName))
	{
		SetDlgItemText(IDC_FILEEDIT, szFile);
		CheckDlgButton(IDC_CHECK1, ((OpenFileName.Flags | OFN_READONLY)!=0)?1:0);
	}
	return 0;
}