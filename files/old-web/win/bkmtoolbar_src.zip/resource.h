//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ToolBand.rc
//
#define ID_EDIT_BOX                     1
#define ID_APPLY                        3
#define IDS_PROJNAME                    100
#define IDR_TOOLBANDOBJ                 101
#define IDC_TOOLBAREDIT                 102
#define IDR_TOOLBAR_TEST                201
#define IDC_RADIO_NO_TEXT               201
#define IDC_RADIO_NO_TEXT_RIGHT         202
#define IDC_CHECK1                      202
#define IDR_MENU_POPUP                  203
#define IDC_RADIO_TEXT_UNDER            203
#define IDC_FILEEDIT                    203
#define IDD_CONFIGDLG                   204
#define IDC_BROWSE                      204
#define IDC_COMMONDIALOG1               205
#define IDR_MENU_POPUP_2                209
#define IDC_COMMONDIALOG4               209
#define IDI_ICON1                       210
#define IDC_UTF                         210
#define IDB_SHEET                       211
#define IDB_CLOSED                      215
#define IDB_OPEN                        216
#define IDB_TOOLBAR                     217
#define ID_BUTTON_BLACK                 10768
#define ID_BUTTON_RED                   10769
#define ID_BUTTON_GREEN                 10770
#define ID_BUTTON_BLUE                  10776
#define ID_MENUPOPUP_OPTION1            32771
#define ID_MENUPOPUP_OPTION2            32772
#define ID_MENUPOPUP_OPTION3            32773
#define ID_MENUPOPUP_CONFIG             32777
#define ID_MORE_LINK1                   32778
#define ID_MORE_LINK2                   32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        222
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         211
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
