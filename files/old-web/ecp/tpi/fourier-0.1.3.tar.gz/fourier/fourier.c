/**
 *  (c) 2002 R�mi Peyronnet <remi.peyronnet@via.ecp.fr>
 *  Plugin GIMP : Fourier Transform
 *  May 2002: Minor modifications by mk@crc.dk
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "libgimp/gimp.h"

// Uses the brillant rfftw lib
#include <rfftw.h>

/** defines ***********************************************************/

#define PLUG_IN_NAME "plug_in_fft"
#define PLUG_IN_VERSION "Februar 2002, 1.0"

/** Plugin interface *********************************************************/

void query(void);
void run(const gchar *name, int nparams, const GimpParam *param, int *nreturn_vals, GimpParam **return_vals);

inline guchar get_guchar (int i)
{
  return (guchar) (i>=255)?255:((i<0)?0:i);
}

inline guchar get_gchar128 (int i)
{
  return (guchar) (i>=(int)128)?255:((i<=(int)-128)?0:i+128);
}

inline guchar get_glog (double d)
{
  int i;
  i = (int) ( ((d>0)?log(d+1):-log(-d+1))*128 );
  return (guchar) (i>128)?255:((i<-128)?0:i+128);
}

inline double get_flog (int i)
{
  double d;
  if (i > 128)
  {
    d = exp((i-128.0)/128.0)-1;
  }
  else
  {
    d = -exp(i/128.0)+1;
  }
  return d;
}

inline double abslog(double d)
{
  if (d > 0)
  {
    return log(d+1);
  }
  else
  {
    return -log(-d+1);
  }
}

inline double absexp(double d)
{
  if (d > 0)
  {
    return exp(d)-1;
  }
  else
  {
    return -exp(-d)+1;
  }
}

GimpPlugInInfo PLUG_IN_INFO = {
  NULL, /* init_proc */
  NULL, /* quit_proc */
  query,        /* query_proc */
  run   /* run_proc */
};

MAIN()

void
query(void)
{
  /* Definition of parameters */
  static GimpParamDef args[] = {
    { GIMP_PDB_INT32, "run_mode", "Interactive, non-interactive" },
    { GIMP_PDB_IMAGE, "image", "Input image (unused)" },
    { GIMP_PDB_DRAWABLE, "drawable", "Input drawable" }
  };

  static GimpParamDef *return_vals  = NULL;
  static int        nargs = sizeof(args) / sizeof(args[0]);
  static int        nreturn_vals = 0;

  gimp_install_procedure(
    "plug_in_fft_dir",
    "Transform the image with the FFT",
    "This plug-in applies a FFT to the image, for educationnal or effects purpose.",
    "Remi Peyronnet",
    "Remi Peyronnet",
    PLUG_IN_VERSION,
    "<Image>/Filters/Render/FFT Directe",
    "RGB*",
    GIMP_PLUGIN,
    nargs,
    nreturn_vals,
    args,
    return_vals);
  gimp_install_procedure(
    "plug_in_fft_inv",
    "Transform the image with the FFT",
    "This plug-in applies a FFT to the image, for educationnal or effects purpose.",
    "Remi Peyronnet",
    "Remi Peyronnet",
    PLUG_IN_VERSION,
    "<Image>/Filters/Render/FFT Inverse",
    "RGB*",
    GIMP_PLUGIN,
    nargs,
    nreturn_vals,
    args,
    return_vals);
}

void
run(const gchar *name, int nparams, const GimpParam *param,
    gint *nreturn_vals, GimpParam **return_vals)
{
  /* Return values */
  static GimpParam values[1];

  gint sel_x1, sel_y1, sel_x2, sel_y2, w, h, padding;
  gint img_height, img_width, img_bpp, cur_bpp, img_has_alpha;

  GimpDrawable     *drawable;
  GimpPixelRgn region;
//  GimpRunModeType  run_mode;
  GimpPDBStatusType   status;

  gint progress, max_progress;

  gint row, col;

  rfftwnd_plan p;
  fftw_real * fft_real, v, m, mean, norm;

  int fft_inv=0;

  if (strcmp(name,"plug_in_fft_inv") == 0) { fft_inv = 1; }

  *nreturn_vals = 1;
  *return_vals  = values;

  status = GIMP_PDB_SUCCESS;

  if (param[0].type!= GIMP_PDB_INT32)  status=GIMP_PDB_CALLING_ERROR;
  if (param[2].type!=GIMP_PDB_DRAWABLE)   status=GIMP_PDB_CALLING_ERROR;

//  run_mode = param[0].data.d_int32;

  drawable = gimp_drawable_get(param[2].data.d_drawable);

  img_width     = gimp_drawable_width(drawable->drawable_id);
  img_height    = gimp_drawable_height(drawable->drawable_id);
  img_bpp       = gimp_drawable_bpp(drawable->drawable_id);
  img_has_alpha = gimp_drawable_has_alpha(drawable->drawable_id);
  gimp_drawable_mask_bounds(drawable->drawable_id, &sel_x1, &sel_y1, &sel_x2, &sel_y2);
  printf("img_width: %d\n", img_width);
  printf("img_height: %d\n", img_height);
  printf("img_bpp: %d\n", img_bpp);
  printf("img_has_alpha: %d\n", img_has_alpha);

  w = sel_x2 - sel_x1;
  h = sel_y2 - sel_y1;

  if (status == GIMP_PDB_SUCCESS)
  {
    guchar buf[]={128,128,128,128};
    guchar * img_pixels;

    gimp_tile_cache_ntiles((drawable->width + gimp_tile_width() - 1) / gimp_tile_width());

    gimp_progress_init(fft_inv?"Apply inverse Fourier transform...":"Apply Fourier transform...");

    // Process
    gimp_pixel_rgn_init (&region, drawable, sel_x1, sel_y1, w, h, FALSE, FALSE);
    img_pixels = g_new (guchar, w * h * img_bpp );
    gimp_pixel_rgn_get_rect(&region, img_pixels, sel_x1, sel_y1, w, h);

    gimp_pixel_rgn_init (&region, drawable, sel_x1, sel_y1, w, h, TRUE, TRUE);

    // FFT !

  if(h&1)
  {
    padding=1;
  }
  else
  {
    padding=2;
  }
  fft_real = g_new(fftw_real, (h+padding) * w);

  norm = sqrt((double)w*h);

  if (fft_inv == 0)
  {
    max_progress = /*w*h*/img_bpp*4;
  }
  else
  {
    max_progress = /*w*h*/img_bpp*3;
  }
  progress = 0;
  for(cur_bpp=0;cur_bpp<img_bpp;cur_bpp++)
  {
    if (fft_inv == 0)
    {
      p = rfftw2d_create_plan(w, h, FFTW_REAL_TO_COMPLEX, FFTW_ESTIMATE | FFTW_IN_PLACE);
      for(col=0;col<w;col++)
      {
        for(row=0;row<h;row++)
        {
          fft_real[col*(h+padding)+row]=
                ((fftw_real) (double)img_pixels[(row*w+col)*img_bpp+cur_bpp]) / 256;
        }
      }
      progress += 1;
      gimp_progress_update((double) progress / max_progress);
      rfftwnd_one_real_to_complex(p, fft_real, NULL);
      progress += 1;
      gimp_progress_update((double) progress / max_progress);

      m = 0;
      for(col=0;col<w;col++)
      {
        for(row=0;row<h;row++)
        {
          v = abslog(fft_real[col*(h+padding)+row] / norm);
          if ( fabs(v) > m) { m = fabs(v); }
        }
      }
      progress += 1;
      gimp_progress_update((double) progress / max_progress);
      for(col=0;col<w;col++)
      {
        for(row=0;row<h;row++)
        {
          v = abslog(fft_real[col*(h+padding)+row] / norm) / m;
          img_pixels[(row*w+col)*img_bpp+cur_bpp] =  get_gchar128( (int)(v*128.0) );
        }
      }
      progress += 1;
      gimp_progress_update((double) progress / max_progress);
      img_pixels[(h*w/2-1)*img_bpp+cur_bpp] = get_guchar((int) m * 10 );

    }
    else
    {
      p = rfftw2d_create_plan(w, h, FFTW_COMPLEX_TO_REAL, FFTW_ESTIMATE | FFTW_IN_PLACE);
      m = (float)img_pixels[(h*w/2-1)*img_bpp+cur_bpp] / 10;
      img_pixels[(h*w/2-1)*img_bpp+cur_bpp] = 128; // Elimine _grosse_ perturbation.
      for(col=0;col<w;col++)
      {
        for(row=0;row<h;row++)
        {
          fft_real[col*(h+padding)+row]= (fftw_real)
                 absexp( ((float)img_pixels[(row*w+col)*img_bpp+cur_bpp]-128.0) / 128.0 * m);
        }
      }
      progress += 1;
      gimp_progress_update((double) progress / max_progress);
      rfftwnd_one_complex_to_real(p, (fftw_complex *) fft_real, NULL);
      progress += 1;
      gimp_progress_update((double) progress / max_progress);
      for(col=0;col<w;col++)
      {
        for(row=0;row<h;row++)
        {
          v = fft_real[col*(h+padding)+row] / norm;
          img_pixels[(row*w+col)*img_bpp+cur_bpp] = get_guchar((int)( (double)v*256.0));
        }
      }
      progress += 1;
      gimp_progress_update((double) progress / max_progress);
    }
  }
  rfftwnd_destroy_plan(p);
  g_free(fft_real);

    // Flush

    gimp_pixel_rgn_set_rect(&region, img_pixels, sel_x1, sel_y1,
                            (sel_x2-sel_x1), (sel_y2-sel_y1));
    g_free (img_pixels);

    gimp_drawable_flush(drawable);
    gimp_drawable_merge_shadow(drawable->drawable_id, TRUE);
    gimp_drawable_update (drawable->drawable_id, sel_x1, sel_y1, (sel_x2-sel_x1), (sel_y2-sel_y1));
    gimp_displays_flush();
  }

  values[0].type = GIMP_PDB_STATUS;
  values[0].data.d_status = status;
  gimp_drawable_detach(drawable);
}
