#define GDK_WINDOWING_WIN32
#define GDK_HAVE_WCHAR_H 1
#ifdef _MSC_VER
#define GDK_HAVE_WCTYPE_H 1
#endif
#define GDK_USE_UTF8_MBS 1

