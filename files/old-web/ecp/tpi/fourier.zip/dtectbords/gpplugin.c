/**
 * (c) 2002 R�mi Peyronnet
 * Plugin GIMP : Artistic Edge Detection
 */
                 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "gtk/gtk.h"
#include "libgimp/gimp.h"

// Uses the brillant rfftw lib
#include <rfftw.h>

#define PLUG_IN_NAME "plug_in_fft"
#define PLUG_IN_VERSION "Februar 2002, 1.0"

void query(void);
void run(char *name, int nparams, GimpParam *param, int *nreturn_vals, GimpParam **return_vals);

inline guchar get_guchar (int i)
{
  return (guchar) (i>=255)?255:((i<0)?0:i);
}

inline guchar get_gchar128 (int i)
{
  return (guchar) (i>=(int)128)?255:((i<=(int)-128)?0:i+128);
}

inline guchar get_gchar128_nul (int i)
{
  return (guchar) (i>=(int)128)?128:((i<=(int)-128)?128:i+128);
}

inline int get_gchar32768 (int i)
{
  return (int) (i>=(int)32768)?65535:((i<=(int)-32768)?0:i+32768);
}


inline double abslog(double d)
{
	if (d > 0)
	{
		return log(d+1);
	}
	else
	{
		return -log(-d+1);
	}
}


inline double absexp(double d)
{
	if (d > 0)
	{
		return exp(d)-1;
	}
	else
	{
		return -exp(-d)+1;
	}
}


GimpPlugInInfo PLUG_IN_INFO = {
  NULL, /* init_proc */
  NULL, /* quit_proc */
  query,        /* query_proc */
  run   /* run_proc */
};


MAIN()



void
query(void)
{
  /* Definition of parameters */
  static GimpParamDef args[] = {
    { GIMP_PDB_INT32, "run_mode", "Interactive, non-interactive" },
    { GIMP_PDB_IMAGE, "image", "Input image (unused)" },
    { GIMP_PDB_DRAWABLE, "drawable", "Input drawable" }
  };

  static GimpParamDef *return_vals  = NULL;
  static int        nargs = sizeof(args) / sizeof(args[0]);
  static int        nreturn_vals = 0;

  gimp_install_procedure(
    "plug_in_fft_edge",
    "Edge Detection",
    "This plug-in applies a FFT to the image, for educationnal or effects purpose.",
    "R�mi Peyronnet",
    "R�mi Peyronnet",
    PLUG_IN_VERSION,
    "<Image>/Filters/Render/Artistic Edge Detection",
    "RGB*",
    GIMP_PLUGIN,
    nargs,
    nreturn_vals,
    args,
    return_vals);
}


void
run(char *name, int nparams, GimpParam *param,
    int *nreturn_vals, GimpParam **return_vals)
{
  /* Return values */
  static GimpParam values[1];

  gint sel_x1, sel_y1, sel_x2, sel_y2, w, h;
  gint img_height, img_width, img_bpp, cur_bpp, img_has_alpha;

  GimpDrawable     *drawable;
  GimpPixelRgn region; 
  GimpRunModeType  run_mode;
  GimpPDBStatusType   status;

  gint progress, max_progress;

  gint row, col;

  rfftwnd_plan p;
  fftw_real * fft_real, v, m, mean, norm;
  fftw_complex * fft_complex;

  int fft_inv=0;

  *nreturn_vals = 1;
  *return_vals  = values;

  status = GIMP_PDB_SUCCESS;
        
  if (param[0].type!= GIMP_PDB_INT32)  status=GIMP_PDB_CALLING_ERROR;
  if (param[2].type!=GIMP_PDB_DRAWABLE)   status=GIMP_PDB_CALLING_ERROR;

  run_mode = param[0].data.d_int32;
  
  drawable = gimp_drawable_get(param[2].data.d_drawable);

  img_width     = gimp_drawable_width(drawable->id);
  img_height    = gimp_drawable_height(drawable->id);
  img_bpp       = gimp_drawable_bpp(drawable->id);
  img_has_alpha = gimp_drawable_has_alpha(drawable->id);
  gimp_drawable_mask_bounds(drawable->id, &sel_x1, &sel_y1, &sel_x2, &sel_y2);

  w = sel_x2 - sel_x1;
  h = sel_y2 - sel_y1;

  max_progress = img_width*img_height;
  
  if (status == GIMP_PDB_SUCCESS)
  {
    guchar buf[]={128,128,128,128};
    guchar * img_pixels;

    gimp_tile_cache_ntiles((drawable->width + gimp_tile_width() - 1) / gimp_tile_width());

    gimp_progress_init("Testing...");

    // Process
    gimp_pixel_rgn_init (&region, drawable, sel_x1, sel_y1, w, h, FALSE, FALSE);
    img_pixels = g_new (guchar, w * h * img_bpp );
    gimp_pixel_rgn_get_rect(&region, img_pixels, sel_x1, sel_y1, w, h);

    gimp_pixel_rgn_init (&region, drawable, sel_x1, sel_y1, w, h, TRUE, TRUE);
    
	fft_real = g_new(fftw_real, (h+2) * w);

	norm = sqrt((double)w*h);

	for(cur_bpp=0;cur_bpp<img_bpp;cur_bpp++) 
	{

			p = rfftw2d_create_plan(w, h, FFTW_REAL_TO_COMPLEX, FFTW_ESTIMATE | FFTW_IN_PLACE);
			for(col=0;col<w;col++)
			{
				for(row=0;row<h;row++)
				{
					fft_real[col*(h+2)+row]=(fftw_real) (double)img_pixels[(row*w+col)*img_bpp+cur_bpp] / 256;
				}
			}
			rfftwnd_one_real_to_complex(p, fft_real, NULL);

			for(col=0;col<w;col++)
			{
				for(row=0;row<h;row++)
				{
					v = fft_real[col*(h+2)+row] / norm;
					//v = abslog(fft_real[col*(h+2)+row] / norm) / m;
					// ----> Simulate 8 bit conversion <----
					fft_real[col*(h+2)+row]=(fftw_real) ((double)get_gchar128_nul( (int)(v*128.0) )-128.0) / 128.0;
					//fft_real[col*(h+2)+row]=(fftw_real) absexp( ((double)get_gchar32768( (int)(v*32768.0) )-32768.0) / 32768.0 * m);
					//printf ("%f %f %d ; ",fft_real[col*(h+2)+row] / norm, v, get_gchar128( (int)(v*128.0)));
				}
			 fft_real[col*(h+2)+h]=0;
 			 fft_real[col*(h+2)+h+1]=0;

			}
		
			p = rfftw2d_create_plan(w, h, FFTW_COMPLEX_TO_REAL, FFTW_ESTIMATE | FFTW_IN_PLACE);
			rfftwnd_one_complex_to_real(p, (struct fftw_complex *) fft_real, NULL);
			for(col=0;col<w;col++)
			{
				for(row=0;row<h;row++)
				{
					v = fft_real[col*(h+2)+row] / norm;
					img_pixels[(row*w+col)*img_bpp+cur_bpp] = get_guchar((int)( (double)v*256.0));
				}
			}

	}
	rfftwnd_destroy_plan(p);
	g_free(fft_real);

    // Flush
    
    gimp_pixel_rgn_set_rect(&region, img_pixels, sel_x1, sel_y1, (sel_x2-sel_x1), (sel_y2-sel_y1));
    g_free (img_pixels);
    
    gimp_drawable_flush(drawable);
    gimp_drawable_merge_shadow(drawable->id, TRUE);
    gimp_drawable_update (drawable->id, sel_x1, sel_y1, (sel_x2-sel_x1), (sel_y2-sel_y1));
    gimp_displays_flush();
  }
  
  values[0].type = GIMP_PDB_STATUS;
  values[0].data.d_status = status;
  gimp_drawable_detach(drawable);
}
